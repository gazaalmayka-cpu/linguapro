
/**
 * Netlify Function: AI Tutor (Gemini)
 * Set env GEMINI_API_KEY in Netlify site settings.
 */
const SYSTEM = `You are LinguaPro AI Tutor, a friendly English teacher for Indonesian university students.
Reply in a mix of clear English and short Indonesian explanations when helpful.
Be practical: give examples, correct gently, and keep answers focused.
If the student asks about IELTS/TOEFL, give structured tips.
Format with short paragraphs or bullet points. Avoid markdown tables.`;

exports.handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers, body: JSON.stringify({ error: "Method not allowed" }) };
  }

  const key = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || "";
  if (!key) {
    return {
      statusCode: 503,
      headers,
      body: JSON.stringify({
        error: "API_NOT_CONFIGURED",
        message: "GEMINI_API_KEY not configured"
      })
    };
  }

  let body = {};
  try {
    body = JSON.parse(event.body || "{}");
  } catch (e) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: "Invalid JSON" }) };
  }

  const message = (body.message || "").trim();
  if (!message) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: "Empty message" }) };
  }

  const history = Array.isArray(body.history) ? body.history.slice(-12) : [];
  const userName = body.userName || "student";
  const level = body.level || "a1";

  const contents = [];
  history.forEach((h) => {
    const role = h.role === "user" ? "user" : "model";
    const text = (h.text || "").replace(/<[^>]+>/g, " ").trim();
    if (text) contents.push({ role, parts: [{ text }] });
  });
  contents.push({
    role: "user",
    parts: [{
      text: `Student name: ${userName}. CEFR level: ${level}.\n\nQuestion:\n${message}`
    }]
  });

  const url =
    "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" +
    encodeURIComponent(key);

  try {
    const resp = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: SYSTEM }] },
        contents,
        generationConfig: { temperature: 0.7, maxOutputTokens: 1024 }
      })
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok) {
      return {
        statusCode: 502,
        headers,
        body: JSON.stringify({
          error: "GEMINI_ERROR",
          message: (data.error && data.error.message) || `Gemini HTTP ${resp.status}`
        })
      };
    }
    const reply =
      data.candidates &&
      data.candidates[0] &&
      data.candidates[0].content &&
      data.candidates[0].content.parts &&
      data.candidates[0].content.parts.map((p) => p.text || "").join("\n");

    if (!reply) {
      return {
        statusCode: 502,
        headers,
        body: JSON.stringify({ error: "EMPTY_REPLY", message: "No text from Gemini" })
      };
    }

    // light HTML-friendly newlines
    const html = reply
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/\n\n/g, "<br><br>")
      .replace(/\n/g, "<br>");

    return { statusCode: 200, headers, body: JSON.stringify({ reply: html }) };
  } catch (e) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: "SERVER_ERROR", message: e.message || "fetch failed" })
    };
  }
};
