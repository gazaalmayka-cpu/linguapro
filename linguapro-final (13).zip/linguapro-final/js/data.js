/* ========== DATA: Questions, Lessons, Mock Tests ========== */

const PLACEMENT_QUESTIONS = [
  {
    "id": 1,
    "type": "grammar",
    "question": "She _____ to the library every Saturday.",
    "options": [
      "go",
      "goes",
      "going",
      "gone"
    ],
    "correct": 1
  },
  {
    "id": 2,
    "type": "grammar",
    "question": "If I _____ rich, I would travel the world.",
    "options": [
      "am",
      "was",
      "were",
      "be"
    ],
    "correct": 2
  },
  {
    "id": 3,
    "type": "grammar",
    "question": "They have been friends _____ ten years.",
    "options": [
      "since",
      "for",
      "during",
      "from"
    ],
    "correct": 1
  },
  {
    "id": 4,
    "type": "grammar",
    "question": "I wish I _____ speak French fluently.",
    "options": [
      "can",
      "could",
      "will",
      "would"
    ],
    "correct": 1
  },
  {
    "id": 5,
    "type": "grammar",
    "question": "The book _____ by J.K. Rowling is very popular.",
    "options": [
      "write",
      "wrote",
      "written",
      "writing"
    ],
    "correct": 2
  },
  {
    "id": 6,
    "type": "grammar",
    "question": "Neither John nor his friends _____ coming to the party.",
    "options": [
      "is",
      "are",
      "was",
      "be"
    ],
    "correct": 1
  },
  {
    "id": 7,
    "type": "grammar",
    "question": "By the time we arrived, the movie _____.",
    "options": [
      "starts",
      "started",
      "had started",
      "has started"
    ],
    "correct": 2
  },
  {
    "id": 8,
    "type": "grammar",
    "question": "She suggested that he _____ the report carefully.",
    "options": [
      "reads",
      "read",
      "reading",
      "to read"
    ],
    "correct": 1
  },
  {
    "id": 9,
    "type": "grammar",
    "question": "Look! The children _____ in the garden right now.",
    "options": [
      "play",
      "plays",
      "are playing",
      "played"
    ],
    "correct": 2
  },
  {
    "id": 10,
    "type": "grammar",
    "question": "I _____ my keys. I can't find them anywhere.",
    "options": [
      "lose",
      "lost",
      "have lost",
      "am losing"
    ],
    "correct": 2
  },
  {
    "id": 11,
    "type": "grammar",
    "question": "This is the best coffee I _____ ever tasted.",
    "options": [
      "have",
      "had",
      "has",
      "having"
    ],
    "correct": 0
  },
  {
    "id": 12,
    "type": "grammar",
    "question": "You _____ wear a seatbelt. It's the law.",
    "options": [
      "can",
      "must",
      "might",
      "would"
    ],
    "correct": 1
  },
  {
    "id": 13,
    "type": "grammar",
    "question": "If it rains tomorrow, we _____ stay indoors.",
    "options": [
      "will",
      "would",
      "might",
      "should"
    ],
    "correct": 0
  },
  {
    "id": 14,
    "type": "grammar",
    "question": "The letter was _____ by the postman this morning.",
    "options": [
      "deliver",
      "delivered",
      "delivering",
      "delivers"
    ],
    "correct": 1
  },
  {
    "id": 15,
    "type": "grammar",
    "question": "She is taller _____ her brother.",
    "options": [
      "as",
      "than",
      "from",
      "of"
    ],
    "correct": 1
  },
  {
    "id": 16,
    "type": "grammar",
    "question": "I have lived here _____ 2018.",
    "options": [
      "for",
      "since",
      "from",
      "during"
    ],
    "correct": 1
  },
  {
    "id": 17,
    "type": "grammar",
    "question": "There _____ many students in the classroom.",
    "options": [
      "is",
      "are",
      "was",
      "be"
    ],
    "correct": 1
  },
  {
    "id": 18,
    "type": "grammar",
    "question": "He asked me where I _____.",
    "options": [
      "live",
      "lived",
      "living",
      "lives"
    ],
    "correct": 1
  },
  {
    "id": 19,
    "type": "grammar",
    "question": "We _____ to the beach if the weather is good.",
    "options": [
      "go",
      "will go",
      "would go",
      "went"
    ],
    "correct": 1
  },
  {
    "id": 20,
    "type": "grammar",
    "question": "The film was so boring that I _____ asleep.",
    "options": [
      "fall",
      "fell",
      "have fallen",
      "falling"
    ],
    "correct": 1
  },
  {
    "id": 21,
    "type": "grammar",
    "question": "_____ you ever been to Japan?",
    "options": [
      "Do",
      "Did",
      "Have",
      "Are"
    ],
    "correct": 2
  },
  {
    "id": 22,
    "type": "grammar",
    "question": "She speaks English _____ than I do.",
    "options": [
      "fluent",
      "more fluent",
      "more fluently",
      "fluently"
    ],
    "correct": 2
  },
  {
    "id": 23,
    "type": "grammar",
    "question": "I prefer tea _____ coffee.",
    "options": [
      "than",
      "to",
      "from",
      "over"
    ],
    "correct": 1
  },
  {
    "id": 24,
    "type": "grammar",
    "question": "The teacher made us _____ the exercise again.",
    "options": [
      "to do",
      "do",
      "doing",
      "did"
    ],
    "correct": 1
  },
  {
    "id": 25,
    "type": "grammar",
    "question": "By next year, I _____ graduated from university.",
    "options": [
      "will",
      "will have",
      "have",
      "had"
    ],
    "correct": 1
  },
  {
    "id": 26,
    "type": "vocab",
    "question": "What is the synonym of 'happy'?",
    "options": [
      "sad",
      "joyful",
      "angry",
      "tired"
    ],
    "correct": 1
  },
  {
    "id": 27,
    "type": "vocab",
    "question": "The opposite of 'increase' is:",
    "options": [
      "rise",
      "grow",
      "decrease",
      "expand"
    ],
    "correct": 2
  },
  {
    "id": 28,
    "type": "vocab",
    "question": "'Ubiquitous' most nearly means:",
    "options": [
      "rare",
      "everywhere",
      "expensive",
      "dangerous"
    ],
    "correct": 1
  },
  {
    "id": 29,
    "type": "vocab",
    "question": "To 'mitigate' means to:",
    "options": [
      "make worse",
      "make less severe",
      "ignore",
      "celebrate"
    ],
    "correct": 1
  },
  {
    "id": 30,
    "type": "vocab",
    "question": "A synonym of 'begin' is:",
    "options": [
      "end",
      "start",
      "finish",
      "stop"
    ],
    "correct": 1
  },
  {
    "id": 31,
    "type": "vocab",
    "question": "'Reluctant' means:",
    "options": [
      "eager",
      "unwilling",
      "happy",
      "confused"
    ],
    "correct": 1
  },
  {
    "id": 32,
    "type": "vocab",
    "question": "The word 'enormous' means:",
    "options": [
      "tiny",
      "average",
      "very large",
      "narrow"
    ],
    "correct": 2
  },
  {
    "id": 33,
    "type": "vocab",
    "question": "'Accurate' is closest in meaning to:",
    "options": [
      "wrong",
      "precise",
      "slow",
      "cheap"
    ],
    "correct": 1
  },
  {
    "id": 34,
    "type": "vocab",
    "question": "To 'postpone' means to:",
    "options": [
      "cancel",
      "delay",
      "start early",
      "finish"
    ],
    "correct": 1
  },
  {
    "id": 35,
    "type": "vocab",
    "question": "'Benefit' means:",
    "options": [
      "problem",
      "advantage",
      "mistake",
      "cost"
    ],
    "correct": 1
  },
  {
    "id": 36,
    "type": "vocab",
    "question": "A synonym of 'difficult' is:",
    "options": [
      "easy",
      "hard",
      "simple",
      "clear"
    ],
    "correct": 1
  },
  {
    "id": 37,
    "type": "vocab",
    "question": "'Essential' means:",
    "options": [
      "optional",
      "necessary",
      "rare",
      "funny"
    ],
    "correct": 1
  },
  {
    "id": 38,
    "type": "vocab",
    "question": "The opposite of 'ancient' is:",
    "options": [
      "old",
      "modern",
      "historic",
      "traditional"
    ],
    "correct": 1
  },
  {
    "id": 39,
    "type": "vocab",
    "question": "'Accomplish' means to:",
    "options": [
      "fail",
      "achieve",
      "avoid",
      "delay"
    ],
    "correct": 1
  },
  {
    "id": 40,
    "type": "vocab",
    "question": "'Vague' means:",
    "options": [
      "clear",
      "unclear",
      "loud",
      "bright"
    ],
    "correct": 1
  },
  {
    "id": 41,
    "type": "reading",
    "question": "According to the passage, climate change is:",
    "options": [
      "not important",
      "a pressing issue",
      "only about ice",
      "a local problem"
    ],
    "correct": 1,
    "passage": "Climate change is one of the most pressing issues of our time. Rising temperatures, melting ice caps, and extreme weather events are affecting communities worldwide."
  },
  {
    "id": 42,
    "type": "reading",
    "question": "What can help students improve productivity?",
    "options": [
      "sleeping more",
      "creating a schedule",
      "avoiding tasks",
      "watching TV"
    ],
    "correct": 1,
    "passage": "Many students struggle with time management. Creating a daily schedule and prioritizing tasks can significantly improve productivity and reduce stress."
  },
  {
    "id": 43,
    "type": "reading",
    "question": "What are the challenges mentioned regarding AI?",
    "options": [
      "cost and speed",
      "privacy and job displacement",
      "only privacy",
      "only benefits"
    ],
    "correct": 1,
    "passage": "Artificial intelligence is transforming industries from healthcare to finance. While it offers tremendous benefits, ethical concerns about privacy and job displacement remain significant challenges."
  },
  {
    "id": 44,
    "type": "reading",
    "question": "According to the passage, regular reading can improve:",
    "options": [
      "only vocabulary",
      "vocabulary, concentration, and critical thinking",
      "only concentration",
      "physical strength"
    ],
    "correct": 1,
    "passage": "Reading regularly improves vocabulary, concentration, and critical thinking. Even 20 minutes a day can lead to noticeable progress over several months."
  },
  {
    "id": 45,
    "type": "reading",
    "question": "What is one benefit of public transportation?",
    "options": [
      "more traffic",
      "less pollution",
      "higher costs",
      "longer travel times"
    ],
    "correct": 1,
    "passage": "Public transportation reduces traffic congestion and air pollution in cities. Governments often encourage citizens to use buses and trains instead of private cars."
  },
  {
    "id": 46,
    "type": "reading",
    "question": "The passage suggests that a balanced diet should include:",
    "options": [
      "only fruits",
      "fruits, vegetables, proteins, and whole grains",
      "only processed food",
      "sugar and salt only"
    ],
    "correct": 1,
    "passage": "A balanced diet includes fruits, vegetables, proteins, and whole grains. Skipping meals or eating too much processed food can harm long-term health."
  },
  {
    "id": 47,
    "type": "reading",
    "question": "One disadvantage of online learning mentioned is:",
    "options": [
      "too much flexibility",
      "lack of face-to-face interaction",
      "high cost",
      "too many teachers"
    ],
    "correct": 1,
    "passage": "Online learning became popular during the pandemic. It offers flexibility, but some students miss face-to-face interaction with teachers and classmates."
  },
  {
    "id": 48,
    "type": "reading",
    "question": "How many hours of sleep do adults usually need?",
    "options": [
      "3–4 hours",
      "5–6 hours",
      "7–9 hours",
      "10–12 hours"
    ],
    "correct": 2,
    "passage": "Sleep is essential for memory and concentration. Adults usually need 7–9 hours of sleep each night to function at their best."
  },
  {
    "id": 49,
    "type": "reading",
    "question": "What is one purpose of recycling?",
    "options": [
      "increase landfill waste",
      "conserve natural resources",
      "use more plastic",
      "avoid separating materials"
    ],
    "correct": 1,
    "passage": "Recycling helps conserve natural resources and reduces landfill waste. Simple actions like separating plastic, paper, and glass can make a big difference."
  },
  {
    "id": 50,
    "type": "reading",
    "question": "According to the passage, exercise can:",
    "options": [
      "only improve physical strength",
      "improve mood and reduce stress",
      "increase stress",
      "replace sleep"
    ],
    "correct": 1,
    "passage": "Exercise releases endorphins that improve mood and reduce stress. Even a short daily walk can benefit both physical and mental health."
  },
  {
    "id": 51,
    "type": "grammar",
    "question": "Choose the correct form: She _____ to campus every day.",
    "options": [
      "go",
      "goes",
      "going",
      "gone"
    ],
    "correct": 1
  },
  {
    "id": 52,
    "type": "grammar",
    "question": "Which is a correct past simple sentence?",
    "options": [
      "He go yesterday.",
      "He went yesterday.",
      "He gone yesterday.",
      "He going yesterday."
    ],
    "correct": 1
  },
  {
    "id": 53,
    "type": "grammar",
    "question": "Select the present continuous sentence.",
    "options": [
      "I read books.",
      "I am reading a book.",
      "I reads a book.",
      "I readed a book."
    ],
    "correct": 1
  },
  {
    "id": 54,
    "type": "grammar",
    "question": "If it rains tomorrow, we _____ the match.",
    "options": [
      "cancel",
      "will cancel",
      "would cancel",
      "cancelled"
    ],
    "correct": 1
  },
  {
    "id": 55,
    "type": "grammar",
    "question": "Which sentence uses present perfect correctly?",
    "options": [
      "I have seen that movie.",
      "I have see that movie.",
      "I has seen that movie.",
      "I seen that movie."
    ],
    "correct": 0
  },
  {
    "id": 56,
    "type": "grammar",
    "question": "Choose the passive form: They built the bridge in 2010.",
    "options": [
      "The bridge built in 2010.",
      "The bridge was built in 2010.",
      "The bridge is build in 2010.",
      "The bridge was build in 2010."
    ],
    "correct": 1
  },
  {
    "id": 57,
    "type": "grammar",
    "question": "Which is a second conditional sentence?",
    "options": [
      "If I study, I will pass.",
      "If I studied, I would pass.",
      "If I had studied, I passed.",
      "If I study, I passed."
    ],
    "correct": 1
  },
  {
    "id": 58,
    "type": "grammar",
    "question": "Choose the correct article: She is _____ honest person.",
    "options": [
      "a",
      "an",
      "the",
      "— (no article)"
    ],
    "correct": 1
  },
  {
    "id": 59,
    "type": "grammar",
    "question": "Which quantifier fits? There isn't _____ milk left.",
    "options": [
      "many",
      "much",
      "few",
      "a few"
    ],
    "correct": 1
  },
  {
    "id": 60,
    "type": "grammar",
    "question": "Select the correct comparative.",
    "options": [
      "This test is more easier.",
      "This test is easier.",
      "This test is easyer.",
      "This test is most easy."
    ],
    "correct": 1
  },
  {
    "id": 61,
    "type": "grammar",
    "question": "Reported speech: She said, \"I am tired.\" →",
    "options": [
      "She said she is tired.",
      "She said she was tired.",
      "She said she were tired.",
      "She said I am tired."
    ],
    "correct": 1
  },
  {
    "id": 62,
    "type": "grammar",
    "question": "Modal of advice:",
    "options": [
      "You must to rest.",
      "You should rest.",
      "You should to rest.",
      "You may resting."
    ],
    "correct": 1
  },
  {
    "id": 63,
    "type": "grammar",
    "question": "Relative clause: The student _____ won the prize is my friend.",
    "options": [
      "which",
      "who",
      "where",
      "whose"
    ],
    "correct": 1
  },
  {
    "id": 64,
    "type": "grammar",
    "question": "Choose correct preposition: The meeting is _____ Monday morning.",
    "options": [
      "in",
      "on",
      "at",
      "by"
    ],
    "correct": 1
  },
  {
    "id": 65,
    "type": "grammar",
    "question": "Which uses 'used to' correctly?",
    "options": [
      "I used to living here.",
      "I used to live here.",
      "I use to live here.",
      "I used live here."
    ],
    "correct": 1
  },
  {
    "id": 66,
    "type": "vocab",
    "question": "What does 'deadline' mean?",
    "options": [
      "A soft pillow",
      "The latest time to finish something",
      "A type of exam",
      "A classroom"
    ],
    "correct": 1
  },
  {
    "id": 67,
    "type": "vocab",
    "question": "'Improve' is closest in meaning to:",
    "options": [
      "get worse",
      "get better",
      "stay the same",
      "ignore"
    ],
    "correct": 1
  },
  {
    "id": 68,
    "type": "vocab",
    "question": "A synonym of 'important' is:",
    "options": [
      "trivial",
      "significant",
      "optional",
      "random"
    ],
    "correct": 1
  },
  {
    "id": 69,
    "type": "vocab",
    "question": "What is a 'lecture'?",
    "options": [
      "A sports match",
      "An academic talk/class",
      "A cafeteria meal",
      "A dorm room"
    ],
    "correct": 1
  },
  {
    "id": 70,
    "type": "vocab",
    "question": "'Submit an assignment' means:",
    "options": [
      "delete it",
      "hand it in",
      "ignore it",
      "copy it"
    ],
    "correct": 1
  },
  {
    "id": 71,
    "type": "vocab",
    "question": "Choose the best word: She needs to _____ for the exam.",
    "options": [
      "revise",
      "revision",
      "revising",
      "revised"
    ],
    "correct": 0
  },
  {
    "id": 72,
    "type": "vocab",
    "question": "'Reliable' describes someone who is:",
    "options": [
      "always late",
      "dependable",
      "confused",
      "silent"
    ],
    "correct": 1
  },
  {
    "id": 73,
    "type": "vocab",
    "question": "What does 'tuition' usually refer to?",
    "options": [
      "bus fare",
      "course fees",
      "lunch money",
      "library fines"
    ],
    "correct": 1
  },
  {
    "id": 74,
    "type": "vocab",
    "question": "'Although' is used to show:",
    "options": [
      "addition",
      "contrast",
      "time only",
      "place"
    ],
    "correct": 1
  },
  {
    "id": 75,
    "type": "vocab",
    "question": "A 'peer' in university often means:",
    "options": [
      "a professor only",
      "a person of similar age/status (classmate)",
      "a building",
      "a textbook"
    ],
    "correct": 1
  },
  {
    "id": 76,
    "type": "vocab",
    "question": "Choose the correct collocation:",
    "options": [
      "do a decision",
      "make a decision",
      "make a deciding",
      "do deciding"
    ],
    "correct": 1
  },
  {
    "id": 77,
    "type": "vocab",
    "question": "'Evidence' is closest to:",
    "options": [
      "opinion only",
      "proof / supporting facts",
      "a joke",
      "a schedule"
    ],
    "correct": 1
  },
  {
    "id": 78,
    "type": "vocab",
    "question": "What does 'postpone' mean?",
    "options": [
      "do earlier",
      "delay to a later time",
      "cancel forever",
      "repeat"
    ],
    "correct": 1
  },
  {
    "id": 79,
    "type": "vocab",
    "question": "'Abroad' means:",
    "options": [
      "at home",
      "in another country",
      "online only",
      "in the library"
    ],
    "correct": 1
  },
  {
    "id": 80,
    "type": "vocab",
    "question": "Choose the odd one out (not a study activity):",
    "options": [
      "revise",
      "summarize",
      "procrastinate",
      "outline"
    ],
    "correct": 2
  },
  {
    "id": 81,
    "type": "reading",
    "question": "Many students prefer online classes because they save travel time. However, some miss face-to-face discussion.\\n\\nMain idea?",
    "options": [
      "Travel is impossible",
      "Online classes have benefits and drawbacks",
      "Discussion is banned",
      "Students never study"
    ],
    "correct": 1
  },
  {
    "id": 82,
    "type": "reading",
    "question": "The library will close at 9 PM during the week and at 5 PM on weekends.\\n\\nWeekend closing time is:",
    "options": [
      "9 PM",
      "5 PM",
      "24 hours",
      "Not stated"
    ],
    "correct": 1
  },
  {
    "id": 83,
    "type": "reading",
    "question": "Although the course is demanding, most students say it is rewarding.\\n\\nThe course is described as:",
    "options": [
      "easy and boring",
      "hard but rewarding",
      "free",
      "cancelled"
    ],
    "correct": 1
  },
  {
    "id": 84,
    "type": "reading",
    "question": "Research shows that short study sessions over several days beat one long cramming night.\\n\\nThe author recommends:",
    "options": [
      "Only all-nighters",
      "Spaced study sessions",
      "No studying",
      "Skipping sleep always"
    ],
    "correct": 1
  },
  {
    "id": 85,
    "type": "reading",
    "question": "Campus buses run every 15 minutes from 7 AM to 7 PM.\\n\\nHow often do buses run?",
    "options": [
      "Every hour",
      "Every 15 minutes",
      "Once a day",
      "Only at night"
    ],
    "correct": 1
  },
  {
    "id": 86,
    "type": "reading",
    "question": "The professor extended the deadline by three days after students requested more time.\\n\\nWhat happened?",
    "options": [
      "The deadline was earlier",
      "The deadline was moved later",
      "The class was cancelled",
      "No change"
    ],
    "correct": 1
  },
  {
    "id": 87,
    "type": "reading",
    "question": "Unlike last year, this year's orientation will be fully online.\\n\\nThis year orientation is:",
    "options": [
      "the same as last year",
      "fully online",
      "cancelled",
      "only for staff"
    ],
    "correct": 1
  },
  {
    "id": 88,
    "type": "reading",
    "question": "Applicants must upload a transcript and a recommendation letter before Friday.\\n\\nWhat is required?",
    "options": [
      "Only a photo",
      "Transcript and recommendation letter",
      "Nothing",
      "A passport only"
    ],
    "correct": 1
  },
  {
    "id": 89,
    "type": "reading",
    "question": "Despite limited funding, the student club still organized a successful language festival.\\n\\nWhat is true?",
    "options": [
      "Funding was huge",
      "The festival failed",
      "The festival succeeded with limited funding",
      "There was no club"
    ],
    "correct": 2
  },
  {
    "id": 90,
    "type": "reading",
    "question": "The announcement says quiet hours begin at 11 PM on weekdays.\\n\\nQuiet hours start at:",
    "options": [
      "9 PM",
      "10 PM",
      "11 PM",
      "Midnight only on weekdays stated as 11"
    ],
    "correct": 2
  }
];

const GRAMMAR_LESSONS = {
  beginner: [
    {
      id: "b1",
      title: "Present Simple Tense",
      explanation: "Present Simple digunakan untuk kebiasaan, fakta umum, dan rutinitas. Bentuk dasar: Subject + V1 (s/es untuk he/she/it).",
      examples: [
        { en: "I study English every day.", id: "Saya belajar bahasa Inggris setiap hari." },
        { en: "She works at a hospital.", id: "Dia bekerja di rumah sakit." },
        { en: "Water boils at 100°C.", id: "Air mendidih pada 100°C." }
      ],
      quiz: [
        { q: "He _____ coffee every morning.", opts: ["drink", "drinks", "drinking"], ans: 1 },
        { q: "They _____ to school by bus.", opts: ["goes", "go", "going"], ans: 1 }
      ]
    },
    {
      id: "b2",
      title: "Present Continuous",
      explanation: "Present Continuous (am/is/are + V-ing) untuk kegiatan yang sedang berlangsung saat ini atau sementara.",
      examples: [
        { en: "I am studying right now.", id: "Saya sedang belajar sekarang." },
        { en: "They are playing football.", id: "Mereka sedang bermain sepak bola." }
      ],
      quiz: [
        { q: "Look! It _____.", opts: ["rains", "is raining", "rain"], ans: 1 },
        { q: "She _____ a book at the moment.", opts: ["reads", "is reading", "read"], ans: 1 }
      ]
    },
    {
      id: "b3",
      title: "Articles (a/an/the)",
      explanation: "A/An untuk benda singular yang belum spesifik. The untuk benda yang sudah spesifik atau unik.",
      examples: [
        { en: "I saw a cat. The cat was black.", id: "Saya melihat seekor kucing. Kucing itu hitam." },
        { en: "The sun rises in the east.", id: "Matahari terbit di timur." }
      ],
      quiz: [
        { q: "I need _____ umbrella.", opts: ["a", "an", "the"], ans: 1 },
        { q: "_____ moon looks beautiful tonight.", opts: ["A", "An", "The"], ans: 2 }
      ]
    },
    {
      id: "b4",
      title: "Past Simple",
      explanation: "Past Simple untuk kejadian yang sudah selesai di masa lalu. Regular: V+ed. Irregular: bentuk khusus (go→went).",
      examples: [
        { en: "I visited Bali last year.", id: "Saya mengunjungi Bali tahun lalu." },
        { en: "She went to the market yesterday.", id: "Dia pergi ke pasar kemarin." }
      ],
      quiz: [
        { q: "They _____ a movie last night.", opts: ["watch", "watched", "watching"], ans: 1 },
        { q: "He _____ home early.", opts: ["go", "goes", "went"], ans: 2 }
      ]
    },
    {
      id: "b5",
      title: "Prepositions of Place",
      explanation: "In (di dalam), On (di atas permukaan), At (di titik spesifik).",
      examples: [
        { en: "The book is on the table.", id: "Buku itu di atas meja." },
        { en: "She lives in Jakarta.", id: "Dia tinggal di Jakarta." },
        { en: "Meet me at the station.", id: "Temui saya di stasiun." }
      ],
      quiz: [
        { q: "The keys are _____ the drawer.", opts: ["on", "in", "at"], ans: 1 },
        { q: "I am _____ home now.", opts: ["in", "on", "at"], ans: 2 }
      ]
    }
  ],
  intermediate: [
    {
      id: "i1",
      title: "Present Perfect",
      explanation: "Have/Has + V3. Digunakan untuk pengalaman, kejadian yang baru selesai, atau yang masih relevan sekarang.",
      examples: [
        { en: "I have visited Japan twice.", id: "Saya sudah mengunjungi Jepang dua kali." },
        { en: "She has just finished her homework.", id: "Dia baru saja menyelesaikan PR-nya." }
      ],
      quiz: [
        { q: "They _____ never _____ sushi.", opts: ["have / eaten", "has / eaten", "have / ate"], ans: 0 },
        { q: "He _____ to Paris.", opts: ["has been", "have been", "was been"], ans: 0 }
      ]
    },
    {
      id: "i2",
      title: "Conditionals (Type 1 & 2)",
      explanation: "Type 1: If + present, will + V1 (real possibility). Type 2: If + past, would + V1 (unreal/hypothetical).",
      examples: [
        { en: "If it rains, I will stay home.", id: "Jika hujan, saya akan tinggal di rumah." },
        { en: "If I were you, I would study harder.", id: "Jika saya jadi kamu, saya akan belajar lebih giat." }
      ],
      quiz: [
        { q: "If she studies, she _____ pass.", opts: ["will", "would", "would have"], ans: 0 },
        { q: "If I _____ a bird, I would fly.", opts: ["am", "was", "were"], ans: 2 }
      ]
    },
    {
      id: "i3",
      title: "Passive Voice",
      explanation: "Object menjadi subject. Be + V3. Digunakan saat pelaku tidak penting atau tidak diketahui.",
      examples: [
        { en: "The letter was written by John.", id: "Surat itu ditulis oleh John." },
        { en: "English is spoken worldwide.", id: "Bahasa Inggris digunakan di seluruh dunia." }
      ],
      quiz: [
        { q: "The cake _____ by my mother.", opts: ["made", "was made", "is make"], ans: 1 },
        { q: "This book _____ in 2020.", opts: ["published", "was published", "publishing"], ans: 1 }
      ]
    },
    {
      id: "i4",
      title: "Relative Clauses",
      explanation: "Who (orang), Which (benda), That (orang/benda), Where (tempat). Memberikan info tambahan tentang noun.",
      examples: [
        { en: "The student who won the prize is my friend.", id: "Mahasiswa yang memenangkan hadiah adalah temanku." },
        { en: "This is the book which I recommended.", id: "Ini adalah buku yang saya rekomendasikan." }
      ],
      quiz: [
        { q: "The man _____ lives next door is a doctor.", opts: ["which", "who", "where"], ans: 1 },
        { q: "I like the movie _____ we watched.", opts: ["who", "where", "that"], ans: 2 }
      ]
    },
    {
      id: "i5",
      title: "Modals (can, could, should, must)",
      explanation: "Can (kemampuan/izin), Could (kemampuan lampau/permintaan sopan), Should (saran), Must (keharusan kuat).",
      examples: [
        { en: "You should see a doctor.", id: "Kamu sebaiknya ke dokter." },
        { en: "Students must submit the assignment.", id: "Mahasiswa harus mengumpulkan tugas." }
      ],
      quiz: [
        { q: "You _____ smoke here. It's prohibited.", opts: ["should", "must not", "can"], ans: 1 },
        { q: "_____ you help me, please?", opts: ["Should", "Must", "Could"], ans: 2 }
      ]
    }
  ],
  advanced: [
    {
      id: "a1",
      title: "Conditionals Type 3 & Mixed",
      explanation: "Type 3: If + past perfect, would have + V3 (past unreal). Mixed: kombinasi type 2 & 3.",
      examples: [
        { en: "If I had studied, I would have passed.", id: "Jika saya belajar, saya pasti lulus." },
        { en: "If I had taken that job, I would be rich now.", id: "Jika saya mengambil pekerjaan itu, saya kaya sekarang." }
      ],
      quiz: [
        { q: "If she _____ harder, she would have won.", opts: ["practiced", "had practiced", "practices"], ans: 1 },
        { q: "If I _____ you, I would have called.", opts: ["knew", "had known", "know"], ans: 1 }
      ]
    },
    {
      id: "a2",
      title: "Reported Speech",
      explanation: "Mengubah direct speech ke indirect. Tenses mundur satu tingkat. Say/tell + that clause.",
      examples: [
        { en: "He said, 'I am tired.' → He said that he was tired.", id: "Dia bilang dia lelah." },
        { en: "She told me, 'I will come.' → She told me that she would come.", id: "Dia bilang akan datang." }
      ],
      quiz: [
        { q: "He said, 'I live in Bali.' → He said he _____ in Bali.", opts: ["lives", "lived", "live"], ans: 1 },
        { q: "She said, 'I can swim.' → She said she _____ swim.", opts: ["can", "could", "will"], ans: 1 }
      ]
    },
    {
      id: "a3",
      title: "Inversion & Emphasis",
      explanation: "Rarely, Never, Not only, Hardly + auxiliary + subject untuk penekanan formal.",
      examples: [
        { en: "Never have I seen such beauty.", id: "Belum pernah saya melihat keindahan seperti itu." },
        { en: "Not only did she pass, but she also got the highest score.", id: "Tidak hanya lulus, dia juga dapat nilai tertinggi." }
      ],
      quiz: [
        { q: "Rarely _____ such a talented musician.", opts: ["we see", "do we see", "we do see"], ans: 1 },
        { q: "Not only _____ late, but he also forgot the documents.", opts: ["he was", "was he", "he is"], ans: 1 }
      ]
    },
    {
      id: "a4",
      title: "Subjunctive Mood",
      explanation: "Digunakan setelah suggest, recommend, insist, demand + that + base form (tanpa -s).",
      examples: [
        { en: "I suggest that he study harder.", id: "Saya sarankan dia belajar lebih giat." },
        { en: "It is essential that she be present.", id: "Sangat penting bahwa dia hadir." }
      ],
      quiz: [
        { q: "The teacher recommended that she _____ the exam.", opts: ["takes", "take", "took"], ans: 1 },
        { q: "It is crucial that every student _____ on time.", opts: ["arrives", "arrive", "arrived"], ans: 1 }
      ]
    }
  ],
  pro: [
    {
      id: "p1",
      title: "Cleft Sentences & Fronting",
      explanation: "It is/was ... that/who untuk fokus. What-clause untuk emphasis. Fronting object/adverbial.",
      examples: [
        { en: "It was John who broke the vase.", id: "John-lah yang memecahkan vas itu." },
        { en: "What I need is a quiet place to study.", id: "Yang saya butuhkan adalah tempat tenang untuk belajar." }
      ],
      quiz: [
        { q: "_____ was the manager who approved the plan.", opts: ["It", "There", "What"], ans: 0 },
        { q: "_____ I really want is success.", opts: ["It", "What", "That"], ans: 1 }
      ]
    },
    {
      id: "p2",
      title: "Advanced Nominalization",
      explanation: "Mengubah verb/adjective menjadi noun untuk gaya akademik yang lebih formal dan padat.",
      examples: [
        { en: "The implementation of the policy led to improvement.", id: "Implementasi kebijakan tersebut menyebabkan peningkatan." },
        { en: "His refusal to cooperate was unexpected.", id: "Penolakannya untuk bekerja sama tidak terduga." }
      ],
      quiz: [
        { q: "The _____ of the project was delayed. (complete)", opts: ["complete", "completion", "completing"], ans: 1 },
        { q: "Her _____ of the theory was brilliant. (analyze)", opts: ["analysis", "analyze", "analyzing"], ans: 0 }
      ]
    },
    {
      id: "p3",
      title: "Discourse Markers & Cohesion",
      explanation: "Furthermore, Nevertheless, Consequently, In contrast, Conversely — untuk academic writing yang kohesif.",
      examples: [
        { en: "The results were inconclusive. Nevertheless, the study provides valuable insights.", id: "Hasilnya tidak konklusif. Namun demikian, studi ini memberikan insight berharga." },
        { en: "Demand increased. Consequently, prices rose.", id: "Permintaan naik. Akibatnya, harga naik." }
      ],
      quiz: [
        { q: "Sales fell. _____, the company remained profitable.", opts: ["Consequently", "Nevertheless", "Furthermore"], ans: 1 },
        { q: "The data supports the hypothesis. _____, further research is needed.", opts: ["However", "Therefore", "Moreover"], ans: 0 }
      ]
    }
  ]
};

const READING_PASSAGES = [
  {
    title: "The Benefits of Reading",
    text: "Reading is one of the most effective ways to expand knowledge and improve cognitive abilities. Studies have shown that regular reading can enhance vocabulary, improve concentration, and even reduce stress levels. For university students, reading academic journals and literature is essential for developing critical thinking skills. Moreover, fiction reading can increase empathy by allowing readers to experience different perspectives and cultures. In an age dominated by short-form digital content, the ability to engage with longer texts remains a valuable skill for academic and professional success.",
    questions: [
      { q: "What is one benefit of regular reading mentioned in the passage?", opts: ["It decreases vocabulary", "It can reduce stress", "It makes people lazy", "It reduces empathy"], ans: 1 },
      { q: "Why is reading important for university students?", opts: ["To pass time", "To develop critical thinking", "To avoid studying", "Only for fiction"], ans: 1 },
      { q: "What does the passage say about fiction reading?", opts: ["It is useless", "It can increase empathy", "It is only for children", "It decreases concentration"], ans: 1 }
    ]
  },
  {
    title: "Remote Work Revolution",
    text: "The COVID-19 pandemic accelerated the adoption of remote work across industries. What was once considered a rare privilege has become a standard option for many knowledge workers. Companies have reported mixed results: some note increased productivity and employee satisfaction, while others struggle with collaboration and company culture. Hybrid models, combining office and remote days, have emerged as a popular compromise. Experts predict that flexible work arrangements will continue to evolve, requiring new management strategies and digital tools to maintain team cohesion and innovation.",
    questions: [
      { q: "What accelerated remote work adoption?", opts: ["New technology only", "The COVID-19 pandemic", "Government policy", "Employee demands alone"], ans: 1 },
      { q: "What is a hybrid model?", opts: ["Fully remote", "Fully office-based", "Combining office and remote days", "Working only weekends"], ans: 2 },
      { q: "What do experts predict about flexible work?", opts: ["It will disappear", "It will continue to evolve", "It is temporary", "Only for tech companies"], ans: 1 }
    ]
  },
  {
    title: "Sustainable Fashion",
    text: "The fashion industry is under growing pressure to become more sustainable. Fast fashion has made clothing cheap and trendy, but it also generates enormous waste and pollution. Brands are experimenting with recycled materials, rental services, and repair programs. Consumers, especially younger generations, increasingly ask how and where clothes are made. However, true sustainability requires changes across the supply chain, from cotton farming to shipping. Without transparent reporting, green marketing claims remain difficult to verify.",
    questions: [
      { q: "A major problem with fast fashion is:", opts: ["It is always expensive", "Waste and pollution", "It only uses silk", "It has no trends"], ans: 1 },
      { q: "What are brands experimenting with?", opts: ["Only higher prices", "Recycled materials and rental services", "Banning cotton", "Shorter store hours"], ans: 1 },
      { q: "Why is transparent reporting important?", opts: ["To verify green claims", "To increase advertising", "To reduce reading time", "To remove labels"], ans: 0 }
    ]
  },
  {
    title: "Urban Green Spaces",
    text: "Parks and green corridors in cities do more than decorate neighborhoods. Research links access to greenery with lower stress, better air quality, and increased physical activity. For students living in dense urban areas, campus gardens and public parks can support mental health during exam periods. City planners now treat green infrastructure as essential, not optional. Still, unequal distribution of parks means some communities benefit far less than others, raising questions of environmental justice.",
    questions: [
      { q: "Green spaces are linked to:", opts: ["Higher stress only", "Lower stress and better air quality", "Less physical activity", "No social effects"], ans: 1 },
      { q: "Why might parks help students?", opts: ["They replace libraries", "They can support mental health", "They ban studying", "They increase noise only"], ans: 1 },
      { q: "Unequal park distribution raises issues of:", opts: ["Fashion trends", "Environmental justice", "Sports scores", "Tax forms"], ans: 1 }
    ]
  },
  {
    title: "The Attention Economy",
    text: "Digital platforms compete fiercely for user attention. Notifications, infinite scroll, and personalized feeds are designed to maximize time spent on apps. While this business model can make services free, it may fragment concentration and reduce deep work capacity. Universities report that students struggle to sustain focus on long readings. Some educators now teach attention management as an academic skill, encouraging scheduled offline blocks and deliberate practice with demanding texts.",
    questions: [
      { q: "Platforms maximize:", opts: ["Battery life only", "Time spent on apps", "Book sales", "Sleep hours"], ans: 1 },
      { q: "A reported academic effect is:", opts: ["Easier long readings", "Difficulty sustaining focus", "No change in study habits", "Automatic essay writing"], ans: 1 },
      { q: "Attention management may include:", opts: ["More notifications", "Scheduled offline blocks", "Removing all books", "Shorter sleep"], ans: 1 }
    ]
  },
  {
    title: "Public Transport and Equity",
    text: "Reliable public transportation shapes access to education and employment. When bus and rail networks are limited, low-income students may face longer commutes and higher fatigue, affecting attendance and performance. Investment in frequent, affordable services can narrow opportunity gaps. Conversely, fare increases without subsidies risk excluding the very riders who depend on transit most. Policy debates therefore combine engineering, budgeting, and social equity concerns.",
    questions: [
      { q: "Limited transit can affect students by:", opts: ["Shorter commutes", "Longer commutes and fatigue", "Free housing", "Automatic scholarships"], ans: 1 },
      { q: "Fare increases without support may:", opts: ["Help all riders equally", "Exclude dependent riders", "Improve equity automatically", "Remove buses"], ans: 1 },
      { q: "Transit policy involves:", opts: ["Only fashion design", "Engineering, budgets, and equity", "Sports only", "Cuisine only"], ans: 1 }
    ]
  },
  {
    title: "Sleep and Academic Performance",
    text: "Sleep is not a luxury for learners; it is a biological requirement for memory consolidation. Laboratory and classroom studies show that students who sleep after studying often outperform those who stay awake to cram. Chronic restriction of sleep impairs attention, mood, and decision-making. Despite this evidence, many campus cultures still celebrate all-nighters. Shifting norms toward healthier schedules may improve both wellbeing and grades.",
    questions: [
      { q: "Sleep supports:", opts: ["Only muscle growth", "Memory consolidation", "Avoiding all classes", "Deleting notes"], ans: 1 },
      { q: "All-nighters are described as:", opts: ["Always optimal", "Still celebrated despite drawbacks", "Required by all universities", "Proven best method"], ans: 1 },
      { q: "Chronic sleep restriction impairs:", opts: ["Nothing important", "Attention and mood", "Only handwriting", "Only sports"], ans: 1 }
    ]
  },
  {
    title: "Peer Feedback in Writing Classes",
    text: "Structured peer review can improve drafting skills when students are trained to comment on clarity, organization, and evidence rather than only grammar. Effective protocols include rubrics, anonymous exchange, and teacher modeling of useful comments. Without guidance, peer feedback may stay superficial or overly polite. When done well, it develops both writing and critical reading, because reviewing others' work trains evaluation skills transferable to self-editing.",
    questions: [
      { q: "Useful peer comments focus on:", opts: ["Only font color", "Clarity, organization, and evidence", "Personal attacks", "Changing the topic"], ans: 1 },
      { q: "Without guidance, feedback may become:", opts: ["Always perfect", "Superficial or overly polite", "Unnecessary forever", "Only numerical"], ans: 1 },
      { q: "Peer review can also train:", opts: ["Cooking", "Critical reading and self-editing", "Driving", "Singing"], ans: 1 }
    ]
  },
  {
    title: "Campus Food Systems",
    text: "University dining services influence student health and sustainability goals. Offering more plant-forward options, clearer nutrition labels, and reduced food waste programs can support both wellbeing and environmental targets. Students often request longer hours and more affordable choices during exam weeks. Collaboration between student unions and catering managers tends to produce more practical menus than top-down changes alone.",
    questions: [
      { q: "Plant-forward options can support:", opts: ["Only decoration", "Health and sustainability goals", "Shorter semesters", "Fewer libraries"], ans: 1 },
      { q: "Exam weeks often increase demand for:", opts: ["Closed cafeterias", "Longer hours and affordable choices", "No labels", "Less food variety"], ans: 1 },
      { q: "Better menus often come from:", opts: ["Ignoring students", "Collaboration with student unions", "Removing managers", "Banning vegetables"], ans: 1 }
    ]
  },
  {
    title: "Digital Archives and Research",
    text: "Digitized archives expand access to historical documents that once required expensive travel. Students can examine primary sources from multiple countries within a single afternoon. Yet digital access introduces new challenges: uneven metadata quality, paywalls, and the need to evaluate scanned materials critically. Training in digital literacy is therefore becoming as important as traditional library skills for research-intensive courses.",
    questions: [
      { q: "A benefit of digitized archives is:", opts: ["Less access", "Broader access without travel", "Automatic essays", "No need for evaluation"], ans: 1 },
      { q: "A challenge mentioned is:", opts: ["Perfect metadata always", "Paywalls and uneven metadata", "Too few documents", "No scans exist"], ans: 1 },
      { q: "Digital literacy is compared to:", opts: ["Sports rules only", "Traditional library skills", "Cooking skills", "Parking rules"], ans: 1 }
    ]
  },
  {
    title: "Group Projects and Fair Assessment",
    text: "Group projects aim to build collaboration skills, but assessment remains controversial. If grades are purely collective, free-riding can occur. If grades are purely individual, teamwork incentives weaken. Many instructors combine a shared product score with peer evaluation and reflective journals. Clear role definitions and mid-project check-ins reduce conflict and make final grading more defensible.",
    questions: [
      { q: "Purely collective grades may encourage:", opts: ["Perfect fairness always", "Free-riding", "No collaboration ever", "Automatic A+"], ans: 1 },
      { q: "A mixed approach may include:", opts: ["Only one final exam", "Peer evaluation and reflection", "Removing all group work", "Random scores"], ans: 1 },
      { q: "Mid-project check-ins help by:", opts: ["Increasing confusion", "Reducing conflict", "Deleting roles", "Banning journals"], ans: 1 }
    ]
  },
  {
    title: "Language Exchange Benefits",
    text: "Language exchange partnerships allow learners to practice speaking with peers who want to learn their language in return. Beyond fluency, participants often gain cultural insight and confidence. Success depends on regular meetings, balanced speaking time, and realistic goals. Apps can help matching, but sustained improvement still requires deliberate practice and feedback, not only casual chat.",
    questions: [
      { q: "Language exchange is based on:", opts: ["One-way teaching only", "Mutual language practice", "Paid tutors only", "Silent reading only"], ans: 1 },
      { q: "Success factors include:", opts: ["Never meeting", "Regular meetings and balanced time", "Avoiding goals", "Only using emojis"], ans: 1 },
      { q: "Apps are described as:", opts: ["A complete substitute for practice", "Helpful for matching, not a full solution", "Useless", "Only for grammar tests"], ans: 1 }
    ]
  }
];

const LISTENING_SCRIPTS = [
  {
    title: "Campus Library Hours",
    script: "Attention students. During the final exam period, the main library will extend its weekday hours. From Monday to Friday the library will open at 7 AM and close at midnight. On Saturdays it will open at 9 AM and close at 8 PM. Group study rooms on the second floor can be booked up to 48 hours in advance through the library website. Please remember that food and drinks are not allowed in the quiet zones on the third floor. If you need research assistance, librarians are available at the help desk until 9 PM.",
    questions: [
      { q: "What time does the library open on weekdays during exams?", opts: ["6 AM", "7 AM", "8 AM", "9 AM"], ans: 1 },
      { q: "Until when can you book group study rooms in advance?", opts: ["24 hours", "48 hours", "72 hours", "1 week"], ans: 1 },
      { q: "Where are food and drinks not allowed?", opts: ["Entire library", "Quiet zones on the third floor", "Help desk", "Weekends only"], ans: 1 }
    ]
  },
  {
    title: "Healthy Study Habits",
    script: "Many students underestimate the importance of sleep and breaks while studying. Research shows that the brain consolidates memory most effectively during sleep. Aim for seven to eight hours each night, especially before an exam. The Pomodoro technique—twenty-five minutes of focused work followed by a five-minute break—can improve concentration. Additionally, studying in shorter sessions over several days is more effective than one long cramming session. Stay hydrated and avoid excessive caffeine late in the evening.",
    questions: [
      { q: "How many hours of sleep are recommended?", opts: ["5-6", "7-8", "9-10", "4-5"], ans: 1 },
      { q: "What is the Pomodoro work interval?", opts: ["15 minutes", "25 minutes", "45 minutes", "60 minutes"], ans: 1 },
      { q: "What study approach is more effective?", opts: ["One long cramming session", "Shorter sessions over several days", "Only all-nighters", "Studying without breaks"], ans: 1 }
    ]
  },
  {
    title: "Campus Cafeteria Announcement",
    script: "Good morning. This is an announcement regarding the student cafeteria. Starting this Wednesday, a new vegetarian and vegan menu will be available every day. The salad bar will be expanded, and we will offer plant-based protein options. Prices for the standard meal plan remain unchanged. Breakfast is served from 7 to 9:30 AM, lunch from 11:30 AM to 2 PM, and dinner from 5:30 to 8 PM. Students with allergies should speak to the staff; allergen information is clearly labeled on each dish.",
    questions: [
      { q: "When does the new vegetarian menu start?", opts: ["Monday", "Tuesday", "Wednesday", "Friday"], ans: 2 },
      { q: "When is lunch served?", opts: ["10–12", "11:30 AM–2 PM", "12–3 PM", "1–3 PM"], ans: 1 },
      { q: "Where can students find allergen information?", opts: ["Only online", "Labeled on each dish", "At the library", "Not available"], ans: 1 }
    ]
  },
  {
    title: "Scholarship Application Briefing",
    script: "This short briefing covers the faculty merit scholarship. Applications open on March first and close on March thirty-first at 5 PM local time. You must upload a transcript, a personal statement of maximum 700 words, and one recommendation letter from a lecturer. Interviews for shortlisted candidates will be held in the second week of April. Results will be emailed by the end of April. Incomplete applications will not be reviewed, so check the document checklist carefully before submitting.",
    questions: [
      { q: "When do applications close?", opts: ["March 1", "March 31 at 5 PM", "April 15", "End of February"], ans: 1 },
      { q: "What is the personal statement limit?", opts: ["300 words", "500 words", "700 words", "1000 words"], ans: 2 },
      { q: "When are interviews held?", opts: ["March", "Second week of April", "May only", "June"], ans: 1 }
    ]
  },
  {
    title: "Lab Safety Orientation",
    script: "Welcome to the chemistry teaching lab orientation. Before any experiment, wear safety goggles and a lab coat. Long hair must be tied back. Food and drinks are strictly prohibited inside the lab. In case of a chemical spill, alert the supervisor immediately and do not attempt cleanup without instruction. Emergency exits are located at the rear of the room and beside the preparation area. Fire extinguishers are mounted near both exits. Finally, all waste must be placed in the labeled containers—never in regular trash bins.",
    questions: [
      { q: "What must be worn before experiments?", opts: ["Only gloves", "Safety goggles and a lab coat", "Headphones", "Sandals only"], ans: 1 },
      { q: "If there is a chemical spill, students should:", opts: ["Clean it alone immediately", "Alert the supervisor first", "Ignore it", "Leave without reporting"], ans: 1 },
      { q: "Where should chemical waste go?", opts: ["Regular trash", "Labeled containers", "Sinks only", "Outside the building"], ans: 1 }
    ]
  },
  {
    title: "Career Fair Logistics",
    script: "The annual career fair will take place this Friday in the sports hall from 10 AM to 4 PM. More than forty employers will attend, including technology firms, banks, and public sector agencies. Students should bring printed copies of their CVs and dress in smart casual clothing. A CV review booth will operate near the entrance from 9:30 AM. Workshops on interview skills will run at 11 AM and 2 PM in Room B2. Please enter through the east gate to avoid congestion.",
    questions: [
      { q: "Where is the career fair held?", opts: ["Library", "Sports hall", "Cafeteria", "Parking lot"], ans: 1 },
      { q: "What should students bring?", opts: ["Only a phone", "Printed CVs", "Lab equipment", "Sports gear"], ans: 1 },
      { q: "Interview workshops are at:", opts: ["9 and 10 AM", "11 AM and 2 PM", "3 and 5 PM", "Only 4 PM"], ans: 1 }
    ]
  },
  {
    title: "Public Lecture: Climate and Cities",
    script: "Good evening and welcome to tonight's public lecture on climate adaptation in coastal cities. Our speaker, Dr. Maya Rahman, will discuss how rising sea levels affect urban planning. The talk lasts approximately forty-five minutes, followed by fifteen minutes of questions. Please silence mobile phones. Recording is permitted for personal study only, not for commercial use. Printed summaries will be available at the exit. Refreshments will be served in the foyer after the session.",
    questions: [
      { q: "How long is the talk itself?", opts: ["15 minutes", "30 minutes", "45 minutes", "90 minutes"], ans: 2 },
      { q: "Recording is allowed for:", opts: ["Commercial broadcasts", "Personal study only", "No one", "Only staff"], ans: 1 },
      { q: "Where are refreshments served?", opts: ["Inside the hall only", "In the foyer after the session", "Not available", "Outside campus"], ans: 1 }
    ]
  },
  {
    title: "IT Service Desk Update",
    script: "This is an update from the campus IT service desk. Starting Monday, password resets will be processed only through the online portal; walk-in resets will stop except for accessibility cases. Software installation requests for lab machines must be submitted five working days in advance. Wi-Fi outages planned for maintenance will occur this Sunday between 2 AM and 5 AM. For urgent issues during office hours, call extension 4500. After hours, use the emergency ticket form on the IT website.",
    questions: [
      { q: "Password resets will mainly be done:", opts: ["Only by phone", "Through the online portal", "By email to friends", "In every classroom"], ans: 1 },
      { q: "Software requests need how much notice?", opts: ["Same day", "Two days", "Five working days", "One month"], ans: 2 },
      { q: "When is Wi-Fi maintenance?", opts: ["Monday morning", "Sunday 2–5 AM", "Friday noon", "All weekend continuously"], ans: 1 }
    ]
  },
  {
    title: "Student Housing Meeting",
    script: "Thank you for attending the residence hall meeting. Quiet hours begin at 11 PM on weekdays and midnight on weekends. Guests must be registered at the front desk and may stay overnight no more than three nights per month. Kitchen cleaning is a shared responsibility; a rotating roster is posted on the fridge. Laundry tokens can be purchased at the lobby machine from 7 AM to 10 PM. Report maintenance problems through the housing app rather than group chats so requests can be tracked.",
    questions: [
      { q: "Weekday quiet hours start at:", opts: ["9 PM", "10 PM", "11 PM", "12 AM"], ans: 2 },
      { q: "Overnight guests are limited to:", opts: ["One night a year", "Three nights per month", "Unlimited", "Weekends only"], ans: 1 },
      { q: "Maintenance should be reported via:", opts: ["Group chats only", "The housing app", "Posters", "Social media comments"], ans: 1 }
    ]
  },
  {
    title: "Internship Orientation Call",
    script: "Welcome to the internship orientation. Your first day is next Monday at 8:30 AM at the downtown office. Please bring a photo ID and a signed confidentiality form. Business casual dress is expected. Lunch is provided in the first week only. Your mentor will meet you in the lobby. During the internship, weekly reflection notes of about 200 words are due every Friday by 5 PM on the learning portal. If you are ill, email both your mentor and the internship coordinator before 9 AM.",
    questions: [
      { q: "What time does the first day start?", opts: ["8:00", "8:30 AM", "9:00", "10:00"], ans: 1 },
      { q: "Weekly reflections are due:", opts: ["Monday morning", "Friday by 5 PM", "Sunday night", "Once a month"], ans: 1 },
      { q: "If ill, students should email:", opts: ["Only friends", "Mentor and coordinator before 9 AM", "No one", "Only after returning"], ans: 1 }
    ]
  },
  {
    title: "Exam Rules Reminder",
    script: "Please listen carefully to the examination rules. Candidates must arrive at least fifteen minutes early. Student cards are required for entry. Bags must be placed at the front of the room. Mobile phones must be switched off and left in bags. Only transparent water bottles are allowed on desks. If you need additional paper, raise your hand; do not leave your seat. The exam lasts ninety minutes. When time is called, stop writing immediately. Failure to follow instructions may result in disqualification.",
    questions: [
      { q: "How early should candidates arrive?", opts: ["5 minutes", "15 minutes", "30 minutes", "1 hour"], ans: 1 },
      { q: "What bottles are allowed on desks?", opts: ["Any bottle", "Transparent water bottles", "No bottles", "Only coffee cups"], ans: 1 },
      { q: "Exam duration is:", opts: ["60 minutes", "90 minutes", "120 minutes", "45 minutes"], ans: 1 }
    ]
  },
  {
    title: "Museum Field Trip Briefing",
    script: "For Saturday's field trip to the city museum, the bus leaves campus at 8:15 AM sharp from Gate C. Bring a notebook, a pen, and your student ID for discounted entry. The guided tour starts at 10 AM and lasts about seventy minutes. After the tour you will have free time until 1:30 PM to explore the modern history wing. The return bus departs at 2 PM. Packed lunches are recommended because the museum café may be crowded. If you miss the bus, you are responsible for your own transport.",
    questions: [
      { q: "Where does the bus leave from?", opts: ["Gate A", "Gate B", "Gate C", "Library"], ans: 2 },
      { q: "How long is the guided tour?", opts: ["30 minutes", "About 70 minutes", "3 hours", "15 minutes"], ans: 1 },
      { q: "Return bus departs at:", opts: ["1:00", "1:30", "2:00 PM", "3:00"], ans: 2 }
    ]
  }
];

const WRITING_PROMPTS = [
  {
    type: "opinion",
    title: "Opinion Essay",
    prompt: "Some people believe university education should be free for all students. Others argue that students should pay tuition because it increases responsibility and funds quality. Discuss both views and give your own opinion.\\n\\nWrite at least 250 words."
  },
  {
    type: "ielts-task2",
    title: "IELTS Writing Task 2",
    prompt: "In many countries, the amount of crime is increasing.\\n\\nWhat do you think are the main causes of crime?\\nHow can we deal with those causes?\\n\\nWrite at least 250 words."
  },
  {
    type: "advantage-disadvantage",
    title: "Advantages & Disadvantages",
    prompt: "More people are choosing to work from home than ever before.\\n\\nDo the advantages of this trend outweigh the disadvantages?\\n\\nWrite at least 250 words."
  },
  {
    type: "problem-solution",
    title: "Problem & Solution",
    prompt: "Many cities face serious traffic congestion.\\n\\nWhat problems does this cause?\\nWhat solutions can you suggest?\\n\\nWrite at least 250 words."
  },
  {
    type: "discuss-both",
    title: "Discussion Essay",
    prompt: "Some educators think examinations are the best way to assess students. Others believe continuous assessment is better.\\n\\nDiscuss both views and give your opinion.\\n\\nWrite at least 250 words."
  },
  {
    type: "agree-disagree",
    title: "Agree / Disagree",
    prompt: "Technology has made young people less creative.\\n\\nTo what extent do you agree or disagree?\\n\\nWrite at least 250 words."
  },
  {
    type: "two-part",
    title: "Two-Part Question",
    prompt: "Many people move from rural areas to large cities.\\n\\nWhy is this happening?\\nWhat effects can it have on cities and rural communities?\\n\\nWrite at least 250 words."
  },
  {
    type: "opinion",
    title: "Education Priority",
    prompt: "Some people think schools should teach financial literacy as a compulsory subject.\\n\\nDo you agree or disagree?\\n\\nWrite at least 250 words."
  },
  {
    type: "advantage-disadvantage",
    title: "Gap Year",
    prompt: "Taking a gap year before university is becoming more popular.\\n\\nDo the advantages outweigh the disadvantages for most students?\\n\\nWrite at least 250 words."
  },
  {
    type: "problem-solution",
    title: "Plastic Waste",
    prompt: "Plastic pollution is damaging oceans and wildlife.\\n\\nWhat are the main causes of this problem?\\nWhat measures can individuals and governments take?\\n\\nWrite at least 250 words."
  },
  {
    type: "ielts-task2",
    title: "Culture & Tourism",
    prompt: "International tourism has become a major industry.\\n\\nSome people say it harms local cultures, while others say it creates understanding between countries.\\n\\nDiscuss both sides and give your opinion.\\n\\nWrite at least 250 words."
  },
  {
    type: "agree-disagree",
    title: "Online Learning",
    prompt: "Online learning can fully replace classroom education.\\n\\nTo what extent do you agree or disagree?\\n\\nWrite at least 250 words."
  }
];

const SPEAKING_PROMPTS = [
  {
    part: "Warm-up",
    prompt: "Describe a skill you want to improve this semester. Why is it important, and how will you practice it?",
    tips: "Speak for 1–2 minutes. Give reasons and one concrete plan."
  },
  {
    part: "Experience",
    prompt: "Talk about a time you worked in a team. What was the goal, what role did you play, and what did you learn?",
    tips: "Use past tenses. Include one challenge and one result."
  },
  {
    part: "Opinion",
    prompt: "Do you think university students should be required to do community service? Explain your view with examples.",
    tips: "State a clear position, then support with 2 reasons."
  },
  {
    part: "Description",
    prompt: "Describe a public place in your city that you enjoy. What does it look like, who goes there, and why do you like it?",
    tips: "Use descriptive adjectives and location language."
  },
  {
    part: "Future",
    prompt: "Where do you see yourself five years after graduation? What steps are you taking now toward that goal?",
    tips: "Mix future forms (will / going to / hope to) naturally."
  },
  {
    part: "Comparison",
    prompt: "Compare studying alone with studying in a group. Which works better for you and in what situations?",
    tips: "Use comparatives and clear examples."
  },
  {
    part: "Problem",
    prompt: "What is one major challenge students face when learning English in your country? Suggest two practical solutions.",
    tips: "Define the challenge briefly, then propose realistic solutions."
  },
  {
    part: "Media",
    prompt: "Talk about a film, book, or podcast that influenced your thinking. What was it about and what changed for you?",
    tips: "Summarize briefly, then focus on personal impact."
  },
  {
    part: "Campus Life",
    prompt: "Describe a club, organization, or campus activity you would recommend to a new student. Why?",
    tips: "Include benefits and who it suits best."
  },
  {
    part: "Abstract",
    prompt: "Some people say success is mainly luck; others say it is mainly hard work. What is your opinion?",
    tips: "Acknowledge both sides briefly, then defend your stance."
  },
  {
    part: "IELTS-style Cue Card",
    prompt: "Describe a person who taught you an important lesson. You should say who the person is, what they taught you, how they taught you, and explain why the lesson was important.",
    tips: "Cover all bullet points. Speak for up to 2 minutes."
  },
  {
    part: "Follow-up Discussion",
    prompt: "Is it better for young people to learn practical skills or academic knowledge first? Discuss both and give your view.",
    tips: "This mimics IELTS Part 3 — develop ideas beyond one sentence."
  }
];

/* IELTS Mock Sections */
const IELTS_LISTENING = [
  {
    title: "Section 1 — Accommodation Enquiry",
    script: "Woman: Good morning, City Homestay Services. Man: Hi, I'm looking for a room near the university for one semester. Woman: We have a single room in Riverside for 120 pounds a week, including utilities, or a shared flat in Green Park for 95 pounds a week. Man: Is Riverside within walking distance? Woman: About fifteen minutes on foot, or five minutes by bus number 42. The Green Park place is closer to the library but further from the science labs. Man: I'd prefer Riverside. When can I view it? Woman: Tomorrow at 4 PM or Friday at 11 AM. Man: Friday at 11 works. My name is Daniel Cho. Woman: Got it. Please bring your student ID and a deposit of 200 pounds if you decide to take it.",
    questions: [
      { q: "How much is the Riverside room per week?", opts: ["£95", "£120", "£200", "£42"], ans: 1 },
      { q: "Riverside is about how long on foot?", opts: ["5 minutes", "15 minutes", "30 minutes", "42 minutes"], ans: 1 },
      { q: "When will Daniel view the room?", opts: ["Tomorrow 4 PM", "Friday 11 AM", "Friday 4 PM", "Monday 11 AM"], ans: 1 },
      { q: "What deposit is required?", opts: ["£95", "£120", "£200", "None"], ans: 2 }
    ]
  },
  {
    title: "Section 2 — Campus Sports Centre",
    script: "Welcome to the campus sports centre induction. Membership is free for full-time students; part-time students pay a reduced fee of 15 pounds per term. The gym opens at 6:30 AM on weekdays and 8 AM on weekends. Group fitness classes must be booked via the app at least two hours in advance. Lockers require a 1-pound coin deposit, refundable when you return the key. Please wear clean indoor shoes in the courts. Photography is not allowed in changing areas. For injuries, contact the first-aid officer at desk 3.",
    questions: [
      { q: "Full-time student membership is:", opts: ["£15 per term", "Free", "£1 per visit", "Not available"], ans: 1 },
      { q: "Weekday gym opening time:", opts: ["6:30 AM", "8 AM", "7 AM", "9 AM"], ans: 0 },
      { q: "Class booking requires advance notice of:", opts: ["10 minutes", "30 minutes", "At least 2 hours", "One week"], ans: 2 },
      { q: "Photography is banned in:", opts: ["The gym only", "Changing areas", "The whole campus", "Outdoor fields only"], ans: 1 }
    ]
  },
  {
    title: "Section 3 — Tutorial Discussion",
    script: "Tutor: How is your group project on urban transport progressing? Student A: We've collected survey responses from 80 students, but the interviews with city planners are delayed. Student B: I can contact the planning office again this week. Tutor: Good. Remember the report must include a literature review, methods, findings, and recommendations. The word limit is 3,000 words, due on the 18th. Student A: Can we submit diagrams as appendices? Tutor: Yes, appendices don't count toward the word limit, but label them clearly. Student B: Should we focus more on buses or cycling lanes? Tutor: Base that decision on your data, not on personal preference.",
    questions: [
      { q: "How many survey responses were collected?", opts: ["18", "80", "3000", "15"], ans: 1 },
      { q: "What is delayed?", opts: ["The survey", "Interviews with planners", "Printing", "The tutorial"], ans: 1 },
      { q: "Word limit for the report:", opts: ["800", "1,500", "3,000", "5,000"], ans: 2 },
      { q: "Appendices:", opts: ["Are forbidden", "Count fully in the word limit", "Do not count toward the word limit", "Must replace the methods section"], ans: 2 }
    ]
  },
  {
    title: "Section 4 — Lecture on Memory",
    script: "In today's lecture we examine how memory supports academic learning. Working memory holds a limited amount of information for roughly fifteen to thirty seconds, typically around seven items. Long-term memory has a much larger capacity and can store information for years. Encoding is strengthened by elaborative rehearsal—linking new ideas to existing knowledge—rather than mere repetition. Sleep plays a critical role in consolidation. Retrieval practice, or testing yourself, is more effective than rereading notes. Finally, spaced practice over several days beats massed practice, commonly known as cramming.",
    questions: [
      { q: "Working memory typically holds about how many items?", opts: ["3", "7", "15", "30"], ans: 1 },
      { q: "Elaborative rehearsal means:", opts: ["Repeating only", "Linking new ideas to existing knowledge", "Sleeping longer", "Avoiding tests"], ans: 1 },
      { q: "Retrieval practice is:", opts: ["Rereading notes", "Testing yourself", "Listening only", "Group chat"], ans: 1 },
      { q: "Spaced practice is better than:", opts: ["Sleep", "Massed practice / cramming", "Exercise", "Diet"], ans: 1 }
    ]
  },
  {
    title: "Section 1 — Library Workshop Booking",
    script: "Staff: Hello, Research Skills Centre. Student: I'd like to book a workshop on citation management. Staff: We run Zotero workshops on Tuesdays at 2 PM and Thursdays at 10 AM. Each session lasts 90 minutes and is held in Lab 4. Student: Thursday morning works. Are laptops provided? Staff: Yes, but you may bring your own. Please create a free Zotero account before you arrive. Student: Is there a fee? Staff: No fee for enrolled students. Bring your student card. Capacity is 20 people.",
    questions: [
      { q: "Thursday workshop time:", opts: ["2 PM", "10 AM", "4 PM", "9 AM"], ans: 1 },
      { q: "Session length:", opts: ["45 minutes", "60 minutes", "90 minutes", "120 minutes"], ans: 2 },
      { q: "Students should prepare by:", opts: ["Buying software", "Creating a Zotero account", "Printing slides", "Nothing"], ans: 1 },
      { q: "Capacity is:", opts: ["10", "15", "20", "50"], ans: 2 }
    ]
  },
  {
    title: "Section 2 — Museum Audio Guide Intro",
    script: "Welcome to the City History Museum audio guide. You are standing in Gallery A, which covers the years 1900 to 1950. Move clockwise to follow the timeline. Highlight objects have a blue marker and a three-digit code. Enter the code on your handset to hear details. The café is on the ground floor near the exit. Free guided tours start at 11 AM and 3 PM from the main desk. Please do not touch the exhibits. Photography without flash is allowed except in the textile room.",
    questions: [
      { q: "Gallery A covers:", opts: ["1800–1850", "1900–1950", "1950–2000", "Only 1900"], ans: 1 },
      { q: "How do you hear object details?", opts: ["Ask any visitor", "Enter a three-digit code", "Only at 3 PM", "Read nothing"], ans: 1 },
      { q: "Guided tours start at:", opts: ["10 and 2", "11 AM and 3 PM", "Noon only", "5 PM only"], ans: 1 },
      { q: "Flash photography is:", opts: ["Always required", "Not allowed in the textile room (and restricted generally)", "Mandatory", "Only for staff"], ans: 1 }
    ]
  }
];

const IELTS_READING = [
  {
    title: "The Rise of Micro-Credentials",
    text: "Micro-credentials—short, focused certifications—are expanding across higher education. Supporters argue they help learners gain job-relevant skills faster than traditional degrees. Employers in technology and healthcare have begun listing specific badges in job posts. Critics warn that a fragmented credential market may confuse applicants and dilute academic standards if quality assurance is weak. Universities are responding by bundling micro-credentials into pathways that can later count toward diplomas. The long-term value will depend on transparent assessment and recognition across institutions and industries.",
    questions: [
      { q: "Micro-credentials are described as:", opts: ["Full doctoral degrees", "Short, focused certifications", "Only unpaid internships", "Secondary school diplomas"], ans: 1 },
      { q: "A concern from critics is:", opts: ["They are always too long", "Market confusion and weak quality assurance", "Employers never notice them", "They ban technology jobs"], ans: 1 },
      { q: "Universities may bundle micro-credentials to:", opts: ["Prevent all learning", "Create pathways toward diplomas", "Remove assessment", "Replace libraries"], ans: 1 },
      { q: "Long-term value depends on:", opts: ["Fashion trends", "Transparent assessment and recognition", "Shorter logos only", "Eliminating employers"], ans: 1 }
    ]
  },
  {
    title: "Urban Heat Islands",
    text: "Cities often record higher temperatures than surrounding rural areas, a phenomenon known as the urban heat island effect. Dark surfaces, dense buildings, and reduced vegetation trap heat. During heatwaves, this raises health risks for elderly residents and outdoor workers. Mitigation strategies include reflective roofing, tree planting, and preserving airflow corridors. Some councils now require shade provision in new public spaces. Effective policy combines climate data with neighborhood-level planning so that cooler infrastructure reaches the most vulnerable communities first.",
    questions: [
      { q: "Urban heat islands are:", opts: ["Colder cities", "Cities hotter than nearby rural areas", "Only coastal parks", "Underground stations"], ans: 1 },
      { q: "Contributing factors include:", opts: ["More forests only", "Dark surfaces and less vegetation", "Always more rain", "Fewer buildings"], ans: 1 },
      { q: "Mitigation may involve:", opts: ["Removing all trees", "Reflective roofs and planting trees", "Banning shade", "Heating pavements"], ans: 1 },
      { q: "Policy should prioritize:", opts: ["Only tourist zones", "Vulnerable communities", "Tallest skyscrapers only", "Airports exclusively"], ans: 1 }
    ]
  },
  {
    title: "Peer Instruction in Lectures",
    text: "Peer instruction asks students to answer conceptual questions individually, discuss with neighbors, then revote. Research in physics and biology classrooms suggests this can improve conceptual understanding compared with pure lecturing. The method works best when questions target common misconceptions and instructors facilitate rather than immediately reveal answers. Time pressure is a challenge in content-heavy courses, so some lecturers use peer instruction only for threshold concepts. When implemented thoughtfully, it transforms passive listening into active reasoning without abandoning expert explanation.",
    questions: [
      { q: "Peer instruction sequence includes:", opts: ["Only final exams", "Individual answer, discussion, revote", "Silent copying", "No questions"], ans: 1 },
      { q: "It works best when questions target:", opts: ["Trivia only", "Common misconceptions", "Attendance lists", "Parking rules"], ans: 1 },
      { q: "A practical challenge is:", opts: ["Too little content ever", "Time pressure in content-heavy courses", "Students refusing to sit", "No classrooms"], ans: 1 },
      { q: "The approach aims to:", opts: ["Eliminate teachers", "Increase active reasoning", "Ban discussion", "Shorten degrees automatically"], ans: 1 }
    ]
  },
  {
    title: "Food Waste on Campus",
    text: "Campus dining halls generate substantial food waste through overproduction and unfinished meals. Interventions such as trayless dining, smaller default portions, and visible waste audits have reduced leftovers in several universities. Student campaigns that combine data posters with recipe workshops for using leftovers show mixed but promising results. Success depends on kitchen logistics as much as awareness: if serving systems remain inflexible, behavioral nudges alone have limited impact. Measuring waste by weight before and after changes helps verify what actually works.",
    questions: [
      { q: "Trayless dining is mentioned as:", opts: ["A cause of more waste", "An intervention to reduce waste", "A sports rule", "A library policy"], ans: 1 },
      { q: "Awareness campaigns work best when combined with:", opts: ["No kitchen changes", "Kitchen logistics improvements", "Removing all data", "Longer queues only"], ans: 1 },
      { q: "Verification of success uses:", opts: ["Guesswork only", "Measuring waste by weight", "Social media likes", "Exam scores"], ans: 1 },
      { q: "Unfinished meals contribute to:", opts: ["Lower tuition", "Food waste", "Better grades automatically", "More dorm space"], ans: 1 }
    ]
  },
  {
    title: "Open Educational Resources",
    text: "Open educational resources (OER) are teaching materials released with licenses that permit reuse and adaptation. Advocates highlight lower costs for students and the ability to localize examples. Barriers include faculty time for adaptation, uncertainty about quality, and limited incentives in promotion criteria. Institutions that provide instructional design support and recognition for OER adoption tend to see wider use. The debate is shifting from whether OER can work to how to sustain high-quality open materials at scale.",
    questions: [
      { q: "OER licenses mainly allow:", opts: ["No sharing", "Reuse and adaptation", "Only paid printing", "Secret archives"], ans: 1 },
      { q: "A barrier to adoption is:", opts: ["Always lower quality by definition", "Faculty time and weak incentives", "Too much funding", "Student demand only"], ans: 1 },
      { q: "Wider use is linked to:", opts: ["No support", "Design support and recognition", "Banning textbooks", "Removing faculty"], ans: 1 },
      { q: "The debate is moving toward:", opts: ["Ignoring quality", "Sustaining quality at scale", "Ending all OER", "Only printed books"], ans: 1 }
    ]
  }
];

const IELTS_WRITING = [
  {
    type: "task1",
    title: "IELTS Writing Task 1",
    prompt: "The chart below shows the percentage of households in owned and rented accommodation in England and Wales between 1918 and 2011.\\n\\nSummarise the information by selecting and reporting the main features, and make comparisons where relevant.\\n\\nWrite at least 150 words.\\n\\n(Data summary for practice: Owned housing rose from about 23% in 1918 to a peak near 69% in 2001, then dipped slightly by 2011. Rented accommodation fell from roughly 77% to around 31% over the same long period.)"
  },
  {
    type: "task2",
    title: "IELTS Writing Task 2",
    prompt: "Some people think that the best way to reduce crime is to give longer prison sentences. Others, however, believe there are better alternative ways of reducing crime.\\n\\nDiscuss both views and give your own opinion.\\n\\nWrite at least 250 words."
  },
  {
    type: "task2",
    title: "IELTS Writing Task 2 — Education",
    prompt: "Universities should accept equal numbers of male and female students in every subject.\\n\\nTo what extent do you agree or disagree?\\n\\nWrite at least 250 words."
  },
  {
    type: "task2",
    title: "IELTS Writing Task 2 — Environment",
    prompt: "Individual action cannot solve environmental problems; governments and large companies must lead.\\n\\nDiscuss both sides and give your opinion.\\n\\nWrite at least 250 words."
  },
  {
    type: "task1",
    title: "IELTS Writing Task 1 — Process",
    prompt: "The diagram shows how rainwater is collected and used for drinking water in a modern system.\\n\\nSummarise the information by selecting and reporting the main features.\\n\\nWrite at least 150 words.\\n\\n(Stages for practice: collection from roofs → filtering → storage tanks → purification → distribution to households.)"
  },
  {
    type: "task2",
    title: "IELTS Writing Task 2 — Technology",
    prompt: "Nowadays people use digital devices from a very young age.\\n\\nWhat problems can this cause?\\nWhat solutions can you suggest?\\n\\nWrite at least 250 words."
  }
];

const IELTS_SPEAKING = [
  { part: "1", prompt: "Let's talk about your studies. What subject are you studying and why did you choose it?" },
  { part: "1", prompt: "Do you prefer to study in the morning or at night? Why?" },
  { part: "2", prompt: "Describe a goal you achieved that took a long time. You should say what the goal was, how long it took, how you achieved it, and explain how you felt afterward." },
  { part: "2", prompt: "Describe a useful app on your phone. You should say what it is, how often you use it, what you use it for, and explain why it is useful." },
  { part: "3", prompt: "What skills do young people need most for future jobs? How can schools better prepare students for working life?" },
  { part: "3", prompt: "Is competition in education a positive or negative influence? Should universities focus more on collaboration than ranking?" }
];

const TOEFL_READING = [
  {
    title: "Coral Reef Stressors",
    text: "Coral reefs support extraordinary biodiversity but face cumulative stressors. Rising sea temperatures cause bleaching when corals expel symbiotic algae. Ocean acidification reduces the availability of carbonate ions needed for skeleton building. Local pressures such as overfishing and nutrient pollution further weaken reef resilience. Marine protected areas can help if they are well enforced and connected. Scientists emphasize that local conservation, while valuable, cannot fully substitute for global reductions in greenhouse gas emissions.",
    questions: [
      { q: "Bleaching involves corals expelling:", opts: ["Fish only", "Symbiotic algae", "Sand", "Plastic only"], ans: 1 },
      { q: "Ocean acidification affects:", opts: ["Nothing biological", "Carbonate ions for skeletons", "Only rainfall inland", "Mountain forests"], ans: 1 },
      { q: "Local conservation alone is:", opts: ["A full substitute for climate action", "Valuable but not a full substitute for emission cuts", "Useless", "Banned"], ans: 1 },
      { q: "Overfishing is categorized as:", opts: ["A global atmosphere issue only", "A local pressure", "Unrelated to reefs", "A solution"], ans: 1 }
    ]
  },
  {
    title: "Spaced Learning Research",
    text: "Spaced learning distributes study sessions over time rather than concentrating them in one block. Experiments repeatedly show superior long-term retention for spaced schedules, especially when sessions include retrieval practice. The mechanism may involve contextual variability and consolidation processes during intervals. Despite robust evidence, many learners still prefer cramming before exams because it can produce short-term familiarity. Educators who redesign courses with distributed quizzes help students experience the benefits directly rather than only reading about them.",
    questions: [
      { q: "Spaced learning means:", opts: ["One single marathon session", "Distributing sessions over time", "Never reviewing", "Only group work"], ans: 1 },
      { q: "Evidence suggests spaced learning improves:", opts: ["Only short-term familiarity", "Long-term retention", "Handwriting speed only", "Nothing measurable"], ans: 1 },
      { q: "Cramming often produces:", opts: ["Best long-term memory always", "Short-term familiarity", "No familiarity", "Permanent mastery"], ans: 1 },
      { q: "Distributed quizzes help students:", opts: ["Avoid all practice", "Experience benefits directly", "Remove content", "Skip exams forever"], ans: 1 }
    ]
  },
  {
    title: "Behavioral Nudges",
    text: "Behavioral nudges alter choice architecture without forbidding options. Classic examples include placing healthier food at eye level or setting defaults for retirement savings enrollment. In education, nudges such as planning prompts and deadline reminders can improve submission rates. Ethical debates focus on transparency and the risk of manipulation. Effective educational nudges typically preserve autonomy while reducing friction for beneficial behaviors already valued by learners.",
    questions: [
      { q: "Nudges work by:", opts: ["Banning all choices", "Changing choice architecture", "Removing education", "Increasing tuition only"], ans: 1 },
      { q: "An education example is:", opts: ["Deleting courses", "Deadline reminders", "Closing libraries", "Banning notes"], ans: 1 },
      { q: "Ethical concerns include:", opts: ["Only font color", "Transparency and manipulation risks", "Too much autonomy always", "No student impact"], ans: 1 },
      { q: "Effective nudges should:", opts: ["Destroy autonomy", "Preserve autonomy while reducing friction", "Hide all information", "Force one major only"], ans: 1 }
    ]
  },
  {
    title: "Bilingual Advantage Debate",
    text: "Researchers have debated whether bilingualism confers broad cognitive advantages, such as improved executive control. Early studies reported benefits, but later large-sample work produced mixed results, partly due to differing definitions of bilingual experience and control for socioeconomic factors. A current view suggests advantages may appear in specific tasks and contexts rather than as a global superiority. This does not diminish cultural and communicative value of bilingualism; it refines claims about underlying cognitive mechanisms.",
    questions: [
      { q: "Later research results were:", opts: ["Uniformly stronger than early claims", "Mixed", "Impossible", "Only about sports"], ans: 1 },
      { q: "A methodological issue is:", opts: ["Ignoring language entirely", "Definitions of bilingual experience and socioeconomic controls", "Too few languages on Earth", "No participants ever"], ans: 1 },
      { q: "Current view suggests advantages may be:", opts: ["Global in every task always", "Task- and context-specific", "Nonexistent in communication", "Only musical"], ans: 1 },
      { q: "The debate refinement does not deny:", opts: ["Cultural and communicative value", "That language exists", "School buildings", "Exam rooms"], ans: 0 }
    ]
  }
];

const TOEFL_LISTENING = [
  {
    title: "Conversation — Course Registration",
    script: "Student: I'm trying to register for Advanced Statistics, but the system says I need a prerequisite. Advisor: You need Intro Statistics or an equivalent. Did you take a similar course at your previous college? Student: Yes, Statistics 101. Advisor: Upload the syllabus and transcript to the waiver form. If approved, we can place you in the class before Friday. Student: How long does review take? Advisor: Usually two business days. Also, seats are limited, so submit today if possible.",
    questions: [
      { q: "What problem does the student have?", opts: ["Wrong password only", "Prerequisite requirement", "Closed campus", "No advisor"], ans: 1 },
      { q: "What should the student upload?", opts: ["Only a photo", "Syllabus and transcript", "A passport", "Nothing"], ans: 1 },
      { q: "Typical review time:", opts: ["Two hours", "Two business days", "Two months", "One year"], ans: 1 },
      { q: "Why submit soon?", opts: ["Seats are limited", "The course is free forever", "Advisors leave campus", "No reason"], ans: 0 }
    ]
  },
  {
    title: "Lecture — Soil Erosion",
    script: "Today we focus on soil erosion in agricultural landscapes. Water and wind remove topsoil, reducing fertility and harming downstream water quality. Contour plowing and cover crops are common mitigation methods. Terracing can be effective on slopes but requires investment. The lecture case study from central Java shows that combining cover crops with community training reduced measurable runoff within two seasons. Note that solutions must fit local rainfall patterns and land tenure systems; otherwise adoption stays low.",
    questions: [
      { q: "Topsoil loss affects:", opts: ["Only building height", "Fertility and water quality", "Internet speed", "Exam schedules"], ans: 1 },
      { q: "Contour plowing is a:", opts: ["Marketing slogan", "Mitigation method", "Type of exam", "Computer virus"], ans: 1 },
      { q: "The Java case study combined cover crops with:", opts: ["No people", "Community training", "Removing farms", "Only satellite ads"], ans: 1 },
      { q: "Adoption stays low when solutions ignore:", opts: ["Local rainfall and land tenure", "All science", "Students", "Libraries"], ans: 0 }
    ]
  },
  {
    title: "Conversation — Lab Partnership",
    script: "Student A: Dr. Lee suggested we partner on the robotics demo for the open day. Student B: Good idea, but the sensors I ordered arrive only next Wednesday. Student A: The open day is Friday week, so that should be okay if we assemble Thursday. Student B: Can we use the fabrication lab after 6 PM? Student A: Yes, if we book by tomorrow. I'll draft the demo script; you handle the wiring checklist. Student B: Deal. Let's meet Monday to test the backup plan in case a sensor fails.",
    questions: [
      { q: "When do sensors arrive?", opts: ["Monday", "Next Wednesday", "Friday", "Tomorrow"], ans: 1 },
      { q: "Open day is:", opts: ["Tomorrow", "Monday", "Friday week", "Next year"], ans: 2 },
      { q: "Fabrication lab after 6 PM requires:", opts: ["No booking", "Booking by tomorrow", "A formal degree", "Nothing"], ans: 1 },
      { q: "Monday meeting purpose:", opts: ["Cancel the project", "Test a backup plan", "Order food only", "Change majors"], ans: 1 }
    ]
  },
  {
    title: "Lecture — Public Goods",
    script: "In economics, public goods are non-excludable and non-rivalrous: one person's use does not reduce availability to others, and people cannot easily be prevented from consuming them. National defense and clean air are standard examples. Markets underprovide public goods because free riders benefit without paying. Governments may fund them through taxation. The lecture also notes club goods and common resources as related categories with different exclusion and rivalry properties, which matter for policy design.",
    questions: [
      { q: "Public goods are:", opts: ["Always private snacks", "Non-excludable and non-rivalrous", "Only luxury cars", "Excluded by definition"], ans: 1 },
      { q: "Free riders:", opts: ["Pay the most", "Benefit without paying", "Produce all goods", "Ban taxes"], ans: 1 },
      { q: "Governments may fund public goods via:", opts: ["Ignoring them", "Taxation", "Deleting markets", "Banning air"], ans: 1 },
      { q: "Club goods and common resources are:", opts: ["Unrelated categories", "Related categories with different properties", "The same as snacks", "Not used in policy"], ans: 1 }
    ]
  }
];

const TOEFL_SPEAKING = [
  { task: "1", prompt: "Some students prefer to work on assignments early. Others wait until close to the deadline. Which approach do you think is better and why?" },
  { task: "2", prompt: "Do you agree or disagree with the following statement? It is more important for students to understand ideas than to memorize facts. Use details in your response." },
  { task: "3", prompt: "Campus announcement: The library will replace printed journals with digital-only access next semester to save costs and space. Explain how a student might feel about this policy and why." },
  { task: "4", prompt: "Using the points from a short lecture on habit formation, explain how cues and rewards help build study routines. (In practice, discuss cues, routines, and rewards with one personal example.)" },
  { task: "1", prompt: "Would you rather take a difficult class that is highly useful for your major or an easier elective that boosts your GPA? Explain your preference." },
  { task: "2", prompt: "Some people prefer group study; others prefer studying alone. Which do you prefer and why? Include specific reasons." }
];

const TOEFL_WRITING = [
  {
    type: "integrated",
    title: "TOEFL Integrated Writing",
    prompt: "Reading passage summary: A university plans to replace the campus bookstore with a smaller retail space and rely mainly on online ordering.\\n\\nLecture viewpoint: The man opposes the plan because students need immediate access to required materials, online shipping can be slow during peak weeks, and campus jobs in the bookstore would disappear.\\n\\nTask: Summarize the points made in the lecture, explaining how they cast doubt on the reading. (Practice version: write 150–225 words using the points above.)"
  },
  {
    type: "independent",
    title: "TOEFL Independent Writing",
    prompt: "Do you agree or disagree with the following statement?\\n\\nStudents should be required to take physical education courses throughout university.\\n\\nUse specific reasons and examples to support your answer. Write at least 300 words."
  },
  {
    type: "independent",
    title: "TOEFL Independent Writing — Technology",
    prompt: "Do you agree or disagree with the following statement?\\n\\nThe widespread use of smartphones has generally improved the quality of students' academic work.\\n\\nSupport your position with reasons and examples. Write at least 300 words."
  },
  {
    type: "integrated",
    title: "TOEFL Integrated Writing — Environment",
    prompt: "Reading: A city proposes building a highway through a wetland to reduce traffic.\\n\\nLecture: The lecturer argues the highway would harm bird breeding grounds, increase pollution in nearby neighborhoods, and that improved public transit is a better alternative.\\n\\nTask: Summarize the lecture points and explain how they challenge the reading. Write 150–225 words."
  },
  {
    type: "independent",
    title: "TOEFL Independent Writing — Work",
    prompt: "Some people prefer a job with a high salary but long hours. Others prefer a lower salary with more free time.\\n\\nWhich do you prefer and why? Use specific reasons and examples. Write at least 300 words."
  }
];

function shuffle(array) {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function getRandomItems(arr, n) {
  return shuffle(arr).slice(0, n);
}

/* ========== STRUCTURED LEARN PATH ========== */
const LEARN_PATH_LEGACY = {
  beginner: [
    {
      id: "beg-1",
      title: "Unit 1: Greetings & Introductions",
      desc: "Memperkenalkan diri, sapaan formal & informal",
      tags: ["Speaking", "Vocab"],
      content: {
        type: "mixed",
        theory: "Dalam Bahasa Inggris, sapaan berubah tergantung formalitas. 'Hi/Hey' informal; 'Good morning/How do you do' lebih formal.",
        vocab: [
          { en: "Nice to meet you", id: "Senang bertemu denganmu", ex: "Nice to meet you, I'm Andi." },
          { en: "Where are you from?", id: "Kamu dari mana?", ex: "Where are you from? I'm from Jakarta." },
          { en: "What do you do?", id: "Apa pekerjaanmu?", ex: "What do you do? I'm a student." },
          { en: "Have a nice day", id: "Semoga harimu menyenangkan", ex: "Bye! Have a nice day." }
        ],
        practice: "Perkenalkan dirimu dalam 4–5 kalimat: nama, asal, jurusan, hobi."
      }
    },
    {
      id: "beg-2",
      title: "Unit 2: Daily Routines",
      desc: "Present Simple untuk kebiasaan sehari-hari",
      tags: ["Grammar", "Vocab"],
      content: {
        type: "mixed",
        theory: "Present Simple: I/You/We/They + V1; He/She/It + V1+s/es. Dipakai untuk rutinitas dan fakta.",
        vocab: [
          { en: "wake up", id: "bangun tidur", ex: "I wake up at 6 AM." },
          { en: "commute", id: "pergi kerja/kuliah", ex: "She commutes by bus." },
          { en: "usually", id: "biasanya", ex: "I usually study in the evening." },
          { en: "rarely", id: "jarang", ex: "He rarely eats fast food." }
        ],
        practice: "Tulis 5 kalimat tentang rutinitas harianmu memakai Present Simple."
      }
    },
    {
      id: "beg-3",
      title: "Unit 3: Numbers, Time & Dates",
      desc: "Menyebut waktu, tanggal, dan angka",
      tags: ["Listening", "Vocab"],
      content: {
        type: "mixed",
        theory: "Waktu: It's half past three (15:30). Tanggal: the 22nd of October. Tahun dibaca dua-dua: twenty twenty-six.",
        vocab: [
          { en: "quarter past", id: "15 menit lewat", ex: "It's quarter past nine." },
          { en: "quarter to", id: "15 menit menuju", ex: "It's quarter to ten." },
          { en: "appointment", id: "janji temu", ex: "I have an appointment at 2 PM." },
          { en: "deadline", id: "batas waktu", ex: "The deadline is next Friday." }
        ],
        practice: "Ucapkan 3 janji imajiner dengan hari dan jam yang berbeda."
      }
    },
    {
      id: "beg-4",
      title: "Unit 4: Describing People & Places",
      desc: "Adjective dasar + there is/are",
      tags: ["Writing", "Vocab"],
      content: {
        type: "mixed",
        theory: "Urutan adjective kasar: opinion → size → age → color. There is (singular) / There are (plural).",
        vocab: [
          { en: "crowded", id: "ramai/penuh", ex: "The campus is crowded in the morning." },
          { en: "spacious", id: "luas", ex: "Our classroom is spacious." },
          { en: "friendly", id: "ramah", ex: "The lecturers are friendly." },
          { en: "convenient", id: "praktis/nyaman", ex: "The dorm is convenient for students." }
        ],
        practice: "Deskripsikan kampus atau kosanmu dalam 6–8 kalimat."
      }
    },
    {
      id: "beg-5",
      title: "Unit 5: Shopping & Food",
      desc: "Dialog di kafe, restoran, toko",
      tags: ["Speaking", "Listening"],
      content: {
        type: "mixed",
        theory: "Pola order: I'd like... / Can I have... / Could I get... Polite request memakai could/would.",
        vocab: [
          { en: "I'd like...", id: "Saya mau...", ex: "I'd like a iced coffee, please." },
          { en: "bill / check", id: "tagihan", ex: "Could I have the bill, please?" },
          { en: "take away", id: "bungkus", ex: "For here or take away?" },
          { en: "change", id: "kembalian", ex: "Here's your change." }
        ],
        practice: "Simulasikan memesan makanan di kafe (4–6 giliran dialog)."
      }
    }
  ],
  intermediate: [
    {
      id: "int-1",
      title: "Unit 1: Past Experiences",
      desc: "Past Simple vs Present Perfect",
      tags: ["Grammar", "Speaking"],
      content: {
        type: "mixed",
        theory: "Past Simple = waktu spesifik selesai. Present Perfect = pengalaman / masih relevan tanpa waktu spesifik.",
        vocab: [
          { en: "have you ever...", id: "pernahkah kamu...", ex: "Have you ever been abroad?" },
          { en: "recently", id: "baru-baru ini", ex: "I've recently started yoga." },
          { en: "in the past", id: "di masa lalu", ex: "In the past, I lived in Bandung." },
          { en: "milestone", id: "tonggak penting", ex: "Graduating was a major milestone." }
        ],
        practice: "Ceritakan 2 pengalaman penting: satu dengan Past Simple, satu Present Perfect."
      }
    },
    {
      id: "int-2",
      title: "Unit 2: Opinions & Arguments",
      desc: "Memberi pendapat + supporting reasons",
      tags: ["Writing", "Speaking"],
      content: {
        type: "mixed",
        theory: "Struktur opini: claim → reason → example → mini-conclusion. Gunakan I believe / In my view / It seems that...",
        vocab: [
          { en: "from my perspective", id: "dari sudut pandang saya", ex: "From my perspective, online classes are flexible." },
          { en: "on the other hand", id: "di sisi lain", ex: "On the other hand, face-to-face is more interactive." },
          { en: "compelling", id: "meyakinkan", ex: "That's a compelling argument." },
          { en: "drawback", id: "kekurangan", ex: "One drawback is the cost." }
        ],
        practice: "Tulis paragraf opini: 'Should university be free?' (80–120 kata)."
      }
    },
    {
      id: "int-3",
      title: "Unit 3: Academic Reading Skills",
      desc: "Skimming, scanning, inference",
      tags: ["Reading"],
      content: {
        type: "mixed",
        theory: "Skimming = ide utama cepat. Scanning = cari detail spesifik. Inference = simpulkan yang tidak tertulis eksplisit.",
        vocab: [
          { en: "main idea", id: "ide pokok", ex: "The main idea of the paragraph is..." },
          { en: "supporting detail", id: "detail pendukung", ex: "Find two supporting details." },
          { en: "infer", id: "menyimpulkan", ex: "We can infer that the author disagrees." },
          { en: "tone", id: "nada tulisan", ex: "The tone is critical but fair." }
        ],
        practice: "Baca satu artikel pendek berita, tulis main idea + 2 detail + 1 inference."
      }
    },
    {
      id: "int-4",
      title: "Unit 4: Conditionals in Real Life",
      desc: "Type 0, 1, 2 untuk situasi nyata & hipotetis",
      tags: ["Grammar", "Speaking"],
      content: {
        type: "mixed",
        theory: "Type 1: real future (If + present, will). Type 2: unreal now (If + past, would). Type 0: facts (If + present, present).",
        vocab: [
          { en: "provided that", id: "asalkan", ex: "You can join provided that you register." },
          { en: "unless", id: "kecuali jika", ex: "I won't go unless it stops raining." },
          { en: "suppose", id: "andaikan", ex: "Suppose you won the lottery, what would you do?" },
          { en: "as long as", id: "selama", ex: "You can stay as long as you help." }
        ],
        practice: "Buat 2 kalimat Type 1 dan 2 Type 2 tentang rencana kuliah/karier."
      }
    },
    {
      id: "int-5",
      title: "Unit 5: Email & Formal Writing",
      desc: "Struktur email formal untuk dosen/HR",
      tags: ["Writing"],
      content: {
        type: "mixed",
        theory: "Formal email: Subject jelas → Salutation → Purpose → Body → Polite close → Sign-off (Best regards).",
        vocab: [
          { en: "I am writing to...", id: "Saya menulis untuk...", ex: "I am writing to inquire about..." },
          { en: "I would appreciate it if...", id: "Saya akan menghargai jika...", ex: "I would appreciate it if you could reply by Friday." },
          { en: "Please find attached", id: "Terlampir", ex: "Please find attached my CV." },
          { en: "at your earliest convenience", id: "secepatnya bila memungkinkan", ex: "Please respond at your earliest convenience." }
        ],
        practice: "Tulis email formal ke dosen meminta rekomendasi magang (120–150 kata)."
      }
    }
  ],
  advanced: [
    {
      id: "adv-1",
      title: "Unit 1: Academic Vocabulary",
      desc: "Academic Word List — subset penting",
      tags: ["Vocab", "Writing"],
      content: {
        type: "mixed",
        theory: "Kata akademik sering dari Latin/Greek. Gunakan nominalization: decide → decision, analyze → analysis.",
        vocab: [
          { en: "significant", id: "penting/bermakna", ex: "There was a significant increase in enrollment." },
          { en: "constitute", id: "merupakan", ex: "These factors constitute a major challenge." },
          { en: "imply", id: "menyiratkan", ex: "The data imply a causal relationship." },
          { en: "framework", id: "kerangka", ex: "We need a theoretical framework." },
          { en: "subsequent", id: "berikutnya", ex: "Subsequent studies confirmed the findings." },
          { en: "robust", id: "kuat/andal", ex: "The methodology is robust." }
        ],
        practice: "Tulis 5 kalimat akademik memakai minimal 5 kata di atas."
      }
    },
    {
      id: "adv-2",
      title: "Unit 2: Essay Structure (IELTS Task 2)",
      desc: "Intro – Body – Conclusion yang band 7+",
      tags: ["Writing"],
      content: {
        type: "mixed",
        theory: "Intro: paraphrase + thesis. Body: topic sentence + explain + example. Conclusion: ringkas stance, no new ideas.",
        vocab: [
          { en: "it is widely argued that", id: "banyak yang berpendapat bahwa", ex: "It is widely argued that technology improves education." },
          { en: "a case in point", id: "contoh yang relevan", ex: "A case in point is Finland's education system." },
          { en: "to a large extent", id: "sebagian besar", ex: "To a large extent, success depends on motivation." },
          { en: "nonetheless", id: "meskipun demikian", ex: "Nonetheless, challenges remain." }
        ],
        practice: "Outline essay 4 paragraf untuk: 'Is remote work better for productivity?'"
      }
    },
    {
      id: "adv-3",
      title: "Unit 3: Listening for Detail & Attitude",
      desc: "Ciri IELTS/TOEFL listening tingkat tinggi",
      tags: ["Listening"],
      content: {
        type: "mixed",
        theory: "Dengarkan signal: however, actually, what I mean is... Attitude: positive/negative/neutral dari tone & word choice.",
        vocab: [
          { en: "to put it another way", id: "dengan kata lain", ex: "To put it another way, we need more data." },
          { en: "frankly", id: "terus terang", ex: "Frankly, the results were disappointing." },
          { en: "underestimate", id: "meremehkan", ex: "Don't underestimate the difficulty." },
          { en: "nuance", id: "nuansa", ex: "There is an important nuance here." }
        ],
        practice: "Dengarkan satu podcast singkat (English), catat 3 detail + attitude pembicara."
      }
    },
    {
      id: "adv-4",
      title: "Unit 4: Complex Grammar for Band 7+",
      desc: "Relative clauses, inversion, conditionals type 3",
      tags: ["Grammar", "Writing"],
      content: {
        type: "mixed",
        theory: "Inversion: Not only... but also / Rarely have I... Type 3: If + past perfect, would have + V3.",
        vocab: [
          { en: "whereby", id: "yang dengannya", ex: "a system whereby students choose courses" },
          { en: "albeit", id: "meskipun", ex: "The plan worked, albeit slowly." },
          { en: "notwithstanding", id: "meski ada", ex: "Notwithstanding the risks, they proceeded." },
          { en: "insofar as", id: "sejauh", ex: "Insofar as the data allow, we conclude..." }
        ],
        practice: "Tulis 3 kalimat memakai relative clause non-defining dan 1 kalimat inversion."
      }
    },
    {
      id: "adv-5",
      title: "Unit 5: Speaking Fluency Strategies",
      desc: "Fillers alami, paraphrase, extend answers",
      tags: ["Speaking"],
      content: {
        type: "mixed",
        theory: "Hindari diam panjang: gunakan 'That's an interesting question...' / 'What I mean is...'. Extend: reason + example + contrast.",
        vocab: [
          { en: "off the top of my head", id: "secara spontan", ex: "Off the top of my head, I'd say..." },
          { en: "to be honest", id: "terus terang", ex: "To be honest, I haven't thought about it much." },
          { en: "it depends", id: "tergantung", ex: "It depends on the context." },
          { en: "for instance", id: "contohnya", ex: "For instance, in my hometown..." }
        ],
        practice: "Jawab 1 menit: 'Describe a skill you want to learn and why.'"
      }
    }
  ],
  pro: [
    {
      id: "pro-1",
      title: "Unit 1: Rhetorical Precision",
      desc: "Hedging, boosting, stance markers",
      tags: ["Writing", "Academic"],
      content: {
        type: "mixed",
        theory: "Hedging: may, might, appear to, it is likely that. Boosting: clearly, undoubtedly (pakai hemat). Stance menunjukkan posisi penulis.",
        vocab: [
          { en: "arguably", id: "bisa dibilang", ex: "Arguably, this is the most effective method." },
          { en: "tentatively", id: "secara sementara", ex: "We tentatively conclude that..." },
          { en: "it stands to reason", id: "masuk akal bahwa", ex: "It stands to reason that demand will rise." },
          { en: "caveat", id: "catatan/pembatas", ex: "One caveat is the small sample size." }
        ],
        practice: "Ubah 3 klaim kuat menjadi versi ber-hedging yang akademik."
      }
    },
    {
      id: "pro-2",
      title: "Unit 2: IELTS/TOEFL Score Push",
      desc: "Strategi band 8 / TOEFL 110+",
      tags: ["Exam"],
      content: {
        type: "mixed",
        theory: "Band 8 writing: rare errors, precise vocab, fully developed ideas. Speaking: flexible structures, natural pace, clear pronunciation.",
        vocab: [
          { en: "calibrated", id: "terselaras", ex: "a carefully calibrated argument" },
          { en: "salient", id: "menonjol/penting", ex: "the most salient point" },
          { en: "nuance", id: "nuansa", ex: "appreciate the nuance" },
          { en: "articulate", id: "mengungkapkan dengan jelas", ex: "She articulated her position clearly." }
        ],
        practice: "Revisi satu paragraph essay lama: ganti 5 kata biasa dengan pilihan lebih precise."
      }
    },
    {
      id: "pro-3",
      title: "Unit 3: Debate & Critical Response",
      desc: "Menanggapi argumen lawan secara elegan",
      tags: ["Speaking", "Writing"],
      content: {
        type: "mixed",
        theory: "Concession + rebuttal: 'While it is true that..., this overlooks...' Steelman lawan dulu, baru kritik.",
        vocab: [
          { en: "on the contrary", id: "sebaliknya", ex: "On the contrary, the evidence suggests..." },
          { en: "this overlooks", id: "ini mengabaikan", ex: "This overlooks demographic change." },
          { en: "a more plausible explanation", id: "penjelasan lebih masuk akal", ex: "A more plausible explanation is..." },
          { en: "granting that", id: "meski mengakui bahwa", ex: "Granting that costs are high, benefits outweigh them." }
        ],
        practice: "Tulis rebuttal 100 kata terhadap: 'Social media only harms students.'"
      }
    },
    {
      id: "pro-4",
      title: "Unit 4: Style & Register Control",
      desc: "Beralih formal ↔ semi-formal dengan tepat",
      tags: ["Writing"],
      content: {
        type: "mixed",
        theory: "Academic: avoid contractions, phrasal verbs berlebih, dan 'get'. Prefer: obtain, demonstrate, indicate, constitute.",
        vocab: [
          { en: "get better → improve", id: "menjadi lebih baik", ex: "Results improved significantly." },
          { en: "find out → determine", id: "menemukan", ex: "The study determined the cause." },
          { en: "a lot of → a substantial number of", id: "banyak", ex: "A substantial number of participants..." },
          { en: "about → approximately", id: "kira-kira", ex: "Approximately 40% agreed." }
        ],
        practice: "Ubah paragraf informal menjadi register akademik (min. 80 kata)."
      }
    }
  ]
};

const VOCAB_BANK = {
  beginner: [
    // Part 1: Daily Life
    { en: "appointment", id: "janji temu", ex: "I have an appointment at 3.", type: "Daily Life" },
    { en: "borrow", id: "meminjam", ex: "Can I borrow your pen?", type: "Daily Life" },
    { en: "careful", id: "hati-hati", ex: "Be careful on the road.", type: "Daily Life" },
    { en: "delicious", id: "enak", ex: "This food is delicious.", type: "Daily Life" },
    { en: "emergency", id: "darurat", ex: "Call 119 in an emergency.", type: "Daily Life" },
    { en: "furniture", id: "perabot", ex: "We need new furniture.", type: "Daily Life" },
    { en: "hungry", id: "lapar", ex: "I'm hungry after class.", type: "Daily Life" },
    { en: "invite", id: "mengundang", ex: "I'd like to invite you.", type: "Daily Life" },
    { en: "journey", id: "perjalanan", ex: "Have a safe journey.", type: "Daily Life" },
    { en: "quiet", id: "tenang", ex: "The library is quiet.", type: "Daily Life" },
    { en: "schedule", id: "jadwal", ex: "My class schedule is busy.", type: "Daily Life" },
    { en: "useful", id: "berguna", ex: "This dictionary is useful.", type: "Daily Life" },
    { en: "breakfast", id: "sarapan", ex: "I eat breakfast at seven.", type: "Daily Life" },
    { en: "neighbour", id: "tetangga", ex: "My neighbour is friendly.", type: "Daily Life" },
    { en: "umbrella", id: "payung", ex: "Take an umbrella; it might rain.", type: "Daily Life" },
    // Part 2: School & Study
    { en: "achieve", id: "mencapai", ex: "I want to achieve my goals.", type: "School & Study" },
    { en: "advice", id: "saran", ex: "My teacher gave me useful advice.", type: "School & Study" },
    { en: "arrive", id: "tiba", ex: "We arrive at school at seven.", type: "School & Study" },
    { en: "choose", id: "memilih", ex: "Choose the answer carefully.", type: "School & Study" },
    { en: "comfortable", id: "nyaman", ex: "This chair is comfortable.", type: "School & Study" },
    { en: "decide", id: "memutuskan", ex: "I need time to decide.", type: "School & Study" },
    { en: "discover", id: "menemukan", ex: "We discovered a new place.", type: "School & Study" },
    { en: "explain", id: "menjelaskan", ex: "Can you explain this rule?", type: "School & Study" },
    { en: "improve", id: "meningkatkan", ex: "Practice can improve your English.", type: "School & Study" },
    { en: "prepare", id: "mempersiapkan", ex: "I prepare my books every night.", type: "School & Study" },
    { en: "remember", id: "mengingat", ex: "Remember to bring your notebook.", type: "School & Study" },
    { en: "suggest", id: "menyarankan", ex: "I suggest taking a short break.", type: "School & Study" },
    { en: "homework", id: "PR / tugas rumah", ex: "I finished my homework early.", type: "School & Study" },
    { en: "exam", id: "ujian", ex: "The exam is next Monday.", type: "School & Study" },
    { en: "dictionary", id: "kamus", ex: "Look up the word in a dictionary.", type: "School & Study" },
    // Part 3: Feelings & People
    { en: "generous", id: "dermawan", ex: "She is very generous.", type: "Feelings & People" },
    { en: "brave", id: "berani", ex: "The firefighter was brave.", type: "Feelings & People" },
    { en: "friendly", id: "ramah", ex: "Everyone was friendly to me.", type: "Feelings & People" },
    { en: "nervous", id: "gugup", ex: "I feel nervous before speaking.", type: "Feelings & People" },
    { en: "proud", id: "bangga", ex: "I am proud of my progress.", type: "Feelings & People" },
    { en: "tired", id: "lelah", ex: "I am tired after studying all day.", type: "Feelings & People" },
    { en: "patient", id: "sabar", ex: "Please be patient with beginners.", type: "Feelings & People" },
    { en: "honest", id: "jujur", ex: "An honest answer is always best.", type: "Feelings & People" },
    { en: "curious", id: "penasaran", ex: "Children are naturally curious.", type: "Feelings & People" },
    { en: "confident", id: "percaya diri", ex: "Practice makes you more confident.", type: "Feelings & People" }
  ],
  intermediate: [
    // Part 1: Academic & Work
    { en: "achieve", id: "mencapai", ex: "She achieved her goals.", type: "Academic & Work" },
    { en: "benefit", id: "manfaat", ex: "Exercise has many benefits.", type: "Academic & Work" },
    { en: "consequence", id: "akibat", ex: "Think about the consequences.", type: "Academic & Work" },
    { en: "efficient", id: "efisien", ex: "This method is more efficient.", type: "Academic & Work" },
    { en: "frequent", id: "sering", ex: "He makes frequent trips.", type: "Academic & Work" },
    { en: "indicate", id: "menunjukkan", ex: "The results indicate progress.", type: "Academic & Work" },
    { en: "maintain", id: "mempertahankan", ex: "Maintain a healthy diet.", type: "Academic & Work" },
    { en: "opportunity", id: "kesempatan", ex: "This is a great opportunity.", type: "Academic & Work" },
    { en: "prefer", id: "lebih suka", ex: "I prefer tea to coffee.", type: "Academic & Work" },
    { en: "require", id: "memerlukan", ex: "The job requires experience.", type: "Academic & Work" },
    { en: "accurate", id: "akurat", ex: "Please provide accurate information.", type: "Academic & Work" },
    { en: "approach", id: "pendekatan", ex: "We need a different approach.", type: "Academic & Work" },
    { en: "aware", id: "menyadari", ex: "Students should be aware of the risks.", type: "Academic & Work" },
    { en: "challenge", id: "tantangan", ex: "Learning a language is a challenge.", type: "Academic & Work" },
    { en: "contribute", id: "berkontribusi", ex: "Everyone can contribute to the project.", type: "Academic & Work" },
    // Part 2: Ideas & Analysis
    { en: "evidence", id: "bukti", ex: "The evidence supports the conclusion.", type: "Ideas & Analysis" },
    { en: "impact", id: "dampak", ex: "Technology has an impact on education.", type: "Ideas & Analysis" },
    { en: "occur", id: "terjadi", ex: "Errors can occur during testing.", type: "Ideas & Analysis" },
    { en: "reliable", id: "dapat diandalkan", ex: "Use a reliable source.", type: "Ideas & Analysis" },
    { en: "significant", id: "signifikan", ex: "There was a significant improvement.", type: "Ideas & Analysis" },
    { en: "specific", id: "spesifik", ex: "Please give a specific example.", type: "Ideas & Analysis" },
    { en: "strategy", id: "strategi", ex: "We developed a study strategy.", type: "Ideas & Analysis" },
    { en: "therefore", id: "oleh karena itu", ex: "It was raining; therefore, we stayed inside.", type: "Ideas & Analysis" },
    { en: "analyze", id: "menganalisis", ex: "We need to analyze the data carefully.", type: "Ideas & Analysis" },
    { en: "compare", id: "membandingkan", ex: "Compare the two essays.", type: "Ideas & Analysis" },
    { en: "conclude", id: "menyimpulkan", ex: "What can we conclude from this?", type: "Ideas & Analysis" },
    { en: "define", id: "mendefinisikan", ex: "Can you define this term?", type: "Ideas & Analysis" },
    { en: "evaluate", id: "mengevaluasi", ex: "Evaluate the advantages and disadvantages.", type: "Ideas & Analysis" },
    { en: "summarize", id: "meringkas", ex: "Summarize the main points in three sentences.", type: "Ideas & Analysis" },
    { en: "persuade", id: "membujuk / meyakinkan", ex: "The speaker tried to persuade the audience.", type: "Ideas & Analysis" },
    // Part 3: Communication
    { en: "clarify", id: "memperjelas", ex: "Could you clarify your point?", type: "Communication" },
    { en: "discuss", id: "mendiskusikan", ex: "Let's discuss the problem together.", type: "Communication" },
    { en: "express", id: "mengekspresikan", ex: "She expressed her opinion clearly.", type: "Communication" },
    { en: "mention", id: "menyebutkan", ex: "He didn't mention the deadline.", type: "Communication" },
    { en: "respond", id: "menanggapi", ex: "Please respond to the email today.", type: "Communication" },
    { en: "suggest", id: "menyarankan", ex: "I suggest we start earlier.", type: "Communication" },
    { en: "negotiate", id: "bernegosiasi", ex: "They negotiated a better deal.", type: "Communication" },
    { en: "present", id: "mempresentasikan", ex: "She presented her research findings.", type: "Communication" },
    { en: "argue", id: "berargumen", ex: "He argued that the policy was unfair.", type: "Communication" },
    { en: "emphasize", id: "menekankan", ex: "The teacher emphasized the importance of practice.", type: "Communication" }
  ],
  advanced: [
    // Part 1: Academic Precision
    { en: "ambiguous", id: "ambigu", ex: "The statement is ambiguous.", type: "Academic Precision" },
    { en: "compel", id: "memaksa/mendesak", ex: "The evidence compelled him to act.", type: "Academic Precision" },
    { en: "diminish", id: "berkurang", ex: "Trust can diminish quickly.", type: "Academic Precision" },
    { en: "elaborate", id: "merinci", ex: "Could you elaborate on that?", type: "Academic Precision" },
    { en: "feasible", id: "layak dilakukan", ex: "Is this plan feasible?", type: "Academic Precision" },
    { en: "hypothesis", id: "hipotesis", ex: "We tested the hypothesis.", type: "Academic Precision" },
    { en: "inevitable", id: "tidak terelakkan", ex: "Change is inevitable.", type: "Academic Precision" },
    { en: "justify", id: "membenarkan", ex: "How do you justify this decision?", type: "Academic Precision" },
    { en: "notion", id: "gagasan", ex: "The notion of freedom varies.", type: "Academic Precision" },
    { en: "reluctant", id: "enggan", ex: "He was reluctant to agree.", type: "Academic Precision" },
    { en: "coherent", id: "koheren / runtut", ex: "Her argument is coherent.", type: "Academic Precision" },
    { en: "compelling", id: "meyakinkan", ex: "He presented a compelling case.", type: "Academic Precision" },
    { en: "derive", id: "memperoleh / menurunkan", ex: "We can derive a formula from the pattern.", type: "Academic Precision" },
    { en: "discrepancy", id: "ketidaksesuaian", ex: "The report contains a discrepancy.", type: "Academic Precision" },
    { en: "empirical", id: "empiris", ex: "The claim needs empirical evidence.", type: "Academic Precision" },
    // Part 2: Analysis & Causation
    { en: "facilitate", id: "memfasilitasi", ex: "Visual aids facilitate understanding.", type: "Analysis & Causation" },
    { en: "inherent", id: "melekat", ex: "Every method has inherent limitations.", type: "Analysis & Causation" },
    { en: "interpret", id: "menafsirkan", ex: "Readers may interpret the phrase differently.", type: "Analysis & Causation" },
    { en: "mitigate", id: "mengurangi dampak", ex: "Trees can mitigate urban heat.", type: "Analysis & Causation" },
    { en: "plausible", id: "masuk akal", ex: "That is a plausible explanation.", type: "Analysis & Causation" },
    { en: "predominantly", id: "sebagian besar", ex: "The class is predominantly online.", type: "Analysis & Causation" },
    { en: "rigorous", id: "ketat / teliti", ex: "The study uses rigorous methods.", type: "Analysis & Causation" },
    { en: "subsequent", id: "berikutnya", ex: "Subsequent research confirmed the result.", type: "Analysis & Causation" },
    { en: "underlying", id: "mendasari", ex: "We must understand the underlying cause.", type: "Analysis & Causation" },
    { en: "correlate", id: "berkorelasi", ex: "Does stress correlate with performance?", type: "Analysis & Causation" },
    { en: "exacerbate", id: "memperburuk", ex: "Poor sleep can exacerbate anxiety.", type: "Analysis & Causation" },
    { en: "fluctuate", id: "berfluktuasi", ex: "Prices fluctuate throughout the year.", type: "Analysis & Causation" },
    { en: "infer", id: "menyimpulkan", ex: "We can infer the meaning from context.", type: "Analysis & Causation" },
    { en: "presume", id: "menganggap / berasumsi", ex: "I presume you have read the article.", type: "Analysis & Causation" },
    { en: "validate", id: "memvalidasi", ex: "The experiment validates the theory.", type: "Analysis & Causation" },
    // Part 3: Formal Expression
    { en: "acknowledge", id: "mengakui", ex: "She acknowledged the contribution of her team.", type: "Formal Expression" },
    { en: "advocate", id: "menganjurkan", ex: "Many experts advocate lifelong learning.", type: "Formal Expression" },
    { en: "assert", id: "menegaskan", ex: "He asserted that the data were reliable.", type: "Formal Expression" },
    { en: "contend", id: "berpendapat / berargumen", ex: "Critics contend that the policy is unfair.", type: "Formal Expression" },
    { en: "demonstrate", id: "menunjukkan / membuktikan", ex: "The results demonstrate clear improvement.", type: "Formal Expression" },
    { en: "emphasize", id: "menekankan", ex: "The report emphasizes the need for reform.", type: "Formal Expression" },
    { en: "illustrate", id: "mengilustrasikan", ex: "This example illustrates the main point.", type: "Formal Expression" },
    { en: "outline", id: "menguraikan secara garis besar", ex: "The chapter outlines the key theories.", type: "Formal Expression" },
    { en: "propose", id: "mengusulkan", ex: "They propose a new framework.", type: "Formal Expression" },
    { en: "undermine", id: "melemahkan", ex: "The scandal could undermine public trust.", type: "Formal Expression" }
  ],
  pro: [
    // Part 1: High-level Academic
    { en: "albeit", id: "meskipun", ex: "The plan worked, albeit slowly.", type: "High-level Academic" },
    { en: "corollary", id: "akibat wajar", ex: "A corollary of the theory is...", type: "High-level Academic" },
    { en: "ephemeral", id: "sementara/fana", ex: "Fame can be ephemeral.", type: "High-level Academic" },
    { en: "juxtapose", id: "menjajarkan", ex: "The film juxtaposes past and present.", type: "High-level Academic" },
    { en: "nuance", id: "nuansa", ex: "Appreciate the nuance in her argument.", type: "High-level Academic" },
    { en: "paradigm", id: "paradigma", ex: "A new paradigm in education.", type: "High-level Academic" },
    { en: "pragmatic", id: "pragmatis", ex: "We need a pragmatic solution.", type: "High-level Academic" },
    { en: "quintessential", id: "paling khas", ex: "She is the quintessential leader.", type: "High-level Academic" },
    { en: "substantiate", id: "membuktikan", ex: "Can you substantiate this claim?", type: "High-level Academic" },
    { en: "ubiquitous", id: "ada di mana-mana", ex: "Smartphones are ubiquitous.", type: "High-level Academic" },
    { en: "aberration", id: "penyimpangan", ex: "The result was an aberration rather than a trend.", type: "High-level Academic" },
    { en: "ameliorate", id: "memperbaiki", ex: "The policy aims to ameliorate inequality.", type: "High-level Academic" },
    { en: "conundrum", id: "persoalan rumit", ex: "Researchers face a difficult conundrum.", type: "High-level Academic" },
    { en: "delineate", id: "menguraikan dengan jelas", ex: "The paper delineates the main arguments.", type: "High-level Academic" },
    { en: "disseminate", id: "menyebarluaskan", ex: "Universities disseminate research findings.", type: "High-level Academic" },
    // Part 2: Critical & Sophisticated
    { en: "exacerbate", id: "memperburuk", ex: "Poor planning may exacerbate the problem.", type: "Critical & Sophisticated" },
    { en: "incontrovertible", id: "tak terbantahkan", ex: "The data provide incontrovertible evidence.", type: "Critical & Sophisticated" },
    { en: "ostensibly", id: "tampaknya", ex: "The ostensibly simple task was complex.", type: "Critical & Sophisticated" },
    { en: "paradigmatic", id: "bersifat paradigma", ex: "The case became paradigmatic in the field.", type: "Critical & Sophisticated" },
    { en: "pervasive", id: "meluas", ex: "Digital media has a pervasive influence.", type: "Critical & Sophisticated" },
    { en: "prescient", id: "berpandangan jauh", ex: "Her prescient warning proved accurate.", type: "Critical & Sophisticated" },
    { en: "reconcile", id: "menyelaraskan", ex: "We must reconcile theory with evidence.", type: "Critical & Sophisticated" },
    { en: "scrutinize", id: "menelaah dengan cermat", ex: "The committee will scrutinize the proposal.", type: "Critical & Sophisticated" },
    { en: "tenuous", id: "lemah / rapuh", ex: "The connection between them is tenuous.", type: "Critical & Sophisticated" },
    { en: "unequivocal", id: "tegas dan tidak ambigu", ex: "The results offer unequivocal support.", type: "Critical & Sophisticated" },
    { en: "arbitrary", id: "sewenang-wenang", ex: "The decision seemed arbitrary.", type: "Critical & Sophisticated" },
    { en: "dichotomy", id: "dikotomi", ex: "There is a false dichotomy between theory and practice.", type: "Critical & Sophisticated" },
    { en: "equivocal", id: "mendua / tidak tegas", ex: "His response was deliberately equivocal.", type: "Critical & Sophisticated" },
    { en: "idiosyncratic", id: "khas / unik", ex: "Her writing style is highly idiosyncratic.", type: "Critical & Sophisticated" },
    { en: "salient", id: "menonjol / penting", ex: "The most salient point is the lack of evidence.", type: "Critical & Sophisticated" },
    // Part 3: Discourse Markers & Nuance
    { en: "nevertheless", id: "meskipun demikian", ex: "The task was difficult; nevertheless, she succeeded.", type: "Discourse & Nuance" },
    { en: "notwithstanding", id: "meskipun", ex: "Notwithstanding the challenges, progress was made.", type: "Discourse & Nuance" },
    { en: "whereby", id: "dengan mana", ex: "They created a system whereby students can track progress.", type: "Discourse & Nuance" },
    { en: "insofar as", id: "sejauh", ex: "The claim is true insofar as the data allow.", type: "Discourse & Nuance" },
    { en: "hitherto", id: "sampai sekarang", ex: "This is a hitherto unexplored area.", type: "Discourse & Nuance" },
    { en: "henceforth", id: "mulai sekarang", ex: "Henceforth, all submissions must be digital.", type: "Discourse & Nuance" },
    { en: "albeit", id: "meskipun", ex: "The solution is effective, albeit temporary.", type: "Discourse & Nuance" },
    { en: "vis-à-vis", id: "berkenaan dengan / dibanding", ex: "How does this policy perform vis-à-vis previous ones?", type: "Discourse & Nuance" },
    { en: "ipso facto", id: "dengan sendirinya", ex: "The contract was void, ipso facto.", type: "Discourse & Nuance" },
    { en: "per se", id: "pada dirinya sendiri", ex: "The method is not flawed per se.", type: "Discourse & Nuance" }
  ]
};




// Expand curriculum — more units per level

// expandLearnPath disabled — CEFR curriculum in curriculum.js
