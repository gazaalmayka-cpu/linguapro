/* ========== LinguaPro App Logic ========== */

const USERS_KEY = "linguapro_users";
const SESSION_KEY = "linguapro_session";

function getUsers() {
  try { return JSON.parse(localStorage.getItem(USERS_KEY) || "{}"); } catch { return {}; }
}
function saveUsers(u) { localStorage.setItem(USERS_KEY, JSON.stringify(u)); }
function getSessionUser() { return localStorage.getItem(SESSION_KEY) || ""; }
function setSession(username) { localStorage.setItem(SESSION_KEY, username); }
function clearSession() { localStorage.removeItem(SESSION_KEY); }

function defaultUserData(name, username) {
  return {
    name: name || "",
    username: username || "",
    level: "a1",
    unlockedLevels: ["a1"],
    xp: 0,
    streak: 0,
    badges: [],
    recommendedUnitId: null,
    recommendedUnitTitle: null,
    lastStudyDate: null,
    lessonsCompleted: [],
    goals: [],
    mockHistory: [],
    placementDone: false,
    placementScore: 0,
    bestMock: null,
    levelTestsPassed: [],
    vocabMastered: [],
    unitRecords: {},
    mistakes: [],
    learningTrack: null
  };
}

function loadState() {
  const username = getSessionUser();
  if (!username) return defaultUserData("", "");
  const users = getUsers();
  if (!users[username]) return defaultUserData("", "");
  return { ...defaultUserData(users[username].name, username), ...(users[username].data || {}) };
}

function saveState() {
  const username = state.username || getSessionUser();
  if (!username) return;
  const users = getUsers();
  if (!users[username]) return;
  users[username].name = state.name;
  users[username].data = { ...state };
  saveUsers(users);
}

function isLevelUnlocked(level) {
  return (state.unlockedLevels || ["beginner"]).includes(level);
}

function levelUnitProgress(level) {
  const units = (typeof LEARN_PATH !== "undefined" && LEARN_PATH[level]) ? LEARN_PATH[level] : [];
  if (!units.length) return 0;
  const done = units.filter(u => (state.lessonsCompleted || []).includes(u.id)).length;
  return Math.round((done / units.length) * 100);
}

function isReadyForLevelExam(level) {
  return levelUnitProgress(level) >= 70;
}

/** Stricter objective speaking score */
function objectiveSpeakingScore(text, themeKeywords) {
  const words = (text || "").trim().split(/\s+/).filter(Boolean);
  const n = words.length;
  const lower = (text || "").toLowerCase();
  let band = 3.0;
  const tips = [];
  if (n >= 80) band += 1.5;
  else if (n >= 50) band += 1.0;
  else if (n >= 30) band += 0.5;
  else if (n >= 15) band += 0.25;
  else tips.push("Jawaban terlalu pendek (target Part 2: 50–90+ kata).");

  const kws = (themeKeywords || []).map(k => String(k).toLowerCase()).filter(Boolean);
  let hits = 0;
  kws.forEach(k => { if (lower.includes(k)) hits++; });
  const rel = kws.length ? hits / kws.length : 0.5;
  if (rel >= 0.4) band += 1.2;
  else if (rel >= 0.2) band += 0.5;
  else if (rel > 0) band += 0.15;
  else { band -= 0.6; tips.push("Kurang sesuai tema pertanyaan — skor turun."); }

  if (/\b(because|which|that|when|if|although|while|however)\b/i.test(text)) band += 0.55;
  else tips.push("Tambah complex sentences.");
  if (/\b(would|could|should|might)\b/i.test(text)) band += 0.3;
  if (/\b(have|has|had)\s+\w+/i.test(text)) band += 0.25;

  const uniq = new Set(words.map(w => w.toLowerCase().replace(/[^a-z']/g, "")));
  const ratio = uniq.size / Math.max(n, 1);
  if (ratio > 0.7 && n > 20) band += 0.65;
  else if (ratio > 0.5) band += 0.3;
  else tips.push("Vocabulary kurang variatif.");

  const fillers = (lower.match(/\b(um+|uh+|like|you know)\b/g) || []).length;
  if (fillers > 5) { band -= 0.35; tips.push("Kurangi filler (um, like)."); }

  band = Math.max(2.0, Math.min(9.0, Math.round(band * 2) / 2));
  return { band, tips, n, hits, totalKw: kws.length };
}

let state = loadState();
let placementIndex = 0;
let placementAnswers = [];
let placementPool = [];
let currentPractice = null;
let currentMock = null;
let callState = null;
let callRec = null;
let callSeconds = 0;
let callTimerInt = null;
let callTranscriptBuf = "";
let speechRecognition = null;
let mockTimerInterval = null;
let mockTimeLeft = 0;
let speechUtterance = null;

// ---------- Init ----------
document.addEventListener("DOMContentLoaded", () => {
  setTimeout(() => {
    document.getElementById("loading-screen").classList.add("hidden");
    const username = getSessionUser();
    state = loadState();
    if (username && state.placementDone && state.name) {
      showApp();
    } else if (username && state.name && !state.placementDone) {
      document.getElementById("onboarding").classList.remove("hidden");
      document.getElementById("step-auth").classList.add("hidden");
      document.getElementById("step-placement").classList.remove("hidden");
      placementPool = buildPlacementPool(15);
      placementIndex = 0;
      placementAnswers = new Array(placementPool.length).fill(null);
      renderPlacementQuestion();
    } else {
      document.getElementById("onboarding").classList.remove("hidden");
      document.getElementById("step-auth").classList.remove("hidden");
    }
  }, 1200);

  // Nav
  document.querySelectorAll(".nav-item").forEach(item => {
    item.addEventListener("click", (e) => {
      e.preventDefault();
      navigateTo(item.dataset.page);
    });
  });

  // Grammar tabs
  document.querySelectorAll("#grammar-tabs .tab").forEach(tab => {
    tab.addEventListener("click", () => {
      document.querySelectorAll("#grammar-tabs .tab").forEach(t => t.classList.remove("active"));
      tab.classList.add("active");
      renderGrammar(tab.dataset.level);
    });
  });

  // Mock tabs
  document.querySelectorAll(".mock-tabs .tab").forEach(tab => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".mock-tabs .tab").forEach(t => t.classList.remove("active"));
      tab.classList.add("active");
      const type = tab.dataset.test;
      document.querySelectorAll(".mock-card").forEach(c => {
        c.style.display = c.dataset.type === type ? "block" : "none";
      });
    });
  });
});

// ---------- Onboarding ----------
function showAuthTab(tab) {
  document.getElementById("tab-login").classList.toggle("active", tab === "login");
  document.getElementById("tab-register").classList.toggle("active", tab === "register");
  document.getElementById("auth-login").classList.toggle("hidden", tab !== "login");
  document.getElementById("auth-register").classList.toggle("hidden", tab !== "register");
}

function doRegister() {
  const name = (document.getElementById("reg-name").value || "").trim();
  const username = (document.getElementById("reg-username").value || "").trim().toLowerCase().replace(/\s+/g, "");
  const pass = document.getElementById("reg-pass").value || "";
  if (!name || !username || pass.length < 6) {
    showToast("Isi nama, username, dan password min. 6 karakter!", "error");
    return;
  }
  if (!/^[a-z0-9._-]{3,24}$/.test(username)) {
    showToast("Username 3–24 karakter: huruf, angka, titik, underscore, atau strip saja.", "error");
    return;
  }
  const users = getUsers();
  if (users[username]) {
    showToast("Username sudah terdaftar! Silakan masuk.", "error");
    showAuthTab("login");
    document.getElementById("login-username").value = username;
    return;
  }
  const data = defaultUserData(name, username);
  users[username] = { name, pass, data };
  saveUsers(users);
  setSession(username);
  state = { ...data };
  saveState();
  showToast("Akun berhasil dibuat!", "success");
  document.getElementById("step-auth").classList.add("hidden");
  startPlacementFlow();
}

function doLogin() {
  const username = (document.getElementById("login-username").value || "").trim().toLowerCase().replace(/\s+/g, "");
  const pass = document.getElementById("login-pass").value || "";
  const users = getUsers();
  if (!users[username] || users[username].pass !== pass) {
    showToast("Username atau password salah!", "error");
    return;
  }
  setSession(username);
  state = { ...defaultUserData(users[username].name, username), ...(users[username].data || {}) };
  if (state.placementDone) {
    document.getElementById("onboarding").classList.add("hidden");
    showApp();
  } else {
    document.getElementById("step-auth").classList.add("hidden");
    startPlacementFlow();
  }
  showToast("Selamat datang kembali, " + state.name + "!", "success");
}

function doLogout() {
  if (!confirm("Logout dari akun ini?")) return;
  clearSession();
  location.reload();
}

function startPlacementFlow() {
  document.getElementById("step-placement").classList.remove("hidden");
  // Ambil 15 soal acak dari bank yang lebih besar agar soal berubah-ubah setiap kali
  placementPool = buildPlacementPool(15);
  placementIndex = 0;
  placementAnswers = new Array(placementPool.length).fill(null);
  renderPlacementQuestion();
}


function buildPlacementPool(n = 15) {
  const all = (typeof PLACEMENT_QUESTIONS !== "undefined" && Array.isArray(PLACEMENT_QUESTIONS))
    ? PLACEMENT_QUESTIONS.slice()
    : [];
  if (!all.length) {
    console.warn("PLACEMENT_QUESTIONS empty");
    return [];
  }
  if (typeof shuffle !== "function") {
    return all.slice(0, n).map(normalizePlacementQ);
  }
  const byType = { grammar: [], vocab: [], reading: [], other: [] };
  all.forEach(q => {
    const t = String(q.type || "other").toLowerCase();
    (byType[t] || byType.other).push(q);
  });
  Object.keys(byType).forEach(k => { byType[k] = shuffle(byType[k].slice()); });
  let picked = [];
  picked = picked.concat(byType.grammar.slice(0, 5));
  picked = picked.concat(byType.vocab.slice(0, 5));
  picked = picked.concat(byType.reading.slice(0, 5));
  const used = new Set(picked);
  const rest = shuffle(all.filter(q => !used.has(q)));
  while (picked.length < Math.min(n, all.length) && rest.length) picked.push(rest.shift());
  picked = shuffle(picked).slice(0, Math.min(n, picked.length));
  return picked.map(normalizePlacementQ);
}

function normalizePlacementQ(q) {
  const text = q.question || q.q || "";
  const options = (q.options || []).slice();
  let correct = typeof q.correct === "number" ? q.correct : 0;
  // shuffle options
  if (typeof shuffle === "function" && options.length) {
    const pairs = options.map((o, i) => ({ o, i }));
    const sh = shuffle(pairs);
    correct = sh.findIndex(x => x.i === correct);
    if (correct < 0) correct = 0;
    return {
      type: q.type || "grammar",
      question: text,
      q: text,
      passage: q.passage || null,
      options: sh.map(x => x.o),
      correct
    };
  }
  return {
    type: q.type || "grammar",
    question: text,
    q: text,
    passage: q.passage || null,
    options,
    correct
  };
}

function renderPlacementQuestion() {
  const container = document.getElementById("placement-question");
  if (!placementPool || !placementPool.length) {
    placementPool = buildPlacementPool(15);
    placementIndex = 0;
    placementAnswers = new Array(placementPool.length).fill(null);
  }
  if (!placementPool.length) {
    if (container) container.innerHTML = `<p style="color:#1e293b;padding:16px;">Bank soal placement kosong. Refresh halaman atau upload data.js terbaru.</p>`;
    return;
  }
  if (placementIndex >= placementPool.length) placementIndex = 0;
  const q = placementPool[placementIndex];
  const total = placementPool.length;
  if (!q) {
    if (container) container.innerHTML = `<p style="color:#1e293b;">Soal tidak ditemukan.</p>`;
    return;
  }
  let html = `<div class="q-number">Soal ${placementIndex + 1} · ${String(q.type || "grammar").toUpperCase()}</div>`;
  if (q.passage) {
    html += `<div class="placement-passage" style="margin-bottom:16px;font-size:0.98rem;line-height:1.65;background:#f1f5f9;color:#0f172a;border-radius:12px;padding:16px;border:1px solid #e2e8f0;"><strong style="color:#4f46e5;display:block;margin-bottom:8px;">Reading passage</strong><span style="color:#0f172a;">${q.passage}</span></div>`;
  }
  html += `<div class="q-text">${q.question || q.q || ""}</div>`;
  q.options.forEach((opt, i) => {
    const selected = placementAnswers[placementIndex] === i ? "selected" : "";
    html += `<div class="option ${selected}" onclick="selectPlacement(${i})">
      <span class="opt-letter">${String.fromCharCode(65 + i)}</span>
      <span>${opt}</span>
    </div>`;
  });
  container.innerHTML = html;

  document.getElementById("placement-bar").style.width = `${((placementIndex + 1) / total) * 100}%`;
  document.getElementById("placement-counter").textContent = `${placementIndex + 1} / ${total}`;
  document.getElementById("btn-prev-placement").disabled = placementIndex === 0;
  document.getElementById("btn-next-placement").textContent =
    placementIndex === total - 1 ? "Selesai ✓" : "Selanjutnya";
}

function selectPlacement(idx) {
  placementAnswers[placementIndex] = idx;
  renderPlacementQuestion();
}

function prevPlacement() {
  if (placementIndex > 0) {
    placementIndex--;
    renderPlacementQuestion();
  }
}

function nextPlacement() {
  if (placementAnswers[placementIndex] === null) {
    showToast("Pilih jawaban dulu!", "error");
    return;
  }
  if (placementIndex < placementPool.length - 1) {
    placementIndex++;
    renderPlacementQuestion();
  } else {
    finishPlacement();
  }
}

function finishPlacement() {
  let score = 0;
  placementPool.forEach((q, i) => {
    if (placementAnswers[i] === q.correct) score++;
  });
  state.placementScore = score;
  state.placementDone = true;

  const order = (typeof CEFR_ORDER !== "undefined") ? CEFR_ORDER : ["a1","a2","b1","b2","c1","c2"];
  if (score <= 4) state.level = "a1";
  else if (score <= 7) state.level = "a2";
  else if (score <= 10) state.level = "b1";
  else if (score <= 12) state.level = "b2";
  else if (score <= 14) state.level = "c1";
  else state.level = "c2";

  const idx = order.indexOf(state.level);
  state.unlockedLevels = order.slice(0, Math.max(0, idx) + 1);

  state.xp += score * 5;
  saveState();

  document.getElementById("step-placement").classList.add("hidden");
  document.getElementById("step-result").classList.remove("hidden");
  document.getElementById("result-level").textContent = capitalize(state.level);
  document.getElementById("result-score").textContent = score;

  const descs = {
    a1: "Kamu di tahap fondasi (A1). Mulai dari alphabet, greetings, dan simple present. Semangat!",
    a2: "Dasar sudah terbentuk (A2). Lanjutkan ke past simple, future, dan modal verbs.",
    b1: "Level intermediate (B1). Saatnya present perfect, conditional, dan opinion writing.",
    b2: "Upper-intermediate (B2). Fokus argumen, passive formal, dan reported speech.",
    c1: "Advanced (C1). Latih gaya akademik, hedging, dan critical response.",
    c2: "Proficiency (C2). Asah nuance, register shift, dan synthesis writing."
  };

  // Recommend first incomplete unit on this level
  let recTitle = null, recId = null;
  try {
    const path = (typeof LEARN_PATH !== "undefined" && LEARN_PATH[state.level]) ? LEARN_PATH[state.level] : [];
    const first = path.find(u => !(state.lessonsCompleted || []).includes(u.id)) || path[0];
    if (first) {
      recId = first.id;
      recTitle = first.title;
      state.recommendedUnitId = recId;
      state.recommendedUnitTitle = recTitle;
    }
  } catch (e) {}

  const descEl = document.getElementById("result-desc");
  let desc = descs[state.level] || "Lanjutkan belajar sesuai levelmu.";
  if (recTitle) {
    desc += " Rekomendasi unit pertama: " + recTitle + ".";
  }
  if (descEl) descEl.textContent = desc;
  checkAndAwardBadges();
}

function goToDashboard() {
  document.getElementById("onboarding").classList.add("hidden");
  showApp();
}

function showApp() {
  document.getElementById("app").classList.remove("hidden");
  updateUI();
  navigateTo("dashboard");
  updateStreak();
}

// ---------- Navigation ----------
function navigateTo(page) {
  document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
  document.querySelectorAll(".nav-item").forEach(n => n.classList.remove("active"));
  const pageEl = document.getElementById(`page-${page}`);
  if (pageEl) pageEl.classList.add("active");
  const nav = document.querySelector(`.nav-item[data-page="${page}"]`);
  if (nav) nav.classList.add("active");

  if (page === "dashboard") renderDashboard();
  if (page === "grammar") renderGrammar(state.level);
  if (page === "learn") renderLearnPath(state.level);
  if (page === "vocab") renderVocabBank("beginner");
  if (page === "mistakes") renderMistakes();
  if (page === "writinglab") { /* static form */ }
  if (page === "goals") { renderGoals(); renderTrackStatus(); }
  if (page === "progress") { renderProgress(); setTimeout(renderProgressCompetencePatch, 0); }
  if (page === "aitutor") {
    loadAIHistory();
    renderAIHistory();
  }
  if (page === "aicall") backToCallLobby();
  if (page === "mocktest") {
    document.getElementById("mock-selection").classList.remove("hidden");
    document.getElementById("mock-runner").classList.add("hidden");
    document.getElementById("mock-result").classList.add("hidden");
  }
  if (page === "practice") {
    document.getElementById("practice-area").classList.add("hidden");
    document.querySelector(".skill-grid").style.display = "grid";
  }

  // Close sidebar on mobile
  document.getElementById("sidebar").classList.remove("open");
}

function toggleSidebar() {
  document.getElementById("sidebar").classList.toggle("open");
}

// ---------- UI Update ----------
function updateUI() {
  document.getElementById("sidebar-name").textContent = state.name || "Mahasiswa";
  document.getElementById("sidebar-level").textContent = capitalize(state.level);
  document.getElementById("user-avatar").textContent = (state.name || "M")[0].toUpperCase();
  document.getElementById("dash-name").textContent = state.name || "Mahasiswa";
  document.getElementById("dash-level").textContent = capitalize(state.level);
  document.getElementById("dash-lessons").textContent = state.lessonsCompleted.length;
  document.getElementById("xp-count").textContent = state.xp;
  document.getElementById("streak-count").textContent = state.streak;

  const goalPct = calcGoalProgress();
  document.getElementById("dash-goal").textContent = goalPct + "%";
  document.getElementById("dash-best").textContent = state.bestMock || "-";
}

function capitalize(s) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

function updateStreak() {
  const today = new Date().toDateString();
  if (state.lastStudyDate === today) {
    checkAndAwardBadges();
    return;
  }
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  if (state.lastStudyDate === yesterday.toDateString()) {
    state.streak = (state.streak || 0) + 1;
  } else {
    state.streak = 1;
  }
  state.lastStudyDate = today;
  saveState();
  updateUI();
  checkAndAwardBadges();
}

const BADGE_DEFS = [
  { id: "first_lesson", name: "First Steps", desc: "Selesaikan 1 unit belajar", icon: "fa-shoe-prints", test: s => (s.lessonsCompleted || []).length >= 1 },
  { id: "lesson_5", name: "Steady Learner", desc: "Selesaikan 5 unit", icon: "fa-book-open", test: s => (s.lessonsCompleted || []).length >= 5 },
  { id: "lesson_15", name: "Dedicated", desc: "Selesaikan 15 unit", icon: "fa-graduation-cap", test: s => (s.lessonsCompleted || []).length >= 15 },
  { id: "streak_3", name: "3-Day Streak", desc: "Belajar 3 hari beruntun", icon: "fa-fire", test: s => (s.streak || 0) >= 3 },
  { id: "streak_7", name: "Week Warrior", desc: "Belajar 7 hari beruntun", icon: "fa-fire-flame-curved", test: s => (s.streak || 0) >= 7 },
  { id: "streak_30", name: "Monthly Flame", desc: "Belajar 30 hari beruntun", icon: "fa-meteor", test: s => (s.streak || 0) >= 30 },
  { id: "xp_100", name: "XP Collector", desc: "Raih 100 XP", icon: "fa-star", test: s => (s.xp || 0) >= 100 },
  { id: "xp_500", name: "XP Hunter", desc: "Raih 500 XP", icon: "fa-trophy", test: s => (s.xp || 0) >= 500 },
  { id: "placement_done", name: "Level Checked", desc: "Selesaikan placement test", icon: "fa-clipboard-check", test: s => !!s.placementDone },
  { id: "practice_mix", name: "Skill Mixer", desc: "Latihan practice minimal sekali", icon: "fa-dumbbell", test: s => (s.xp || 0) >= 30 && !!s.placementDone },
  { id: "a2_ready", name: "A2 Unlocked", desc: "Buka level A2", icon: "fa-unlock", test: s => (s.unlockedLevels || []).includes("a2") },
  { id: "b1_ready", name: "B1 Unlocked", desc: "Buka level B1", icon: "fa-unlock", test: s => (s.unlockedLevels || []).includes("b1") }
];

function checkAndAwardBadges() {
  state.badges = state.badges || [];
  let earned = [];
  BADGE_DEFS.forEach(b => {
    if (!state.badges.includes(b.id) && b.test(state)) {
      state.badges.push(b.id);
      earned.push(b);
    }
  });
  if (earned.length) {
    saveState();
    const names = earned.map(b => b.name).join(", ");
    showToast("Badge baru: " + names, "success");
  }
}

function getBadgeInfo(id) {
  return BADGE_DEFS.find(b => b.id === id);
}

// ---------- Dashboard ----------
function renderDashboard() {
  updateUI();
  checkAndAwardBadges();
  const grid = document.getElementById("continue-grid");
  const items = [];

  // Recommended unit from placement / progress
  if (state.recommendedUnitTitle) {
    items.push({
      icon: "fa-location-arrow",
      title: "Lanjut: " + state.recommendedUnitTitle,
      sub: "Rekomendasi untuk level " + (state.level || "").toUpperCase(),
      page: "learn",
      special: true
    });
  } else {
    items.push({ icon: "fa-book-open", title: "Jalur Belajar " + capitalize(state.level), sub: "Buka kurikulum unit", page: "learn" });
  }

  items.push({ icon: "fa-headphones", title: "Listening Practice", sub: "Audio + soal acak", page: "practice" });
  items.push({ icon: "fa-phone", title: "AI Call", sub: "Latihan speaking natural", page: "aicall" });
  items.push({ icon: "fa-clipboard-list", title: "Mock IELTS/TOEFL", sub: "Simulasi tes", page: "mocktest" });

  grid.innerHTML = items.map(i => `
    <div class="continue-card${i.special ? " continue-card-special" : ""}" onclick="navigateTo('${i.page}')">
      <div class="cc-icon"><i class="fas ${i.icon}"></i></div>
      <div>
        <h4>${i.title}</h4>
        <span>${i.sub}</span>
      </div>
    </div>
  `).join("");

  // Badges strip
  let badgeHost = document.getElementById("dash-badges");
  if (!badgeHost) {
    const dash = document.getElementById("page-dashboard");
    if (dash) {
      badgeHost = document.createElement("div");
      badgeHost.id = "dash-badges";
      badgeHost.className = "dash-badges";
      const cont = dash.querySelector(".continue-section") || dash.querySelector(".dashboard-hero") || dash;
      cont.insertAdjacentElement("afterend", badgeHost);
    }
  }
  if (badgeHost) {
    const owned = state.badges || [];
    if (!owned.length) {
      badgeHost.innerHTML = `<div class="badge-strip-title"><i class="fas fa-medal"></i> Badge</div><p class="badge-empty">Belum ada badge — selesaikan unit & jaga streak!</p>`;
    } else {
      badgeHost.innerHTML = `<div class="badge-strip-title"><i class="fas fa-medal"></i> Badge kamu (${owned.length})</div><div class="badge-row">` +
        owned.map(id => {
          const b = getBadgeInfo(id) || { name: id, desc: "", icon: "fa-certificate" };
          return `<div class="badge-chip" title="${b.desc}"><i class="fas ${b.icon}"></i><span>${b.name}</span></div>`;
        }).join("") + `</div>`;
    }
  }
}

// ---------- Vocabulary Bank ----------
let vocabSearchTerm = "";
let vocabFilter = "all";
let vocabCurrentLevel = "beginner";

function renderVocabBank(level = "beginner") {
  const levels = ["beginner", "intermediate", "advanced", "pro"];
  if (!levels.includes(level)) level = "beginner";
  vocabCurrentLevel = level;
  document.querySelectorAll("#vocab-tabs .tab").forEach(tab => {
    tab.classList.toggle("active", tab.dataset.level === level);
    tab.onclick = () => renderVocabBank(tab.dataset.level);
  });
  const section = document.getElementById("page-vocab");
  const list = document.getElementById("vocab-bank-list");
  if (!section || !list) return;
  let tools = document.getElementById("vocab-bank-tools");
  if (!tools) {
    tools = document.createElement("div");
    tools.id = "vocab-bank-tools";
    tools.className = "vocab-bank-tools";
    document.getElementById("vocab-tabs").insertAdjacentElement("afterend", tools);
  }
  const data = (typeof VOCAB_BANK !== "undefined" && Array.isArray(VOCAB_BANK[level])) ? VOCAB_BANK[level] : [];
  const mastered = new Set(state.vocabMastered || []);
  const filtered = data.filter(item => {
    const haystack = `${item.en} ${item.id} ${item.ex || ""} ${item.type || ""}`.toLowerCase();
    const matchesSearch = haystack.includes(vocabSearchTerm.toLowerCase());
    const matchesFilter = vocabFilter === "all" || (vocabFilter === "mastered" ? mastered.has(item.en.toLowerCase()) : !mastered.has(item.en.toLowerCase()));
    return matchesSearch && matchesFilter;
  });
  const totalMastered = data.filter(item => mastered.has(item.en.toLowerCase())).length;
  tools.innerHTML = `
    <div class="vocab-bank-intro">
      <div><span class="vocab-eyebrow">LEARN • REMEMBER • USE</span><h2>${({beginner:"Build your foundation",intermediate:"Grow your vocabulary",advanced:"Express ideas precisely",pro:"Master nuanced English"})[level]}</h2><p>Pelajari kata, pahami artinya, lalu gunakan dalam kalimatmu sendiri.</p></div>
      <div class="vocab-progress"><strong>${totalMastered}/${data.length}</strong><span>kata dikuasai</span><div class="vocab-progress-track"><span style="width:${data.length ? Math.round(totalMastered/data.length*100) : 0}%"></span></div></div>
    </div>
    <div class="vocab-controls"><label class="vocab-search"><i class="fas fa-search"></i><input id="vocab-search-input" type="search" placeholder="Cari kata atau arti..." value="${escapeHtml(vocabSearchTerm)}" aria-label="Cari kosakata"></label><select id="vocab-filter-select" aria-label="Filter kosakata"><option value="all" ${vocabFilter === "all" ? "selected" : ""}>Semua kata</option><option value="unmastered" ${vocabFilter === "unmastered" ? "selected" : ""}>Belum dikuasai</option><option value="mastered" ${vocabFilter === "mastered" ? "selected" : ""}>Sudah dikuasai</option></select><button class="btn btn-secondary btn-sm" type="button" id="vocab-quiz-btn"><i class="fas fa-bolt"></i> Kuis cepat</button></div>`;
  const searchInput = document.getElementById("vocab-search-input");
  searchInput.addEventListener("input", e => { vocabSearchTerm = e.target.value; renderVocabCards(level); });
  document.getElementById("vocab-filter-select").addEventListener("change", e => { vocabFilter = e.target.value; renderVocabBank(level); });
  document.getElementById("vocab-quiz-btn").addEventListener("click", startVocabBankQuiz);
  renderVocabCards(level);
}

function renderVocabCards(level = vocabCurrentLevel) {
  const list = document.getElementById("vocab-bank-list");
  if (!list) return;
  const data = (typeof VOCAB_BANK !== "undefined" && Array.isArray(VOCAB_BANK[level])) ? VOCAB_BANK[level] : [];
  const mastered = new Set(state.vocabMastered || []);
  const filtered = data.filter(item => {
    const haystack = `${item.en} ${item.id} ${item.ex || ""} ${item.type || ""}`.toLowerCase();
    const matchesSearch = haystack.includes(vocabSearchTerm.toLowerCase());
    const matchesFilter = vocabFilter === "all" || (vocabFilter === "mastered" ? mastered.has(item.en.toLowerCase()) : !mastered.has(item.en.toLowerCase()));
    return matchesSearch && matchesFilter;
  });
  if (!filtered.length) {
    list.innerHTML = `<div class="vocab-empty"><i class="fas fa-book-open"></i><h3>${data.length ? "Kata tidak ditemukan" : "Materi sedang disiapkan"}</h3><p>${data.length ? "Coba kata kunci lain atau ubah filter." : "Belum ada kosakata untuk level ini."}</p></div>`;
    return;
  }
  // Group by part/type so vocab appears in sections
  const groups = {};
  filtered.forEach(item => {
    const part = item.type || "Vocabulary";
    if (!groups[part]) groups[part] = [];
    groups[part].push(item);
  });
  let html = "";
  let globalIdx = 0;
  Object.keys(groups).forEach(part => {
    html += `<div class="vocab-part-header"><h3><i class="fas fa-layer-group"></i> ${escapeHtml(part)}</h3><span>${groups[part].length} kata</span></div><div class="vocab-grid-inner">`;
    groups[part].forEach(item => {
      globalIdx++;
      const key = item.en.toLowerCase();
      const isDone = mastered.has(key);
      const type = item.type || "Vocabulary";
      html += `<article class="vocab-card ${isDone ? "mastered" : ""}"><div class="vocab-card-top"><span class="vocab-type">${escapeHtml(type)}</span><button class="vocab-master-btn ${isDone ? "is-mastered" : ""}" type="button" onclick="toggleVocabMastered('${escapeHtml(key)}')" aria-label="${isDone ? "Batalkan status dikuasai" : "Tandai dikuasai"}" title="${isDone ? "Sudah dikuasai" : "Tandai dikuasai"}"><i class="fas ${isDone ? "fa-check-circle" : "fa-circle"}"></i></button></div><h3 class="en">${escapeHtml(item.en)}</h3><p class="id">${escapeHtml(item.id)}</p><p class="ex">“${escapeHtml(item.ex || "")}”</p><div class="vocab-card-footer"><span>${String(globalIdx).padStart(2,"0")}</span><button type="button" class="vocab-example-btn" onclick="showToast('Baca contoh dengan suara keras untuk melatih pelafalan.', 'info')"><i class="fas fa-volume-up"></i> Latih</button></div></article>`;
    });
    html += `</div>`;
  });
  list.innerHTML = html;
}

function toggleVocabMastered(word) {
  state.vocabMastered = state.vocabMastered || [];
  const key = word.toLowerCase();
  const idx = state.vocabMastered.indexOf(key);
  if (idx >= 0) state.vocabMastered.splice(idx, 1); else state.vocabMastered.push(key);
  saveState();
  renderVocabBank(vocabCurrentLevel);
  showToast(idx >= 0 ? "Status kata diperbarui." : "Kosakata ditandai sudah dikuasai!", "success");
}

function startVocabBankQuiz() {
  const data = (typeof VOCAB_BANK !== "undefined" && Array.isArray(VOCAB_BANK[vocabCurrentLevel])) ? VOCAB_BANK[vocabCurrentLevel].slice() : [];
  if (!data.length) { showToast("Belum ada kosakata untuk kuis.", "error"); return; }
  const item = data[Math.floor(Math.random() * data.length)];
  const distractors = data.filter(v => v.en !== item.en).sort(() => Math.random() - 0.5).slice(0, 3);
  const options = [item, ...distractors].sort(() => Math.random() - 0.5);
  const list = document.getElementById("vocab-bank-list");
  list.innerHTML = `<div class="vocab-quiz-panel"><span class="vocab-eyebrow">QUICK CHECK</span><h2>Apa arti kata <strong>${escapeHtml(item.en)}</strong>?</h2><p>Pilih jawaban yang paling tepat.</p><div class="vocab-quiz-options">${options.map((v,i)=>`<button type="button" class="vocab-quiz-option" onclick="answerVocabBankQuiz(this, ${v.en === item.en}, '${escapeHtml(item.id)}')">${String.fromCharCode(65+i)}. ${escapeHtml(v.id)}</button>`).join("")}</div><button class="btn btn-secondary btn-sm" type="button" onclick="renderVocabBank(vocabCurrentLevel)">Kembali ke kosakata</button></div>`;
}

function answerVocabBankQuiz(button, correct, answer) {
  document.querySelectorAll(".vocab-quiz-option").forEach(b => { b.disabled = true; });
  button.classList.add(correct ? "correct" : "incorrect");
  const panel = button.closest(".vocab-quiz-panel");
  panel.insertAdjacentHTML("beforeend", `<p class="vocab-quiz-feedback">${correct ? "Benar! Bagus." : `Belum tepat. Arti yang benar: <strong>${escapeHtml(answer)}</strong>.`}</p>`);
  if (correct) showToast("Jawaban benar!", "success");
}

// ---------- Grammar ----------
function renderGrammar(level) {
  // Grammar reference library is open at every level; CEFR exam unlocks apply to Learn Path, not this library.
  const validLevels = ["beginner", "intermediate", "advanced", "pro"];
  if (!validLevels.includes(level)) level = "beginner";
  document.querySelectorAll("#grammar-tabs .tab").forEach(t => {
    const lv = t.dataset.level;
    t.classList.remove("locked");
    t.onclick = () => {
      document.querySelectorAll("#grammar-tabs .tab").forEach(x => x.classList.remove("active"));
      t.classList.add("active");
      renderGrammar(lv);
    };
  });
  const list = document.getElementById("grammar-list");
  const lessons = GRAMMAR_LESSONS[level] || [];
  list.innerHTML = lessons.map(lesson => {
    const done = (state.lessonsCompleted || []).includes(lesson.id);
    return `
      <div class="grammar-item" id="g-${lesson.id}">
        <div class="grammar-item-header" onclick="toggleGrammar('${lesson.id}')">
          <h3><i class="fas fa-bookmark"></i> ${lesson.title}</h3>
          <span class="status ${done ? 'done' : 'todo'}">${done ? 'Selesai' : 'Belum'}</span>
        </div>
        <div class="grammar-body" id="body-${lesson.id}">
          <div class="explanation">${lesson.explanation}</div>
          ${lesson.examples.map(ex => `
            <div class="example">
              <strong>${ex.en}</strong><br>
              <span style="color:var(--text-muted);font-size:0.9rem;">${ex.id}</span>
            </div>
          `).join("")}
          <div class="quiz-area">
            <h4>Mini Quiz</h4>
            ${lesson.quiz.map((qz, qi) => `
              <div style="margin-bottom:16px;">
                <p style="margin-bottom:8px;">${qi + 1}. ${qz.q}</p>
                ${qz.opts.map((o, oi) => `
                  <div class="option" style="padding:10px 14px;margin-bottom:6px;" onclick="checkGrammarQuiz('${lesson.id}', ${qi}, ${oi}, ${qz.ans}, this)">
                    <span class="opt-letter">${String.fromCharCode(65 + oi)}</span>
                    <span>${o}</span>
                  </div>
                `).join("")}
              </div>
            `).join("")}
            <button class="btn btn-primary btn-sm" onclick="completeLesson('${lesson.id}')">
              <i class="fas fa-check"></i> Tandai Selesai (+20 XP)
            </button>
          </div>
        </div>
      </div>
    `;
  }).join("");

  // Highlight current level tab
  document.querySelectorAll("#grammar-tabs .tab").forEach(t => {
    t.classList.toggle("active", t.dataset.level === level);
  });
}

function toggleGrammar(id) {
  const body = document.getElementById(`body-${id}`);
  body.classList.toggle("open");
}

function checkGrammarQuiz(lessonId, qIdx, optIdx, correct, el) {
  const parent = el.parentElement;
  parent.querySelectorAll(".option").forEach(o => {
    o.style.pointerEvents = "none";
    o.classList.remove("selected");
  });
  if (optIdx === correct) {
    el.classList.add("selected");
    el.style.borderColor = "var(--success)";
    el.style.background = "rgba(16,185,129,0.15)";
    showToast("Benar! 🎉", "success");
  } else {
    el.style.borderColor = "var(--danger)";
    el.style.background = "rgba(239,68,68,0.15)";
    parent.querySelectorAll(".option")[correct].style.borderColor = "var(--success)";
    parent.querySelectorAll(".option")[correct].style.background = "rgba(16,185,129,0.15)";
    showToast("Belum tepat, coba pelajari lagi.", "error");
  }
}

function completeLesson(id) {
  if (!state.lessonsCompleted.includes(id)) {
    state.lessonsCompleted.push(id);
    state.xp += 20;
    updateGoalProgress("lessons");
    saveState();
    updateUI();
    showToast("Lesson selesai! +20 XP", "success");
    const status = document.querySelector(`#g-${id} .status`);
    if (status) {
      status.textContent = "Selesai";
      status.className = "status done";
    }
  } else {
    showToast("Lesson ini sudah selesai sebelumnya.", "success");
  }
}

// ---------- Practice ----------
function startPractice(skill) {
  document.querySelector(".skill-grid").style.display = "none";
  const area = document.getElementById("practice-area");
  area.classList.remove("hidden");
  document.getElementById("practice-title").textContent = skill.charAt(0).toUpperCase() + skill.slice(1) + " Practice";

  currentPractice = { skill, answers: [], score: 0 };

  if (skill === "reading") startReading();
  else if (skill === "listening") startListening();
  else if (skill === "writing") startWriting();
  else if (skill === "speaking") startSpeaking();
}

function closePractice() {
  document.getElementById("practice-area").classList.add("hidden");
  document.querySelector(".skill-grid").style.display = "grid";
  currentPractice = null;
}

function startReading() {
  const passage = getRandomItems(READING_PASSAGES, 1)[0];
  currentPractice.data = passage;
  currentPractice.answers = new Array(passage.questions.length).fill(null);

  let html = `<div class="passage-box"><h4>${passage.title}</h4><p>${passage.text}</p></div>`;
  passage.questions.forEach((q, i) => {
    html += `<div style="margin-bottom:20px;">
      <p style="font-weight:500;margin-bottom:10px;">${i + 1}. ${q.q}</p>
      ${q.opts.map((o, oi) => `
        <div class="option" onclick="selectPracticeAnswer(${i}, ${oi}, this)">
          <span class="opt-letter">${String.fromCharCode(65 + oi)}</span>
          <span>${o}</span>
        </div>
      `).join("")}
    </div>`;
  });
  document.getElementById("practice-content").innerHTML = html;
  document.getElementById("practice-actions").innerHTML = `
    <button class="btn btn-primary" onclick="submitReading()"><i class="fas fa-check"></i> Submit Jawaban</button>
  `;
}

function selectPracticeAnswer(qIdx, optIdx, el) {
  currentPractice.answers[qIdx] = optIdx;
  const parent = el.parentElement;
  parent.querySelectorAll(".option").forEach(o => o.classList.remove("selected"));
  el.classList.add("selected");
}

function submitReading() {
  const passage = currentPractice.data;
  let correct = 0;
  passage.questions.forEach((q, i) => {
    if (currentPractice.answers[i] === q.ans) correct++;
  });
  const total = passage.questions.length;
  const pct = Math.round((correct / total) * 100);
  state.xp += correct * 10;
  updateGoalProgress("practice");
  saveState();
  updateUI();

  document.getElementById("practice-content").innerHTML += `
    <div class="feedback-box">
      <div class="score-line"><span>Skor Reading</span><strong>${correct}/${total} (${pct}%)</strong></div>
      <p style="color:var(--text-muted);">${pct >= 70 ? "Bagus! Comprehension kamu bagus." : "Perlu latihan lagi. Baca lebih teliti ya."}</p>
    </div>
  `;
  document.getElementById("practice-actions").innerHTML = `
    <button class="btn btn-primary" onclick="startReading()">Coba Passage Lain</button>
    <button class="btn btn-secondary" onclick="closePractice()">Kembali</button>
  `;
  showToast(`+${correct * 10} XP`, "success");
}

function startListening() {
  stopSpeech();
  const item = getRandomItems(LISTENING_SCRIPTS, 1)[0];
  currentPractice.data = item;
  currentPractice.answers = new Array(item.questions.length).fill(null);
  currentPractice.playing = false;

  let html = `
    <div class="listening-box">
      <h4>${item.title}</h4>
      <p style="color:var(--text-muted);margin-top:8px;">Klik Play — audio dibacakan dengan suara (berubah tiap kali). Dengarkan lalu jawab.</p>
      <div class="audio-wave" id="audio-wave">
        <span></span><span></span><span></span><span></span><span></span><span></span><span></span>
      </div>
      <div class="audio-controls">
        <button class="play-btn" id="play-btn" onclick="toggleListenPlay()"><i class="fas fa-play"></i></button>
        <span id="audio-status">Klik play untuk mendengarkan</span>
      </div>
      <div class="script-toggle" onclick="toggleScript()">Tampilkan / Sembunyikan Script</div>
      <div class="script-text" id="script-text">${item.script}</div>
    </div>
  `;
  item.questions.forEach((q, i) => {
    html += `<div style="margin-bottom:20px;">
      <p style="font-weight:500;margin-bottom:10px;">${i + 1}. ${q.q}</p>
      ${q.opts.map((o, oi) => `
        <div class="option" onclick="selectPracticeAnswer(${i}, ${oi}, this)">
          <span class="opt-letter">${String.fromCharCode(65 + oi)}</span>
          <span>${o}</span>
        </div>
      `).join("")}
    </div>`;
  });
  document.getElementById("practice-content").innerHTML = html;
  document.getElementById("practice-actions").innerHTML = `
    <button class="btn btn-primary" onclick="submitListening()"><i class="fas fa-check"></i> Submit Jawaban</button>
  `;
}

function getRandomVoice() {
  const voices = speechSynthesis.getVoices().filter(v => v.lang.startsWith("en"));
  if (voices.length === 0) return null;
  // Prefer US/GB voices, pick randomly
  const preferred = voices.filter(v => /en-US|en-GB|English/.test(v.lang + v.name));
  const pool = preferred.length ? preferred : voices;
  return pool[Math.floor(Math.random() * pool.length)];
}

function stopSpeech() {
  if (window.speechSynthesis) {
    speechSynthesis.cancel();
  }
  speechUtterance = null;
  if (currentPractice) currentPractice.playing = false;
  const wave = document.getElementById("audio-wave");
  if (wave) wave.classList.remove("playing");
}

function toggleListenPlay() {
  if (!window.speechSynthesis) {
    showToast("Browser tidak mendukung audio speech. Tampilkan script saja.", "error");
    document.getElementById("script-text").classList.add("show");
    return;
  }

  const btn = document.getElementById("play-btn");
  const status = document.getElementById("audio-status");
  const wave = document.getElementById("audio-wave");

  if (currentPractice.playing) {
    stopSpeech();
    btn.innerHTML = '<i class="fas fa-play"></i>';
    status.textContent = "Dijeda — klik play untuk lanjut";
    return;
  }

  // Ensure voices loaded
  const speak = () => {
    const text = currentPractice.data.script;
    speechUtterance = new SpeechSynthesisUtterance(text);
    speechUtterance.lang = "en-US";
    speechUtterance.rate = 0.9 + Math.random() * 0.15; // slight variation
    speechUtterance.pitch = 0.95 + Math.random() * 0.15;
    const voice = getRandomVoice();
    if (voice) speechUtterance.voice = voice;

    speechUtterance.onstart = () => {
      currentPractice.playing = true;
      btn.innerHTML = '<i class="fas fa-pause"></i>';
      status.textContent = voice ? `Memutar · ${voice.name.split(" ")[0]}...` : "Memutar audio...";
      if (wave) wave.classList.add("playing");
    };
    speechUtterance.onend = () => {
      currentPractice.playing = false;
      btn.innerHTML = '<i class="fas fa-redo"></i>';
      status.textContent = "Selesai. Jawab pertanyaan di bawah (atau putar ulang).";
      if (wave) wave.classList.remove("playing");
    };
    speechUtterance.onerror = () => {
      stopSpeech();
      btn.innerHTML = '<i class="fas fa-play"></i>';
      status.textContent = "Gagal memutar. Coba tampilkan script.";
    };

    speechSynthesis.speak(speechUtterance);
  };

  if (speechSynthesis.getVoices().length === 0) {
    speechSynthesis.onvoiceschanged = speak;
    // fallback
    setTimeout(speak, 300);
  } else {
    speak();
  }
}

function toggleScript() {
  document.getElementById("script-text").classList.toggle("show");
}

function submitListening() {
  const item = currentPractice.data;
  let correct = 0;
  item.questions.forEach((q, i) => {
    if (currentPractice.answers[i] === q.ans) correct++;
  });
  const total = item.questions.length;
  const pct = Math.round((correct / total) * 100);
  state.xp += correct * 10;
  updateGoalProgress("practice");
  saveState();
  updateUI();

  document.getElementById("practice-content").innerHTML += `
    <div class="feedback-box">
      <div class="score-line"><span>Skor Listening</span><strong>${correct}/${total} (${pct}%)</strong></div>
      <p style="color:var(--text-muted);">${pct >= 70 ? "Great listening skills!" : "Coba dengarkan lebih fokus dan catat keyword."}</p>
    </div>
  `;
  document.getElementById("practice-actions").innerHTML = `
    <button class="btn btn-primary" onclick="startListening()">Audio Lain</button>
    <button class="btn btn-secondary" onclick="closePractice()">Kembali</button>
  `;
  showToast(`+${correct * 10} XP`, "success");
}

function startWriting() {
  const prompt = getRandomItems(WRITING_PROMPTS, 1)[0];
  currentPractice.data = prompt;

  document.getElementById("practice-content").innerHTML = `
    <div class="writing-prompt">
      <h4>${prompt.title}</h4>
      <p style="margin-top:10px;">${prompt.prompt}</p>
    </div>
    <div class="writing-area">
      <textarea id="writing-text" placeholder="Tulis essay kamu di sini..." oninput="updateWordCount()"></textarea>
      <div class="word-count"><span id="word-count">0</span> words (min. ${prompt.minWords})</div>
    </div>
  `;
  document.getElementById("practice-actions").innerHTML = `
    <button class="btn btn-primary" onclick="submitWriting()"><i class="fas fa-paper-plane"></i> Submit & Dapatkan Feedback</button>
  `;
}

function updateWordCount() {
  const text = document.getElementById("writing-text").value.trim();
  const words = text ? text.split(/\s+/).length : 0;
  document.getElementById("word-count").textContent = words;
}

function submitWriting() {
  const text = document.getElementById("writing-text").value.trim();
  const words = text ? text.split(/\s+/).length : 0;
  const min = currentPractice.data.minWords;

  if (words < min * 0.5) {
    showToast(`Tulis minimal sekitar ${min} kata ya!`, "error");
    return;
  }

  // AI-style analysis
  const analysis = analyzeWriting(text, words, min);
  const score = analysis.score;

  state.xp += Math.round(score * 5);
  updateGoalProgress("practice");
  saveState();
  updateUI();

  document.getElementById("practice-content").innerHTML += `
    <div class="ai-feedback-box">
      <h4><i class="fas fa-robot"></i> AI Writing Feedback</h4>
      <div class="score-line" style="margin-bottom:14px;"><span>Estimated Band Score</span><strong style="color:var(--success);font-size:1.4rem;">${score.toFixed(1)}</strong></div>
      <div class="fb-item"><strong>Word count</strong>${words} kata ${words >= min ? "✓ mencapai minimum" : "(di bawah target " + min + ")"}</div>
      <div class="fb-item"><strong>Task Response</strong>${analysis.task}</div>
      <div class="fb-item"><strong>Coherence & Cohesion</strong>${analysis.cohesion}</div>
      <div class="fb-item"><strong>Lexical Resource</strong>${analysis.vocab}</div>
      <div class="fb-item"><strong>Grammatical Range</strong>${analysis.grammar}</div>
      ${analysis.tips.length ? `<div class="fb-item"><strong>Saran perbaikan</strong><ul style="margin:6px 0 0 16px;color:var(--text-muted);">${analysis.tips.map(t => `<li>${t}</li>`).join("")}</ul></div>` : ""}
    </div>
  `;
  document.getElementById("practice-actions").innerHTML = `
    <button class="btn btn-primary" onclick="startWriting()">Prompt Baru</button>
    <button class="btn btn-secondary" onclick="closePractice()">Kembali</button>
  `;
  showToast(`AI Feedback siap · Band ${score.toFixed(1)} · +${Math.round(score * 5)} XP`, "success");
}

function analyzeWriting(text, words, min) {
  let score = 4.5;
  const tips = [];
  const lower = text.toLowerCase();

  // Length
  if (words >= min) score += 1.0;
  else tips.push("Tulis lebih panjang agar mendekati batas minimum kata.");
  if (words >= min * 1.15) score += 0.5;

  // Structure / cohesion
  const hasConnectors = /\b(however|therefore|moreover|furthermore|in addition|on the other hand|in conclusion|firstly|secondly|finally|although|whereas|consequently|as a result)\b/i.test(text);
  const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 5);
  if (hasConnectors) score += 0.8;
  else tips.push("Tambahkan linking words (however, therefore, moreover, in conclusion) biar lebih kohesif.");
  if (sentences.length >= 4) score += 0.4;

  // Vocab variety (rough)
  const unique = new Set(lower.split(/\s+/).filter(w => w.length > 3));
  if (unique.size > words * 0.45) score += 0.6;
  else tips.push("Coba variasikan vocabulary — hindari mengulang kata yang sama terus.");

  // Grammar signals
  const hasComplex = /\b(which|who|that|although|because|if|when|while)\b/i.test(text);
  const hasPerfect = /\b(have|has|had)\s+\w+ed\b/i.test(text) || /\b(have|has)\s+been\b/i.test(text);
  if (hasComplex) score += 0.5;
  if (hasPerfect) score += 0.3;
  if (!hasComplex) tips.push("Gunakan relative clause atau complex sentence untuk naik band.");

  // Opinion / conclusion markers
  if (/\b(i (believe|think|agree|disagree)|in my opinion|it is clear that)\b/i.test(text)) score += 0.3;

  score = Math.min(9.0, Math.round(score * 2) / 2);

  const task = words >= min
    ? "Ide cukup dikembangkan dan relevan dengan topik."
    : "Pengembangan ide masih terbatas; perlu lebih banyak supporting detail.";
  const cohesion = hasConnectors
    ? "Ada penggunaan linking devices yang membantu alur."
    : "Organisasi ide ada, tapi cohesive devices masih kurang.";
  const vocab = unique.size > words * 0.45
    ? "Range vocabulary cukup baik untuk level ini."
    : "Lexical resource masih basic; perlu lebih banyak word choice yang akurat.";
  const grammar = hasComplex
    ? "Ada usaha memakai struktur kompleks."
    : "Mayoritas simple sentences — tingkatkan grammatical range.";

  if (score >= 7) tips.unshift("Sudah solid! Fokus ke precision dan less common vocabulary untuk band lebih tinggi.");
  else if (tips.length === 0) tips.push("Latihan konsisten akan menaikkan skor secara bertahap.");

  return { score, task, cohesion, vocab, grammar, tips };
}


let speakingTranscript = "";

function startSpeaking() {
  stopSpeechRecognition();
  speakingTranscript = "";
  const prompt = getRandomItems(SPEAKING_PROMPTS, 1)[0];
  currentPractice.data = prompt;

  document.getElementById("practice-content").innerHTML = `
    <div class="speaking-prompt">
      <h3>${prompt.part}</h3>
      <p>${prompt.prompt}</p>
      <div class="speaking-tips"><strong>Tips:</strong> ${prompt.tips}</div>
    </div>
    <div class="mic-zone">
      <button class="mic-btn" id="mic-btn" onclick="toggleMic()"><i class="fas fa-microphone"></i></button>
      <div class="mic-status" id="mic-status">Klik mikrofon, izinkan akses mic, lalu berbicara dalam bahasa Inggris</div>
      <div class="transcript-box" id="transcript-box">
        <div class="label">Transkrip ucapanmu</div>
        <div id="transcript-text"><em style="color:var(--text-muted)">Belum ada — mulai bicara setelah klik mic</em></div>
      </div>
    </div>
  `;
  document.getElementById("practice-actions").innerHTML = `
    <button class="btn btn-primary" id="btn-score-speaking" onclick="scoreSpeakingAI()" disabled>
      <i class="fas fa-robot"></i> Dapatkan Feedback AI & Skor
    </button>
  `;
}

function stopSpeechRecognition() {
  if (speechRecognition) {
    try { speechRecognition.stop(); } catch (e) {}
    speechRecognition = null;
  }
}

function toggleMic() {
  const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRec) {
    showToast("Browser tidak mendukung speech recognition. Pakai Chrome/Edge.", "error");
    document.getElementById("transcript-text").innerHTML =
      "<em>Ketik jawabanmu di sini sebagai alternatif:</em><br><textarea id='manual-speech' rows='4' style='width:100%;margin-top:8px;padding:10px;border-radius:8px;background:var(--bg);color:var(--text);border:1px solid var(--border);'></textarea>";
    document.getElementById("btn-score-speaking").disabled = false;
    return;
  }

  const btn = document.getElementById("mic-btn");
  const status = document.getElementById("mic-status");

  if (speechRecognition) {
    stopSpeechRecognition();
    btn.classList.remove("recording");
    status.textContent = "Berhenti. Klik lagi untuk lanjut, atau minta feedback AI.";
    document.getElementById("btn-score-speaking").disabled = speakingTranscript.trim().length < 5;
    return;
  }

  speechRecognition = new SpeechRec();
  speechRecognition.lang = "en-US";
  speechRecognition.continuous = true;
  speechRecognition.interimResults = true;

  speechRecognition.onstart = () => {
    btn.classList.add("recording");
    status.textContent = "🎤 Mendengarkan... Bicara dalam English!";
  };

  speechRecognition.onresult = (event) => {
    let interim = "";
    let final = speakingTranscript;
    for (let i = event.resultIndex; i < event.results.length; i++) {
      const t = event.results[i][0].transcript;
      if (event.results[i].isFinal) final += t + " ";
      else interim += t;
    }
    speakingTranscript = final;
    document.getElementById("transcript-text").textContent =
      (final + (interim ? " " + interim : "")).trim() || "...";
    if (final.trim().length > 5) {
      document.getElementById("btn-score-speaking").disabled = false;
    }
  };

  speechRecognition.onerror = (e) => {
    status.textContent = "Error: " + (e.error || "mic") + " — coba lagi atau ketik manual.";
    btn.classList.remove("recording");
    if (e.error === "not-allowed") {
      showToast("Izinkan akses mikrofon di browser ya!", "error");
    }
  };

  speechRecognition.onend = () => {
    btn.classList.remove("recording");
    if (document.getElementById("mic-status")) {
      document.getElementById("mic-status").textContent = "Selesai merekam. Klik mic lagi atau minta skor AI.";
    }
    document.getElementById("btn-score-speaking").disabled = speakingTranscript.trim().length < 5;
  };

  try {
    speechRecognition.start();
  } catch (err) {
    showToast("Gagal start mic: " + err.message, "error");
  }
}

function scoreSpeakingAI() {
  stopSpeechRecognition();
  let text = speakingTranscript.trim();
  const manual = document.getElementById("manual-speech");
  if (manual && manual.value.trim()) text = manual.value.trim();

  if (!text || text.length < 5) {
    showToast("Belum ada ucapan yang tertangkap. Coba bicara lebih lama.", "error");
    return;
  }

  const promptText = (currentPractice.data && currentPractice.data.prompt) || "";
  const kws = promptText.toLowerCase().split(/\W+/).filter(w => w.length > 4);
  const analysis = objectiveSpeakingScore(text, kws);
  analysis.fluency = analysis.n >= 40 ? "Developed response." : "Perlu lebih extended.";
  analysis.vocab = analysis.band >= 6.5 ? "Lexical resource memadai." : "Vocabulary perlu diperkaya.";
  analysis.grammar = analysis.band >= 6 ? "Grammar cukup untuk level ini." : "Perkuat complex structures.";
  analysis.relevance = analysis.hits >= 2 ? "Cukup relevan ke tema." : "Kurang mengena ke tema — skor dikurangi.";
  analysis.band = analysis.band;
  state.xp += Math.round(analysis.band * 5);
  updateGoalProgress("practice");
  saveState();
  updateUI();

  document.getElementById("practice-content").innerHTML += `
    <div class="ai-feedback-box">
      <h4><i class="fas fa-robot"></i> AI Speaking Feedback</h4>
      <div class="score-line" style="margin-bottom:12px;">
        <span>Estimated Band Score</span>
        <strong style="color:var(--success);font-size:1.5rem;">${analysis.band.toFixed(1)}</strong>
      </div>
      <div class="fb-item"><strong>Yang kamu ucapkan</strong>"${text}"</div>
      <div class="fb-item"><strong>Fluency & length</strong>${analysis.fluency}</div>
      <div class="fb-item"><strong>Vocabulary</strong>${analysis.vocab}</div>
      <div class="fb-item"><strong>Grammar signals</strong>${analysis.grammar}</div>
      <div class="fb-item"><strong>Relevance to prompt</strong>${analysis.relevance}</div>
      ${analysis.tips.length ? `<div class="fb-item"><strong>Saran</strong><ul style="margin:6px 0 0 16px;color:var(--text-muted);">${analysis.tips.map(t => `<li>${t}</li>`).join("")}</ul></div>` : ""}
    </div>
  `;
  document.getElementById("practice-actions").innerHTML = `
    <button class="btn btn-primary" onclick="startSpeaking()">Prompt Baru</button>
    <button class="btn btn-secondary" onclick="closePractice()">Kembali</button>
  `;
  showToast(`Speaking Band ${analysis.band.toFixed(1)} · +${Math.round(analysis.band * 5)} XP`, "success");
}

function analyzeSpeaking(text, prompt) {
  const words = text.split(/\s+/).filter(Boolean);
  const n = words.length;
  const lower = text.toLowerCase();
  const tips = [];
  let band = 4.0;

  // Length / fluency proxy
  if (n >= 40) { band += 1.5; }
  else if (n >= 25) { band += 1.0; }
  else if (n >= 12) { band += 0.5; }
  else tips.push("Coba bicara lebih panjang (target 30–60 detik / 40+ kata).");

  const fluency = n >= 40 ? "Panjang jawaban cukup; terkesan developed." :
    n >= 20 ? "Cukup, tapi bisa lebih extended dengan contoh." :
    "Masih pendek — extend dengan reason + example.";

  // Vocab variety
  const unique = new Set(words.map(w => w.toLowerCase().replace(/[^a-z']/g, "")));
  const ratio = unique.size / Math.max(n, 1);
  if (ratio > 0.7 && n > 15) band += 0.8;
  else if (ratio > 0.5) band += 0.4;
  else tips.push("Variasikan vocabulary; hindari mengulang kata yang sama.");

  const vocab = ratio > 0.65 ? "Lexical range cukup baik." : "Lexical resource masih terbatas.";

  // Grammar signals
  const hasPast = /\b(was|were|had|went|did|ed)\b/i.test(text);
  const hasComplex = /\b(because|which|that|when|if|although|while)\b/i.test(text);
  const hasModal = /\b(would|could|should|might|can)\b/i.test(text);
  if (hasComplex) band += 0.5;
  if (hasModal) band += 0.3;
  if (hasPast) band += 0.2;
  if (!hasComplex) tips.push("Pakai complex sentences (because, which, although) untuk naik band.");

  const grammar = hasComplex
    ? "Ada indikasi struktur kompleks."
    : "Mayoritas simple sentences — tingkatkan range.";

  // Relevance: keyword overlap with prompt
  const promptWords = (prompt.prompt || "").toLowerCase().split(/\W+/).filter(w => w.length > 4);
  const hits = promptWords.filter(w => lower.includes(w)).length;
  if (hits >= 3) band += 0.6;
  else if (hits >= 1) band += 0.3;
  else tips.push("Hubungkan jawaban lebih jelas ke pertanyaan di prompt.");

  const relevance = hits >= 3 ? "Relevan dengan topik prompt." :
    hits >= 1 ? "Cukup relevan." : "Kurang mengena ke pertanyaan — fokus ulang ke prompt.";

  band = Math.min(9.0, Math.round(band * 2) / 2);
  if (band >= 7) tips.unshift("Bagus! Pertahankan pace natural dan tambah precise vocabulary.");
  if (tips.length === 0) tips.push("Latihan konsisten dengan timer 1–2 menit.");

  return { band, fluency, vocab, grammar, relevance, tips };
}

// ---------- Mock Tests ----------
function startMock(type) {
  currentMock = {
    type,
    mode: "full",
    sections: type === "ielts"
      ? ["listening", "reading", "writing", "speaking"]
      : ["reading", "listening", "speaking", "writing"],
    sectionIndex: 0,
    questions: [],
    answers: [],
    scores: {},
    qIndex: 0
  };
  loadMockSection();
}

function startMockSection(type) {
  const sections = type === "ielts"
    ? ["Listening", "Reading", "Writing", "Speaking"]
    : ["Reading", "Listening", "Speaking", "Writing"];
  const html = `
    <h3 style="margin-bottom:16px;">Pilih Section ${type.toUpperCase()}</h3>
    ${sections.map(s => `
      <button class="btn btn-outline" style="display:block;width:100%;margin-bottom:10px;justify-content:center;"
        onclick="startSingleSection('${type}', '${s.toLowerCase()}')">${s}</button>
    `).join("")}
  `;
  showModal(html);
}

function startSingleSection(type, section) {
  closeModal();
  currentMock = {
    type,
    mode: "section",
    sections: [section],
    sectionIndex: 0,
    questions: [],
    answers: [],
    scores: {},
    qIndex: 0
  };
  loadMockSection();
}

function loadMockSection() {
  const section = currentMock.sections[currentMock.sectionIndex];
  currentMock.currentSection = section;
  currentMock.qIndex = 0;
  currentMock.answers = [];

  // Speaking section → AI Call (phone-style) with objective scoring
  if (section === "speaking") {
    document.getElementById("mock-selection").classList.add("hidden");
    document.getElementById("mock-runner").classList.add("hidden");
    navigateTo("aicall");
    const mode = currentMock.type === "ielts" ? "ielts" : "interview";
    setTimeout(() => startAICall(mode), 400);
    // When call ends, finishMockSection will need scores — hook via call
    currentMock.awaitingCallScore = true;
    return;
  }

  let questions = [];
  if (currentMock.type === "ielts") {
    if (section === "listening") {
      IELTS_LISTENING.forEach(s => {
        s.questions.forEach(q => questions.push({ ...q, script: s.script, title: s.title }));
      });
    } else if (section === "reading") {
      IELTS_READING.forEach(p => {
        p.questions.forEach(q => questions.push({ ...q, passage: p.text, title: p.title }));
      });
    } else if (section === "writing") {
      questions = IELTS_WRITING.map(w => ({ type: "writing", ...w }));
    } else if (section === "speaking") {
      questions = IELTS_SPEAKING.map(s => ({ type: "speaking", ...s }));
    }
  } else {
    if (section === "reading") {
      TOEFL_READING.forEach(p => {
        p.questions.forEach(q => questions.push({ ...q, passage: p.text, title: p.title }));
      });
    } else if (section === "listening") {
      TOEFL_LISTENING.forEach(s => {
        s.questions.forEach(q => questions.push({ ...q, script: s.script, title: s.title }));
      });
    } else if (section === "speaking") {
      questions = TOEFL_SPEAKING.map(s => ({ type: "speaking", ...s }));
    } else if (section === "writing") {
      questions = TOEFL_WRITING.map(w => ({ type: "writing", ...w }));
    }
  }

  // Randomize each attempt: shuffle and take a varied subset so retries differ
  questions = shuffle(questions.slice());
  if (section === "listening" || section === "reading") {
    const cap = Math.min(questions.length, section === "listening" ? 12 : 10);
    questions = questions.slice(0, Math.max(6, cap));
  } else if (section === "writing") {
    questions = questions.slice(0, Math.min(2, questions.length));
  } else if (section === "speaking") {
    questions = questions.slice(0, Math.min(3, questions.length));
  }
  currentMock.questions = questions;
  currentMock.answers = new Array(currentMock.questions.length).fill(null);

  // Realistic-ish timers (scaled for web practice)
  const n = questions.length;
  if (section === "writing") mockTimeLeft = 2400; // ~40 min
  else if (section === "speaking") mockTimeLeft = 900; // 15 min
  else if (section === "reading") mockTimeLeft = Math.max(1200, n * 60); // ~1 min/q
  else mockTimeLeft = Math.max(900, n * 45); // listening
  startMockTimer();

  document.getElementById("mock-selection").classList.add("hidden");
  document.getElementById("mock-result").classList.add("hidden");
  document.getElementById("mock-runner").classList.remove("hidden");
  document.getElementById("mock-type-label").textContent = currentMock.type.toUpperCase();
  document.getElementById("mock-section-label").textContent = capitalize(section);
  renderMockQuestion();
}

function startMockTimer() {
  if (mockTimerInterval) clearInterval(mockTimerInterval);
  updateMockTimerDisplay();
  mockTimerInterval = setInterval(() => {
    mockTimeLeft--;
    updateMockTimerDisplay();
    if (mockTimeLeft <= 0) {
      clearInterval(mockTimerInterval);
      finishMockSection();
    }
  }, 1000);
}

function updateMockTimerDisplay() {
  const m = Math.floor(mockTimeLeft / 60);
  const s = mockTimeLeft % 60;
  document.getElementById("mock-timer").textContent =
    `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}


function playMockListeningAudio() {
  if (!currentMock) return;
  const q = currentMock.questions[currentMock.qIndex];
  if (!q || !q.script) {
    showToast("Tidak ada script audio.", "error");
    return;
  }
  stopSpeech();
  const status = document.getElementById("mock-audio-status");
  const utter = new SpeechSynthesisUtterance(q.script);
  utter.lang = "en-US";
  const voice = (typeof getRandomVoice === "function") ? getRandomVoice() : null;
  if (voice) utter.voice = voice;
  utter.rate = 0.92;
  utter.onstart = () => { if (status) status.textContent = "Memutar audio..."; };
  utter.onend = () => { if (status) status.textContent = "Selesai — putar lagi jika perlu"; };
  utter.onerror = () => { if (status) status.textContent = "Gagal memutar"; showToast("Audio gagal", "error"); };
  speechSynthesis.speak(utter);
}

function renderMockQuestion() {
  const q = currentMock.questions[currentMock.qIndex];
  const total = currentMock.questions.length;
  document.getElementById("mock-q-counter").textContent = `${currentMock.qIndex + 1} / ${total}`;
  document.getElementById("mock-progress-bar").style.width = `${((currentMock.qIndex + 1) / total) * 100}%`;

  let html = "";
  if (q.type === "writing") {
    html = `
      <div class="writing-prompt">
        <h4>${q.title}</h4>
        <p style="margin-top:10px;white-space:pre-wrap;">${q.prompt}</p>
      </div>
      <div class="writing-area">
        <textarea id="mock-writing" placeholder="Tulis jawabanmu di sini..." rows="10"></textarea>
      </div>
    `;
  } else if (q.type === "speaking") {
    html = `
      <div class="speaking-prompt">
        <h3>Part ${q.part || q.task || ""}</h3>
        <p>${q.prompt}</p>
        <div class="speaking-tips">Siapkan jawaban 1–2 menit. Kamu bisa merekam diri atau berlatih keras.</div>
      </div>
      <div style="text-align:center;">
        <p style="color:var(--text-muted);">Setelah selesai praktik, klik Selanjutnya.</p>
      </div>
    `;
  } else {
    if (q.passage) {
      html += `<div class="passage-box"><h4>${q.title || ""}</h4><p>${q.passage}</p></div>`;
    }
    if (q.script) {
      html += `
        <div class="listening-box">
          <h4>${q.title || "Listening"}</h4>
          <p style="color:var(--text-muted);font-size:0.9rem;margin:8px 0;">Klik Play untuk mendengarkan audio (TTS). Script disembunyikan secara default agar mirip tes asli.</p>
          <div class="audio-controls" style="margin:12px 0;">
            <button class="play-btn" type="button" onclick="playMockListeningAudio()"><i class="fas fa-play"></i></button>
            <span id="mock-audio-status">Siap diputar</span>
          </div>
          <div class="script-toggle" onclick="this.nextElementSibling.classList.toggle('show')">Tampilkan / Sembunyikan Script</div>
          <div class="script-text">${q.script}</div>
        </div>
      `;
    }
    html += `<p style="font-weight:500;margin:16px 0 12px;">${q.q}</p>`;
    q.opts.forEach((o, i) => {
      const sel = currentMock.answers[currentMock.qIndex] === i ? "selected" : "";
      html += `<div class="option ${sel}" onclick="selectMockAnswer(${i})">
        <span class="opt-letter">${String.fromCharCode(65 + i)}</span>
        <span>${o}</span>
      </div>`;
    });
  }

  document.getElementById("mock-content").innerHTML = html;
  document.getElementById("mock-prev").disabled = currentMock.qIndex === 0;
  document.getElementById("mock-next").textContent =
    currentMock.qIndex === total - 1 ? "Selesai Section" : "Selanjutnya";
}

function selectMockAnswer(idx) {
  currentMock.answers[currentMock.qIndex] = idx;
  renderMockQuestion();
}

function mockPrev() {
  if (currentMock.qIndex > 0) {
    currentMock.qIndex--;
    renderMockQuestion();
  }
}

function mockNext() {
  const q = currentMock.questions[currentMock.qIndex];
  if (q.type === "writing") {
    const text = document.getElementById("mock-writing")?.value || "";
    currentMock.answers[currentMock.qIndex] = text;
  } else if (q.type === "speaking") {
    currentMock.answers[currentMock.qIndex] = "practiced";
  }

  if (currentMock.qIndex < currentMock.questions.length - 1) {
    currentMock.qIndex++;
    renderMockQuestion();
  } else {
    finishMockSection();
  }
}

function finishMockSection() {
  clearInterval(mockTimerInterval);
  const section = currentMock.currentSection;
  const questions = currentMock.questions;
  let score = 0;
  let max = questions.length;

  if (section === "speaking") {
    // Speaking scored only via AI Call (objective). If skipped, mark incomplete.
    if (currentMock.scores.speaking == null) {
      currentMock.scores.speaking = 0;
      showToast("Speaking belum dinilai — skor 0. Gunakan AI Call untuk skor objektif.", "error");
    }
    score = currentMock.scores.speaking;
  } else if (section === "writing") {
    // Score from actual user answers (length + basic structure), NOT random
    let total = 0;
    let n = 0;
    questions.forEach((q, i) => {
      const ans = (currentMock.answers[i] || "").toString().trim();
      if (!ans) return;
      n++;
      const words = ans.split(/\s+/).filter(Boolean).length;
      let band = 4.0;
      if (words >= 150) band += 1.5;
      else if (words >= 80) band += 1.0;
      else if (words >= 40) band += 0.5;
      else band -= 0.5;
      if (/\b(however|therefore|furthermore|although|because)\b/i.test(ans)) band += 0.5;
      if (/\b(in conclusion|to conclude|overall)\b/i.test(ans)) band += 0.25;
      if (words < 20) band = Math.min(band, 3.5);
      total += Math.max(2, Math.min(9, band));
    });
    score = n ? Math.round((total / n) * 2) / 2 : 0;
    currentMock.scores[section] = score;
  } else {
    let correct = 0;
    questions.forEach((q, i) => {
      const right = q.ans !== undefined ? q.ans : q.correct;
      if (right !== undefined && currentMock.answers[i] === right) correct++;
    });
    if (max === 0) {
      score = 0;
    } else if (currentMock.type === "ielts") {
      const pct = correct / max;
      score = Math.min(9, Math.round(pct * 9 * 2) / 2);
    } else {
      score = Math.round((correct / max) * 30);
    }
    currentMock.scores[section] = score;
  }

  currentMock.sectionIndex++;
  if (currentMock.sectionIndex < currentMock.sections.length) {
    showToast(`Section ${section} selesai! Lanjut ke section berikutnya.`, "success");
    setTimeout(loadMockSection, 800);
  } else {
    showMockResult();
  }
}

function showMockResult() {
  document.getElementById("mock-runner").classList.add("hidden");
  document.getElementById("mock-result").classList.remove("hidden");

  const scores = currentMock.scores || {};
  const vals = Object.values(scores).filter((v) => typeof v === "number");
  if (!vals.length) {
    document.getElementById("mock-final-score").textContent = "—";
    document.getElementById("mock-score-desc").textContent = "Belum ada skor — selesaikan section dulu";
    document.getElementById("section-scores").innerHTML = "";
    return;
  }

  let overall;
  if (currentMock.type === "ielts") {
    overall = vals.reduce((a, b) => a + b, 0) / vals.length;
    overall = Math.round(overall * 2) / 2;
    document.getElementById("mock-final-score").textContent = overall.toFixed(1);
    document.getElementById("mock-score-desc").textContent = "IELTS Overall Band Score (dari section yang dikerjakan)";
  } else {
    overall = vals.reduce((a, b) => a + (b > 9 ? b : Math.round(b * 3.3)), 0);
    overall = Math.min(120, Math.round(overall));
    document.getElementById("mock-final-score").textContent = overall;
    document.getElementById("mock-score-desc").textContent = "TOEFL iBT Total (approx, section dikerjakan)";
  }

  // Section scores
  document.getElementById("section-scores").innerHTML = Object.entries(scores).map(([sec, sc]) => `
    <div class="section-score-card">
      <h4>${capitalize(sec)}</h4>
      <div class="score">${typeof sc === "number" ? (sc % 1 === 0 ? sc : sc.toFixed(1)) : sc}</div>
    </div>
  `).join("");

  // Save history
  const entry = {
    type: currentMock.type,
    score: overall,
    scores: { ...scores },
    date: new Date().toLocaleDateString("id-ID")
  };
  state.mockHistory.unshift(entry);
  if (!state.bestMock || overall > parseFloat(state.bestMock)) {
    state.bestMock = currentMock.type === "ielts" ? overall.toFixed(1) : String(overall);
  }
  state.xp += 50;
  updateGoalProgress("mock");
  saveState();
  updateUI();
  showToast("Mock test selesai! +50 XP", "success");
}

function exitMock() {
  clearInterval(mockTimerInterval);
  currentMock = null;
  document.getElementById("mock-runner").classList.add("hidden");
  document.getElementById("mock-result").classList.add("hidden");
  document.getElementById("mock-selection").classList.remove("hidden");
}

function reviewMock() {
  showToast("Fitur review detail akan segera hadir. Lihat skor section di atas!", "success");
}

// ---------- Goals ----------
function createGoal() {
  const type = document.getElementById("goal-type").value;
  const amount = parseInt(document.getElementById("goal-amount").value) || 1;
  const period = document.getElementById("goal-period").value;

  const labels = {
    lessons: "Selesaikan Lesson",
    minutes: "Belajar (menit)",
    practice: "Latihan Skills",
    mock: "Selesaikan Mock Test"
  };
  const periodLabels = { daily: "Harian", weekly: "Mingguan", monthly: "Bulanan" };

  const goal = {
    id: Date.now(),
    type,
    amount,
    period,
    progress: 0,
    label: `${labels[type]}: ${amount} (${periodLabels[period]})`,
    created: new Date().toISOString(),
    expires: getExpiry(period)
  };

  state.goals.push(goal);
  saveState();
  renderGoals();
  showToast("Target berhasil dibuat!", "success");
}

function getExpiry(period) {
  const d = new Date();
  if (period === "daily") d.setHours(23, 59, 59);
  else if (period === "weekly") d.setDate(d.getDate() + (7 - d.getDay()));
  else d.setMonth(d.getMonth() + 1, 0);
  return d.toISOString();
}

function updateGoalProgress(type) {
  const now = new Date();
  state.goals.forEach(g => {
    if (g.type === type && new Date(g.expires) > now) {
      g.progress = Math.min(g.amount, g.progress + 1);
    }
  });
  saveState();
}

function calcGoalProgress() {
  if (state.goals.length === 0) return 0;
  const active = state.goals.filter(g => new Date(g.expires) > new Date());
  if (active.length === 0) return 0;
  const avg = active.reduce((sum, g) => sum + (g.progress / g.amount) * 100, 0) / active.length;
  return Math.round(avg);
}

function renderGoals() {
  const list = document.getElementById("goals-list");
  if (state.goals.length === 0) {
    list.innerHTML = `<p class="empty-state">Belum ada target. Buat target pertamamu di atas!</p>`;
    return;
  }

  const now = new Date();
  list.innerHTML = state.goals.map(g => {
    const expired = new Date(g.expires) < now;
    const pct = Math.round((g.progress / g.amount) * 100);
    let status = "in-progress";
    let statusText = `${g.progress}/${g.amount}`;
    if (g.progress >= g.amount) {
      status = "achieved";
      statusText = "Tercapai ✓";
    } else if (expired) {
      status = "failed";
      statusText = "Tidak tercapai";
    }

    return `
      <div class="goal-item">
        <div class="goal-icon"><i class="fas fa-bullseye"></i></div>
        <div class="goal-info">
          <h4>${g.label}</h4>
          <div class="goal-meta">Berakhir: ${new Date(g.expires).toLocaleDateString("id-ID")}</div>
          <div class="goal-progress-bar"><div class="fill" style="width:${Math.min(100, pct)}%"></div></div>
        </div>
        <span class="goal-status ${status}">${statusText}</span>
      </div>
    `;
  }).join("");
}

// ---------- Progress ----------
function renderProgress() {
  const totalLessons = Object.values(GRAMMAR_LESSONS).flat().length;
  const pct = Math.round((state.lessonsCompleted.length / totalLessons) * 100) || 0;
  document.getElementById("overall-circle").setAttribute("stroke-dasharray", `${pct}, 100`);
  document.getElementById("overall-percent").textContent = pct + "%";
  document.getElementById("prog-xp").textContent = state.xp;
  document.getElementById("prog-streak").textContent = state.streak + " hari";
  document.getElementById("prog-lessons").textContent = state.lessonsCompleted.length;
  document.getElementById("prog-mocks").textContent = state.mockHistory.length;

  const hist = document.getElementById("score-history");
  if (state.mockHistory.length === 0) {
    hist.innerHTML = `<p class="empty-state">Belum ada mock test yang dikerjakan.</p>`;
  } else {
    hist.innerHTML = state.mockHistory.map(h => `
      <div class="history-item">
        <div class="h-left">
          <span class="h-badge ${h.type}">${h.type.toUpperCase()}</span>
          <span>${h.date}</span>
        </div>
        <div class="h-score">${typeof h.score === "number" ? (h.score % 1 === 0 ? h.score : h.score.toFixed(1)) : h.score}</div>
      </div>
    `).join("");
  }
}

// ---------- Utils ----------
function showToast(msg, type = "success") {
  const toast = document.getElementById("toast");
  toast.textContent = msg;
  toast.className = `toast ${type}`;
  toast.classList.remove("hidden");
  setTimeout(() => toast.classList.add("hidden"), 3000);
}

function showModal(html) {
  document.getElementById("modal-body").innerHTML = html;
  document.getElementById("modal").classList.remove("hidden");
}

function closeModal() {
  document.getElementById("modal").classList.add("hidden");
}

// ---------- Structured Learn Path ----------


// ---------- Vocab & Dialog phase (rich) ----------
function speakWord(text, rate) {
  if (!window.speechSynthesis || !text) {
    showToast("Text-to-speech tidak tersedia di browser ini.", "error");
    return;
  }
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(String(text));
  u.lang = "en-US";
  u.rate = rate || 0.9;
  const voices = window.speechSynthesis.getVoices();
  const en = voices.find(v => /en(-|_)US/i.test(v.lang)) || voices.find(v => /^en/i.test(v.lang));
  if (en) u.voice = en;
  window.speechSynthesis.speak(u);
}

function renderVocabDialogPhase(c, unit, level) {
  const vocab = c.vocab || [];
  const dialogues = c.dialogues || [];
  const nav = `
    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:22px;">
      <button class="btn btn-secondary" type="button" onclick="learnPhase=2;renderLearnPhase()"><i class="fas fa-arrow-left"></i> Kembali</button>
      <button class="btn btn-primary" type="button" onclick="learnPhase=4;renderLearnPhase()">Latihan terbimbing <i class="fas fa-arrow-right"></i></button>
    </div>`;

  const vocabHtml = vocab.map((v, i) => `
    <div class="vocab-card vocab-card-rich">
      <div class="en" style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
        <strong>${escapeHtml(v.en)}</strong>
        <small style="opacity:.75">${escapeHtml(v.ipa || "")}</small>
        <button type="button" class="btn btn-sm btn-secondary" title="Dengar pelafalan"
          onclick="speakWord(${JSON.stringify(v.en)})"><i class="fas fa-volume-up"></i></button>
      </div>
      <div class="id">${escapeHtml(v.id || "")}</div>
      <div class="ex" style="margin-top:6px;">
        <em>${escapeHtml(v.ex || "")}</em>
        ${v.exId ? `<br><span style="color:var(--text-muted);font-size:0.85rem;">${escapeHtml(v.exId)}</span>` : ""}
        ${v.ex ? `<button type="button" class="btn btn-sm btn-secondary" style="margin-top:6px;" onclick='speakWord(${JSON.stringify(v.ex)}, 0.85)'><i class="fas fa-volume-up"></i> Contoh</button>` : ""}
      </div>
    </div>`).join("");

  const dlgHtml = dialogues.length
    ? dialogues.map((d, di) => `
      <div class="dialog-block" style="margin-bottom:16px;padding:14px;background:var(--bg);border-radius:12px;border:1px solid var(--border);">
        <h5 style="margin:0 0 10px;color:var(--primary-light);">${di + 1}. ${escapeHtml(d.title || "Dialog")}</h5>
        ${(d.lines || []).map(ln => `
          <div style="margin-bottom:8px;">
            <strong>${escapeHtml(ln.sp || "")}:</strong>
            <button type="button" class="btn btn-sm btn-secondary" style="padding:2px 8px;margin-left:4px;" onclick='speakWord(${JSON.stringify(ln.en)})'><i class="fas fa-volume-up"></i></button>
            <div>${escapeHtml(ln.en || "")}</div>
            <div style="color:var(--text-muted);font-size:0.88rem;">${escapeHtml(ln.id || "")}</div>
          </div>`).join("")}
        ${d.tips ? `<p style="margin-top:10px;font-size:0.9rem;"><strong>Ungkapan penting:</strong> ${escapeHtml(d.tips)}</p>` : ""}
      </div>`).join("")
    : (c.dialogue
        ? `<pre style="white-space:pre-wrap;background:var(--bg);padding:14px;border-radius:12px;">${escapeHtml(c.dialogue)}</pre>`
        : "<p>Belum ada dialog.</p>");

  return `
    <h4 style="color:var(--primary-light);">1) Kosakata & pelafalan</h4>
    <p style="color:var(--text-muted);margin-bottom:12px;">Tekan ikon volume untuk mendengar (Text-to-Speech browser). Cocok untuk latihan alfabet & bunyi dasar.</p>
    <div class="vocab-grid">${vocabHtml}</div>

    <h4 style="margin-top:22px;color:var(--primary-light);">2) Dialog kontekstual</h4>
    <p style="color:var(--text-muted);">Baca, dengarkan tiap baris, pahami terjemahan, lalu coba latihan interaktif di bawah.</p>
    ${dlgHtml}

    <h4 style="margin-top:22px;color:var(--primary-light);">3) Latihan kosakata (satu soal per layar)</h4>
    <p style="color:var(--text-muted);">Kunci jawaban baru muncul setelah kamu menjawab.</p>
    <button class="btn btn-primary" type="button" onclick="startVocabDrill()"><i class="fas fa-play"></i> Mulai latihan kosakata</button>
    <div id="vocab-drill-area" style="margin-top:12px;"></div>

    <h4 style="margin-top:22px;color:var(--primary-light);">4) Latihan dialog interaktif</h4>
    <button class="btn btn-primary" type="button" onclick="startDialogDrill()"><i class="fas fa-comments"></i> Mulai latihan dialog</button>
    <div id="dialog-drill-area" style="margin-top:12px;"></div>

    ${c.summary ? `<div style="margin-top:18px;padding:12px;border:1px solid var(--border);border-radius:10px;"><strong>Ringkasan:</strong> ${c.summary}</div>` : ""}
    ${nav}`;
}

function startVocabDrill() {
  if (!learnCtx) return;
  const items = (learnCtx.unit.content.vocabPractice || []).slice();
  if (!items.length) {
    showToast("Latihan kosakata belum tersedia di unit ini.", "error");
    return;
  }
  window.__vocabDrill = { items, idx: 0, correct: 0, answered: false };
  renderVocabDrillQ();
}

function renderVocabDrillQ() {
  const st = window.__vocabDrill;
  const box = document.getElementById("vocab-drill-area");
  if (!st || !box) return;
  if (st.idx >= st.items.length) {
    const score = st.correct / st.items.length;
    box.innerHTML = `<div class="writing-prompt"><strong>Selesai.</strong> Skor: ${st.correct}/${st.items.length} (${Math.round(score * 100)}%).
      ${score >= 0.8 ? "Bagus!" : "Ulangi lagi untuk menguasai."}</div>
      <button class="btn btn-secondary btn-sm" type="button" onclick="startVocabDrill()">Ulangi latihan</button>`;
    // persist soft progress note (not unit mastery)
    state.vocabDrillScores = state.vocabDrillScores || {};
    const key = (learnCtx.level || "") + ":" + (learnCtx.unit.id || "");
    state.vocabDrillScores[key] = { correct: st.correct, total: st.items.length, at: new Date().toISOString() };
    saveState();
    return;
  }
  const it = st.items[st.idx];
  let opts = "";
  if (it.type === "gap") {
    opts = `<input id="vd-gap" type="text" placeholder="Ketik jawaban" style="width:100%;padding:10px;border-radius:10px;border:1px solid var(--border);background:var(--card);color:var(--text);">
      <button class="btn btn-primary btn-sm" style="margin-top:8px;" type="button" onclick="answerVocabGap()">Cek</button>`;
  } else {
    opts = (it.options || []).map((o, oi) =>
      `<button type="button" class="option adapt-opt" style="display:block;width:100%;text-align:left;margin-bottom:8px;" onclick="answerVocabOpt(${oi})">${String.fromCharCode(65 + oi)}. ${escapeHtml(o)}</button>`
    ).join("");
  }
  box.innerHTML = `
    <div style="padding:14px;background:var(--bg);border-radius:12px;border:1px solid var(--border);">
      <p style="font-size:0.85rem;color:var(--text-muted);">Soal ${st.idx + 1}/${st.items.length} · ${it.type || "mcq"}</p>
      <p style="font-weight:600;">${escapeHtml(it.q)}</p>
      <div id="vd-opts">${opts}</div>
      <div id="vd-fb" style="margin-top:10px;"></div>
      <button type="button" class="btn btn-primary hidden" id="vd-next" onclick="nextVocabDrill()">Soal berikutnya</button>
    </div>`;
}

function answerVocabOpt(oi) {
  const st = window.__vocabDrill;
  if (!st || st.answered) return;
  st.answered = true;
  const it = st.items[st.idx];
  const good = oi === it.correct;
  if (good) st.correct++;
  else {
    logMistake({
      q: it.q,
      correctOpt: (it.options || [])[it.correct],
      userAns: (it.options || [])[oi],
      explain: it.explain || "",
      level: learnCtx.level,
      unitId: learnCtx.unit.id,
      source: "vocab-drill"
    });
  }
  document.querySelectorAll("#vd-opts .adapt-opt").forEach(btn => {
    btn.disabled = true;
  });
  const fb = document.getElementById("vd-fb");
  if (fb) {
    fb.innerHTML = good
      ? `<span style="color:var(--success);font-weight:600;">Benar.</span> ${escapeHtml(it.explain || "")}`
      : `<span style="color:#f87171;font-weight:600;">Belum tepat.</span> Kunci: <strong>${escapeHtml((it.options || [])[it.correct] || "")}</strong>. ${escapeHtml(it.explain || "")}`;
  }
  const next = document.getElementById("vd-next");
  if (next) {
    next.classList.remove("hidden");
    next.textContent = st.idx >= st.items.length - 1 ? "Lihat hasil" : "Soal berikutnya";
  }
}

function answerVocabGap() {
  const st = window.__vocabDrill;
  if (!st || st.answered) return;
  const it = st.items[st.idx];
  const val = (document.getElementById("vd-gap") && document.getElementById("vd-gap").value || "").trim().toLowerCase();
  const ans = String(it.answer || "").trim().toLowerCase();
  st.answered = true;
  const good = val === ans || (ans.endsWith("s") && val === ans.slice(0, -1)) || (val + "s" === ans);
  if (good) st.correct++;
  else {
    logMistake({
      q: it.q,
      correctOpt: it.answer,
      userAns: val || "(kosong)",
      explain: it.explain || "",
      level: learnCtx.level,
      unitId: learnCtx.unit.id,
      source: "vocab-drill"
    });
  }
  const fb = document.getElementById("vd-fb");
  if (fb) {
    fb.innerHTML = good
      ? `<span style="color:var(--success);font-weight:600;">Benar.</span> ${escapeHtml(it.explain || "")}`
      : `<span style="color:#f87171;font-weight:600;">Belum tepat.</span> Kunci: <strong>${escapeHtml(it.answer || "")}</strong>. ${escapeHtml(it.explain || "")}`;
  }
  const next = document.getElementById("vd-next");
  if (next) next.classList.remove("hidden");
}

function nextVocabDrill() {
  const st = window.__vocabDrill;
  if (!st) return;
  st.idx++;
  st.answered = false;
  renderVocabDrillQ();
}

function startDialogDrill() {
  if (!learnCtx) return;
  const items = (learnCtx.unit.content.dialoguePractice || []).slice();
  if (!items.length) {
    showToast("Latihan dialog belum tersedia di unit ini.", "error");
    return;
  }
  window.__dialogDrill = { items, idx: 0, correct: 0, answered: false };
  renderDialogDrillQ();
}

function renderDialogDrillQ() {
  const st = window.__dialogDrill;
  const box = document.getElementById("dialog-drill-area");
  if (!st || !box) return;
  if (st.idx >= st.items.length) {
    box.innerHTML = `<div class="writing-prompt"><strong>Latihan dialog selesai.</strong> Benar ${st.correct}/${st.items.length}.</div>
      <button class="btn btn-secondary btn-sm" type="button" onclick="startDialogDrill()">Ulangi</button>`;
    return;
  }
  const it = st.items[st.idx];
  box.innerHTML = `
    <div style="padding:14px;background:var(--bg);border-radius:12px;border:1px solid var(--border);">
      <p style="font-size:0.85rem;color:var(--text-muted);">Dialog ${st.idx + 1}/${st.items.length}</p>
      <p style="font-weight:600;">${escapeHtml(it.q)}</p>
      <div id="dd-opts">${(it.options || []).map((o, oi) =>
        `<button type="button" class="option adapt-opt" style="display:block;width:100%;text-align:left;margin-bottom:8px;" onclick="answerDialogOpt(${oi})">${String.fromCharCode(65 + oi)}. ${escapeHtml(o)}</button>`
      ).join("")}</div>
      <div id="dd-fb" style="margin-top:10px;"></div>
      <button type="button" class="btn btn-primary hidden" id="dd-next" onclick="nextDialogDrill()">Lanjut</button>
    </div>`;
}

function answerDialogOpt(oi) {
  const st = window.__dialogDrill;
  if (!st || st.answered) return;
  st.answered = true;
  const it = st.items[st.idx];
  const good = oi === it.correct;
  if (good) st.correct++;
  else {
    logMistake({
      q: it.q,
      correctOpt: (it.options || [])[it.correct],
      userAns: (it.options || [])[oi],
      explain: it.explain || "",
      level: learnCtx.level,
      unitId: learnCtx.unit.id,
      source: "dialog-drill"
    });
  }
  document.querySelectorAll("#dd-opts .adapt-opt").forEach(b => { b.disabled = true; });
  const fb = document.getElementById("dd-fb");
  if (fb) {
    fb.innerHTML = good
      ? `<span style="color:var(--success);font-weight:600;">Tepat.</span> ${escapeHtml(it.explain || "")}`
      : `<span style="color:#f87171;font-weight:600;">Belum tepat.</span> Pilihan yang baik: <strong>${escapeHtml((it.options || [])[it.correct] || "")}</strong>. ${escapeHtml(it.explain || "")}`;
  }
  const next = document.getElementById("dd-next");
  if (next) next.classList.remove("hidden");
}

function nextDialogDrill() {
  const st = window.__dialogDrill;
  if (!st) return;
  st.idx++;
  st.answered = false;
  renderDialogDrillQ();
}


// ---------- CEFR Learn Path Engine ----------
function getUnitMasteryKey(level, unitId) {
  return level + "::" + unitId;
}

function getUnitRecord(level, unitId) {
  state.unitRecords = state.unitRecords || {};
  const k = getUnitMasteryKey(level, unitId);
  return state.unitRecords[k] || null;
}

function setUnitRecord(level, unitId, rec) {
  state.unitRecords = state.unitRecords || {};
  state.unitRecords[getUnitMasteryKey(level, unitId)] = rec;
  saveState();
}

function isUnitMastered(level, unitId) {
  const r = getUnitRecord(level, unitId);
  return r && r.passed === true;
}

function isUnitUnlocked(level, unitIndex) {
  if (!isLevelUnlocked(level)) return false;
  if (unitIndex === 0) return true;
  const units = (LEARN_PATH[level] || []);
  const prev = units[unitIndex - 1];
  if (!prev) return true;
  return isUnitMastered(level, prev.id);
}

function levelUnitProgress(level) {
  const units = (LEARN_PATH && LEARN_PATH[level]) ? LEARN_PATH[level] : [];
  if (!units.length) return 0;
  const done = units.filter(u => isUnitMastered(level, u.id)).length;
  return Math.round((done / units.length) * 100);
}

function isReadyForLevelExam(level) {
  return levelUnitProgress(level) >= 80;
}

function renderLearnPath(level) {
  const order = (typeof CEFR_ORDER !== "undefined") ? CEFR_ORDER : ["a1","a2","b1","b2","c1","c2"];
  if (!level) level = state.level || "a1";
  if (!isLevelUnlocked(level)) {
    showToast("Level " + level.toUpperCase() + " terkunci. Selesaikan level sebelumnya.", "error");
    level = state.level || "a1";
  }

  document.querySelectorAll("#learn-tabs .tab").forEach(t => {
    const lv = t.dataset.level;
    t.classList.toggle("active", lv === level);
    t.classList.toggle("locked", !isLevelUnlocked(lv));
    t.onclick = () => {
      if (!isLevelUnlocked(lv)) {
        showToast("🔒 Selesaikan & lulus evaluasi level sebelumnya.", "error");
        return;
      }
      renderLearnPath(lv);
    };
  });

  const meta = (typeof CEFR_META !== "undefined" && CEFR_META[level]) ? CEFR_META[level] : {};
  const goalEl = document.getElementById("cefr-goal");
  if (goalEl) {
    goalEl.innerHTML = meta.label
      ? `<strong>${meta.label}</strong> — ${meta.goal || ""}`
      : "";
  }

  document.getElementById("learn-lesson").classList.add("hidden");
  document.getElementById("learn-path").classList.remove("hidden");

  const units = LEARN_PATH[level] || [];
  const path = document.getElementById("learn-path");
  const pct = levelUnitProgress(level);
  const passedLevel = (state.levelTestsPassed || []).includes(level);

  let banner = `
    <div class="level-exam-banner">
      <div>
        <strong>Progres ${ (meta.label || level).toString() }: ${pct}%</strong>
        <p style="font-size:0.85rem;color:var(--text-muted);margin:4px 0 0;">
          Unit terbuka berurutan. Evaluasi unit minimal ${Math.round((typeof UNIT_PASS_SCORE!=="undefined"?UNIT_PASS_SCORE:0.8)*100)}%. 
          Level exam setelah ≥80% unit lulus.
        </p>
      </div>
      ${passedLevel ? '<span class="goal-status achieved">Level exam lulus ✓</span>' :
        (isReadyForLevelExam(level)
          ? `<button class="btn btn-primary btn-sm" onclick="startLevelExam('${level}')">Ujian Naik Level</button>`
          : `<span class="goal-status in-progress">${pct}% unit dikuasai</span>`)}
    </div>`;

  path.innerHTML = banner + units.map((u, i) => {
    const mastered = isUnitMastered(level, u.id);
    const unlocked = isUnitUnlocked(level, i);
    const rec = getUnitRecord(level, u.id);
    let cls = "learn-unit";
    if (mastered) cls += " done";
    else if (unlocked) cls += " current";
    else cls += " level-locked";
    const scoreTxt = rec && typeof rec.score === "number"
      ? ` · skor ${Math.round(rec.score * 100)}%`
      : "";
    return `
      <div class="${cls}">
        <div class="learn-dot">${mastered ? "✓" : (i + 1)}</div>
        <div class="learn-unit-body" onclick="${unlocked ? `openLearnLesson('${level}','${u.id}')` : `showToast('Selesaikan unit sebelumnya dulu','error')`}">
          <h4>${u.title}${!unlocked ? " 🔒" : ""}</h4>
          <p>${u.desc}${scoreTxt}</p>
          <div class="learn-tags">${(u.tags || []).map(tg => `<span>${tg}</span>`).join("")}</div>
        </div>
      </div>`;
  }).join("");
}

let learnCtx = null;
let learnPhase = 0;
/** Phases: 0 orient, 1 theory, 2 examples, 3 vocab, 4 guided, 5 independent, 6 practice, 7 eval, 8 result */

function openLearnLesson(level, id) {
  const units = LEARN_PATH[level] || [];
  const idx = units.findIndex(u => u.id === id);
  if (idx < 0) return;
  if (!isUnitUnlocked(level, idx)) {
    showToast("Unit terkunci — selesaikan prasyarat.", "error");
    return;
  }
  learnCtx = { level, unit: units[idx], idx };
  learnPhase = 0;
  document.getElementById("learn-path").classList.add("hidden");
  document.getElementById("learn-lesson").classList.remove("hidden");
  renderLearnPhase();
}

function closeLearnLesson() {
  const lv = (learnCtx && learnCtx.level) || state.level || "a1";
  learnCtx = null;
  document.getElementById("learn-lesson").classList.add("hidden");
  document.getElementById("learn-path").classList.remove("hidden");
  renderLearnPath(lv);
}

function learnPhaseNames() {
  return [
    "Orientasi", "Materi inti", "Contoh", "Vocab & dialog",
    "Latihan terbimbing", "Latihan mandiri", "Praktik", "Evaluasi", "Hasil"
  ];
}

function renderLearnPhase() {
  if (!learnCtx) return;
  const { unit, level } = learnCtx;
  const c = unit.content || {};
  const names = learnPhaseNames();
  const bar = names.map((n, i) => {
    const st = i === learnPhase ? "background:var(--primary);color:#fff;" :
      (i < learnPhase ? "background:var(--success);color:#fff;" : "background:var(--bg);color:var(--text-muted);");
    return `<span style="padding:4px 8px;border-radius:12px;font-size:0.68rem;font-weight:600;${st}">${i + 1}. ${n}</span>`;
  }).join(" ");

  let body = "";
  const nav = (prev, next, nextLabel) => `
    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:22px;">
      ${prev != null ? `<button class="btn btn-secondary" type="button" onclick="learnPhase=${prev};renderLearnPhase()"><i class="fas fa-arrow-left"></i> Kembali</button>` : ""}
      ${next != null ? `<button class="btn btn-primary" type="button" onclick="learnPhase=${next};renderLearnPhase()">${nextLabel || "Lanjut"} <i class="fas fa-arrow-right"></i></button>` : ""}
    </div>`;

  if (learnPhase === 0) {
    body = `
      <div class="book-section-title"><i class="fas fa-bullseye"></i> Orientasi & Tujuan</div>
      <div class="book-objectives">
        <h4>🎯 Tujuan pembelajaran</h4>
        <ul>${(c.objectives || []).map(o => `<li>${o}</li>`).join("") || "<li>Menguasai materi unit ini</li>"}</ul>
      </div>
      <div class="book-prose"><p>${c.orientation || ""}</p></div>
      <div class="book-card tip"><strong>Catatan:</strong> Kelulusan unit ditentukan evaluasi (minimal ${Math.round((UNIT_PASS_SCORE||0.8)*100)}%). Baca materi dengan saksama seperti membaca buku teks.</div>
      <div class="book-nav">
        <button class="btn btn-primary" type="button" onclick="learnPhase=1;renderLearnPhase()">Mulai materi inti <i class="fas fa-arrow-right"></i></button>
      </div>`;
  } else if (learnPhase === 1) {
    body = `
      <div class="book-section-title"><i class="fas fa-book"></i> Materi Inti</div>
      <div class="book-prose">${c.theory || "<p>Materi sedang disiapkan.</p>"}</div>
      ${(c.rules && c.rules.length) ? `<div class="book-section-title" style="margin-top:22px;"><i class="fas fa-list-check"></i> Aturan Penting</div><ul class="book-rule-list">${c.rules.map(r => `<li>${r}</li>`).join("")}</ul>` : ""}
      <div class="book-nav">
        <button class="btn btn-secondary" type="button" onclick="learnPhase=0;renderLearnPhase()"><i class="fas fa-arrow-left"></i> Kembali</button>
        <button class="btn btn-primary" type="button" onclick="learnPhase=2;renderLearnPhase()">Lanjut ke contoh <i class="fas fa-arrow-right"></i></button>
      </div>`;
  } else if (learnPhase === 2) {
    body = `
      <div class="book-section-title"><i class="fas fa-lightbulb"></i> Contoh & Analisis</div>
      ${(c.examples || []).map((ex, i) => `
        <div class="book-card example">
          <div class="book-en">${i + 1}. ${ex.en}</div>
          <div class="book-id">${ex.id || ""}</div>
          <div class="book-why">Mengapa benar: ${ex.why || ""}</div>
        </div>`).join("") || "<p>Tidak ada contoh.</p>"}
      ${c.compare ? `<div class="book-card compare"><strong>Perbandingan:</strong> ${c.compare}</div>` : ""}
      ${(c.commonErrors || []).length ? `
        <div class="book-section-title" style="margin-top:20px;"><i class="fas fa-triangle-exclamation"></i> Kesalahan Umum</div>
        ${(c.commonErrors).map(e => `
          <div class="book-card error">
            <div style="color:#f87171;margin-bottom:4px;">✗ ${e.wrong}</div>
            <div style="color:#6ee7b7;margin-bottom:4px;">✓ ${e.right}</div>
            <div class="book-why">${e.why || ""}</div>
          </div>`).join("")}` : ""}
      <div class="book-nav">
        <button class="btn btn-secondary" type="button" onclick="learnPhase=1;renderLearnPhase()"><i class="fas fa-arrow-left"></i> Kembali</button>
        <button class="btn btn-primary" type="button" onclick="learnPhase=3;renderLearnPhase()">Lanjut <i class="fas fa-arrow-right"></i></button>
      </div>`;
  } else if (learnPhase === 3) {
    body = renderVocabDialogPhase(c, unit, level);
  } else if (learnPhase === 4) {
    const items = c.guided || [];
    body = `
      <h4 style="color:var(--primary-light);">Latihan terbimbing</h4>
      <p style="color:var(--text-muted);margin-bottom:12px;">Jawab, lalu cek. Ada pembahasan.</p>
      <div id="guided-box">${items.map((it, qi) => `
        <div style="margin-bottom:16px;padding:12px;background:var(--bg);border-radius:12px;border:1px solid var(--border);">
          <p>${qi + 1}. ${it.q}</p>
          ${(it.options || []).map((o, oi) => `
            <label class="option" style="display:flex;cursor:pointer;margin:6px 0;">
              <input type="radio" name="gd${qi}" value="${oi}" style="margin-right:8px;"> ${o}
            </label>`).join("")}
          <div id="gd-fb${qi}" style="margin-top:8px;font-size:0.9rem;"></div>
        </div>`).join("") || "<p>Tidak ada soal terbimbing.</p>"}</div>
      <button class="btn btn-primary" type="button" onclick="checkGuidedPhase()">Cek jawaban terbimbing</button>
      ${nav(3, 5, "Lanjut mandiri")}`;
  } else if (learnPhase === 5) {
    const items = c.independent || [];
    body = `
      <h4 style="color:var(--primary-light);">Latihan mandiri</h4>
      ${items.map((it, qi) => {
        if (it.type === "write" || it.answer === "open") {
          return `<div style="margin-bottom:14px;"><p>${qi + 1}. ${it.q}</p>
            <textarea id="ind${qi}" rows="3" style="width:100%;padding:10px;border-radius:10px;background:var(--bg);border:1px solid var(--border);color:var(--text);"></textarea>
            <p style="font-size:0.85rem;color:var(--text-muted);margin-top:6px;">Petunjuk: ${it.explain || "Jawab sesuai materi."}</p></div>`;
        }
        if (it.options) {
          return `<div style="margin-bottom:14px;padding:12px;background:var(--bg);border-radius:12px;">
            <p>${qi + 1}. ${it.q}</p>
            ${(it.options).map((o, oi) => `<label class="option" style="display:flex;cursor:pointer;margin:6px 0;">
              <input type="radio" name="ind${qi}" value="${oi}" style="margin-right:8px;"> ${o}</label>`).join("")}
          </div>`;
        }
        return `<div style="margin-bottom:14px;"><p>${qi + 1}. ${it.q}</p>
          <input id="ind${qi}" style="width:100%;padding:10px;border-radius:10px;background:var(--bg);border:1px solid var(--border);color:var(--text);" placeholder="Jawaban singkat">
          <p style="font-size:0.85rem;color:var(--text-muted);">Kunci: akan dibahas di evaluasi / self-check (${it.explain || it.answer || ""})</p></div>`;
      }).join("") || "<p>Praktikkan sendiri dari materi.</p>"}
      ${nav(4, 6, "Praktik nyata")}`;
  } else if (learnPhase === 6) {
    body = `
      <h4 style="color:var(--primary-light);">Praktik nyata</h4>
      <div class="writing-prompt">${c.practice || "Terapkan materi dalam konteks nyata."}</div>
      <textarea id="practice-real" rows="4" style="width:100%;margin-top:12px;padding:12px;border-radius:12px;background:var(--bg);border:1px solid var(--border);color:var(--text);" placeholder="Catat praktikmu di sini (opsional, untuk refleksi)"></textarea>
      ${nav(5, 7, "Mulai evaluasi")}`;
  } else if (learnPhase === 7) {
    const items = c.evaluation || [];
    body = `
      <h4 style="color:var(--primary-light);">Evaluasi penguasaan</h4>
      <p style="color:var(--text-muted);margin-bottom:12px;">Satu soal per layar. Kunci jawaban baru muncul setelah kamu menjawab. Lulus ≥ ${Math.round((UNIT_PASS_SCORE||0.8)*100)}%.</p>
      <p><strong>${items.length}</strong> soal · unit: ${unit.title}</p>
      <button class="btn btn-primary" type="button" onclick="startAdaptiveEval()"><i class="fas fa-play"></i> Mulai evaluasi adaptif</button>
      ${nav(6, null)}`;
  } else {
    const rec = getUnitRecord(level, unit.id) || {};
    const pass = !!rec.passed;
    body = `
      <div class="result-hero" style="text-align:center;padding:20px;">
        <h2>${pass ? "Unit dikuasai ✓" : "Belum lulus"}</h2>
        <div class="big-score">${rec.score != null ? Math.round(rec.score * 100) + "%" : "—"}</div>
        <p>${pass ? "Kamu bisa lanjut unit berikutnya." : "Pelajari remedial, lalu ulangi evaluasi."}</p>
      </div>
      ${!pass && c.remedial ? `<div class="writing-prompt"><strong>Remedial:</strong> ${c.remedial}</div>` : ""}
      ${rec.details ? `<div style="margin-top:12px;font-size:0.9rem;">${rec.details}</div>` : ""}
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:18px;justify-content:center;">
        ${!pass ? `<button class="btn btn-primary" type="button" onclick="learnPhase=1;renderLearnPhase()">Ulangi materi</button>
        <button class="btn btn-secondary" type="button" onclick="learnPhase=7;renderLearnPhase()">Ulangi evaluasi</button>` : ""}
        <button class="btn btn-secondary" type="button" onclick="closeLearnLesson();renderLearnPath('${level}')">Kembali ke jalur</button>
      </div>`;
  }

  const phaseNames = learnPhaseNames();
  const pills = phaseNames.map((n, i) => {
    const cls = i === learnPhase ? "active" : (i < learnPhase ? "done" : "todo");
    return `<span class="book-phase-pill ${cls}">${i + 1}. ${n}</span>`;
  }).join("");
  const levelLabel = (typeof CEFR_META !== "undefined" && CEFR_META[level]) ? CEFR_META[level].label : level.toUpperCase();
  document.getElementById("learn-lesson-body").innerHTML = `
    <div class="book-shell">
      <div class="book-spine"></div>
      <div class="book-header">
        <div class="book-level"><i class="fas fa-book-open"></i> ${levelLabel} · Unit ${(learnCtx.idx||0)+1}</div>
        <h2>${unit.title}</h2>
        <p class="book-desc">${unit.desc || ""}</p>
      </div>
      <div class="book-phase-bar">${pills}</div>
      <div class="book-page">
        ${body}
        <div style="margin-top:18px;">
          <button class="btn btn-secondary btn-sm" type="button" onclick="closeLearnLesson();renderLearnPath('${level}')"><i class="fas fa-arrow-left"></i> Kembali ke jalur belajar</button>
        </div>
      </div>
    </div>`;
}

function checkGuidedPhase() {
  if (!learnCtx) return;
  const items = learnCtx.unit.content.guided || [];
  let ok = 0;
  items.forEach((it, qi) => {
    const sel = document.querySelector(`input[name="gd${qi}"]:checked`);
    const fb = document.getElementById("gd-fb" + qi);
    if (!fb) return;
    if (sel && parseInt(sel.value, 10) === it.correct) {
      ok++;
      fb.innerHTML = `<span style="color:var(--success);">Benar. ${it.explain || ""}</span>`;
    } else {
      fb.innerHTML = `<span style="color:#f87171;">Belum tepat. ${it.explain || ""} Jawaban: ${(it.options || [])[it.correct] || ""}</span>`;
    }
  });
  showToast(`Terbimbing: ${ok}/${items.length}`, ok === items.length ? "success" : "error");
}

function logMistake(entry) {
  state.mistakes = state.mistakes || [];
  const key = (entry.q || "") + "|" + (entry.level || "");
  const existing = state.mistakes.find(m => (m.q + "|" + m.level) === key);
  if (existing) {
    existing.count = (existing.count || 1) + 1;
    existing.lastAt = new Date().toISOString();
    existing.userAns = entry.userAns;
  } else {
    state.mistakes.unshift({
      ...entry,
      count: 1,
      resolved: false,
      lastAt: new Date().toISOString()
    });
  }
  state.mistakes = state.mistakes.slice(0, 100);
  saveState();
}

function submitUnitEvaluation() {
  if (!learnCtx) return;
  const { unit, level } = learnCtx;
  const items = unit.content.evaluation || [];
  if (!items.length) {
    showToast("Evaluasi belum tersedia.", "error");
    return;
  }
  // Adaptive one-at-a-time uses evalState
  if (window.__evalState && window.__evalState.active) {
    finishAdaptiveEval();
    return;
  }
  let correct = 0;
  let details = "<ul style='margin:8px 0 0 16px;'>";
  items.forEach((it, qi) => {
    const sel = document.querySelector(`input[name="ev${qi}"]:checked`);
    const ans = sel ? parseInt(sel.value, 10) : -1;
    const good = ans === it.correct;
    if (good) correct++;
    else {
      logMistake({
        q: it.q,
        correctOpt: (it.options || [])[it.correct],
        userAns: ans >= 0 ? (it.options || [])[ans] : "(kosong)",
        explain: it.explain || "",
        level,
        unitId: unit.id,
        source: "unit-eval"
      });
    }
    details += `<li>${good ? "✓" : "✗"} ${it.q} — ${it.explain || ""} ${!good ? "(kunci: " + ((it.options||[])[it.correct]||"") + ")" : ""}</li>`;
  });
  details += "</ul>";
  const score = correct / items.length;
  const threshold = typeof UNIT_PASS_SCORE !== "undefined" ? UNIT_PASS_SCORE : 0.8;
  const passed = score >= threshold;

  const prev = getUnitRecord(level, unit.id);
  const firstPass = passed && !(prev && prev.passed);
  setUnitRecord(level, unit.id, {
    passed,
    score,
    correct,
    total: items.length,
    details,
    at: new Date().toISOString()
  });

  if (firstPass) {
    if (!(state.lessonsCompleted || []).includes(unit.id)) {
      state.lessonsCompleted = state.lessonsCompleted || [];
      state.lessonsCompleted.push(unit.id);
    }
    state.xp = (state.xp || 0) + 40;
    updateGoalProgress("lessons");
    saveState();
    updateUI();
    showToast("Lulus unit! +40 XP", "success");
    // Update next recommended unit
    try {
      const path = (LEARN_PATH[level] || []);
      const next = path.find(u => !(state.lessonsCompleted || []).includes(u.id));
      if (next) {
        state.recommendedUnitId = next.id;
        state.recommendedUnitTitle = next.title;
      } else {
        state.recommendedUnitTitle = "Level " + level.toUpperCase() + " selesai — coba level berikutnya";
      }
      saveState();
    } catch (e) {}
    checkAndAwardBadges();
  } else if (passed) {
    showToast("Sudah lulus sebelumnya — XP tidak digandakan.", "success");
  } else {
    showToast(`Belum lulus (${Math.round(score*100)}%). Lihat My Mistakes & remedial.`, "error");
  }

  learnPhase = 8;
  renderLearnPhase();
}

function startAdaptiveEval() {
  if (!learnCtx) return;
  const items = (learnCtx.unit.content.evaluation || []).slice();
  if (!items.length) {
    showToast("Tidak ada soal evaluasi.", "error");
    return;
  }
  window.__evalState = {
    active: true,
    items,
    idx: 0,
    correct: 0,
    details: [],
    answered: false
  };
  renderAdaptiveEvalQuestion();
}

function renderAdaptiveEvalQuestion() {
  const st = window.__evalState;
  if (!st || !learnCtx) return;
  const { unit, level } = learnCtx;
  const it = st.items[st.idx];
  const total = st.items.length;
  const box = document.getElementById("learn-lesson-body");
  if (!it) {
    finishAdaptiveEval();
    return;
  }
  box.innerHTML = `
    <button class="btn btn-secondary btn-sm" type="button" onclick="closeLearnLesson();renderLearnPath('${level}')"><i class="fas fa-arrow-left"></i> Jalur</button>
    <h2 style="margin:12px 0 6px;">Evaluasi — ${st.idx + 1} / ${total}</h2>
    <p style="color:var(--text-muted);">Satu soal per layar. Kunci baru muncul setelah kamu menjawab.</p>
    <div style="margin-top:16px;padding:16px;background:var(--bg);border-radius:14px;border:1px solid var(--border);">
      <p style="font-weight:600;margin-bottom:12px;">${it.q}</p>
      <div id="adapt-opts">${(it.options || []).map((o, oi) => `
        <button type="button" class="option adapt-opt" data-oi="${oi}" style="display:block;width:100%;text-align:left;margin-bottom:8px;cursor:pointer;"
          onclick="answerAdaptive(${oi})">${String.fromCharCode(65 + oi)}. ${o}</button>`).join("")}
      </div>
      <div id="adapt-fb" style="margin-top:12px;"></div>
      <button type="button" class="btn btn-primary hidden" id="adapt-next" onclick="nextAdaptiveQuestion()">Soal berikutnya</button>
    </div>
    <p style="margin-top:10px;font-size:0.85rem;color:var(--text-muted);">Skor saat ini: ${st.correct} benar</p>
  `;
}

function answerAdaptive(oi) {
  const st = window.__evalState;
  if (!st || st.answered) return;
  st.answered = true;
  const it = st.items[st.idx];
  const good = oi === it.correct;
  if (good) st.correct++;
  else {
    logMistake({
      q: it.q,
      correctOpt: (it.options || [])[it.correct],
      userAns: (it.options || [])[oi],
      explain: it.explain || "",
      level: learnCtx.level,
      unitId: learnCtx.unit.id,
      source: "unit-eval"
    });
  }
  st.details.push({ good, q: it.q, explain: it.explain || "", oi, correct: it.correct });
  const fb = document.getElementById("adapt-fb");
  document.querySelectorAll(".adapt-opt").forEach(btn => {
    btn.disabled = true;
    const v = parseInt(btn.dataset.oi, 10);
    if (v === it.correct) btn.style.outline = "2px solid var(--success)";
    if (v === oi && !good) btn.style.outline = "2px solid #f87171";
  });
  if (fb) {
    fb.innerHTML = good
      ? `<span style="color:var(--success);font-weight:600;">Benar.</span> ${it.explain || ""}`
      : `<span style="color:#f87171;font-weight:600;">Belum tepat.</span> Kunci: <strong>${(it.options || [])[it.correct]}</strong>. ${it.explain || ""}`;
  }
  const next = document.getElementById("adapt-next");
  if (next) {
    next.classList.remove("hidden");
    next.textContent = st.idx >= st.items.length - 1 ? "Lihat hasil" : "Soal berikutnya";
  }
}

function nextAdaptiveQuestion() {
  const st = window.__evalState;
  if (!st) return;
  st.idx++;
  st.answered = false;
  if (st.idx >= st.items.length) finishAdaptiveEval();
  else renderAdaptiveEvalQuestion();
}

function finishAdaptiveEval() {
  const st = window.__evalState;
  if (!st || !learnCtx) return;
  const { unit, level } = learnCtx;
  const total = st.items.length;
  const correct = st.correct;
  const score = total ? correct / total : 0;
  const threshold = typeof UNIT_PASS_SCORE !== "undefined" ? UNIT_PASS_SCORE : 0.8;
  const passed = score >= threshold;
  let details = "<ul style='margin:8px 0 0 16px;'>";
  st.details.forEach(d => {
    details += `<li>${d.good ? "✓" : "✗"} ${d.q} — ${d.explain}</li>`;
  });
  details += "</ul>";
  const prev = getUnitRecord(level, unit.id);
  const firstPass = passed && !(prev && prev.passed);
  setUnitRecord(level, unit.id, {
    passed, score, correct, total, details, at: new Date().toISOString()
  });
  if (firstPass) {
    if (!(state.lessonsCompleted || []).includes(unit.id)) {
      state.lessonsCompleted = state.lessonsCompleted || [];
      state.lessonsCompleted.push(unit.id);
    }
    state.xp = (state.xp || 0) + 40;
    updateGoalProgress("lessons");
    saveState();
    updateUI();
    showToast("Lulus unit! +40 XP", "success");
  } else if (!passed) {
    showToast(`Belum lulus (${Math.round(score * 100)}%). Cek My Mistakes.`, "error");
  }
  window.__evalState = null;
  learnPhase = 8;
  renderLearnPhase();
}


function startLevelExam(level) {
  if (!isReadyForLevelExam(level)) {
    showToast("Selesaikan minimal 80% unit (lulus evaluasi) dulu.", "error");
    return;
  }
  const units = LEARN_PATH[level] || [];
  const pool = [];
  units.forEach(u => {
    (u.content && u.content.evaluation || []).forEach(q => pool.push(q));
  });
  const quiz = shuffle(pool).slice(0, Math.min(10, pool.length));
  if (quiz.length < 5) {
    showToast("Bank soal level belum cukup.", "error");
    return;
  }
  let idx = 0, answers = [];
  const run = () => {
    if (idx >= quiz.length) {
      let sc = 0;
      answers.forEach((a, i) => { if (a === quiz[i].correct) sc++; });
      const ratio = sc / quiz.length;
      const pass = ratio >= (UNIT_PASS_SCORE || 0.8);
      if (pass) {
        if (!(state.levelTestsPassed || []).includes(level)) {
          state.levelTestsPassed = [...(state.levelTestsPassed || []), level];
        }
        const order = CEFR_ORDER || ["a1","a2","b1","b2","c1","c2"];
        const i = order.indexOf(level);
        if (i >= 0 && i < order.length - 1) {
          const next = order[i + 1];
          if (!(state.unlockedLevels || []).includes(next)) {
            state.unlockedLevels = [...(state.unlockedLevels || []), next];
          }
          state.level = next;
        }
        state.xp = (state.xp || 0) + 120;
        saveState();
        updateUI();
        showModal(`<h3>Lulus ${level.toUpperCase()}!</h3><p>Skor ${sc}/${quiz.length}. Level berikutnya terbuka.</p>
          <button class="btn btn-primary" onclick="closeModal();renderLearnPath(state.level)">Lanjut</button>`);
      } else {
        showModal(`<h3>Belum lulus level exam</h3><p>Skor ${sc}/${quiz.length}. Ulangi unit lemah.</p>
          <button class="btn btn-primary" onclick="closeModal()">OK</button>`);
      }
      return;
    }
    const q = quiz[idx];
    showModal(`<h3>Level exam ${level.toUpperCase()} — ${idx+1}/${quiz.length}</h3>
      <p style="margin:12px 0;">${q.q}</p>
      ${(q.options||[]).map((o,oi)=>`<div class="option" onclick="window.__lev=${oi}">${String.fromCharCode(65+oi)}. ${o}</div>`).join("")}
      <button class="btn btn-primary" style="margin-top:14px;" onclick="
        if(window.__lev===undefined){alert('Pilih jawaban');return;}
        answers.push(window.__lev);window.__lev=undefined;idx++;closeModal();setTimeout(run,200);
      ">Lanjut</button>`);
  };
  // bind locals for inline handler via closure on window
  window.__levelExamRun = { get idx(){return idx;}, set idx(v){idx=v;}, answers, quiz, run };
  // simpler sequential without broken inline
  const step = () => {
    if (idx >= quiz.length) {
      let sc = 0;
      answers.forEach((a, i) => { if (a === quiz[i].correct) sc++; });
      const ratio = sc / quiz.length;
      const pass = ratio >= (UNIT_PASS_SCORE || 0.8);
      if (pass) {
        if (!(state.levelTestsPassed || []).includes(level)) {
          state.levelTestsPassed = [...(state.levelTestsPassed || []), level];
        }
        const order = (typeof CEFR_ORDER !== "undefined") ? CEFR_ORDER : ["a1","a2","b1","b2","c1","c2"];
        const ii = order.indexOf(level);
        if (ii >= 0 && ii < order.length - 1) {
          const next = order[ii + 1];
          if (!(state.unlockedLevels || []).includes(next)) {
            state.unlockedLevels.push(next);
          }
          state.level = next;
        }
        state.xp = (state.xp || 0) + 120;
        saveState();
        updateUI();
        showModal(`<h3>Lulus ${level.toUpperCase()}!</h3><p>Skor ${sc}/${quiz.length}.</p>
          <button class="btn btn-primary" onclick="closeModal();renderLearnPath(state.level)">Lanjut</button>`);
      } else {
        showModal(`<h3>Belum lulus</h3><p>Skor ${sc}/${quiz.length} (butuh ≥80%).</p>
          <button class="btn btn-primary" onclick="closeModal()">OK</button>`);
      }
      return;
    }
    const q = quiz[idx];
    const opts = (q.options || []).map((o, oi) =>
      `<div class="option" data-oi="${oi}" style="cursor:pointer;">${String.fromCharCode(65+oi)}. ${o}</div>`
    ).join("");
    showModal(`<h3>Level exam ${level.toUpperCase()} — ${idx+1}/${quiz.length}</h3>
      <p style="margin:12px 0;">${q.q}</p>${opts}
      <button class="btn btn-primary" style="margin-top:14px;" id="lev-next">Lanjut</button>`);
    let chosen = undefined;
    document.querySelectorAll("#modal-body .option").forEach(el => {
      el.onclick = () => {
        document.querySelectorAll("#modal-body .option").forEach(x => x.style.outline = "");
        el.style.outline = "2px solid var(--primary)";
        chosen = parseInt(el.dataset.oi, 10);
      };
    });
    document.getElementById("lev-next").onclick = () => {
      if (chosen === undefined) { alert("Pilih jawaban"); return; }
      answers.push(chosen);
      idx++;
      closeModal();
      setTimeout(step, 200);
    };
  };
  step();
}

function completeLearnUnit(id) {
  // Legacy no-op: mastery only via evaluation
  showToast("Selesaikan evaluasi unit untuk menandai penguasaan.", "error");
}


function resetApp() {
  if (confirm("Yakin ingin reset semua data? Progress akan hilang.")) {
    localStorage.removeItem("linguapro_state");
    location.reload();
  }
}

// ---------- AI Tutor (real API via Netlify Function) ----------
const AI_HISTORY_KEY = "linguapro_ai_history";
let aiChatHistory = [];
let aiSending = false;

function loadAIHistory() {
  try {
    const raw = localStorage.getItem(AI_HISTORY_KEY + "_" + (state.username || "guest"));
    aiChatHistory = raw ? JSON.parse(raw) : [];
  } catch {
    aiChatHistory = [];
  }
}

function saveAIHistory() {
  try {
    localStorage.setItem(
      AI_HISTORY_KEY + "_" + (state.username || "guest"),
      JSON.stringify(aiChatHistory.slice(-40))
    );
  } catch (_) {}
}

function renderAIHistory() {
  const box = document.getElementById("ai-messages");
  if (!box) return;
  const welcome = `
    <div class="ai-msg bot">
      <div class="ai-avatar">🤖</div>
      <div class="ai-bubble">
        Halo${state.name ? ", <strong>" + escapeHtml(state.name) + "</strong>" : ""}! Aku AI Tutor LinguaPro.
        Tanya apa saja: koreksi kalimat, penjelasan grammar (Bahasa Indonesia), contoh, atau minta soal latihan.
        <br><small style="opacity:.75">Translate, arti kata, koreksi, grammar, tips IELTS — ketik bebas. Cloud Gemini opsional.</small>
      </div>
    </div>`;
  if (!aiChatHistory.length) {
    box.innerHTML = welcome;
    return;
  }
  box.innerHTML =
    welcome +
    aiChatHistory
      .map(
        (m) => `
    <div class="ai-msg ${m.role === "user" ? "user" : "bot"}">
      <div class="ai-avatar">${m.role === "user" ? "👤" : "🤖"}</div>
      <div class="ai-bubble">${m.role === "user" ? escapeHtml(m.text) : m.text}</div>
    </div>`
      )
      .join("");
  box.scrollTop = box.scrollHeight;
}


function localAITutorReply(q, level) {
  const t = (q || "").toLowerCase();
  const lv = (level || "a1").toUpperCase();
  if (/present simple|simple present/.test(t)) {
    return `Present Simple dipakai untuk kebiasaan & fakta.<br><br>
    <strong>Rumus:</strong> Subject + V1 (+s/es untuk he/she/it)<br>
    Contoh: <em>She studies every night.</em><br>
    Negative: <em>She does not study on Fridays.</em><br>
    Level kamu sekarang: <strong>${lv}</strong>. Latihan: tulis 5 kalimat rutinitas harianmu.`;
  }
  if (/present continuous|present progressive/.test(t)) {
    return `Present Continuous = sedang terjadi sekarang.<br><br>
    Rumus: <strong>am/is/are + V-ing</strong><br>
    Contoh: <em>I am preparing for IELTS.</em><br>
    Bandingkan: <em>I study English</em> (kebiasaan) vs <em>I am studying English</em> (sedang berlangsung).`;
  }
  if (/past simple|simple past/.test(t)) {
    return `Past Simple untuk kejadian selesai di masa lalu.<br><br>
    Regular: V+ed → <em>worked, played</em><br>
    Irregular: <em>go→went, have→had, make→made</em><br>
    Tanya: <em>Did you finish the assignment?</em>`;
  }
  if (/present perfect/.test(t)) {
    return `Present Perfect menghubungkan masa lalu dengan sekarang.<br><br>
    Rumus: <strong>have/has + V3</strong><br>
    Contoh: <em>I have submitted the form.</em><br>
    Kata kunci: already, yet, just, ever, never, since, for.`;
  }
  if (/conditional|if clause|second conditional|first conditional/.test(t)) {
    return `Conditionals singkat:<br><br>
    <strong>First:</strong> If + present, will + V1 → kemungkinan nyata<br>
    <strong>Second:</strong> If + past, would + V1 → hipotetis<br>
    Contoh: <em>If I had more time, I would join the club.</em>`;
  }
  if (/passive/.test(t)) {
    return `Passive: <strong>be + V3</strong><br>
    Contoh: <em>The report was submitted yesterday.</em><br>
    Dipakai saat fokus ke hasil/proses, sering di writing akademik.`;
  }
  if (/ielts.*writ|writing task|task 2/.test(t)) {
    return `IELTS Writing Task 2 — kerangka cepat:<br><br>
    1) Intro + thesis<br>
    2) Body 1: alasan + contoh<br>
    3) Body 2: alasan lain / counter singkat<br>
    4) Conclusion<br><br>
    Target ≥250 kata. Jaga cohesive devices: however, furthermore, for example, therefore.`;
  }
  if (/ielts.*speak|speaking part/.test(t)) {
    return `IELTS Speaking tips:<br><br>
    Part 1: jawaban 2–3 kalimat<br>
    Part 2: cover semua bullet, 1–2 menit<br>
    Part 3: kembangkan opini + contoh<br><br>
    Latihan di menu <strong>AI Call</strong> mode IELTS.`;
  }
  if (/vocab|kosakata|synonym/.test(t)) {
    return `Cara perluas vocab efektif:<br><br>
    • Belajar collocation (make a decision, strong evidence)<br>
    • Pakai kata baru di 1 kalimat milikmu<br>
    • Review dengan spaced repetition<br><br>
    Buka <strong>Bank Vocab</strong> di aplikasi untuk latihan per level.`;
  }
  if (/toefl/.test(t)) {
    return `TOEFL iBT ringkas:<br>
    Reading & Listening = multiple choice berbasis teks/audio<br>
    Speaking = 4 task (opini + integrated)<br>
    Writing = integrated + independent<br><br>
    Latihan di menu <strong>Mock Test → TOEFL</strong>.`;
  }
  if (/halo|hello|hi\b|bantuan|help|apa yang bisa/.test(t)) {
    return `Halo! Saya AI Tutor lokal LinguaPro.<br><br>
    Kamu bisa tanya: Present Simple, Past Simple, Present Perfect, Passive, Conditional, tips IELTS Writing/Speaking, TOEFL, atau vocab.<br>
    Levelmu: <strong>${lv}</strong>.`;
  }
  // generic short help
  if (t.length < 12) return null;
  return `Aku terima pertanyaanmu tentang “${escapeHtml(q.slice(0, 80))}”.<br><br>
  Mode cloud sedang tidak aktif (function/API belum tersedia), jadi ini jawaban lokal.<br><br>
  Coba tanya lebih spesifik, misalnya:<br>
  • “Jelaskan present perfect”<br>
  • “Tips IELTS writing task 2”<br>
  • “Contoh passive voice”<br><br>
  Level kamu: <strong>${lv}</strong>.`;
}


function clearAIChat() {
  aiChatHistory = [];
  saveAIHistory();
  if (typeof renderAIHistory === "function") renderAIHistory();
  showToast("Riwayat chat dihapus", "success");
}

function sanitizeAIHtml(html) {
  if (!html) return "";
  // allow basic tags from local/cloud replies
  const s = String(html);
  // strip script
  return s.replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi, "");
}

function askAI(text) {
  document.getElementById("ai-input").value = text;
  sendAI();
}


async function sendAI() {
  if (aiSending) return;
  const input = document.getElementById("ai-input");
  if (!input) return;
  const text = (input.value || "").trim();
  if (!text) return;
  input.value = "";

  appendAIMessage(escapeHtml(text), "user");
  aiChatHistory.push({ role: "user", text });
  saveAIHistory();

  aiSending = true;
  const sendBtn = document.querySelector(".ai-chat-input button");
  if (sendBtn) sendBtn.disabled = true;
  const thinking = appendAIMessage(
    `<span class="ai-loading"><span></span><span></span><span></span></span> AI sedang menjawab...`,
    "bot",
    true
  );

  const finishWith = (html, toastMsg) => {
    if (thinking && thinking.remove) thinking.remove();
    const safe = html;
    appendAIMessage(safe, "bot");
    aiChatHistory.push({ role: "bot", text: safe });
    saveAIHistory();
    if (toastMsg) showToast(toastMsg, "success");
  };

  try {
    const endpoints = ["/.netlify/functions/ai-tutor", "/api/ai-tutor"];
    let cloudReply = null;
    let lastErr = null;

    for (const url of endpoints) {
      try {
        const controller = typeof AbortController !== "undefined" ? new AbortController() : null;
        const timer = controller ? setTimeout(() => controller.abort(), 12000) : null;
        const resp = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            message: text,
            history: aiChatHistory.slice(0, -1).map((h) => ({
              role: h.role === "user" ? "user" : "model",
              text: String(h.text || "").replace(/<[^>]+>/g, " ").slice(0, 500)
            })),
            userName: state.name || "siswa",
            level: state.level || "a1"
          }),
          signal: controller ? controller.signal : undefined
        });
        if (timer) clearTimeout(timer);
        const data = await resp.json().catch(() => ({}));
        if (resp.ok && data.reply) {
          cloudReply = data.reply;
          break;
        }
        lastErr = data.message || data.error || ("HTTP " + resp.status);
      } catch (e) {
        lastErr = e.name === "AbortError" ? "timeout" : (e.message || "network");
      }
    }

    if (cloudReply) {
      finishWith(typeof sanitizeAIHtml === "function" ? sanitizeAIHtml(cloudReply) : cloudReply, "AI cloud");
    } else {
      let local = await offlineAIReply(text);
      if (!local) {
        local = `Coba: <em>Terjemahkan: ...</em>, <em>Arti: word</em>, <em>Koreksi: ...</em>, atau tanya grammar.`;
      }
      finishWith(local, "Tutor lokal");
    }
  } catch (e) {
    if (thinking && thinking.remove) thinking.remove();
    let local = null;
    try { local = await offlineAIReply(text); } catch (_) {}
    appendAIMessage(
      local || `Maaf, error. Coba: Terjemahkan / Arti / Koreksi / tanya grammar.<br><small>${escapeHtml(e.message || "")}</small>`,
      "bot"
    );
  } finally {
    aiSending = false;
    if (sendBtn) sendBtn.disabled = false;
  }
}

function appendAIMessage(html, role, isTemp) {
  const box = document.getElementById("ai-messages");
  const div = document.createElement("div");
  div.className = `ai-msg ${role}`;
  if (isTemp) div.id = "ai-thinking";
  div.innerHTML = `
    <div class="ai-avatar">${role === "bot" ? "🤖" : "👤"}</div>
    <div class="ai-bubble">${html}</div>
  `;
  box.appendChild(div);
  box.scrollTop = box.scrollHeight;
  return div;
}


function generateAIReply(q) {
  const lower = (q || "").toLowerCase().trim();

  // Correction
  if (/koreksi|correct|perbaiki|fix this|salahkah/i.test(q)) {
    const sentence = q.replace(/koreksi[:\s]*|correct[:\s]*|perbaiki[:\s]*|fix this[:\s]*/i, "").trim();
    return correctEnglish(sentence || q);
  }

  // Translate intent handled async in offlineAIReply — sync hint only if needed
  if (/^(translate|terjemah(kan)?|arti|meaning)\b/i.test(lower) && lower.length < 12) {
    return `Untuk translate, ketik misalnya:<br>
    <div class="example-line">Terjemahkan: saya ingin belajar bahasa Inggris</div>
    <div class="example-line">Translate to Indonesian: I have finished my homework</div>`;
  }

  if (/present perfect/i.test(lower)) {
    return `<strong>Present Perfect</strong> = have/has + V3<br><br>
    Dipakai untuk pengalaman, hasil yang masih relevan, atau kejadian baru saja.<br>
    <div class="example-line">I have visited Bali twice.</div>
    <div class="example-line">She has just finished her essay.</div>
    Jangan gabung dengan <em>yesterday / last week</em> → pakai Past Simple.`;
  }
  if (/present simple|simple present/i.test(lower)) {
    return `<strong>Present Simple</strong> untuk kebiasaan & fakta.<br>
    Rumus: Subject + V1 (he/she/it + s/es)<br>
    <div class="example-line">She studies every night.</div>
    Negative: does not / do not + V1.`;
  }
  if (/present continuous|present progressive/i.test(lower)) {
    return `<strong>Present Continuous</strong> = am/is/are + V-ing (sedang terjadi).<br>
    <div class="example-line">I am preparing for the test.</div>
    Bandingkan: <em>I study</em> (kebiasaan) vs <em>I am studying</em> (sekarang).`;
  }
  if (/past simple|simple past/i.test(lower)) {
    return `<strong>Past Simple</strong> untuk kejadian selesai di masa lalu.<br>
    Regular: V+ed · Irregular: go→went, have→had<br>
    <div class="example-line">I went to campus yesterday.</div>`;
  }
  if (/since.*for|for.*since|bedanya since|since dan for/i.test(lower)) {
    return `<strong>Since vs For</strong><br>
    <strong>For</strong> = durasi: for 3 years<br>
    <strong>Since</strong> = titik awal: since 2021<br>
    Sering dengan Present Perfect.`;
  }
  if (/conditional|if clause|type 2|tipe 2|second conditional/i.test(lower)) {
    return `<strong>Conditionals</strong><br>
    First: If + present, will + V1 (nyata)<br>
    Second: If + past, would + V1 (hipotetis)<br>
    <div class="example-line">If I were rich, I would travel more.</div>`;
  }
  if (/passive/i.test(lower)) {
    return `<strong>Passive Voice</strong> = be + V3<br>
    <div class="example-line">The report was written yesterday.</div>
    Fokus ke hasil/proses — umum di writing akademik.`;
  }
  if (/relative clause|who which that/i.test(lower)) {
    return `<strong>Relative clauses</strong><br>
    who (orang), which (benda), that (defining), whose (milik)<br>
    <div class="example-line">The student who won is my friend.</div>`;
  }
  if (/modal|can could should must/i.test(lower)) {
    return `<strong>Modals</strong>: can (kemampuan), could (sopan/kemungkinan), should (saran), must (wajib).<br>
    Setelah modal → kata kerja dasar: <em>She can speak English.</em>`;
  }
  if (/article|a an the/i.test(lower)) {
    return `<strong>Articles</strong><br>
    a/an = tidak spesifik · the = spesifik/sudah diketahui<br>
    an sebelum bunyi vokal: an hour, an essay.`;
  }
  if (/ielts.*writ|writing task|task 2/i.test(lower)) {
    return `<strong>IELTS Writing Task 2</strong><br>
    Intro + thesis → Body (alasan+contoh) → Body 2 → Conclusion<br>
    ≥250 kata. Linker: however, furthermore, for example, therefore.`;
  }
  if (/ielts.*speak|speaking part/i.test(lower)) {
    return `<strong>IELTS Speaking</strong><br>
    Part 1 singkat · Part 2 (cue card) 1–2 menit · Part 3 opini + contoh<br>
    Latihan di menu <strong>AI Call</strong>.`;
  }
  if (/toefl/i.test(lower)) {
    return `<strong>TOEFL iBT</strong>: Reading, Listening, Speaking, Writing.<br>
    Latihan di <strong>Mock Test → TOEFL</strong>.`;
  }
  if (/vocab|kosakata|synonym|collocation/i.test(lower)) {
    return `Perluas vocab dengan collocation (make a decision, strong evidence), contoh kalimat sendiri, dan review rutin.<br>
    Buka <strong>Bank Vocab</strong> di aplikasi.`;
  }
  if (/halo|hello|hi\b|hai\b|bantuan|help|apa yang bisa|mulai/i.test(lower)) {
    return `Halo! Aku AI Tutor LinguaPro 👋<br><br>
    Kamu bisa:<br>
    • Tanya grammar (present perfect, passive, dll.)<br>
    • <strong>Translate</strong>: "Terjemahkan: ..." / "Translate: ..."<br>
    • <strong>Arti kata</strong>: "Arti: resilient"<br>
    • <strong>Koreksi</strong>: "Koreksi: I go yesterday"<br>
    • Tips IELTS/TOEFL<br><br>
    Langsung ketik saja — bebas.`;
  }

  return null; // biar offlineAIReply yang handle translate / freeform
}

/** Deteksi permintaan translate */
function parseTranslateRequest(q) {
  const raw = (q || "").trim();
  let m;
  m = raw.match(/^(?:terjemah(?:kan)?|translate)\s*(?:ke\s*(inggris|english|indonesia|indonesian|id|en))?\s*[:\-–]?\s*([\s\S]+)$/i);
  if (m && m[2]) {
    const target = (m[1] || "").toLowerCase();
    const text = m[2].trim();
    let pair = "id|en";
    if (/indonesia|indonesian|^id$/.test(target)) pair = "en|id";
    else if (/inggris|english|^en$/.test(target)) pair = "id|en";
    else {
      // auto: if mostly ascii english words → to id, else to en
      const asciiRatio = (text.replace(/[^a-zA-Z\s]/g, "").length) / Math.max(text.length, 1);
      pair = asciiRatio > 0.7 ? "en|id" : "id|en";
    }
    return { text, pair };
  }
  m = raw.match(/^(?:arti|meaning|define|definisi)\s*[:\-–]?\s*([a-zA-Z\-']{2,40})\s*$/i);
  if (m) return { define: m[1] };
  m = raw.match(/^(?:apa arti|what(?:'s| is) the meaning of)\s+["']?([a-zA-Z\-']+)["']?/i);
  if (m) return { define: m[1] };
  return null;
}

async function translateText(text, langpair) {
  const url = "https://api.mymemory.translated.net/get?q=" + encodeURIComponent(text.slice(0, 450)) + "&langpair=" + encodeURIComponent(langpair);
  const resp = await fetch(url);
  const data = await resp.json();
  const out = data && data.responseData && data.responseData.translatedText;
  if (!out) throw new Error("Translate gagal");
  return out;
}

async function defineEnglishWord(word) {
  const url = "https://api.dictionaryapi.dev/api/v2/entries/en/" + encodeURIComponent(word.toLowerCase());
  const resp = await fetch(url);
  if (!resp.ok) throw new Error("Kata tidak ditemukan");
  const data = await resp.json();
  const entry = data[0];
  const phon = entry.phonetic || (entry.phonetics && entry.phonetics.find(p => p.text) || {}).text || "";
  let html = `<strong>${escapeHtml(entry.word)}</strong> ${phon ? "<em>" + escapeHtml(phon) + "</em>" : ""}<br><br>`;
  (entry.meanings || []).slice(0, 3).forEach(mean => {
    html += `<strong>${escapeHtml(mean.partOfSpeech || "")}</strong><ul style="margin:6px 0 10px 18px;">`;
    (mean.definitions || []).slice(0, 2).forEach(d => {
      html += `<li>${escapeHtml(d.definition || "")}`;
      if (d.example) html += `<br><em style="opacity:.85">e.g. ${escapeHtml(d.example)}</em>`;
      html += `</li>`;
    });
    html += `</ul>`;
  });
  return html;
}

async function offlineAIReply(text) {
  // 1) translate / define via free APIs
  const parsed = parseTranslateRequest(text);
  if (parsed && parsed.define) {
    try {
      return await defineEnglishWord(parsed.define);
    } catch (e) {
      return `Tidak ketemu definisi untuk <strong>${escapeHtml(parsed.define)}</strong>. Coba kata dasar (mis. <em>run</em> bukan <em>running</em>).`;
    }
  }
  if (parsed && parsed.text) {
    try {
      const out = await translateText(parsed.text, parsed.pair);
      const dir = parsed.pair === "id|en" ? "ID → EN" : "EN → ID";
      return `<strong>Translate (${dir})</strong><br>
      Asli: <div class="example-line">${escapeHtml(parsed.text)}</div>
      Hasil: <div class="example-line">${escapeHtml(out)}</div>
      <small style="opacity:.75">Sumber: MyMemory (gratis). Untuk gaya lebih natural, cek juga konteks kalimat.</small>`;
    } catch (e) {
      return `Gagal translate otomatis. Coba ulang atau pecah kalimat lebih pendek.<br><small>${escapeHtml(e.message || "")}</small>`;
    }
  }

  // 2) template grammar / tips
  let local = null;
  try { local = generateAIReply(text); } catch (e) {}
  if (local) return local;
  try {
    if (typeof localAITutorReply === "function") local = localAITutorReply(text, (state && state.level) || "a1");
  } catch (e) {}
  if (local) return local;

  // 3) freeform: try auto-translate if looks like pure ID or pure EN sentence asking nothing structured
  const lower = text.toLowerCase();
  if (/cara bilang|bagaimana mengatakan|how do you say|in english\b|dalam bahasa inggris/i.test(lower)) {
    const m = text.match(/(?:cara bilang|bagaimana mengatakan|how do you say)\s+["']?(.+?)["']?\s*(?:dalam bahasa inggris|in english)?\s*$/i);
    const phrase = (m && m[1] ? m[1] : text).trim();
    try {
      const out = await translateText(phrase, "id|en");
      return `<strong>Cara bilang dalam English</strong><br>
      <div class="example-line">${escapeHtml(phrase)}</div>
      → <div class="example-line">${escapeHtml(out)}</div>`;
    } catch (e) {}
  }

  // 4) general tutor-style response (bebas, tetap helpful)
  return `<strong>AI Tutor</strong> — aku tangkap pertanyaanmu:<br>
  <div class="example-line">${escapeHtml(text.slice(0, 240))}</div>
  Aku bisa bantu lebih tepat kalau kamu pakai salah satu pola ini:<br><br>
  • <strong>Translate:</strong> <em>Terjemahkan: ...</em> atau <em>Translate: ...</em><br>
  • <strong>Arti kata:</strong> <em>Arti: sustainable</em><br>
  • <strong>Koreksi:</strong> <em>Koreksi: she go to school</em><br>
  • <strong>Grammar:</strong> <em>Jelaskan present perfect</em><br>
  • <strong>Tips:</strong> <em>Tips IELTS writing task 2</em><br><br>
  Langsung ketik ulang dengan pola di atas — atau aktifkan cloud Gemini (GEMINI_API_KEY di Netlify) untuk jawaban AI bebas penuh.`;
}

function correctEnglish(sentence) {
  if (!sentence || sentence.length < 3) {
    return `Ketik kalimat yang mau dikoreksi, contoh:<br><div class="example-line">Koreksi: I go to school yesterday</div>`;
  }

  let fixed = sentence;
  const notes = [];

  // Common fixes
  if (/\bi go\b.*\byesterday\b/i.test(sentence)) {
    fixed = sentence.replace(/\bi go\b/i, "I went");
    notes.push("Past time marker (yesterday) → pakai Past Simple: go → went");
  }
  if (/\bshe go\b/i.test(sentence)) {
    fixed = fixed.replace(/\bshe go\b/i, "she goes");
    notes.push("He/She/It + Present Simple → verb + s/es");
  }
  if (/\bi have went\b/i.test(sentence)) {
    fixed = fixed.replace(/\bhave went\b/i, "have gone");
    notes.push("Present Perfect memakai V3: go → gone (bukan went)");
  }
  if (/\bmore better\b/i.test(sentence)) {
    fixed = fixed.replace(/\bmore better\b/i, "better");
    notes.push("'Better' sudah comparative — tidak perlu 'more'");
  }
  if (/\binteresing\b/i.test(sentence)) {
    fixed = fixed.replace(/\binteresing\b/i, "interesting");
    notes.push("Spelling: interesting");
  }
  if (/\bdont\b/i.test(sentence)) {
    fixed = fixed.replace(/\bdont\b/i, "don't");
    notes.push("Apostrophe: don't");
  }
  if (/\bi am agree\b/i.test(sentence)) {
    fixed = fixed.replace(/\bi am agree\b/i, "I agree");
    notes.push("'Agree' tidak memakai 'am' — langsung: I agree");
  }
  if (/\bhe can plays\b/i.test(sentence)) {
    fixed = fixed.replace(/\bcan plays\b/i, "can play");
    notes.push("Setelah modal (can/should/must) → base verb tanpa -s");
  }

  if (notes.length === 0) {
    return `Kalimat: <div class="example-line">${escapeHtml(sentence)}</div>
    Tidak ketemu error umum yang jelas. Coba cek: subject-verb agreement, tense vs time marker, dan spelling.<br>
    Untuk feedback lebih dalam, latihan di menu Writing.`;
  }

  return `Asli: <div class="example-line">${escapeHtml(sentence)}</div>
  Koreksi: <div class="example-line">${escapeHtml(fixed)}</div>
  <strong>Catatan:</strong><ul style="margin:8px 0 0 16px;">${notes.map(n => `<li>${n}</li>`).join("")}</ul>`;
}

function escapeHtml(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}



// ---------- Goal tracks ----------
function setLearningTrack(track) {
  state.learningTrack = track;
  saveState();
  renderTrackStatus();
  const tips = {
    conversation: "Prioritas: Jalur A1–B1 speaking units, AI Call Casual, Latihan Speaking.",
    academic: "Prioritas: writing units B1+, Writing Lab, Grammar advanced patterns.",
    scholarship: "Prioritas: Writing Lab essay, AI Call Interview, vocab akademik.",
    exam: "Prioritas: Mock IELTS/TOEFL setelah B1+ dikuasai. Jangan skip fondasi A1–A2."
  };
  showToast("Jalur: " + track, "success");
  const el = document.getElementById("track-status");
  if (el) el.innerHTML = `<strong>Jalur aktif:</strong> ${track}<br>${tips[track] || ""}`;
}

function renderTrackStatus() {
  const el = document.getElementById("track-status");
  if (!el) return;
  if (!state.learningTrack) {
    el.textContent = "Belum memilih jalur tujuan — pilih kartu di atas.";
    return;
  }
  el.innerHTML = `<strong>Jalur aktif:</strong> ${state.learningTrack}`;
}

// ---------- My Mistakes ----------
function renderMistakes() {
  const box = document.getElementById("mistakes-list");
  if (!box) return;
  const list = state.mistakes || [];
  if (!list.length) {
    box.innerHTML = `<p class="empty-state">Belum ada kesalahan tersimpan. Kerjakan evaluasi unit — jawaban salah akan masuk ke sini.</p>`;
    return;
  }
  box.innerHTML = list.map((m, i) => `
    <div class="mistake-card ${m.resolved ? 'resolved' : ''}">
      <div class="mistake-meta">${(m.level || "").toUpperCase()} · ${m.source || "eval"} · ×${m.count || 1}</div>
      <p><strong>Soal:</strong> ${escapeHtml(m.q || "")}</p>
      <p style="color:#f87171;"><strong>Jawabanmu:</strong> ${escapeHtml(m.userAns || "")}</p>
      <p style="color:var(--success);"><strong>Kunci:</strong> ${escapeHtml(m.correctOpt || "")}</p>
      <p style="color:var(--text-muted);">${escapeHtml(m.explain || "")}</p>
      <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;">
        <button class="btn btn-sm btn-primary" type="button" onclick="drillMistake(${i})">Latihan ulang</button>
        <button class="btn btn-sm btn-secondary" type="button" onclick="resolveMistake(${i})">Tandai dikuasai</button>
      </div>
    </div>
  `).join("");
}

function resolveMistake(i) {
  if (!state.mistakes || !state.mistakes[i]) return;
  state.mistakes[i].resolved = true;
  saveState();
  renderMistakes();
  showToast("Ditandai dikuasai", "success");
}

function drillMistake(i) {
  const m = state.mistakes && state.mistakes[i];
  if (!m) return;
  const opts = shuffle([m.correctOpt, m.userAns, "Not sure", "Skip"].filter(Boolean));
  // unique
  const uniq = [...new Set(opts)].slice(0, 4);
  const correct = uniq.indexOf(m.correctOpt);
  showModal(`<h3>Drill kesalahan</h3>
    <p style="margin:12px 0;">${escapeHtml(m.q)}</p>
    ${uniq.map((o, oi) => `<div class="option" data-oi="${oi}" style="cursor:pointer;margin:6px 0;">${String.fromCharCode(65+oi)}. ${escapeHtml(o)}</div>`).join("")}
    <div id="drill-fb" style="margin-top:10px;"></div>
    <button class="btn btn-primary" style="margin-top:12px;" id="drill-close" onclick="closeModal()">Tutup</button>`);
  document.querySelectorAll("#modal-body .option").forEach(el => {
    el.onclick = () => {
      const oi = parseInt(el.dataset.oi, 10);
      const fb = document.getElementById("drill-fb");
      if (oi === correct) {
        fb.innerHTML = `<span style="color:var(--success);">Benar! ${escapeHtml(m.explain || "")}</span>`;
        state.mistakes[i].resolved = true;
        saveState();
      } else {
        fb.innerHTML = `<span style="color:#f87171;">Masih salah. Kunci: ${escapeHtml(m.correctOpt)}</span>`;
      }
    };
  });
}

// ---------- Writing Lab ----------
function runWritingLab() {
  const text = (document.getElementById("wl-text").value || "").trim();
  const prompt = (document.getElementById("wl-prompt").value || "").trim();
  const out = document.getElementById("wl-result");
  if (!out) return;
  if (text.split(/\s+/).filter(Boolean).length < 15) {
    showToast("Tulis minimal ~15 kata dulu.", "error");
    return;
  }
  // Local heuristic analysis (always available). AI optional via askAIWritingLab.
  const words = text.split(/\s+/).filter(Boolean);
  const issues = [];
  let revised = text;

  if (/\bi go\b.*\b(yesterday|last)\b/i.test(text)) {
    issues.push({ bad: "go + past time", fix: "Pakai Past Simple: went", why: "Waktu lampau spesifik membutuhkan V2." });
    revised = revised.replace(/\bi go\b/i, "I went");
  }
  if (/\bshe go\b/i.test(text)) {
    issues.push({ bad: "she go", fix: "she goes", why: "He/She/It + Present Simple → verb-s." });
    revised = revised.replace(/\bshe go\b/i, "she goes");
  }
  if (/\bi have went\b/i.test(text)) {
    issues.push({ bad: "have went", fix: "have gone", why: "Past participle of go = gone." });
    revised = revised.replace(/\bi have went\b/i, "I have gone");
  }
  if (/\ba apple\b/i.test(text)) {
    issues.push({ bad: "a apple", fix: "an apple", why: "Bunyi vokal → an." });
    revised = revised.replace(/\ba apple\b/i, "an apple");
  }
  if (/\bi am agree\b/i.test(text)) {
    issues.push({ bad: "I am agree", fix: "I agree", why: "Agree adalah verb, bukan adjective." });
    revised = revised.replace(/\bi am agree\b/i, "I agree");
  }
  if (/\bmore better\b/i.test(text)) {
    issues.push({ bad: "more better", fix: "better", why: "Better sudah comparative." });
    revised = revised.replace(/\bmore better\b/i, "better");
  }
  // weak thesis for short opinion
  if (prompt && /opinion|should|agree/i.test(prompt) && words.length < 80) {
    issues.push({ bad: "Pengembangan terbatas", fix: "Tambah alasan + contoh (target 100+ kata untuk opini B1).", why: "Esai pendek jarang memenuhi task response." });
  }
  if (!issues.length) {
    issues.push({ bad: "Tidak ada pola error klasik terdeteksi", fix: "Periksa coherence & vocabulary secara mandiri atau pakai AI Tutor.", why: "Analyzer lokal hanya menangkap pola umum." });
  }

  out.classList.remove("hidden");
  out.innerHTML = `
    <h4>Hasil analisis (lokal)</h4>
    <p style="color:var(--text-muted);font-size:0.9rem;">Ini bukan skor IELTS resmi. Pola error umum dicek di perangkatmu. Untuk feedback lebih dalam, gunakan tombol AI Tutor.</p>
    <div class="fb-item"><strong>Jumlah kata</strong>${words.length}</div>
    ${issues.map(is => `<div class="fb-item"><strong>${escapeHtml(is.bad)}</strong>→ ${escapeHtml(is.fix)}<br><em>${escapeHtml(is.why)}</em></div>`).join("")}
    <h4 style="margin-top:14px;">Revisi usulan</h4>
    <div class="writing-prompt">${escapeHtml(revised)}</div>
    <h4 style="margin-top:14px;">Latihan lanjutan</h4>
    <p>Tulis ulang paragraf yang sama dengan 2 complex sentences (because / although / which).</p>
  `;
  state.xp = (state.xp || 0) + 5;
  saveState();
  updateUI();
}

function askAIWritingLab() {
  const text = (document.getElementById("wl-text").value || "").trim();
  const prompt = (document.getElementById("wl-prompt").value || "").trim();
  if (text.length < 20) {
    showToast("Isi tulisan dulu.", "error");
    return;
  }
  const q = `Koreksi dan perbaiki tulisan berikut untuk level ${state.level || "a1"}. Beri: (1) daftar kesalahan spesifik, (2) versi revisi, (3) satu latihan lanjutan. Prompt/topik: ${prompt || "(umum)"}.\n\nTulisan:\n${text}`;
  navigateTo("aitutor");
  setTimeout(() => {
    document.getElementById("ai-input").value = q;
    sendAI();
  }, 400);
}

// Enhance renderProgress competence vs activity
function renderProgressCompetencePatch() {
  // called from renderProgress if container exists
  const host = document.getElementById("progress-competence");
  if (!host) return;
  const order = (typeof CEFR_ORDER !== "undefined") ? CEFR_ORDER : ["a1","a2","b1","b2","c1","c2"];
  host.innerHTML = order.map(lv => {
    const pct = levelUnitProgress(lv);
    const unlocked = isLevelUnlocked(lv);
    return `<div class="section-score-card"><h4>${lv.toUpperCase()}</h4>
      <div class="score">${unlocked ? pct + "%" : "🔒"}</div>
      <p style="font-size:0.75rem;color:var(--text-muted);">unit dikuasai</p></div>`;
  }).join("");
}

// Preload speech voices
if (typeof speechSynthesis !== "undefined") {
  speechSynthesis.getVoices();
  speechSynthesis.onvoiceschanged = () => speechSynthesis.getVoices();
}

// ========== AI CALL (phone-style conversation) ==========
const CALL_SCRIPTS = {
  ielts: [
    { role: "ai", text: "Hello! Thanks for joining this IELTS Speaking practice. I'm your examiner today — just relax and answer naturally. Can you tell me your full name, please?" },
    { role: "wait", expect: "name" },
    { role: "ai", text: "Thanks. And where are you from? Feel free to mention how long you've lived there." },
    { role: "wait", expect: "place" },
    { role: "ai", text: "Nice. Are you a student or do you work at the moment? What do you enjoy most about that?" },
    { role: "wait", expect: "study" },
    { role: "ai", text: "Okay, Part Two. I'd like you to talk about a skill you want to learn. Say what it is, why you want it, how you'd learn it, and how it could help you later. Take a moment if you need, then speak for about one to two minutes." },
    { role: "wait", expect: "long" },
    { role: "ai", text: "Thank you. For Part Three — what skills do you think matter most for young people in your country right now, and why?" },
    { role: "wait", expect: "opinion" },
    { role: "ai", text: "Interesting point. Has technology changed the skills people need at work? Could you give a reason or an example?" },
    { role: "wait", expect: "opinion" },
    { role: "ai", text: "That's the end of the speaking practice. Thanks for the conversation — I'll share some feedback with you now." }
  ],
  casual: [
    { role: "ai", text: "Hey! Good to meet you. I'm your practice partner today — no pressure, just a normal chat in English. How's your day going?" },
    { role: "wait", expect: "casual" },
    { role: "ai", text: "Nice. What keeps you busy these days — studying, working, or a bit of both?" },
    { role: "wait", expect: "study" },
    { role: "ai", text: "That sounds cool. When you're free, what do you usually do for fun?" },
    { role: "wait", expect: "hobby" },
    { role: "ai", text: "I like that. If you could take a short trip next month, where would you go?" },
    { role: "wait", expect: "travel" },
    { role: "ai", text: "One more — is there a small goal you're trying to hit this semester?" },
    { role: "wait", expect: "goal" },
    { role: "ai", text: "Great talking with you. I'll give you a few tips on your speaking in a second." }
  ],
  interview: [
    { role: "ai", text: "Good morning, and thanks for coming in today. We'll keep this conversational. Could you briefly introduce yourself?" },
    { role: "wait", expect: "name" },
    { role: "ai", text: "Thank you. Why are you interested in this kind of role or field?" },
    { role: "wait", expect: "motivation" },
    { role: "ai", text: "Tell me about a challenge you faced recently and how you handled it." },
    { role: "wait", expect: "challenge" },
    { role: "ai", text: "What would you say is one of your strengths, and how have you used it?" },
    { role: "wait", expect: "strength" },
    { role: "ai", text: "Do you have any questions for me about the role or the team?" },
    { role: "wait", expect: "question" },
    { role: "ai", text: "Thanks for your time today. I'll wrap up with some brief speaking feedback." }
  ]
};

function startAICall(mode) {
  try { stopSpeech(); } catch (e) {}
  try { stopSpeechRecognition(); } catch (e) {}
  if (callRec) { try { callRec.stop(); } catch (e) {} callRec = null; }

  if (!CALL_SCRIPTS || !CALL_SCRIPTS.casual) {
    showToast("Script AI Call belum termuat. Refresh halaman.", "error");
    return;
  }

  callState = {
    mode: mode || "casual",
    step: 0,
    script: CALL_SCRIPTS[mode] || CALL_SCRIPTS.casual,
    userTurns: [],
    allText: ""
  };
  callSeconds = 0;
  callTranscriptBuf = "";

  const lobby = document.getElementById("call-lobby");
  const result = document.getElementById("call-result");
  const screen = document.getElementById("call-screen");
  if (!lobby || !screen) {
    showToast("UI AI Call tidak ditemukan.", "error");
    return;
  }
  lobby.classList.add("hidden");
  if (result) result.classList.add("hidden");
  screen.classList.remove("hidden");

  const transcript = document.getElementById("call-transcript");
  if (transcript) transcript.innerHTML = "";
  const label = document.getElementById("call-mode-label");
  if (label) {
    label.textContent = mode === "ielts" ? "IELTS Speaking" : mode === "interview" ? "Job Interview" : "Casual Chat";
  }
  const micBtn = document.getElementById("call-mic-btn");
  if (micBtn) micBtn.disabled = true;
  const hint = document.getElementById("call-mic-hint");
  if (hint) hint.textContent = "Tunggu AI selesai bicara...";
  const status = document.getElementById("call-status");
  if (status) status.textContent = "Tersambung";
  const timer = document.getElementById("call-timer");
  if (timer) timer.textContent = "00:00";

  // Ensure type-answer fallback exists
  ensureCallTextFallback();

  if (callTimerInt) clearInterval(callTimerInt);
  callTimerInt = setInterval(() => {
    callSeconds++;
    const m = String(Math.floor(callSeconds / 60)).padStart(2, "0");
    const s = String(callSeconds % 60).padStart(2, "0");
    const t = document.getElementById("call-timer");
    if (t) t.textContent = m + ":" + s;
  }, 1000);

  // Warm up voices then start
  if (window.speechSynthesis) {
    speechSynthesis.getVoices();
  }
  setTimeout(() => runCallStep(), 500);
}

function ensureCallTextFallback() {
  if (document.getElementById("call-text-fallback")) return;
  const controls = document.querySelector("#call-screen .call-controls");
  if (!controls) return;
  const wrap = document.createElement("div");
  wrap.id = "call-text-fallback";
  wrap.style.cssText = "margin-top:14px;width:100%;max-width:420px;";
  wrap.innerHTML = `
    <p style="font-size:0.82rem;color:var(--text-muted);margin-bottom:6px;">Jika mic/audio bermasalah, ketik jawaban English di sini:</p>
    <div style="display:flex;gap:8px;">
      <input id="call-text-input" type="text" placeholder="Type your answer in English..." style="flex:1;padding:10px 12px;border-radius:10px;border:1px solid var(--border);background:var(--bg);color:var(--text);">
      <button class="btn btn-primary btn-sm" type="button" onclick="submitCallTextInput()"><i class="fas fa-paper-plane"></i></button>
    </div>`;
  controls.appendChild(wrap);
  const input = document.getElementById("call-text-input");
  if (input) {
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") submitCallTextInput();
    });
  }
}

function submitCallTextInput() {
  const input = document.getElementById("call-text-input");
  if (!input) return;
  const val = (input.value || "").trim();
  if (val.length < 2) {
    showToast("Ketik minimal beberapa kata.", "error");
    return;
  }
  input.value = "";
  submitCallTurn(val);
}

function runCallStep() {
  if (!callState) return;
  const script = callState.script;
  if (callState.step >= script.length) {
    finishAICall();
    return;
  }
  const item = script[callState.step];
  if (item.role === "ai") {
    callState.step++;
    speakAILine(item.text, () => {
      // After AI speaks, check next
      const next = script[callState.step];
      if (!next) { finishAICall(); return; }
      if (next.role === "wait") {
        enableCallMic();
      } else {
        runCallStep();
      }
    });
  } else if (item.role === "wait") {
    enableCallMic();
  }
}

function speakAILine(text, onDone) {
  appendCallBubble("ai", text);
  const status = document.getElementById("call-status");
  const avatar = document.getElementById("call-avatar");
  const wave = document.getElementById("call-wave");
  const micBtn = document.getElementById("call-mic-btn");
  if (status) status.textContent = "AI sedang berbicara...";
  if (avatar) avatar.classList.add("speaking");
  if (wave) wave.classList.add("active");
  if (micBtn) micBtn.disabled = true;

  let finished = false;
  const done = () => {
    if (finished) return;
    finished = true;
    if (avatar) avatar.classList.remove("speaking");
    if (wave) wave.classList.remove("active");
    if (status) status.textContent = "Giliranmu — klik mic atau ketik jawaban";
    if (onDone) onDone();
  };

  // Safety timeout so call never freezes if TTS hangs
  const safetyMs = Math.min(20000, Math.max(3500, (text || "").length * 80));
  const safety = setTimeout(done, safetyMs);

  if (!window.speechSynthesis) {
    clearTimeout(safety);
    setTimeout(done, 1500);
    return;
  }

  try { stopSpeech(); } catch (e) {}

  const speakNow = () => {
    try {
      const u = new SpeechSynthesisUtterance(text);
      u.lang = "en-US";
      u.rate = 0.92;
      const voice = (typeof getRandomVoice === "function") ? getRandomVoice() : null;
      if (voice) u.voice = voice;
      u.onend = () => { clearTimeout(safety); done(); };
      u.onerror = () => { clearTimeout(safety); done(); };
      speechSynthesis.speak(u);
    } catch (err) {
      clearTimeout(safety);
      done();
    }
  };

  // Chrome sometimes needs voices loaded first
  const voices = speechSynthesis.getVoices();
  if (!voices || voices.length === 0) {
    const once = () => {
      speechSynthesis.onvoiceschanged = null;
      speakNow();
    };
    speechSynthesis.onvoiceschanged = once;
    setTimeout(speakNow, 400);
  } else {
    speakNow();
  }
}

function appendCallBubble(who, text) {
  const box = document.getElementById("call-transcript");
  const div = document.createElement("div");
  div.className = "call-bubble " + who;
  div.innerHTML = `<div class="who">${who === "ai" ? "AI Examiner" : "Kamu"}</div>${escapeHtml(text)}`;
  box.appendChild(div);
  box.scrollTop = box.scrollHeight;
}

function enableCallMic() {
  const micBtn = document.getElementById("call-mic-btn");
  const hint = document.getElementById("call-mic-hint");
  const status = document.getElementById("call-status");
  if (micBtn) micBtn.disabled = false;
  if (hint) hint.textContent = "Klik mic, bicara, lalu klik lagi — atau ketik di kotak bawah";
  if (status) status.textContent = "Menunggu jawabanmu...";
  callTranscriptBuf = "";
  const input = document.getElementById("call-text-input");
  if (input) {
    input.disabled = false;
    try { input.focus(); } catch (e) {}
  }
}

function toggleCallMic() {
  const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRec) {
    showToast("Pakai Chrome/Edge untuk mic. Atau ketik jawaban.", "error");
    const typed = prompt("Ketik jawaban English kamu:");
    if (typed && typed.trim()) submitCallTurn(typed.trim());
    return;
  }

  const btn = document.getElementById("call-mic-btn");

  if (callRec) {
    try { callRec.stop(); } catch(e){}
    callRec = null;
    btn.classList.remove("recording");
    const finalText = callTranscriptBuf.trim();
    if (finalText.length < 3) {
      showToast("Belum tertangkap — coba bicara lebih jelas.", "error");
      enableCallMic();
      return;
    }
    submitCallTurn(finalText);
    return;
  }

  callTranscriptBuf = "";
  callRec = new SpeechRec();
  callRec.lang = "en-US";
  callRec.continuous = true;
  callRec.interimResults = true;

  callRec.onstart = () => {
    btn.classList.add("recording");
    document.getElementById("call-status").textContent = "🎤 Mendengarkan...";
    document.getElementById("call-mic-hint").textContent = "Bicara sekarang — klik mic lagi jika selesai";
  };

  callRec.onresult = (ev) => {
    let interim = "";
    for (let i = ev.resultIndex; i < ev.results.length; i++) {
      if (ev.results[i].isFinal) callTranscriptBuf += ev.results[i][0].transcript + " ";
      else interim += ev.results[i][0].transcript;
    }
    document.getElementById("call-status").textContent =
      "🎤 " + (callTranscriptBuf + interim).trim().slice(0, 80) + "...";
  };

  callRec.onerror = (e) => {
    btn.classList.remove("recording");
    if (e.error === "not-allowed") showToast("Izinkan mikrofon!", "error");
  };

  callRec.onend = () => {
    btn.classList.remove("recording");
    callRec = null;
  };

  try { callRec.start(); } catch (err) {
    showToast("Mic error: " + err.message, "error");
  }
}

function submitCallTurn(text) {
  if (!callState) {
    showToast("Call belum aktif. Pilih mode dulu.", "error");
    return;
  }
  appendCallBubble("user", text);
  callState.userTurns.push(text);
  callState.allText += " " + text;
  document.getElementById("call-mic-btn").disabled = true;
  document.getElementById("call-mic-hint").textContent = "Tunggu AI...";

  // Advance past wait step
  if (callState.script[callState.step] && callState.script[callState.step].role === "wait") {
    callState.step++;
  }

  // Short reactive reply then continue script
  const reaction = getCallReaction(text, callState.mode);
  if (reaction && callState.step < callState.script.length) {
    speakAILine(reaction, () => {
      setTimeout(() => runCallStep(), 400);
    });
  } else {
    setTimeout(() => runCallStep(), 500);
  }
}

function getCallReaction(userText, mode) {
  const t = (userText || "").toLowerCase().trim();
  const words = t.split(/\s+/).filter(Boolean);

  if (words.length < 4) {
    return mode === "casual"
      ? "No worries — could you add a bit more detail? Even one example helps."
      : "Could you expand on that a little? A short example would be great.";
  }

  // Keyword-aware, varied reactions (feels less scripted)
  if (/\b(nervous|shy|worried|scared)\b/.test(t)) {
    return "Totally understandable — take your time. You're doing fine.";
  }
  if (/\b(student|university|campus|major|semester|kuliah|dosen)\b/.test(t)) {
    const opts = [
      "Thanks for sharing that about your studies.",
      "University life can be intense — appreciate the detail.",
      "Got it. Sounds like you've got a clear focus there."
    ];
    return opts[Math.floor(Math.random() * opts.length)];
  }
  if (/\b(work|job|internship|office|career|company)\b/.test(t)) {
    return "Thanks — that work context helps me understand your answer.";
  }
  if (/\b(hobby|music|football|soccer|game|reading|film|movie|travel|cook)\b/.test(t)) {
    return mode === "casual"
      ? "That sounds fun. I like hearing what people do outside class."
      : "Thanks for the personal example — that makes your answer stronger.";
  }
  if (/\b(because|for example|such as|however|although)\b/.test(t)) {
    return "Clear reasoning — thanks for explaining that.";
  }
  if (words.length > 40) {
    return "Thanks, that was a full answer. Let's keep going.";
  }

  if (mode === "casual") {
    const casual = [
      "Yeah, I follow you.",
      "Nice, thanks for that.",
      "Makes sense.",
      "Cool, I got what you mean.",
      "Alright, good to know."
    ];
    return casual[Math.floor(Math.random() * casual.length)];
  }
  if (mode === "interview") {
    const iv = [
      "Thank you, that's helpful.",
      "I appreciate the example.",
      "Understood — thanks for walking me through that.",
      "Okay, thank you."
    ];
    return iv[Math.floor(Math.random() * iv.length)];
  }
  const ielts = [
    "Thank you.",
    "Alright, thank you for that.",
    "I see. Thanks for explaining.",
    "Okay, let's continue."
  ];
  return ielts[Math.floor(Math.random() * ielts.length)];
}

function endAICall() {
  if (!callState) { backToCallLobby(); return; }
  if (callState.userTurns.length === 0) {
    if (confirm("Belum ada jawaban. Akhiri call?")) {
      cleanupCall();
      backToCallLobby();
    }
    return;
  }
  finishAICall();
}

function finishAICall() {
  cleanupCall();
  const text = (callState && callState.allText || "").trim();
  const turns = (callState && callState.userTurns || []).length;
  const themeKw = (callState && callState.mode === "ielts")
    ? ["study", "skill", "learn", "work", "technology", "important", "because", "example", "country", "student"]
    : (callState && callState.mode === "interview")
      ? ["experience", "team", "challenge", "goal", "skill", "because", "project", "company"]
      : ["university", "hobby", "travel", "goal", "free", "time", "study"];
  const obj = objectiveSpeakingScore(text || "hi", themeKw);
  let band = obj.band;
  // Multiple developed turns help a bit, short empty turns don't
  if (turns >= 4 && obj.n >= 40) band = Math.min(9, band + 0.5);
  if (turns <= 1 || obj.n < 12) band = Math.min(band, 4.0);
  band = Math.round(band * 2) / 2;

  state.xp += Math.round(band * 8);
  updateGoalProgress("practice");

  // Feed into mock test if speaking section was launched from mock
  if (currentMock && currentMock.awaitingCallScore) {
    currentMock.scores = currentMock.scores || {};
    currentMock.scores.speaking = band;
    currentMock.awaitingCallScore = false;
    currentMock.sectionIndex = (currentMock.sectionIndex || 0) + 1;
    saveState();
    if (currentMock.sectionIndex < (currentMock.sections || []).length) {
      showToast("Speaking band " + band.toFixed(1) + " — lanjut section berikutnya", "success");
      document.getElementById("call-result").classList.add("hidden");
      document.getElementById("call-screen").classList.add("hidden");
      navigateTo("mocktest");
      setTimeout(() => loadMockSection(), 500);
      callState = null;
      return;
    } else {
      navigateTo("mocktest");
      setTimeout(() => showMockResult(), 300);
      callState = null;
      return;
    }
  }

  saveState();
  updateUI();

  document.getElementById("call-screen").classList.add("hidden");
  document.getElementById("call-result").classList.remove("hidden");
  document.getElementById("call-final-band").textContent = band.toFixed(1);
  document.getElementById("call-feedback-detail").innerHTML = `
    <h4><i class="fas fa-robot"></i> Penilaian objektif</h4>
    <div class="fb-item"><strong>Giliran bicara</strong>${turns}</div>
    <div class="fb-item"><strong>Perkiraan jumlah kata</strong>${obj.n}</div>
    <div class="fb-item"><strong>Kecocokan tema</strong>${obj.hits}/${obj.totalKw} keyword terkait</div>
    <div class="fb-item"><strong>Band (bukan default 6)</strong>Dihitung dari panjang, tema, grammar, vocab, filler</div>
    ${obj.tips.length ? `<div class="fb-item"><strong>Saran</strong><ul style="margin:6px 0 0 16px;">${obj.tips.map(t=>`<li>${t}</li>`).join("")}</ul></div>` : ""}
  `;
  showToast(`AI Call · Band objektif ${band.toFixed(1)}`, "success");
  callState = null;
}

function cleanupCall() {
  stopSpeech();
  if (callRec) { try { callRec.stop(); } catch(e){} callRec = null; }
  if (callTimerInt) { clearInterval(callTimerInt); callTimerInt = null; }
  const btn = document.getElementById("call-mic-btn");
  if (btn) btn.classList.remove("recording");
}

function backToCallLobby() {
  cleanupCall();
  callState = null;
  document.getElementById("call-screen").classList.add("hidden");
  document.getElementById("call-result").classList.add("hidden");
  document.getElementById("call-lobby").classList.remove("hidden");
}

// Daily focus checklist: stored locally for this browser, without claiming server sync.
function markDailyFocus() {
  const key = 'linguapro_daily_focus_v1';
  const today = new Date().toISOString().slice(0, 10);
  let state = { date: today, done: false };
  try {
    const saved = JSON.parse(localStorage.getItem(key) || 'null');
    if (saved && saved.date === today) state = saved;
  } catch (e) {}
  state.done = !state.done;
  state.date = today;
  try { localStorage.setItem(key, JSON.stringify(state)); } catch (e) {}
  updateDailyFocus();
  if (typeof showToast === 'function') showToast(state.done ? 'Sesi fokus hari ini ditandai selesai.' : 'Tanda selesai dibatalkan.', state.done ? 'success' : 'info');
}

function updateDailyFocus() {
  const key = 'linguapro_daily_focus_v1';
  const today = new Date().toISOString().slice(0, 10);
  let done = false;
  try {
    const saved = JSON.parse(localStorage.getItem(key) || 'null');
    done = !!(saved && saved.date === today && saved.done);
  } catch (e) {}
  const count = document.getElementById('daily-focus-count');
  const fill = document.getElementById('daily-focus-fill');
  const button = document.querySelector('.daily-focus-side button');
  if (count) count.textContent = done ? '2/2' : '0/2';
  if (fill) fill.style.width = done ? '100%' : '0%';
  if (button) button.innerHTML = done ? '<i class="fas fa-rotate-left"></i> Batalkan tanda selesai' : '<i class="fas fa-check"></i> Tandai sesi hari ini selesai';
}

document.addEventListener('DOMContentLoaded', updateDailyFocus);
