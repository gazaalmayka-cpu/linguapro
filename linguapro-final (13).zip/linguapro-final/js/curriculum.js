/**
 * LinguaPro CEFR Curriculum
 * A1 → A2 → B1 → B2 → C1 → C2
 * Each unit: objectives, deep theory, examples, errors, vocab, dialogue,
 * guided + independent practice, evaluation, remedial hints
 */

const CEFR_ORDER = ["a1", "a2", "b1", "b2", "c1", "c2"];

const CEFR_META = {
  a1: {
    label: "Beginner (A1)",
    goal: "Memahami dan memakai ungkapan sehari-hari sangat dasar: perkenalan, needs sederhana, percakapan lambat.",
    prereq: null
  },
  a2: {
    label: "Elementary (A2)",
    goal: "Rutinitas, pengalaman singkat, deskripsi sederhana tentang keluarga, belanja, pekerjaan, perjalanan.",
    prereq: "a1"
  },
  b1: {
    label: "Intermediate (B1)",
    goal: "Menangani situasi travel, opini sederhana, narasi kejadian, teks factual singkat.",
    prereq: "a2"
  },
  b2: {
    label: "Upper-Intermediate (B2)",
    goal: "Argumen terstruktur, teks kompleks umum, interaksi spontan dengan penutur native.",
    prereq: "b1"
  },
  c1: {
    label: "Advanced (C1)",
    goal: "Bahasa fleksibel untuk akademik/profesional, teks panjang, nuance, register.",
    prereq: "b2"
  },
  c2: {
    label: "Proficiency (C2)",
    goal: "Hampir native-like: ringkas, presisi, idiom, wacana akademik/profesional tingkat tinggi.",
    prereq: "c1"
  }
};

/** Pass threshold for unit evaluation (0–1) */
const UNIT_PASS_SCORE = 0.8;

const LEARN_PATH = {
  a1: [
    {
      id: "a1-u01",
      title: "Unit 1: Alphabet, Sounds & Basic Pronunciation",
      desc: "Huruf, bunyi dasar, dan cara membaca kata sederhana",
      tags: ["Pronunciation", "Foundation"],
      content: {
        objectives: [
          "Mengenali 26 huruf alfabet English dan bunyi dasar",
          "Membedakan vowel pendek vs panjang pada kata sederhana",
          "Mengeja nama dan kata umum dengan keras"
        ],
        orientation: "Sebelum grammar, kamu perlu bisa membaca dan mengucapkan huruf. Unit ini fondasi A1 — jangan dilewati.",
        theory: `<p><strong>Alphabet English</strong> punya 26 huruf: A–Z. Nama huruf berbeda dari cara membacanya dalam kata.</p>
<p>Contoh: huruf <em>A</em> namanya /eɪ/, tapi dalam kata <em>cat</em> berbunyi /æ/.</p>
<p><strong>Vowels (vokal):</strong> A E I O U — sering berubah bunyi. <strong>Consonants:</strong> huruf lain.</p>
<p><strong>Stress:</strong> dalam kata 2 suku kata, biasanya suku kata pertama lebih kuat: <em>TA-ble</em>, <em>WIN-dow</em>.</p>
<p>Latih: ucapkan pelan → normal. Rekam suara sendiri jika bisa.</p>`,
        rules: [
          "Ucapkan nama huruf berbeda dari bunyi dalam kata",
          "Vowel panjang sering diikuti silent e: cake /keɪk/",
          "Huruf C: /k/ sebelum a/o/u (cat), /s/ sebelum e/i/y (city)"
        ],
        examples: [
          { en: "A B C D E", id: "Ei-bi-si-di-i", why: "Ini nama huruf, bukan bunyi dalam kata." },
          { en: "cat — /kæt/", id: "kucing", why: "A pendek /æ/, bukan /eɪ/." },
          { en: "name — /neɪm/", id: "nama", why: "A panjang karena pola vowel + consonant + e." },
          { en: "ship vs sheep", id: "kapal vs domba", why: "/ɪ/ pendek vs /iː/ panjang — beda arti." }
        ],
        compare: "<strong>/ɪ/ vs /iː/</strong>: ship (kapal) ≠ sheep (domba). <strong>/æ/ vs /e/</strong>: bag ≠ beg.",
        commonErrors: [
          { wrong: "Mengucapkan 'name' seperti 'nam'", right: "name /neɪm/", why: "A di open syllable sering diftong /eɪ/." },
          { wrong: "Mengeja C-A-T sebagai 'ce-a-te'", right: "C-A-T = /siː/ /eɪ/ /tiː/", why: "Pakai nama huruf English, bukan ejaan Indonesia." }
        ],
        vocab: [
          { en: "letter", id: "huruf", ipa: "/ˈletər/", ex: "How many letters are in the alphabet?", exId: "Ada berapa huruf dalam alfabet?" },
          { en: "alphabet", id: "alfabet", ipa: "/ˈælfəbet/", ex: "The English alphabet has 26 letters.", exId: "Alfabet English punya 26 huruf." },
          { en: "spell", id: "mengeja", ipa: "/spel/", ex: "Please spell your name.", exId: "Tolong eja namamu." },
          { en: "vowel", id: "huruf vokal", ipa: "/ˈvaʊəl/", ex: "A, E, I, O, and U are vowels.", exId: "A, E, I, O, dan U adalah vokal." },
          { en: "consonant", id: "huruf konsonan", ipa: "/ˈkɒnsənənt/", ex: "B is a consonant.", exId: "B adalah konsonan." },
          { en: "sound", id: "bunyi", ipa: "/saʊnd/", ex: "This sound is long.", exId: "Bunyi ini panjang." },
          { en: "pronounce", id: "mengucapkan", ipa: "/prəˈnaʊns/", ex: "How do you pronounce this word?", exId: "Bagaimana cara mengucapkan kata ini?" },
          { en: "pronunciation", id: "pelafalan", ipa: "/prəˌnʌnsiˈeɪʃn/", ex: "Check the pronunciation carefully.", exId: "Periksa pelafalan dengan saksama." },
          { en: "repeat", id: "mengulang", ipa: "/rɪˈpiːt/", ex: "Please repeat after me.", exId: "Tolong ulangi setelah saya." },
          { en: "slowly", id: "pelan-pelan", ipa: "/ˈsləʊli/", ex: "Can you say it slowly?", exId: "Bisakah kamu mengucapkannya pelan-pelan?" },
          { en: "clearly", id: "dengan jelas", ipa: "/ˈklɪəli/", ex: "Please speak clearly.", exId: "Tolong bicara dengan jelas." },
          { en: "name", id: "nama", ipa: "/neɪm/", ex: "What is your name?", exId: "Siapa namamu?" },
          { en: "word", id: "kata", ipa: "/wɜːd/", ex: "Spell this word, please.", exId: "Eja kata ini, tolong." },
          { en: "syllable", id: "suku kata", ipa: "/ˈsɪləbl/", ex: "Table has two syllables.", exId: "Table punya dua suku kata." },
          { en: "stress", id: "tekanan (pada suku kata)", ipa: "/stres/", ex: "The stress is on the first syllable.", exId: "Tekanannya di suku kata pertama." },
          { en: "silent", id: "tidak dilafalkan", ipa: "/ˈsaɪlənt/", ex: "The e in name is silent.", exId: "Huruf e di name tidak dilafalkan." },
          { en: "capital", id: "huruf kapital", ipa: "/ˈkæpɪtl/", ex: "Start with a capital letter.", exId: "Mulai dengan huruf kapital." },
          { en: "lowercase", id: "huruf kecil", ipa: "/ˈləʊəkeɪs/", ex: "Write it in lowercase.", exId: "Tulis dengan huruf kecil." },
          { en: "ship", id: "kapal", ipa: "/ʃɪp/", ex: "The ship is big.", exId: "Kapalnya besar. (bunyi /ɪ/ pendek)" },
          { en: "sheep", id: "domba", ipa: "/ʃiːp/", ex: "I see a sheep.", exId: "Saya melihat seekor domba. (bunyi /iː/ panjang)" }
        ],
        dialogues: [
          {
            title: "Menanyakan ejaan nama",
            lines: [
              { sp: "A", en: "Hi! What is your name?", id: "Hai! Siapa namamu?" },
              { sp: "B", en: "My name is Rina.", id: "Nama saya Rina." },
              { sp: "A", en: "How do you spell that?", id: "Bagaimana cara mengejanya?" },
              { sp: "B", en: "R-I-N-A.", id: "R-I-N-A." },
              { sp: "A", en: "Thank you!", id: "Terima kasih!" }
            ],
            tips: "Ungkapan kunci: How do you spell that? = Bagaimana mengejanya? Dipakai saat nama atau kata baru."
          },
          {
            title: "Meminta seseorang mengeja kata",
            lines: [
              { sp: "A", en: "How do you spell \"book\"?", id: "Bagaimana mengeja kata book?" },
              { sp: "B", en: "B-O-O-K.", id: "B-O-O-K." },
              { sp: "A", en: "Can you say it slowly, please?", id: "Bisakah kamu ucapkan pelan-pelan?" },
              { sp: "B", en: "Sure. B… O… O… K.", id: "Tentu. B… O… O… K." },
              { sp: "A", en: "Got it. Thanks!", id: "Mengerti. Terima kasih!" }
            ],
            tips: "Can you say it slowly, please? = permintaan sopan agar diucapkan pelan."
          },
          {
            title: "Mengklarifikasi bunyi huruf",
            lines: [
              { sp: "A", en: "Is this /ɪ/ or /iː/? Ship or sheep?", id: "Ini /ɪ/ atau /iː/? Ship atau sheep?" },
              { sp: "B", en: "It's /ɪ/. Ship — S-H-I-P.", id: "Ini /ɪ/. Ship — S-H-I-P." },
              { sp: "A", en: "And sheep?", id: "Kalau sheep?" },
              { sp: "B", en: "Sheep is /iː/. The vowel is longer.", id: "Sheep itu /iː/. Vokalnya lebih panjang." },
              { sp: "A", en: "Please repeat after me: ship, sheep.", id: "Tolong ulangi setelah saya: ship, sheep." },
              { sp: "B", en: "Ship. Sheep.", id: "Ship. Sheep." }
            ],
            tips: "Repeat after me = ulangi setelah saya. Berguna saat latihan pelafalan."
          }
        ],
        dialogue: "A: How do you spell \"book\"?\\nB: B-O-O-K.\\nA: Thank you.",
        vocabPractice: [
          { type: "match", q: "Arti dari \"spell\"?", options: ["mengeja", "huruf", "vokal", "pelan"], correct: 0, explain: "spell = mengeja." },
          { type: "match", q: "\"vowel\" artinya…", options: ["konsonan", "huruf vokal", "suku kata", "ejaan"], correct: 1, explain: "vowel = huruf vokal (A E I O U)." },
          { type: "match", q: "IPA /ʃiːp/ paling dekat dengan…", options: ["ship", "sheep", "shop", "shape"], correct: 1, explain: "/iː/ panjang = sheep." },
          { type: "gap", q: "Please ___ your name. (spell / letter / sound)", answer: "spell", explain: "spell your name = eja namamu." },
          { type: "gap", q: "A, E, I, O, U are ___.", answer: "vowels", explain: "vowels = vokal." },
          { type: "pron", q: "Mana pelafalan yang benar untuk \"name\"?", options: ["/næm/", "/neɪm/", "/niːm/", "/nɒm/"], correct: 1, explain: "name = /neɪm/ (vowel panjang + silent e)." },
          { type: "pron", q: "Minimal pair: mana yang berbunyi /ɪ/ pendek?", options: ["sheep", "ship", "sheet", "cheap"], correct: 1, explain: "ship = /ʃɪp/." },
          { type: "match", q: "\"Repeat after me\" artinya…", options: ["Tulis namamu", "Ulangi setelah saya", "Baca pelan", "Huruf kapital"], correct: 1, explain: "Permintaan menirukan ucapan." }
        ],
        dialoguePractice: [
          { q: "Seseorang bilang: \"My name is Budi.\" Respon terbaik untuk minta ejaan:", options: ["How do you spell that?", "What is book?", "Good night", "How many letters?"], correct: 0, explain: "How do you spell that? = minta ejaan." },
          { q: "Kamu ingin orang mengucapkan lebih pelan. Katakan:", options: ["Spell the alphabet", "Can you say it slowly, please?", "What is a vowel?", "Capital letter"], correct: 1, explain: "Can you say it slowly, please?" },
          { q: "Guru bilang: \"Please repeat after me.\" Artinya kamu harus…", options: ["Menulis huruf", "Menirukan ucapannya", "Menutup buku", "Menghitung sampai 26"], correct: 1, explain: "Menirukan / mengulang ucapan." }
        ],

        summary: "Hafalkan nama huruf. Latih minimal pairs (ship/sheep). Biasakan spell nama sendiri.",
        guided: [
          { q: "Nama huruf B dalam English adalah…", options: ["be", "bi", "/biː/", "ba"], correct: 2, explain: "Huruf B dibaca /biː/." },
          { q: "Kata mana yang punya vowel panjang /iː/?", options: ["ship", "sheep", "sit", "bit"], correct: 1, explain: "sheep = /ʃiːp/." },
          { q: "Cara mengeja 'cat' yang benar:", options: ["C-A-T", "K-A-T", "C-E-T", "S-A-T"], correct: 0, explain: "C-A-T." }
        ],
        independent: [
          { type: "spell", q: "Spell the word: TABLE", answer: "T-A-B-L-E", explain: "T-A-B-L-E" },
          { type: "choose", q: "ship dan sheep bedanya terutama pada…", options: ["konsonan awal", "panjang vokal", "jumlah huruf", "stress"], correct: 1, explain: "Panjang vokal /ɪ/ vs /iː/." }
        ],
        practice: "Ucapkan dan tulis ejaan: your full name, city, and three school items (pen, book, bag).",
        evaluation: [
          { q: "Alphabet English punya berapa huruf?", options: ["24", "25", "26", "28"], correct: 2, explain: "26 huruf." },
          { q: "Pilih minimal pair yang benar:", options: ["cat / cut sama bunyi", "ship / sheep beda vokal", "pen / pan sama total", "book / look tak ada vokal"], correct: 1, explain: "ship/sheep beda panjang vokal." },
          { q: "Spell 'pen':", options: ["P-E-N", "P-A-N", "B-E-N", "P-E-M"], correct: 0, explain: "P-E-N." },
          { q: "Silent e di 'name' membuat A berbunyi…", options: ["pendek /æ/", "panjang /eɪ/", "hilang", "/iː/"], correct: 1, explain: "Pola VCe → vowel panjang." },
          { q: "Mana yang benar?", options: ["I spell my name", "I spelling my name", "I spells my name", "I to spell name"], correct: 0, explain: "Present simple: I spell…" }
        ],
        remedial: "Ulangi daftar huruf A–Z dengan audio (YouTube: English alphabet). Latih 5 kata: cat, name, ship, sheep, book."
      }
    },
    {
      id: "a1-u02",
      title: "Unit 2: Greetings & Introductions",
      desc: "Salam, perkenalan diri, formal vs informal",
      tags: ["Speaking", "Vocabulary"],
      content: {
        objectives: [
          "Mengucapkan salam sesuai waktu dan situasi",
          "Memperkenalkan nama, asal, dan menanyakan lawan bicara",
          "Membalas 'How are you?' dengan natural"
        ],
        orientation: "Percakapan dimulai dari salam. Salah salam = terasa kaku. Unit ini melatih otomatisasi.",
        theory: `<p><strong>Greetings</strong> = salam. Pilih formal (kerja, orang tua, guru) atau informal (teman).</p>
<p><strong>Formal:</strong> Good morning / Good afternoon / Good evening. Good night = pamit tidur, bukan salam datang.</p>
<p><strong>Informal:</strong> Hi / Hey / Hello.</p>
<p><strong>Perkenalan:</strong> I'm … / My name is … → Nice to meet you. → Nice to meet you too.</p>
<p><strong>How are you?</strong> Jawaban umum: I'm fine, thanks. And you? — bukan hanya "fine" tanpa timbal balik.</p>`,
        rules: [
          "Good night ≠ salam saat baru bertemu malam hari (pakai Good evening)",
          "I'm = I am (kontraksi)",
          "Setelah Nice to meet you, balas Nice to meet you too"
        ],
        examples: [
          { en: "Good morning, Mr. Lee.", id: "Selamat pagi, Pak Lee.", why: "Formal + title." },
          { en: "Hi! I'm Rina.", id: "Hai! Aku Rina.", why: "Informal, langsung nama." },
          { en: "Nice to meet you.", id: "Senang berkenalan.", why: "Standar setelah perkenalan." },
          { en: "I'm fine, thank you. And you?", id: "Baik, terima kasih. Bagaimana denganmu?", why: "Jawaban lengkap + tanya balik." }
        ],
        compare: "<strong>Good evening</strong> (salam datang malam) vs <strong>Good night</strong> (pamit). <strong>How are you?</strong> (basa-basi) vs <strong>How do you do?</strong> (sangat formal, jarang).",
        commonErrors: [
          { wrong: "Good night, teacher! (saat masuk kelas malam)", right: "Good evening, teacher.", why: "Good night untuk berpisah/tidur." },
          { wrong: "I fine", right: "I'm fine", why: "Perlu linking verb be: I am fine." }
        ],
        vocab: [
          { en: "hello", id: "halo", ipa: "/həˈloʊ/", ex: "Hello, everyone." },
          { en: "goodbye", id: "selamat tinggal", ipa: "/ɡʊdˈbaɪ/", ex: "Goodbye!" },
          { en: "meet", id: "bertemu", ipa: "/miːt/", ex: "Nice to meet you." },
          { en: "fine", id: "baik-baik saja", ipa: "/faɪn/", ex: "I'm fine." }
        ],
        dialogue: `A: Good morning!\nB: Good morning! How are you?\nA: I'm fine, thanks. And you?\nB: I'm good. My name is Budi. Nice to meet you.\nA: I'm Sari. Nice to meet you too.`,
        summary: "Pilih salam sesuai waktu & formalitas. I'm + name. Balas How are you dengan lengkap.",
        guided: [
          { q: "Salam formal pagi hari:", options: ["Hey", "Good morning", "Good night", "Yo"], correct: 1, explain: "Good morning formal/netral." },
          { q: "Yang benar:", options: ["I fine", "I'm fine", "Me fine", "I is fine"], correct: 1, explain: "I'm = I am." },
          { q: "Setelah 'Nice to meet you', balasan terbaik:", options: ["OK", "Nice to meet you too", "Yes", "Hello"], correct: 1, explain: "too = juga." }
        ],
        independent: [
          { type: "write", q: "Tulis 3 baris perkenalan: salam + nama + Nice to meet you.", answer: "open", explain: "Contoh: Hi, I'm Andi. Nice to meet you." }
        ],
        practice: "Rekam 20 detik: sapa, sebut nama, tanya how are you, jawab.",
        evaluation: [
          { q: "Good night dipakai untuk…", options: ["salam pagi", "pamit tidur/berpisah", "perkenalan", "belanja"], correct: 1, explain: "Pamit." },
          { q: "Lengkapi: ___ name is Rina.", options: ["I", "My", "Me", "Mine"], correct: 1, explain: "My name is…" },
          { q: "Formal ke dosen:", options: ["Hey prof", "Good morning, Professor", "Yo", "Night"], correct: 1, explain: "Good morning + title." },
          { q: "I'm = ", options: ["I was", "I am", "I be", "I are"], correct: 1, explain: "kontraksi I am." },
          { q: "Pilih dialog yang natural setelah kenalan:", options: ["Nice to meet you. / Bye only", "Nice to meet you. / Nice to meet you too", "Hello. / Table", "Fine. / Cat"], correct: 1, explain: "Timbal balik." }
        ],
        remedial: "Hafalkan 4 salam (morning/afternoon/evening/hi) + template: Hi, I'm ___. Nice to meet you."
      }
    },
    {
      id: "a1-u03",
      title: "Unit 3: Subject Pronouns & Verb Be",
      desc: "I/you/he/she/it/we/they + am/is/are",
      tags: ["Grammar", "Foundation"],
      content: {
        objectives: [
          "Memakai subject pronouns dengan benar",
          "Memilih am / is / are sesuai subject",
          "Membuat kalimat positif, negatif, dan tanya dengan be"
        ],
        orientation: "Tanpa 'be', kamu tidak bisa bilang siapa/apa/di mana. Ini grammar A1 paling penting.",
        theory: `<p><strong>Subject pronouns:</strong> I, you, he, she, it, we, they — menggantikan nama orang/benda sebagai subjek.</p>
<p><strong>Verb be:</strong></p>
<ul>
<li>I <strong>am</strong> (I'm)</li>
<li>you/we/they <strong>are</strong> (you're, we're, they're)</li>
<li>he/she/it <strong>is</strong> (he's, she's, it's)</li>
</ul>
<p><strong>Negatif:</strong> am not / is not (isn't) / are not (aren't).</p>
<p><strong>Tanya:</strong> Am I…? Is she…? Are they…?</p>
<p>Fungsi be: identitas (I am a student), sifat (She is tall), lokasi (We are here).</p>`,
        rules: [
          "Jangan: He are / She am / They is",
          "It untuk benda, hewan (umum), atau situasi: It's sunny",
          "You selalu are (tunggal maupun jamak)"
        ],
        examples: [
          { en: "I am a student.", id: "Saya seorang siswa.", why: "I + am." },
          { en: "She is from Bandung.", id: "Dia (pr) dari Bandung.", why: "She + is." },
          { en: "They are not teachers.", id: "Mereka bukan guru.", why: "They + are + not." },
          { en: "Are you ready?", id: "Apakah kamu siap?", why: "Are + subject + adj." }
        ],
        compare: "<strong>is</strong> (he/she/it) vs <strong>are</strong> (you/we/they). <strong>I'm not</strong> (bukan I amn't).",
        commonErrors: [
          { wrong: "He are happy", right: "He is happy", why: "He → is." },
          { wrong: "I is student", right: "I am a student", why: "I → am; perlu article a." }
        ],
        vocab: [
          { en: "student", id: "siswa/mahasiswa", ipa: "/ˈstuːdnt/", ex: "I am a student." },
          { en: "teacher", id: "guru", ipa: "/ˈtiːtʃər/", ex: "She is a teacher." },
          { en: "happy", id: "senang", ipa: "/ˈhæpi/", ex: "We are happy." },
          { en: "ready", id: "siap", ipa: "/ˈredi/", ex: "Are you ready?" }
        ],
        dialogue: `A: Are you a student?\nB: Yes, I am. I'm a student at UNPAD.\nA: Is she your friend?\nB: Yes, she is. Her name is Dina.`,
        summary: "I am · he/she/it is · you/we/they are. Negatif + not. Tanya: Be + subject?",
        guided: [
          { q: "She ___ a doctor.", options: ["am", "is", "are", "be"], correct: 1, explain: "She + is." },
          { q: "I ___ not tired.", options: ["is", "are", "am", "be"], correct: 2, explain: "I am not." },
          { q: "___ they students?", options: ["Is", "Are", "Am", "Be"], correct: 1, explain: "Are they…?" }
        ],
        independent: [
          { type: "fill", q: "He ___ my brother. (be)", answer: "is", explain: "He is." },
          { type: "fill", q: "We ___ in class. (be)", answer: "are", explain: "We are." }
        ],
        practice: "Tulis 6 kalimat: 2 positif, 2 negatif, 2 tanya memakai be tentang dirimu dan teman.",
        evaluation: [
          { q: "They ___ at home.", options: ["is", "am", "are", "be"], correct: 2, explain: "They are." },
          { q: "___ I late?", options: ["Is", "Am", "Are", "Be"], correct: 1, explain: "Am I…?" },
          { q: "It ___ cold today.", options: ["are", "am", "is", "be"], correct: 2, explain: "It is." },
          { q: "Negatif dari 'She is here':", options: ["She not is here", "She isn't here", "She aren't here", "She am not here"], correct: 1, explain: "isn't = is not." },
          { q: "You and I → pronoun:", options: ["I", "you", "we", "they"], correct: 2, explain: "we." }
        ],
        remedial: "Tabel: I am, you are, he is, she is, it is, we are, they are. Tulis 10x lalu buat kalimat sendiri."
      }
    },
    {
      id: "a1-u04",
      title: "Unit 4: Nouns, A/An/The & Demonstratives",
      desc: "Kata benda, artikel, this/that/these/those",
      tags: ["Grammar", "Vocabulary"],
      content: {
        objectives: [
          "Membedakan singular/plural nouns",
          "Memakai a/an/the secara dasar",
          "Memakai this/that/these/those sesuai jarak dan jumlah"
        ],
        orientation: "Artikel sering diabaikan pemula Indonesia karena bahasa Indonesia tidak punya sistem yang sama.",
        theory: `<p><strong>Noun</strong> = nama orang/benda/tempat. Singular (satu) vs plural (banyak, biasanya +s/-es).</p>
<p><strong>a</strong> + bunyi konsonan: a book, a university (/j/). <strong>an</strong> + bunyi vokal: an apple, an hour (/aʊ/).</p>
<p><strong>the</strong> = spesifik / sudah disebut / unik: the sun, the book on the table.</p>
<p><strong>this/these</strong> = dekat; <strong>that/those</strong> = jauh. this/that singular; these/those plural.</p>`,
        rules: [
          "a/an hanya singular countable",
          "Jangan a apple → an apple",
          "this book (dekat, 1) · these books (dekat, banyak)"
        ],
        examples: [
          { en: "This is a pen.", id: "Ini (dekat) sebuah pena.", why: "singular dekat + a." },
          { en: "Those are books.", id: "Itu (jauh) buku-buku.", why: "plural jauh." },
          { en: "An hour ago…", id: "Satu jam yang lalu…", why: "hour bunyi vokal." },
          { en: "I see a cat. The cat is black.", id: "Lihat kucing. Kucing itu hitam.", why: "kedua kali → the." }
        ],
        compare: "a/an (tidak spesifik) vs the (spesifik). this (dekat) vs that (jauh).",
        commonErrors: [
          { wrong: "a apple", right: "an apple", why: "bunyi vokal." },
          { wrong: "this books", right: "these books", why: "plural → these." }
        ],
        vocab: [
          { en: "book", id: "buku", ipa: "/bʊk/", ex: "This is my book." },
          { en: "apple", id: "apel", ipa: "/ˈæpl/", ex: "an apple" },
          { en: "table", id: "meja", ipa: "/ˈteɪbl/", ex: "that table" },
          { en: "keys", id: "kunci-kunci", ipa: "/kiːz/", ex: "these keys" }
        ],
        dialogue: `A: What is this?\nB: It's a phone.\nA: And those?\nB: Those are my keys.`,
        summary: "a/an singular · the spesifik · this/these dekat · that/those jauh.",
        guided: [
          { q: "___ orange (satu, tak spesifik)", options: ["a", "an", "the", "these"], correct: 1, explain: "an + vokal." },
          { q: "Buku-buku di sini (dekat):", options: ["that book", "this book", "these books", "those book"], correct: 2, explain: "these + plural." }
        ],
        independent: [
          { type: "fill", q: "___ sun is bright. (article)", answer: "The", explain: "unik → the." }
        ],
        practice: "Tunjuk 5 benda di sekitarmu: This is a… / Those are…",
        evaluation: [
          { q: "___ umbrella", options: ["a", "an", "these", "those"], correct: 1, explain: "an + u vokal." },
          { q: "Far + plural:", options: ["this", "that", "these", "those"], correct: 3, explain: "those." },
          { q: "I have ___ idea.", options: ["a", "an", "these", "-"], correct: 1, explain: "an idea." },
          { q: "Plural of 'box':", options: ["boxs", "boxes", "boxies", "boxen"], correct: 1, explain: "+es." },
          { q: "Second mention: I bought a bag. ___ bag is red.", options: ["A", "An", "The", "Those"], correct: 2, explain: "the." }
        ],
        remedial: "Latih a/an dengan 10 kata: book, apple, hour, university, pen, egg, chair, orange, house, uncle."
      }
    },
    {
      id: "a1-u05",
      title: "Unit 5: Possessives & Possessive Adjectives",
      desc: "my/your/his/her/its/our/their dan 's",
      tags: ["Grammar"],
      content: {
        objectives: [
          "Memakai possessive adjectives (my, your, …)",
          "Membentuk possessive dengan 's pada nama",
          "Membedakan its vs it's"
        ],
        orientation: "Possessive menjawab: milik siapa?",
        theory: `<p><strong>Possessive adjectives:</strong> my, your, his, her, its, our, their — diikuti noun: my book.</p>
<p><strong>'s:</strong> Rina's bag = tasnya Rina. Untuk plural regular: students' room.</p>
<p><strong>its</strong> = milik it. <strong>it's</strong> = it is / it has. Jangan tertukar.</p>`,
        rules: [
          "my + noun (bukan mine book)",
          "it's raining = it is raining",
          "The dog wagged its tail (bukan it's tail)"
        ],
        examples: [
          { en: "This is my phone.", id: "Ini ponsel saya.", why: "my + noun." },
          { en: "Her name is Lina.", id: "Namanya Lina.", why: "her untuk she." },
          { en: "Budi's car is new.", id: "Mobilnya Budi baru.", why: "nama + 's." },
          { en: "It's a cat. Its fur is white.", id: "Itu kucing. Bulunya putih.", why: "it's=it is; its=milik." }
        ],
        compare: "my (adjective) vs mine (pronoun: The book is mine). its vs it's.",
        commonErrors: [
          { wrong: "This is mine book", right: "This is my book", why: "mine tidak diikuti noun." },
          { wrong: "Its OK", right: "It's OK", why: "it is → it's." }
        ],
        vocab: [
          { en: "my", id: "punya saya", ipa: "/maɪ/", ex: "my bag" },
          { en: "your", id: "punya kamu", ipa: "/jɔːr/", ex: "your name" },
          { en: "their", id: "punya mereka", ipa: "/ðeər/", ex: "their house" },
          { en: "ours", id: "milik kami", ipa: "/aʊərz/", ex: "This is ours." }
        ],
        dialogue: `A: Is this your book?\nB: No, it's Rina's book. Mine is blue.`,
        summary: "my/your/his/her/its/our/their + noun. Nama + 's. its ≠ it's.",
        guided: [
          { q: "___ name is Tom. (he)", options: ["He", "His", "Him", "He's"], correct: 1, explain: "His name." },
          { q: "The city and ___ parks", options: ["it's", "its", "it", "their"], correct: 1, explain: "its = milik." }
        ],
        independent: [
          { type: "fill", q: "We love ___ school. (possessive)", answer: "our", explain: "our school." }
        ],
        practice: "Deskripsikan 4 benda: This is my/your/his…",
        evaluation: [
          { q: "She has a bag. It is ___ bag.", options: ["she", "her", "hers", "his"], correct: 1, explain: "her bag." },
          { q: "___ a nice day.", options: ["Its", "It's", "It", "His"], correct: 1, explain: "It's = it is." },
          { q: "Andi's sister =", options: ["Andi sister", "Andis sister", "Andi's sister", "Andi his sister"], correct: 2, explain: "'s." },
          { q: "They open ___ books.", options: ["they", "them", "their", "theirs"], correct: 2, explain: "their books." },
          { q: "The book is ___. (milik saya, tanpa noun)", options: ["my", "mine", "I", "me"], correct: 1, explain: "mine." }
        ],
        remedial: "Buat tabel pronoun → possessive: I→my, you→your, he→his, she→her, it→its, we→our, they→their."
      }
    },
    {
      id: "a1-u06",
      title: "Unit 6: Simple Present — Habits & Facts",
      desc: "Kalimat kebiasaan, fakta, +s pada he/she/it",
      tags: ["Grammar", "Writing"],
      content: {
        objectives: [
          "Membentuk simple present untuk kebiasaan dan fakta",
          "Menambah -s/-es pada he/she/it",
          "Membuat negatif dan pertanyaan dengan do/does"
        ],
        orientation: "Simple present = tense A1 paling sering dipakai untuk rutinitas.",
        theory: `<p><strong>Fungsi:</strong> kebiasaan (I eat rice every day), fakta (Water boils at 100°C), jadwal.</p>
<p><strong>Bentuk:</strong> I/you/we/they + V1 · he/she/it + V1+s/es</p>
<p><strong>Negatif:</strong> do not (don't) / does not (doesn't) + V1 — tanpa -s pada verb utama.</p>
<p><strong>Tanya:</strong> Do you…? Does she…?</p>`,
        rules: [
          "He works (bukan he work)",
          "She doesn't like (bukan doesn't likes)",
          "Do they live…? (bukan Are they live…?)"
        ],
        examples: [
          { en: "I study English every day.", id: "Saya belajar English setiap hari.", why: "kebiasaan." },
          { en: "She works in a bank.", id: "Dia bekerja di bank.", why: "she + works." },
          { en: "He doesn't drink coffee.", id: "Dia tidak minum kopi.", why: "doesn't + V1." },
          { en: "Do you live here?", id: "Apakah kamu tinggal di sini?", why: "Do + subject + V1." }
        ],
        compare: "Simple present (rutin) vs present continuous (sedang terjadi sekarang — unit nanti di A2).",
        commonErrors: [
          { wrong: "He go to school", right: "He goes to school", why: "+es." },
          { wrong: "She doesn't goes", right: "She doesn't go", why: "setelah does, V1 polos." }
        ],
        vocab: [
          { en: "usually", id: "biasanya", ipa: "/ˈjuːʒuəli/", ex: "I usually wake up at 6." },
          { en: "always", id: "selalu", ipa: "/ˈɔːlweɪz/", ex: "She always smiles." },
          { en: "never", id: "tidak pernah", ipa: "/ˈnevər/", ex: "I never smoke." },
          { en: "work", id: "bekerja", ipa: "/wɜːrk/", ex: "They work hard." }
        ],
        dialogue: `A: What do you do every morning?\nB: I drink tea and check my phone.\nA: Does your sister work?\nB: Yes, she works in a hospital.`,
        summary: "V1 / V1+s · don't/doesn't + V1 · Do/Does…?",
        guided: [
          { q: "He ___ English.", options: ["study", "studies", "studying", "studied"], correct: 1, explain: "he + studies." },
          { q: "She ___ not like tea. (do)", options: ["do", "does", "is", "are"], correct: 1, explain: "does not." }
        ],
        independent: [
          { type: "write", q: "3 kalimat kebiasaanmu (I…) dan 2 tentang teman (He/She…).", answer: "open", explain: "Cek -s pada he/she." }
        ],
        practice: "Tulis jadwal harian 5 kalimat simple present.",
        evaluation: [
          { q: "My brother ___ TV every night.", options: ["watch", "watches", "watching", "watched"], correct: 1, explain: "watches." },
          { q: "___ she play football?", options: ["Do", "Does", "Is", "Are"], correct: 1, explain: "Does she…?" },
          { q: "They ___ live here.", options: ["doesn't", "don't", "isn't", "aren't"], correct: 1, explain: "don't." },
          { q: "Water ___ at 100°C.", options: ["boil", "boils", "boiling", "boiled"], correct: 1, explain: "fakta: boils." },
          { q: "I ___ breakfast at 7.", options: ["eats", "eat", "eating", "ate"], correct: 1, explain: "I + eat." }
        ],
        remedial: "List verb: go→goes, watch→watches, study→studies, do→does, have→has. Buat 1 kalimat tiap verb."
      }
    },
    {
      id: "a1-u07",
      title: "Unit 7: Numbers, Time & Prepositions of Time/Place",
      desc: "Angka, jam, in/on/at, tempat dasar",
      tags: ["Vocabulary", "Listening"],
      content: {
        objectives: [
          "Menyebut angka dan jam",
          "Memakai in/on/at untuk waktu",
          "Memakai in/on/at/under/next to untuk tempat dasar"
        ],
        orientation: "Angka dan preposisi membuat janji dan lokasi bisa dipahami.",
        theory: `<p><strong>Jam:</strong> It's 7 o'clock. It's half past 7 (7:30). It's a quarter past 7 (7:15). It's a quarter to 8 (7:45).</p>
<p><strong>at</strong> + jam: at 5 pm. <strong>on</strong> + hari/tanggal: on Monday, on 5 May. <strong>in</strong> + bulan/tahun/periode: in June, in 2026, in the morning.</p>
<p><strong>Place:</strong> in a room, on a table, at school/at home (fixed phrases).</p>`,
        rules: [
          "at night · in the morning (bukan at morning)",
          "on the wall · in the box",
          "at 7:00 (bukan in 7:00)"
        ],
        examples: [
          { en: "The class starts at 8.", id: "Kelas mulai pukul 8.", why: "at + clock time." },
          { en: "I work on Monday.", id: "Saya kerja hari Senin.", why: "on + day." },
          { en: "She was born in 2004.", id: "Dia lahir tahun 2004.", why: "in + year." },
          { en: "The keys are on the table.", id: "Kunci di atas meja.", why: "on + surface." }
        ],
        compare: "in the morning vs at night. at school vs in the classroom.",
        commonErrors: [
          { wrong: "in Monday", right: "on Monday", why: "hari → on." },
          { wrong: "at morning", right: "in the morning", why: "frasa tetap." }
        ],
        vocab: [
          { en: "o'clock", id: "tepat … jam", ipa: "/əˈklɒk/", ex: "two o'clock" },
          { en: "half past", id: "setengah", ipa: "/hɑːf pɑːst/", ex: "half past three" },
          { en: "between", id: "di antara", ipa: "/bɪˈtwiːn/", ex: "between A and B" },
          { en: "next to", id: "di samping", ipa: "/nekst tuː/", ex: "next to the door" }
        ],
        dialogue: `A: What time is the meeting?\nB: At half past nine.\nA: Where?\nB: In room 12, next to the library.`,
        summary: "at + jam · on + hari · in + bulan/tahun. Place: in/on/at/next to.",
        guided: [
          { q: "___ 5 May", options: ["in", "on", "at", "to"], correct: 1, explain: "on + date." },
          { q: "___ night", options: ["in", "on", "at", "to"], correct: 2, explain: "at night." }
        ],
        independent: [
          { type: "fill", q: "The book is ___ the bag. (in/on/at)", answer: "in", explain: "in the bag." }
        ],
        practice: "Tulis 5 janji imajiner: day + time + place dengan preposisi benar.",
        evaluation: [
          { q: "I get up ___ 6 a.m.", options: ["in", "on", "at", "to"], correct: 2, explain: "at + time." },
          { q: "See you ___ Friday.", options: ["in", "on", "at", "to"], correct: 1, explain: "on Friday." },
          { q: "___ 2020", options: ["at", "on", "in", "to"], correct: 2, explain: "in + year." },
          { q: "The picture is ___ the wall.", options: ["in", "on", "at", "under"], correct: 1, explain: "on the wall." },
          { q: "Half past two =", options: ["1:30", "2:30", "2:15", "3:00"], correct: 1, explain: "2:30." }
        ],
        remedial: "Buat mind map: at (clock, night, school) · on (days, dates, surfaces) · in (months, years, containers)."
      }
    },
    {
      id: "a1-u08",
      title: "Unit 8: A1 Checkpoint — Conversation & Review",
      desc: "Gabungan skills A1 + evaluasi level",
      tags: ["Review", "Speaking", "Evaluation"],
      content: {
        objectives: [
          "Menggabungkan salam, be, present simple, dan preposisi dalam dialog",
          "Menunjukkan penguasaan minimal 80% pada evaluasi A1"
        ],
        orientation: "Unit penutup A1. Lulus evaluasi ini membuka A2.",
        theory: `<p>Review singkat A1: alphabet & sounds → greetings → pronouns + be → nouns/articles/demonstratives → possessives → simple present → numbers/time/prepositions.</p>
<p>Kompetensi percakapan: perkenalan, bilang jam, sebut lokasi, ceritakan rutinitas singkat (4–6 kalimat).</p>`,
        rules: ["Gunakan struktur yang sudah dipelajari; prioritaskan kejelasan daripada kalimat panjang."],
        examples: [
          { en: "Hi, I'm Ardi. I'm a student. I live in Depok. I study every morning at 7.", id: "Contoh monolog A1.", why: "be + present simple + time." }
        ],
        compare: "A1 = kalimat sederhana terpisah. Belum wajib complex sentences (meskipun, karena, …).",
        commonErrors: [
          { wrong: "I am study English", right: "I study English", why: "Jangan dobel verb (am + study)." }
        ],
        vocab: [
          { en: "review", id: "mengulas", ipa: "/rɪˈvjuː/", ex: "Let's review." },
          { en: "checkpoint", id: "titik periksa", ipa: "/ˈtʃekpɔɪnt/", ex: "A1 checkpoint" }
        ],
        dialogue: `A: Hello! What's your name?\nB: I'm Maya. Nice to meet you.\nA: Where do you live?\nB: I live in Bogor. I go to campus on Monday and Wednesday.`,
        summary: "A1 siap jika kamu bisa perkenalan + rutinitas + jam/tempat dengan be & present simple akurat.",
        guided: [
          { q: "I ___ a teacher. I ___ English.", options: ["am / teach", "is / teaches", "are / teach", "am / teaches"], correct: 0, explain: "I am · I teach." }
        ],
        independent: [
          { type: "write", q: "Tulis paragraf 5–7 kalimat tentang dirimu (nama, asal, studi, rutinitas, jam).", answer: "open", explain: "Cek be & -s." }
        ],
        practice: "Simulasi: perkenalan 30 detik tanpa teks.",
        evaluation: [
          { q: "She ___ from Bali. She ___ coffee.", options: ["is / like", "is / likes", "are / likes", "am / like"], correct: 1, explain: "is + likes." },
          { q: "___ you work ___ Monday?", options: ["Do / on", "Does / in", "Are / at", "Do / in"], correct: 0, explain: "Do you · on Monday." },
          { q: "This is ___ book. ___ a good book.", options: ["my / It's", "mine / Its", "my / Its", "me / It's"], correct: 0, explain: "my · It's." },
          { q: "The keys are ___ the table ___ the morning.", options: ["on / in", "in / on", "at / at", "on / at"], correct: 0, explain: "on the table · in the morning." },
          { q: "He ___ not ___ here.", options: ["do / live", "does / live", "does / lives", "is / live"], correct: 1, explain: "doesn't live." }
        ],
        remedial: "Kembali ke unit dengan skor terendah. Minimal ulangi Unit 3 (be) dan Unit 6 (present simple)."
      }
    }
  ],


  a2: [
    {
      id: "a2-u01",
      title: "Unit 1: Present Continuous & Now",
      desc: "Sedang terjadi vs kebiasaan — be + V-ing",
      tags: ["Grammar", "Speaking"],
      content: {
        objectives: [
          "Membentuk am/is/are + V-ing dengan benar",
          "Membedakan present continuous (sekarang/sementara) dari simple present (rutin)",
          "Mengajukan dan menjawab pertanyaan What are you doing?"
        ],
        orientation: "Di A1 kamu bilang kebiasaan (I study every day). Di A2 kamu bilang apa yang sedang terjadi sekarang. Dua tense ini sering tertukar.",
        theory: `<p><strong>Present continuous</strong> = <em>be + V-ing</em>.</p>
<ul>
<li>I <strong>am writing</strong> an email.</li>
<li>She <strong>is cooking</strong> now.</li>
<li>They <strong>are waiting</strong> outside.</li>
</ul>
<p><strong>Kapan dipakai?</strong></p>
<ol>
<li>Aksi sedang berlangsung sekarang: Look! It is raining.</li>
<li>Situasi sementara: I am staying with a friend this week.</li>
<li>Rencana dekat yang sudah diatur (kadang): I am meeting Ana at 5.</li>
</ol>
<p><strong>Simple present</strong> tetap untuk kebiasaan/fakta: I drink tea every morning.</p>
<p><strong>Stative verbs</strong> (jarang continuous): know, like, love, want, need, believe, understand, have (punya).</p>
<p>Salah: I am knowing him. Benar: I know him.</p>`,
        rules: [
          "Selalu ada be: I am studying (bukan I studying)",
          "V-ing: write→writing, run→running, swim→swimming, lie→lying",
          "Negatif: is not (isn't) + V-ing · Tanya: Are you + V-ing?"
        ],
        examples: [
          { en: "I am studying English right now.", id: "Saya sedang belajar English saat ini.", why: "right now → continuous." },
          { en: "She works in a bank, but today she is working from home.", id: "Kebiasaan vs sementara.", why: "works = rutin; is working = hari ini." },
          { en: "What are you doing?", id: "Sedang apa?", why: "Are + subject + V-ing." },
          { en: "I know the answer. (bukan I am knowing)", id: "Saya tahu jawabannya.", why: "know = stative." }
        ],
        compare: "<strong>I live in Jakarta</strong> (permanen) vs <strong>I am living with my uncle this month</strong> (sementara). <strong>every day</strong> → simple present; <strong>now / at the moment</strong> → continuous.",
        commonErrors: [
          { wrong: "I studying now", right: "I am studying now", why: "Wajib be (am/is/are)." },
          { wrong: "She is want a coffee", right: "She wants a coffee", why: "want stative → simple present." },
          { wrong: "Are you study?", right: "Are you studying? / Do you study?", why: "Continuous perlu V-ing; kebiasaan pakai Do." }
        ],
        vocab: [
          { en: "right now", id: "saat ini juga", ipa: "/raɪt naʊ/", ex: "I am busy right now." },
          { en: "at the moment", id: "saat ini", ipa: "/æt ðə ˈməʊmənt/", ex: "At the moment, I am working." },
          { en: "currently", id: "saat ini (lebih formal)", ipa: "/ˈkʌrəntli/", ex: "She is currently studying abroad." },
          { en: "temporary", id: "sementara", ipa: "/ˈtempəreri/", ex: "This is a temporary job." },
          { en: "look!", id: "lihat!", ipa: "/lʊk/", ex: "Look! The bus is coming." }
        ],
        dialogue: `A: Hi! What are you doing?\nB: I'm reading a report for class.\nA: Do you read reports every day?\nB: No. I usually watch videos, but today I am preparing for a quiz.`,
        summary: "be + V-ing untuk now/temporary. Simple present untuk habits. Stative verbs tidak continuous.",
        guided: [
          { q: "Look! He ___ the door.", options: ["open", "opens", "is opening", "opened"], correct: 2, explain: "Look! → aksi sekarang → is opening." },
          { q: "I ___ to campus every day, but today I ___ at home.", options: ["go / study", "go / am studying", "am going / study", "goes / am studying"], correct: 1, explain: "habit = go; today temporary = am studying." },
          { q: "___ you ___ lunch now?", options: ["Do / have", "Are / having", "Is / having", "Do / having"], correct: 1, explain: "Are you having…?" }
        ],
        independent: [
          { type: "write", q: "Tulis 3 kalimat present continuous (sekarang) dan 3 simple present (rutin) tentang harimu.", answer: "open", explain: "Cek be + V-ing vs V1." },
          { type: "choose", q: "Mana yang benar untuk 'tahu'?", options: ["I am knowing the answer", "I know the answer", "I knowing the answer", "I is know"], correct: 1, explain: "know stative." }
        ],
        practice: "Rekam 30 detik: ceritakan apa yang sedang kamu lakukan sekarang + 2 kebiasaan harianmu.",
        evaluation: [
          { q: "Quiet! The baby ___.", options: ["sleep", "sleeps", "is sleeping", "slept"], correct: 2, explain: "is sleeping." },
          { q: "She ___ English this semester (kelas sementara).", options: ["study", "studies", "is studying", "studied"], correct: 2, explain: "is studying." },
          { q: "I ___ this song. (tahu/mengenal)", options: ["am knowing", "know", "is know", "knowing"], correct: 1, explain: "stative know." },
          { q: "___ they ___ football right now?", options: ["Do / play", "Are / playing", "Is / playing", "Do / playing"], correct: 1, explain: "Are they playing?" },
          { q: "He ___ in Bandung, but this month he ___ in Jakarta.", options: ["lives / stays", "lives / is staying", "is living / stays", "live / is staying"], correct: 1, explain: "lives = permanen; is staying = sementara." }
        ],
        remedial: "Buat tabel: every day / usually → simple present; now / look! / this week → continuous. 10 kalimat campuran."
      }
    },
    {
      id: "a2-u02",
      title: "Unit 2: Past Simple — Regular & Irregular",
      desc: "Menceritakan kejadian lampau dengan V2 dan did",
      tags: ["Grammar", "Writing"],
      content: {
        objectives: [
          "Membentuk past simple regular (-ed) dan irregular umum",
          "Membuat negatif dan pertanyaan dengan did + V1",
          "Memakai time markers: yesterday, last week, ago"
        ],
        orientation: "Tanpa past simple kamu tidak bisa menjawab 'What did you do yesterday?' — skill A2 inti.",
        theory: `<p><strong>Fungsi:</strong> kejadian selesai di masa lalu dengan waktu spesifik (atau jelas sudah selesai).</p>
<p><strong>Regular:</strong> work→worked, play→played, study→studied, stop→stopped.</p>
<p><strong>Irregular (wajib hafal inti):</strong> go→went, have→had, do→did, see→saw, eat→ate, buy→bought, come→came, make→made, take→took, write→wrote, read→read /red/, give→gave, find→found, know→knew, think→thought, get→got, say→said, tell→told, leave→left, feel→felt.</p>
<p><strong>Negatif:</strong> did not (didn't) + V1 — <em>bukan</em> didn't went.</p>
<p><strong>Tanya:</strong> Did you go…? Yes, I did. / No, I didn't.</p>
<p><strong>Time:</strong> yesterday, last night/week/year, in 2020, two days ago, when I was a child.</p>`,
        rules: [
          "Did + subject + V1 (bukan Did you went?)",
          "I went (bukan I goed / I did went)",
          "She didn't like (bukan didn't liked)"
        ],
        examples: [
          { en: "I visited my grandma yesterday.", id: "Saya mengunjungi nenek kemarin.", why: "regular -ed + yesterday." },
          { en: "She went to Bali last year.", id: "Dia pergi ke Bali tahun lalu.", why: "went = irregular." },
          { en: "They didn't see the message.", id: "Mereka tidak melihat pesan itu.", why: "didn't + V1 (see)." },
          { en: "Did you finish the homework?", id: "Apakah kamu menyelesaikan PR?", why: "Did + V1." }
        ],
        compare: "Past simple = selesai + waktu jelas. Present perfect (B1) = pengalaman/waktu tak spesifik: I have visited Bali (bukan I have visited Bali yesterday).",
        commonErrors: [
          { wrong: "I did went home", right: "I went home / I did go home", why: "did + V1 atau V2 tanpa did." },
          { wrong: "She didn't went", right: "She didn't go", why: "setelah did, verb polos." },
          { wrong: "Did he ate?", right: "Did he eat?", why: "Did + V1." }
        ],
        vocab: [
          { en: "yesterday", id: "kemarin", ipa: "/ˈjestərdeɪ/", ex: "yesterday morning" },
          { en: "ago", id: "yang lalu", ipa: "/əˈɡəʊ/", ex: "three days ago" },
          { en: "last weekend", id: "akhir pekan lalu", ipa: "/lɑːst ˈwiːkend/", ex: "last weekend I stayed home." },
          { en: "suddenly", id: "tiba-tiba", ipa: "/ˈsʌdənli/", ex: "Suddenly it started to rain." },
          { en: "finally", id: "akhirnya", ipa: "/ˈfaɪnəli/", ex: "Finally we arrived." }
        ],
        dialogue: `A: What did you do last weekend?\nB: I went to the beach and ate seafood.\nA: Did you swim?\nB: No, I didn't. The water was cold.`,
        summary: "V2 untuk positif. didn't/Did + V1. Hafalkan irregular inti. Time markers lampau.",
        guided: [
          { q: "They ___ football last Sunday.", options: ["play", "played", "playing", "plays"], correct: 1, explain: "played (regular)." },
          { q: "___ you ___ the film yesterday?", options: ["Did / see", "Did / saw", "Do / see", "Are / see"], correct: 0, explain: "Did you see?" },
          { q: "He ___ not ___ coffee this morning.", options: ["did / drank", "did / drink", "does / drank", "was / drink"], correct: 1, explain: "didn't drink." }
        ],
        independent: [
          { type: "write", q: "Paragraf 6–8 kalimat tentang last weekend (minimal 3 irregular verbs).", answer: "open", explain: "Cek V2 dan didn't + V1." },
          { type: "fill", q: "She ___ (buy) a new bag two days ago.", answer: "bought", explain: "bought." }
        ],
        practice: "Ceritakan 1 kejadian penting tahun lalu (6 kalimat). Lalu ubah 2 kalimat menjadi negatif.",
        evaluation: [
          { q: "He ___ to campus by bus yesterday.", options: ["go", "goes", "went", "gone"], correct: 2, explain: "went." },
          { q: "___ she ___ the email?", options: ["Did / send", "Did / sent", "Does / send", "Was / send"], correct: 0, explain: "Did she send?" },
          { q: "We ___ a great time at the party.", options: ["have", "had", "has", "having"], correct: 1, explain: "had." },
          { q: "I ___ not ___ the question.", options: ["did / understood", "did / understand", "do / understood", "was / understand"], correct: 1, explain: "didn't understand." },
          { q: "They ___ home an hour ago.", options: ["leave", "left", "leaves", "leaving"], correct: 1, explain: "left." }
        ],
        remedial: "Hafalkan 20 irregular: go, have, do, see, eat, buy, come, make, take, write, read, give, find, know, think, get, say, tell, leave, feel. Buat 1 kalimat tiap kata."
      }
    },
    {
      id: "a2-u03",
      title: "Unit 3: Countable, Uncountable & Quantity",
      desc: "some/any/much/many/a lot of/a few/a little",
      tags: ["Grammar", "Vocabulary"],
      content: {
        objectives: [
          "Membedakan countable dan uncountable nouns",
          "Memilih many/much/a few/a little/a lot of dengan tepat",
          "Memakai some dan any dalam positif, negatif, dan tanya"
        ],
        orientation: "Kesalahan klasik penutur Indonesia: many waters, much books, informations.",
        theory: `<p><strong>Countable:</strong> bisa dihitung — book/books, apple/apples. Bisa a/an dan angka.</p>
<p><strong>Uncountable:</strong> tidak dihitung satuan dalam English biasa — water, rice, information, money, advice, furniture, news, homework, bread. Tidak pakai a/an; tidak plural biasa (*informations salah).</p>
<p><strong>many</strong> + countable · <strong>much</strong> + uncountable · <strong>a lot of</strong> + keduanya.</p>
<p><strong>a few</strong> + countable (sedikit tapi ada) · <strong>a little</strong> + uncountable.</p>
<p><strong>some</strong> sering di positif; <strong>any</strong> sering di negatif/tanya (Do you have any…? I don't have any…).</p>`,
        rules: [
          "How many apples? How much water/money/time?",
          "some information (bukan an information / informations)",
          "a few friends · a little sugar"
        ],
        examples: [
          { en: "There are many students in the hall.", id: "Ada banyak siswa di aula.", why: "many + countable plural." },
          { en: "There isn't much time left.", id: "Tidak banyak waktu tersisa.", why: "much + uncountable." },
          { en: "I need some advice.", id: "Saya perlu sedikit saran.", why: "advice uncountable." },
          { en: "Do we have any milk?", id: "Apakah kita punya susu?", why: "any di pertanyaan." }
        ],
        compare: "few (hampir tidak ada, bernada negatif) vs a few (ada beberapa). little vs a little — pola sama untuk uncountable.",
        commonErrors: [
          { wrong: "many informations", right: "a lot of information / much information", why: "information uncountable." },
          { wrong: "much books", right: "many books", why: "books countable." },
          { wrong: "a apple juice", right: "some apple juice / a glass of juice", why: "juice uncountable." }
        ],
        vocab: [
          { en: "advice", id: "saran", ipa: "/ədˈvaɪs/", ex: "Can I give you some advice?" },
          { en: "furniture", id: "perabot", ipa: "/ˈfɜːrnɪtʃər/", ex: "new furniture" },
          { en: "homework", id: "PR", ipa: "/ˈhəʊmwɜːrk/", ex: "a lot of homework" },
          { en: "a few", id: "beberapa", ipa: "/ə fjuː/", ex: "a few minutes" },
          { en: "a little", id: "sedikit", ipa: "/ə ˈlɪtl/", ex: "a little milk" }
        ],
        dialogue: `A: Do we have any eggs?\nB: We have a few eggs, but we don't have much milk.\nA: I'll buy some milk then.`,
        summary: "many/a few + count · much/a little + uncount · a lot of fleksibel · some/any.",
        guided: [
          { q: "How ___ sugar do you need?", options: ["many", "much", "few", "a"], correct: 1, explain: "much + uncountable." },
          { q: "There aren't ___ chairs here.", options: ["much", "many", "a little", "an"], correct: 1, explain: "many + countable." },
          { q: "I need ___ information about the course.", options: ["an", "many", "some", "few"], correct: 2, explain: "some information." }
        ],
        independent: [
          { type: "write", q: "List 5 countable + 5 uncountable di kampus/dapur. Buat 1 kalimat quantity untuk tiap kategori.", answer: "open", explain: "Cek many/much." }
        ],
        practice: "Deskripsikan isikulkas/tasmu pakai some, any, much, many, a few, a little (6 kalimat).",
        evaluation: [
          { q: "There isn't ___ milk.", options: ["many", "much", "few", "several"], correct: 1, explain: "much milk." },
          { q: "How ___ people came?", options: ["much", "many", "little", "a"], correct: 1, explain: "many people." },
          { q: "She gave me ___ useful advice.", options: ["a", "many", "some", "few"], correct: 2, explain: "some advice." },
          { q: "We have only ___ eggs left. (sedikit, countable)", options: ["a little", "a few", "much", "any"], correct: 1, explain: "a few eggs." },
          { q: "Is there ___ water in the bottle?", options: ["many", "few", "any", "several"], correct: 2, explain: "any." }
        ],
        remedial: "Kartu dua kolom Countable | Uncountable (20 kata). Latihan How much/How many 10x."
      }
    },
    {
      id: "a2-u04",
      title: "Unit 4: Comparatives & Superlatives",
      desc: "lebih… / paling… — -er/-est dan more/most",
      tags: ["Grammar", "Speaking"],
      content: {
        objectives: [
          "Membentuk comparative (-er / more) dan superlative (-est / most)",
          "Memakai than dan the + superlative",
          "Menguasai bentuk irregular: better, worse, best, worst"
        ],
        orientation: "Membandingkan orang, tempat, dan pilihan — skill percakapan A2 sangat sering.",
        theory: `<p><strong>Adjective pendek (1 suku kata):</strong> tall→taller→the tallest; big→bigger→the biggest.</p>
<p><strong>2 suku kata -y:</strong> happy→happier→the happiest.</p>
<p><strong>Panjang (2+ suku kata):</strong> more useful → the most useful; more expensive → the most expensive.</p>
<p><strong>Irregular:</strong> good→better→best; bad→worse→worst; far→farther/further→farthest/furthest.</p>
<p>Pola: A is <strong>adj-er than</strong> B. A is <strong>the adj-est</strong> in the group.</p>`,
        rules: [
          "than (bukan from) setelah comparative: taller than me",
          "the sebelum superlative: the tallest student",
          "Jangan more taller / the most tallest"
        ],
        examples: [
          { en: "This book is easier than that one.", id: "Buku ini lebih mudah daripada yang itu.", why: "easy → easier + than." },
          { en: "She is the most hardworking student in class.", id: "Dia siswa paling rajin di kelas.", why: "long adj → most." },
          { en: "My results are better than last semester.", id: "Hasil saya lebih baik dari semester lalu.", why: "better irregular." },
          { en: "This is the worst coffee I have ever had. (preview)", id: "Ini kopi terburuk…", why: "worst = superlative bad." }
        ],
        compare: "comparative = banding 2 hal; superlative = 3+ atau dalam grup. as…as untuk kesamaan: as tall as.",
        commonErrors: [
          { wrong: "more taller", right: "taller", why: "jangan dobel comparative." },
          { wrong: "the most cheapest", right: "the cheapest", why: "jangan dobel." },
          { wrong: "better that", right: "better than", why: "than." }
        ],
        vocab: [
          { en: "than", id: "daripada", ipa: "/ðæn/", ex: "bigger than" },
          { en: "better", id: "lebih baik", ipa: "/ˈbetər/", ex: "better than before" },
          { en: "worse", id: "lebih buruk", ipa: "/wɜːrs/", ex: "worse than yesterday" },
          { en: "the best", id: "yang terbaik", ipa: "/ðə best/", ex: "the best option" },
          { en: "expensive", id: "mahal", ipa: "/ɪkˈspensɪv/", ex: "more expensive" }
        ],
        dialogue: `A: Is the new phone better than your old one?\nB: Yes, it's faster and lighter. But it's more expensive.\nA: What's the best feature?\nB: The camera is the best part.`,
        summary: "-er/-est untuk pendek; more/most untuk panjang; better/worse irregular; than & the.",
        guided: [
          { q: "This bag is ___ than that bag. (cheap)", options: ["more cheap", "cheaper", "the cheapest", "cheapper"], correct: 1, explain: "cheaper." },
          { q: "She is ___ student in the team. (good)", options: ["better", "the best", "more good", "the goodest"], correct: 1, explain: "the best." },
          { q: "English is ___ than I thought. (interesting)", options: ["interestinger", "more interesting", "most interesting", "the more interesting"], correct: 1, explain: "more interesting." }
        ],
        independent: [
          { type: "write", q: "Bandingkan kota/kampus/mu dengan tempat lain (5 kalimat comparative + 2 superlative).", answer: "open", explain: "than / the." }
        ],
        practice: "Bandingkan 3 mata kuliah: mana lebih sulit, paling menarik, dll.",
        evaluation: [
          { q: "My brother is ___ than me.", options: ["more tall", "taller", "the tallest", "tallest"], correct: 1, explain: "taller than." },
          { q: "This is ___ café near campus.", options: ["the more popular", "the most popular", "most popular", "more popular"], correct: 1, explain: "the most popular." },
          { q: "His English is ___ than last year.", options: ["more good", "better", "best", "gooder"], correct: 1, explain: "better." },
          { q: "Avoid double comparative:", options: ["more easier", "easier", "more easy than more", "the more easiest"], correct: 1, explain: "easier saja." },
          { q: "A is as tall ___ B.", options: ["than", "as", "from", "that"], correct: 1, explain: "as…as." }
        ],
        remedial: "Tabel: adj → comparative → superlative untuk 15 kata (termasuk good/bad/far)."
      }
    },
    {
      id: "a2-u05",
      title: "Unit 5: Be Going To & Will (Future)",
      desc: "Rencana, niat, prediksi, keputusan spontan",
      tags: ["Grammar", "Speaking"],
      content: {
        objectives: [
          "Memakai be going to untuk rencana/niat/bukti",
          "Memakai will untuk keputusan spontan dan prediksi",
          "Membedakan kedua bentuk dalam konteks nyata"
        ],
        orientation: "A2 future: jangan hanya hafal will — pilih bentuk sesuai makna.",
        theory: `<p><strong>be going to</strong> + V1:</p>
<ul>
<li>Rencana/niat: I am going to study medicine.</li>
<li>Prediksi dengan bukti: Look at those clouds! It is going to rain.</li>
</ul>
<p><strong>will</strong> + V1:</p>
<ul>
<li>Keputusan spontan: The phone is ringing. I will answer it.</li>
<li>Prediksi/opini: I think she will pass.</li>
<li>Janji/tawaran: I will help you.</li>
</ul>
<p>Present continuous juga bisa untuk janji tetap: I am meeting the advisor at 10.</p>`,
        rules: [
          "going to + V1 (bukan going to going)",
          "will not = won't",
          "I will / I'll — kontraksi umum di spoken"
        ],
        examples: [
          { en: "I am going to apply for a scholarship next month.", id: "Saya berencana apply beasiswa bulan depan.", why: "rencana." },
          { en: "It is going to rain. (clouds)", id: "Akan hujan.", why: "bukti visual." },
          { en: "I'll get the door.", id: "Biar saya bukakan pintu.", why: "spontan." },
          { en: "I think you will enjoy this course.", id: "Menurut saya kamu akan menikmati kursus ini.", why: "prediksi opini." }
        ],
        compare: "going to = sudah ada niat/bukti; will = baru diputuskan / opini. Keduanya future — beda nuansa.",
        commonErrors: [
          { wrong: "I will going to study", right: "I am going to study / I will study", why: "jangan campur." },
          { wrong: "I going to buy", right: "I am going to buy", why: "perlu be." }
        ],
        vocab: [
          { en: "plan", id: "rencana", ipa: "/plæn/", ex: "My plan is clear." },
          { en: "probably", id: "kemungkinan besar", ipa: "/ˈprɒbəbli/", ex: "I will probably come." },
          { en: "promise", id: "janji", ipa: "/ˈprɒmɪs/", ex: "I promise I will call." },
          { en: "offer", id: "tawaran", ipa: "/ˈɒfər/", ex: "I'll offer my help." }
        ],
        dialogue: `A: Any plans for the weekend?\nB: I'm going to visit my cousin. What about you?\nA: I'm not sure. Maybe I'll just rest.\nB: Look at the sky — it's going to rain. Take an umbrella.`,
        summary: "going to = plan/evidence · will = spontaneous/prediction/promise.",
        guided: [
          { q: "I ___ visit my uncle this weekend. (sudah direncanakan)", options: ["will", "am going to", "go to", "going"], correct: 1, explain: "am going to." },
          { q: "Someone's at the door. I ___ open it.", options: ["am going to", "will", "going to", "opens"], correct: 1, explain: "spontan → will." },
          { q: "Look at the score! We ___.", options: ["will win", "are going to win", "win", "won"], correct: 1, explain: "bukti → going to." }
        ],
        independent: [
          { type: "write", q: "3 rencana (going to) + 2 keputusan spontan (will) + 1 prediksi.", answer: "open", explain: "Bedakan konteks." }
        ],
        practice: "Tanya teman: What are you going to do after graduation? Catat 5 jawaban.",
        evaluation: [
          { q: "She ___ start a new course in July. (rencana)", options: ["will", "is going to", "goes to", "going"], correct: 1, explain: "is going to." },
          { q: "The glass is on the edge! It ___.", options: ["will fall", "is going to fall", "falls", "fall"], correct: 1, explain: "bukti → going to." },
          { q: "I ___ help you with that bag.", options: ["am going to", "will", "going", "helps"], correct: 1, explain: "tawaran → will." },
          { q: "I think he ___ arrive late.", options: ["is going", "will", "going to", "goes"], correct: 1, explain: "opini → will." },
          { q: "We ___ not ___ to the party. (niat tidak datang)", options: ["will / going", "are / going to go", "are / go", "will / go to"], correct: 1, explain: "aren't going to go." }
        ],
        remedial: "Buat 10 situasi: tandai will atau going to + alasan singkat."
      }
    },
    {
      id: "a2-u06",
      title: "Unit 6: Modal Verbs — Can, Could, Should, Must",
      desc: "Kemampuan, izin, saran, kewajiban",
      tags: ["Grammar", "Speaking"],
      content: {
        objectives: [
          "Memakai can/can't untuk ability dan permission",
          "Memakai should untuk saran",
          "Memakai must/mustn't dan have to untuk kewajiban"
        ],
        orientation: "Modal membuat kalimat lebih natural: permintaan, saran, larangan.",
        theory: `<p><strong>can</strong> + V1: kemampuan / izin informal — I can swim. Can I sit here?</p>
<p><strong>could</strong>: lebih sopan / ability lampau — Could you help me? I could run fast when I was young.</p>
<p><strong>should</strong>: saran — You should sleep earlier.</p>
<p><strong>must</strong>: kewajiban kuat / kesimpulan — You must wear a helmet. You must be tired.</p>
<p><strong>mustn't</strong>: larangan — You mustn't smoke here.</p>
<p><strong>have to</strong>: kewajiban (sering dari aturan luar) — I have to submit the form today.</p>
<p>Modal + V1 polos: She can go (bukan can goes / can to go).</p>`,
        rules: [
          "modal + V1 tanpa to (kecuali have to / need to / ought to)",
          "Negatif: can't, shouldn't, mustn't",
          "Tanya: Can you…? Should I…?"
        ],
        examples: [
          { en: "I can speak three languages.", id: "Saya bisa tiga bahasa.", why: "ability." },
          { en: "You should review the notes.", id: "Kamu sebaiknya review catatan.", why: "saran." },
          { en: "Students must not cheat.", id: "Mahasiswa tidak boleh mencontek.", why: "larangan kuat." },
          { en: "I have to wake up at 5 on weekdays.", id: "Saya harus bangun jam 5.", why: "kewajiban rutin." }
        ],
        compare: "must (pembicara merasa wajib) vs have to (aturan/situasi). shouldn't (saran jangan) vs mustn't (dilarang).",
        commonErrors: [
          { wrong: "He can to swim", right: "He can swim", why: "tanpa to." },
          { wrong: "You should to go", right: "You should go", why: "tanpa to." },
          { wrong: "She musts study", right: "She must study", why: "modal tidak +s." }
        ],
        vocab: [
          { en: "ability", id: "kemampuan", ipa: "/əˈbɪləti/", ex: "language ability" },
          { en: "permission", id: "izin", ipa: "/pərˈmɪʃn/", ex: "ask for permission" },
          { en: "advice", id: "saran", ipa: "/ədˈvaɪs/", ex: "give advice" },
          { en: "obligation", id: "kewajiban", ipa: "/ˌɒblɪˈɡeɪʃn/", ex: "a strong obligation" }
        ],
        dialogue: `A: Can you help me with this form?\nB: Sure. You should fill section B carefully.\nA: Must I attach a photo?\nB: Yes, you have to. And you mustn't forget the signature.`,
        summary: "can ability/permission · should advice · must/have to obligation · mustn't prohibition · + V1.",
        guided: [
          { q: "You ___ eat more vegetables. (saran)", options: ["can", "should", "must to", "are"], correct: 1, explain: "should." },
          { q: "___ I open the window?", options: ["Should", "Must to", "Do", "Am"], correct: 0, explain: "Should I…?" },
          { q: "You ___ use your phone in the exam. (larangan)", options: ["shouldn't", "mustn't", "don't have", "can't to"], correct: 1, explain: "mustn't = dilarang." }
        ],
        independent: [
          { type: "write", q: "5 aturan kampus pakai must/mustn't/have to/should/can.", answer: "open", explain: "Modal + V1." }
        ],
        practice: "Roleplay: minta izin, beri saran belajar, sebut 2 kewajiban kuliah.",
        evaluation: [
          { q: "She ___ drive. She has a license.", options: ["can", "should to", "must to", "cans"], correct: 0, explain: "can." },
          { q: "You ___ see a doctor. (saran kuat)", options: ["can", "should", "are", "going"], correct: 1, explain: "should." },
          { q: "Students ___ upload the file today. (aturan)", options: ["can", "have to", "should to", "must to"], correct: 1, explain: "have to." },
          { q: "You ___ cheat. (larangan)", options: ["mustn't", "shouldn't to", "haven't to", "don't must"], correct: 0, explain: "mustn't." },
          { q: "___ you pass the salt?", options: ["Should", "Could", "Must", "Have"], correct: 1, explain: "Could you…? sopan." }
        ],
        remedial: "Tabel modal + contoh + fungsi. Latihan 10 transform affirmative→negative→question."
      }
    },
    {
      id: "a2-u07",
      title: "Unit 7: Present Perfect Intro (A2 bridge)",
      desc: "have/has + V3 untuk pengalaman dasar — ever/never",
      tags: ["Grammar"],
      content: {
        objectives: [
          "Membentuk have/has + past participle",
          "Memakai ever/never untuk pengalaman",
          "Mulai membedakan dari past simple (tanpa waktu spesifik)"
        ],
        orientation: "Pengantar B1. Di A2 cukup kuasai bentuk + ever/never + already/yet dasar.",
        theory: `<p><strong>Present perfect</strong> = have/has + V3 (past participle).</p>
<p>I <strong>have visited</strong> Bali. She <strong>has never tried</strong> sushi.</p>
<p><strong>ever</strong> di pertanyaan: Have you ever…? <strong>never</strong> di negatif pengalaman.</p>
<p><strong>already</strong> (sudah) · <strong>yet</strong> (belum, di tanya/negatif).</p>
<p>Jika ada waktu lampau spesifik (yesterday, in 2019) → biasanya <strong>past simple</strong>.</p>`,
        rules: [
          "have/has + V3 (gone, seen, done, written, eaten…)",
          "Have you ever been to…?",
          "I have already finished. / I haven't finished yet."
        ],
        examples: [
          { en: "I have never eaten raw fish.", id: "Saya belum pernah makan ikan mentah.", why: "never + perfect." },
          { en: "Have you ever been abroad?", id: "Pernahkah kamu ke luar negeri?", why: "ever di tanya." },
          { en: "She has already submitted the form.", id: "Dia sudah mengumpulkan formulir.", why: "already." },
          { en: "I went to Bali in 2022. (bukan have gone … in 2022)", id: "Waktu spesifik → past simple.", why: "in 2022." }
        ],
        compare: "Have you seen that film? (pengalaman) vs Did you see it yesterday? (waktu jelas).",
        commonErrors: [
          { wrong: "I have saw", right: "I have seen", why: "V3 = seen." },
          { wrong: "I have gone there yesterday", right: "I went there yesterday", why: "yesterday → past simple." }
        ],
        vocab: [
          { en: "ever", id: "pernah (tanya)", ipa: "/ˈevər/", ex: "Have you ever…?" },
          { en: "never", id: "tidak pernah", ipa: "/ˈnevər/", ex: "I have never…" },
          { en: "already", id: "sudah", ipa: "/ɔːlˈredi/", ex: "already done" },
          { en: "yet", id: "belum", ipa: "/jet/", ex: "not yet" }
        ],
        dialogue: `A: Have you ever tried online courses?\nB: Yes, I have. I took one last year.\nA: Have you finished this week's module yet?\nB: Not yet. I've already done the quiz, though.`,
        summary: "have/has + V3 · ever/never/already/yet · past simple jika waktu spesifik.",
        guided: [
          { q: "___ you ever ___ Japan?", options: ["Did / visit", "Have / visited", "Have / visit", "Do / visited"], correct: 1, explain: "Have you ever visited?" },
          { q: "She has ___ finished.", options: ["yet", "ago", "already", "yesterday"], correct: 2, explain: "already." }
        ],
        independent: [
          { type: "write", q: "5 kalimat: 3 never/ever experience + 2 already/yet tentang tugas kuliah.", answer: "open", explain: "V3 benar." }
        ],
        practice: "Interview: 5 pertanyaan Have you ever…? ke teman/diri sendiri.",
        evaluation: [
          { q: "I ___ this movie three times.", options: ["saw", "have seen", "see", "seeing"], correct: 1, explain: "have seen." },
          { q: "___ he finished ___?", options: ["Has / yet", "Did / yet", "Has / yesterday", "Does / already"], correct: 0, explain: "Has… yet?" },
          { q: "We ___ there in 2019.", options: ["have gone", "went", "have went", "go"], correct: 1, explain: "in 2019 → went." },
          { q: "Past participle of write:", options: ["wrote", "written", "writed", "writing"], correct: 1, explain: "written." },
          { q: "I have ___ tried skydiving.", options: ["ever", "never", "yet", "ago"], correct: 1, explain: "never." }
        ],
        remedial: "List V3: gone, seen, done, written, eaten, taken, been, had, bought, made. 1 kalimat perfect tiap kata."
      }
    },
    {
      id: "a2-u08",
      title: "Unit 8: A2 Checkpoint & Mini Project",
      desc: "Review A2 + proyek: cerita weekend + rencana",
      tags: ["Review", "Writing", "Speaking", "Evaluation"],
      content: {
        objectives: [
          "Menggabungkan continuous, past, quantity, comparative, future, modal, perfect intro",
          "Menyelesaikan mini project tertulis/lisan 8–10 kalimat",
          "Lulus evaluasi A2 (≥80%) untuk membuka B1"
        ],
        orientation: "Penutup A2. Tunjukkan kamu bisa ceritakan lalu, sekarang, dan rencana dengan grammar yang tepat.",
        theory: `<p><strong>Checklist A2:</strong> present continuous · past simple · quantity · comparative · going to/will · modals · present perfect intro.</p>
<p><strong>Mini project:</strong> Tulis atau rekam monolog: (1) apa yang kamu lakukan sekarang, (2) last weekend, (3) rencana bulan depan, (4) satu saran untuk teman belajar English.</p>`,
        rules: ["Campur tense dengan sadar — jangan semua present simple."],
        examples: [
          { en: "Right now I am reviewing A2 grammar. Last Saturday I visited a museum. I am going to take the B1 path next. You should practice a little every day.", id: "Model mini project.", why: "continuous + past + going to + should." }
        ],
        compare: "A2 = kalimat lebih bervariasi dari A1, masih konkret dan personal.",
        commonErrors: [
          { wrong: "Yesterday I am going to the mall", right: "Yesterday I went to the mall", why: "yesterday → past." }
        ],
        vocab: [
          { en: "review", id: "mengulas", ipa: "/rɪˈvjuː/", ex: "review the units" },
          { en: "project", id: "proyek", ipa: "/ˈprɒdʒekt/", ex: "mini project" },
          { en: "checkpoint", id: "titik periksa", ipa: "/ˈtʃekpɔɪnt/", ex: "A2 checkpoint" }
        ],
        dialogue: `A: How was your weekend?\nB: Great. I went hiking. What are you doing now?\nA: I'm finishing the A2 project. I'm going to start B1 next week.`,
        summary: "A2 siap jika past, now, future, modal, dan quantity dipakai akurat dalam teks pendek.",
        guided: [
          { q: "I ___ TV when you texted me yesterday evening. (preview continuous past — optional feel)", options: ["watch", "watched", "was watching", "am watching"], correct: 2, explain: "was watching (bridge ke B1)." }
        ],
        independent: [
          { type: "write", q: "MINI PROJECT: 8–10 kalimat (now + last weekend + plan + one should-advice).", answer: "open", explain: "Minimal 4 tense/modal berbeda." }
        ],
        practice: "Baca keras mini project 1 menit tanpa membaca teks penuh.",
        evaluation: [
          { q: "Look! Someone ___ at the door.", options: ["knock", "knocks", "is knocking", "knocked"], correct: 2, explain: "is knocking." },
          { q: "We ___ a movie last night.", options: ["see", "saw", "seen", "seeing"], correct: 1, explain: "saw." },
          { q: "There isn't ___ milk left.", options: ["many", "much", "few", "several"], correct: 1, explain: "much." },
          { q: "This phone is ___ than mine.", options: ["more cheap", "cheaper", "the cheapest", "cheap"], correct: 1, explain: "cheaper." },
          { q: "I ___ apply next month. (rencana)", options: ["will", "am going to", "go", "going"], correct: 1, explain: "am going to." },
          { q: "You ___ revise before the quiz. (saran)", options: ["can to", "should", "must to", "are"], correct: 1, explain: "should." },
          { q: "Have you ever ___ to Singapore?", options: ["go", "went", "been", "going"], correct: 2, explain: "been." },
          { q: "She ___ not ___ the email yet.", options: ["has / send", "has / sent", "have / sent", "did / sent"], correct: 1, explain: "has not sent / hasn't sent." }
        ],
        remedial: "Identifikasi unit A2 dengan skor terendah; ulangi evaluasi unit itu sebelum level exam."
      }
    }
  ],

  b1: [
    {
      id: "b1-u01",
      title: "Unit 1: Present Perfect — Experience & Result",
      desc: "have/has + V3, ever/never/already/yet/just/since/for",
      tags: ["Grammar", "Speaking"],
      content: {
        objectives: [
          "Memakai present perfect untuk pengalaman dan hasil yang relevan sekarang",
          "Memakai since/for dengan tepat",
          "Memilih present perfect vs past simple secara sadar"
        ],
        orientation: "B1: masa lalu yang masih 'terhubung' ke sekarang. Ini fondasi akademik & percakapan natural.",
        theory: `<p><strong>Bentuk:</strong> have/has + past participle (V3).</p>
<p><strong>Fungsi utama:</strong></p>
<ol>
<li>Pengalaman hidup (waktu tak spesifik): I have visited three countries.</li>
<li>Hasil sekarang: She has lost her keys (jadi sekarang tidak punya).</li>
<li>Dengan since/for: I have lived here since 2020 / for five years.</li>
</ol>
<p><strong>Signal:</strong> ever, never, already, yet, just, recently, so far, since, for.</p>
<p><strong>Past simple</strong> jika waktu selesai & disebut: I visited Japan in 2019.</p>
<p>been to vs gone to: She has gone to the lab (masih di sana). She has been to the lab (pernah, sudah kembali).</p>`,
        rules: [
          "since + titik waktu; for + durasi",
          "Jangan present perfect + yesterday/last year",
          "has untuk he/she/it; have untuk I/you/we/they"
        ],
        examples: [
          { en: "I have never tried rock climbing.", id: "Saya belum pernah panjat tebing.", why: "never + pengalaman." },
          { en: "She has just finished her thesis draft.", id: "Dia baru saja menyelesaikan draf tesis.", why: "just + result." },
          { en: "We have studied here for two years.", id: "Kami belajar di sini selama dua tahun.", why: "for + durasi." },
          { en: "I saw that film yesterday.", id: "Saya menonton film itu kemarin.", why: "yesterday → past simple." }
        ],
        compare: "Have you eaten? (masih relevan sekarang) vs Did you eat at 7? (waktu spesifik). since 2020 vs for 4 years.",
        commonErrors: [
          { wrong: "I have seen him yesterday", right: "I saw him yesterday", why: "yesterday memaksa past simple." },
          { wrong: "She has went", right: "She has gone", why: "V3 = gone." },
          { wrong: "I live here since 2020", right: "I have lived here since 2020", why: "since + perfect." }
        ],
        vocab: [
          { en: "recently", id: "baru-baru ini", ipa: "/ˈriːsntli/", ex: "I have recently changed majors." },
          { en: "so far", id: "sejauh ini", ipa: "/səʊ fɑːr/", ex: "So far, so good." },
          { en: "since", id: "sejak", ipa: "/sɪns/", ex: "since Monday" },
          { en: "for", id: "selama", ipa: "/fɔːr/", ex: "for a week" },
          { en: "just", id: "baru saja", ipa: "/dʒʌst/", ex: "has just arrived" }
        ],
        dialogue: `A: Have you ever worked part-time?\nB: Yes, I have. I worked at a café in 2023.\nA: Have you submitted the application yet?\nB: I've already uploaded the CV, but I haven't written the essay yet.`,
        summary: "have/has + V3 untuk experience/result/since-for; past simple untuk finished time.",
        guided: [
          { q: "She ___ in Medan ___ 2019.", options: ["lives / since", "has lived / since", "has lived / for", "lived / for"], correct: 1, explain: "has lived since 2019." },
          { q: "___ you ___ lunch yet?", options: ["Did / have", "Have / had", "Has / have", "Do / had"], correct: 1, explain: "Have you had…?" },
          { q: "I ___ this book last night.", options: ["have finished", "finished", "has finished", "finish"], correct: 1, explain: "last night → finished." }
        ],
        independent: [
          { type: "write", q: "Paragraf 8 kalimat: pengalaman kuliah (perfect) + 2 detail waktu spesifik (past simple).", answer: "open", explain: "Campur sadar." }
        ],
        practice: "Diskusi: 6 pertanyaan Have you ever…? dilanjutkan When…? (past simple).",
        evaluation: [
          { q: "I ___ this course three times.", options: ["took", "have taken", "take", "taking"], correct: 1, explain: "have taken (experience)." },
          { q: "He ___ to the library. He will be back soon.", options: ["has been", "has gone", "went", "goes"], correct: 1, explain: "has gone = masih di sana." },
          { q: "We ___ here ___ five years.", options: ["are / since", "have been / for", "have been / since", "were / for"], correct: 1, explain: "have been for five years." },
          { q: "___ she already ___ the email?", options: ["Has / sent", "Did / sent", "Has / send", "Have / sent"], correct: 0, explain: "Has she already sent…?" },
          { q: "They ___ the museum on Monday.", options: ["have visited", "visited", "visit", "are visiting"], correct: 1, explain: "on Monday → visited." }
        ],
        remedial: "Dua kolom: Perfect signals vs Past simple signals. 15 kalimat sorting + production."
      }
    },
    {
      id: "b1-u02",
      title: "Unit 2: Past Continuous & Interrupted Past",
      desc: "was/were + V-ing dan when/while",
      tags: ["Grammar", "Writing"],
      content: {
        objectives: [
          "Membentuk past continuous",
          "Menceritakan aksi yang sedang berlangsung saat diganggu aksi lain",
          "Memakai when dan while dengan tepat"
        ],
        orientation: "Narasi B1: bukan hanya daftar kejadian, tapi latar + gangguan.",
        theory: `<p><strong>Past continuous:</strong> was/were + V-ing.</p>
<p>I <strong>was studying</strong> when the power went out.</p>
<p><strong>when</strong> + past simple (aksi pendek); <strong>while</strong> + past continuous (latar panjang).</p>
<p>While I was walking home, it started to rain.</p>
<p>Dua continuous paralel: While I was cooking, he was setting the table.</p>`,
        rules: [
          "was (I/he/she/it) · were (you/we/they)",
          "when + shorter action (often past simple)",
          "while + longer background (continuous)"
        ],
        examples: [
          { en: "I was reading when she called.", id: "Saya sedang membaca saat dia menelepon.", why: "latar + gangguan." },
          { en: "While we were waiting, the bus arrived.", id: "Sementara kami menunggu, bus datang.", why: "while + continuous." },
          { en: "They were not listening to the lecture.", id: "Mereka tidak sedang mendengarkan kuliah.", why: "negatif continuous." }
        ],
        compare: "Past simple = urutan kejadian selesai. Past continuous = latar/proses di masa lalu.",
        commonErrors: [
          { wrong: "I was study", right: "I was studying", why: "V-ing." },
          { wrong: "When I was arrived…", right: "When I arrived…", why: "arrive singkat → past simple." }
        ],
        vocab: [
          { en: "while", id: "sementara/saat", ipa: "/waɪl/", ex: "while I was sleeping" },
          { en: "when", id: "ketika", ipa: "/wen/", ex: "when the phone rang" },
          { en: "suddenly", id: "tiba-tiba", ipa: "/ˈsʌdənli/", ex: "Suddenly the lights went out." }
        ],
        dialogue: `A: What were you doing at 8 last night?\nB: I was finishing my assignment when my laptop froze.\nA: Oh no. What did you do then?\nB: I restarted it and continued.`,
        summary: "was/were + V-ing untuk latar; when/while mengatur hubungan waktu.",
        guided: [
          { q: "She ___ TV when I ___ home.", options: ["watched / came", "was watching / came", "was watching / was coming", "watch / come"], correct: 1, explain: "latar continuous + came short." },
          { q: "___ we were studying, the fire alarm ___.", options: ["When / was ringing", "While / rang", "While / was ringing", "When / rings"], correct: 1, explain: "While + continuous, rang short." }
        ],
        independent: [
          { type: "write", q: "Cerita 6–8 kalimat: satu latar continuous + 2 gangguan past simple.", answer: "open", explain: "when/while." }
        ],
        practice: "Ceritakan kejadian lucu/kaget minggu lalu dengan past continuous.",
        evaluation: [
          { q: "I ___ dinner when you texted.", options: ["cooked", "was cooking", "am cooking", "cook"], correct: 1, explain: "was cooking." },
          { q: "While they ___, it ___ to rain.", options: ["walked / started", "were walking / started", "were walking / was starting", "walk / starts"], correct: 1, explain: "were walking / started." },
          { q: "What ___ you ___ at 9 p.m.?", options: ["did / do", "were / doing", "are / doing", "was / do"], correct: 1, explain: "were you doing?" },
          { q: "He ___ not ___ attention.", options: ["was / pay", "was / paying", "did / paying", "were / pay"], correct: 1, explain: "was not paying." },
          { q: "When the teacher ___, the students ___.", options: ["was entering / talked", "entered / were talking", "entered / talked", "was entering / were talking"], correct: 1, explain: "entered short; were talking background." }
        ],
        remedial: "10 pasangan when/while — lengkapi tense."
      }
    },
    {
      id: "b1-u03",
      title: "Unit 3: First Conditional & Future Time Clauses",
      desc: "If + present, will; when/as soon as/until",
      tags: ["Grammar", "Speaking"],
      content: {
        objectives: [
          "Membentuk first conditional untuk situasi realistis",
          "Memakai when/as soon as/until + present untuk future meaning",
          "Membedakan will vs going to dalam konteks syarat"
        ],
        orientation: "Syarat nyata di masa depan — rencana, peringatan, janji.",
        theory: `<p><strong>First conditional:</strong> If + present simple, will + V1.</p>
<p>If it rains, we will cancel the picnic.</p>
<p>If-clause bisa di belakang: We will cancel if it rains.</p>
<p><strong>Future time clauses:</strong> When I arrive, I will call you. (bukan when I will arrive)</p>
<p>as soon as, until, before, after + present untuk arti future.</p>`,
        rules: [
          "If + present (bukan if + will) di first conditional",
          "Koma jika if di depan",
          "when/as soon as + present, will di main clause"
        ],
        examples: [
          { en: "If I pass the test, I will apply for the exchange.", id: "Jika lulus, saya akan apply exchange.", why: "first conditional." },
          { en: "As soon as she finishes, she will email us.", id: "Segera setelah selesai, dia akan email.", why: "finishes = present form, future meaning." },
          { en: "I won't leave until you arrive.", id: "Saya tidak pergi sampai kamu datang.", why: "until + present." }
        ],
        compare: "First conditional = mungkin terjadi. Second conditional (nanti) = hipotetis sekarang.",
        commonErrors: [
          { wrong: "If it will rain…", right: "If it rains…", why: "if-clause present." },
          { wrong: "When I will see him…", right: "When I see him…", why: "time clause present." }
        ],
        vocab: [
          { en: "as soon as", id: "segera setelah", ipa: "/əz suːn əz/", ex: "as soon as possible" },
          { en: "unless", id: "kecuali jika", ipa: "/ənˈles/", ex: "unless you hurry" },
          { en: "in case", id: "jaga-jaga jika", ipa: "/ɪn keɪs/", ex: "in case it rains" }
        ],
        dialogue: `A: What will you do if you get the scholarship?\nB: I'll study abroad. As soon as I receive the result, I'll tell you.\nA: And if you don't get it?\nB: Then I'll apply again next year.`,
        summary: "If/when/as soon as + present, will + V1 di main clause.",
        guided: [
          { q: "If she ___, we ___ start without her.", options: ["will be late / will", "is late / will", "is late / are", "late / will"], correct: 1, explain: "is late / will start." },
          { q: "I ___ you when I ___.", options: ["will call / will arrive", "will call / arrive", "call / arrive", "call / will arrive"], correct: 1, explain: "will call / arrive." }
        ],
        independent: [
          { type: "write", q: "6 first conditionals tentang kuliah + 3 kalimat as soon as/until.", answer: "open", explain: "Cek if-clause." }
        ],
        practice: "Roleplay rencana weekend dengan 4 if-sentences.",
        evaluation: [
          { q: "If it ___ sunny, we ___ go out.", options: ["will be / will", "is / will", "is / are", "be / will"], correct: 1, explain: "is / will." },
          { q: "As soon as he ___, the meeting ___.", options: ["will arrive / starts", "arrives / will start", "arrives / starts", "will arrive / will start"], correct: 1, explain: "arrives / will start." },
          { q: "I won't buy it ___ it is on sale.", options: ["if", "unless", "when will", "as"], correct: 1, explain: "unless = if not." },
          { q: "If you ___ hard, you ___ pass.", options: ["will study / pass", "study / will pass", "studied / pass", "study / pass"], correct: 1, explain: "study / will pass." },
          { q: "When the semester ___, I ___ travel.", options: ["will end / will", "ends / will", "ends / am", "end / will"], correct: 1, explain: "ends / will travel." }
        ],
        remedial: "20 sentence completion if/when/as soon as."
      }
    },
    {
      id: "b1-u04",
      title: "Unit 4: Second Conditional (Hypothetical)",
      desc: "If + past, would — situasi tidak nyata sekarang",
      tags: ["Grammar", "Speaking"],
      content: {
        objectives: [
          "Membentuk second conditional",
          "Memakai were untuk semua subject di formal hypothetical",
          "Membedakan first vs second conditional"
        ],
        orientation: "Mimpi, saran hipotetis, situasitak nyata — penting untuk opini B1.",
        theory: `<p><strong>Second conditional:</strong> If + past simple, would + V1.</p>
<p>If I <strong>had</strong> more time, I <strong>would learn</strong> another language.</p>
<p>If I <strong>were</strong> you, I would talk to the lecturer. (were formal untuk semua subject)</p>
<p>First = mungkin. Second = imajinasi / kecil kemungkinannya sekarang.</p>`,
        rules: [
          "If + past, would + V1 (bukan would di if-clause)",
          "If I were you… (saran klasik)",
          "could/might di main clause untuk nuansa"
        ],
        examples: [
          { en: "If I won a scholarship, I would study in Japan.", id: "Jika saya menang beasiswa, saya akan kuliah di Jepang.", why: "hipotetis." },
          { en: "If she knew the answer, she would tell us.", id: "Jika dia tahu, dia akan memberi tahu.", why: "sekarang dia tidak tahu." },
          { en: "If I were richer, I would travel more.", id: "Jika saya lebih kaya…", why: "were + would." }
        ],
        compare: "If it rains, I will stay (mungkin hari ini). If it rained, I would stay (imajinasi).",
        commonErrors: [
          { wrong: "If I would be rich…", right: "If I were rich…", why: "would tidak di if-clause second." },
          { wrong: "If he was you… (informal ok, formal were)", right: "If he were you…", why: "traditional subjunctive." }
        ],
        vocab: [
          { en: "hypothetical", id: "hipotetis", ipa: "/ˌhaɪpəˈθetɪkl/", ex: "a hypothetical situation" },
          { en: "imagine", id: "membayangkan", ipa: "/ɪˈmædʒɪn/", ex: "Imagine if…" },
          { en: "would", id: "akan (hipotetis)", ipa: "/wʊd/", ex: "I would go" }
        ],
        dialogue: `A: What would you do if you had a free year?\nB: I would travel and volunteer. What about you?\nA: If I were free, I would take online courses abroad.`,
        summary: "If + past, would + V1 untuk tidak nyata sekarang.",
        guided: [
          { q: "If I ___ more money, I ___ buy a laptop.", options: ["have / will", "had / would", "had / will", "have / would"], correct: 1, explain: "had / would." },
          { q: "If I ___ you, I ___ email the professor.", options: ["am / will", "were / would", "was / will", "were / will"], correct: 1, explain: "were / would." }
        ],
        independent: [
          { type: "write", q: "8 second conditionals tentang karier, belajar, dan kota.", answer: "open", explain: "If + past, would." }
        ],
        practice: "Diskusi kelompok: If you could change one campus rule…",
        evaluation: [
          { q: "If he ___ harder, he ___ better grades.", options: ["studies / will get", "studied / would get", "studied / will get", "study / would get"], correct: 1, explain: "studied / would get." },
          { q: "If I ___ a bird, I ___ fly home.", options: ["am / will", "were / would", "was / will", "were / will"], correct: 1, explain: "were / would." },
          { q: "First conditional memakai…", options: ["past + would", "present + will", "past + will", "present + would"], correct: 1, explain: "present + will." },
          { q: "If she ___ the truth, she would be upset.", options: ["knows", "knew", "know", "knowing"], correct: 1, explain: "knew." },
          { q: "I ___ help if I ___.", options: ["will / can", "would / could", "would / can", "will / could"], correct: 1, explain: "would / could." }
        ],
        remedial: "Transform 10 first conditionals menjadi second (ubah makna jadi hipotetis)."
      }
    },
    {
      id: "b1-u05",
      title: "Unit 5: Passive Voice (Present & Past)",
      desc: "be + V3 — fokus ke proses dan objek",
      tags: ["Grammar", "Academic"],
      content: {
        objectives: [
          "Mengubah active → passive di present dan past",
          "Memilih passive saat pelaku tidak penting",
          "Menulis kalimat formal singkat dengan passive"
        ],
        orientation: "Academic B1: laporan, berita, prosedur sering passive.",
        theory: `<p><strong>Passive:</strong> object + be + V3 (+ by agent).</p>
<p>Present: The report <strong>is written</strong> every semester.</p>
<p>Past: The report <strong>was written</strong> last week.</p>
<p>Dipakai saat: pelaku tidak diketahui/tidak penting; ingin fokus hasil; gaya formal.</p>
<p>by + agent opsional: The window was broken (by the storm).</p>`,
        rules: [
          "be menyesuaikan tense; V3 tetap",
          "was/were written (bukan was wrote)",
          "Jangan hilangkan be"
        ],
        examples: [
          { en: "English is spoken in many countries.", id: "English dipakai di banyak negara.", why: "focus language." },
          { en: "The emails were sent yesterday.", id: "Email dikirim kemarin.", why: "past passive." },
          { en: "The lab was cleaned this morning.", id: "Lab dibersihkan pagi ini.", why: "agent tidak penting." }
        ],
        compare: "Active: Someone cleaned the lab. Passive: The lab was cleaned.",
        commonErrors: [
          { wrong: "The letter was wrote", right: "The letter was written", why: "V3." },
          { wrong: "The data analyzed", right: "The data were/was analyzed", why: "perlu be." }
        ],
        vocab: [
          { en: "process", id: "proses", ipa: "/ˈprəʊses/", ex: "the process is repeated" },
          { en: "publish", id: "menerbitkan", ipa: "/ˈpʌblɪʃ/", ex: "was published" },
          { en: "conduct", id: "melakukan (riset)", ipa: "/kənˈdʌkt/", ex: "was conducted" }
        ],
        dialogue: `A: Has the schedule been posted?\nB: Yes, it was posted this morning on the portal.\nA: Great. The rooms are cleaned every Friday.`,
        summary: "be + V3; tense pada be; agent opsional.",
        guided: [
          { q: "The email ___ sent yesterday.", options: ["is", "was", "were", "be"], correct: 1, explain: "was sent." },
          { q: "These books ___ in 2020.", options: ["publish", "were published", "was published", "published"], correct: 1, explain: "were published." }
        ],
        independent: [
          { type: "write", q: "Ubah 6 kalimat active menjadi passive (3 present, 3 past).", answer: "open", explain: "Cek be + V3." }
        ],
        practice: "Tulis 5 prosedur lab/perpustakaan dalam passive.",
        evaluation: [
          { q: "The results ___ published last year.", options: ["was", "were", "are", "been"], correct: 1, explain: "were published." },
          { q: "Coffee ___ in many countries.", options: ["grows", "is grown", "grew", "growing"], correct: 1, explain: "is grown." },
          { q: "The window ___ by the storm.", options: ["broke", "was broken", "was broke", "broken"], correct: 1, explain: "was broken." },
          { q: "V3 of take:", options: ["took", "taken", "taked", "taking"], correct: 1, explain: "taken." },
          { q: "A new rule ___ next month. (rencana formal)", options: ["will introduce", "will be introduced", "is introduce", "introduced"], correct: 1, explain: "will be introduced." }
        ],
        remedial: "Tabel active↔passive untuk 12 kalimat."
      }
    },
    {
      id: "b1-u06",
      title: "Unit 6: Relative Clauses (who/which/that)",
      desc: "Menggabungkan informasi dalam satu kalimat",
      tags: ["Grammar", "Writing"],
      content: {
        objectives: [
          "Memakai who/which/that untuk defining clauses",
          "Menggabungkan dua kalimat pendek jadi satu",
          "Menghindari sentence fragments"
        ],
        orientation: "Tulisan B1 lebih padat: satu kalimat membawa dua informasi terkait.",
        theory: `<p><strong>who</strong> → orang; <strong>which</strong> → benda; <strong>that</strong> → keduanya (defining).</p>
<p>The student <strong>who called you</strong> is my classmate.</p>
<p>The book <strong>that I bought</strong> is useful.</p>
<p>Defining clause = informasi penting (tanpa koma). Non-defining (dengan koma) = info tambahan (lebih B2).</p>`,
        rules: [
          "who/which/that menggantikan subject/object di clause kedua",
          "Defining: tanpa koma",
          "Jangan dobel object: The book that I bought it (salah)"
        ],
        examples: [
          { en: "Students who study daily improve faster.", id: "Siswa yang belajar tiap hari lebih cepat maju.", why: "who + defining." },
          { en: "This is the app that helps me practice.", id: "Ini app yang membantu saya latihan.", why: "that." },
          { en: "The laptop which I use is old.", id: "Laptop yang saya pakai sudah tua.", why: "which/that." }
        ],
        compare: "Dua kalimat vs satu relative clause — kohesi meningkat.",
        commonErrors: [
          { wrong: "The man which lives here…", right: "The man who lives here…", why: "who untuk orang." },
          { wrong: "The book that I bought it", right: "The book that I bought", why: "jangan it." }
        ],
        vocab: [
          { en: "clause", id: "klausa", ipa: "/klɔːz/", ex: "relative clause" },
          { en: "define", id: "mendefinisikan", ipa: "/dɪˈfaɪn/", ex: "defining clause" },
          { en: "combine", id: "menggabungkan", ipa: "/kəmˈbaɪn/", ex: "combine sentences" }
        ],
        dialogue: `A: Do you know the tutor who teaches listening?\nB: Yes. She's the one that helped me last semester.`,
        summary: "who people · which things · that both · no comma in defining clauses.",
        guided: [
          { q: "The woman ___ called is a doctor.", options: ["which", "who", "where", "what"], correct: 1, explain: "who." },
          { q: "The course ___ I chose is hard.", options: ["who", "which", "where", "whose"], correct: 1, explain: "which/that." }
        ],
        independent: [
          { type: "write", q: "Gabungkan 8 pasang kalimat dengan who/which/that.", answer: "open", explain: "Tanpa koma defining." }
        ],
        practice: "Deskripsikan 4 teman/benda di sekitarmu dengan relative clause.",
        evaluation: [
          { q: "People ___ live abroad face challenges.", options: ["which", "who", "where", "what"], correct: 1, explain: "who." },
          { q: "This is the video ___ explains passive voice.", options: ["who", "which", "where", "whose"], correct: 1, explain: "which/that." },
          { q: "Avoid:", options: ["the book that I read", "the book that I read it", "the book which I read", "the book I read"], correct: 1, explain: "jangan it." },
          { q: "whose menunjuk…", options: ["tempat", "kepemilikan", "waktu", "cara"], correct: 1, explain: "possession." },
          { q: "The students ___ answers were correct smiled.", options: ["who", "which", "whose", "that"], correct: 2, explain: "whose answers." }
        ],
        remedial: "15 sentence-combining drills."
      }
    },
    {
      id: "b1-u07",
      title: "Unit 7: Opinion Paragraphs & Linking",
      desc: "Menulis opini 100–140 kata dengan kohesi",
      tags: ["Writing", "Academic"],
      content: {
        objectives: [
          "Menulis paragraf opini dengan thesis, alasan, contoh",
          "Memakai linking: because, for example, however, therefore, in addition",
          "Menghindari pengulangan dan kalimat tidak lengkap"
        ],
        orientation: "B1 writing akademik dasar — sebelum essay penuh B2.",
        theory: `<p><strong>Struktur:</strong> Opinion → Reason 1 + example → Reason 2 → Closing.</p>
<p><strong>Linking:</strong> because, so, for example, however, therefore, in addition, on the other hand.</p>
<p>Target: 100–140 kata, grammar B1 (perfect, conditional, relative boleh muncul).</p>`,
        rules: [
          "Satu ide utama per paragraf",
          "Setiap alasan butuh support (example/explanation)",
          "Closing jangan ide baru total"
        ],
        examples: [
          { en: "I believe learning English is essential for university students because it opens internship opportunities. For example, many companies require intermediate English. In addition, academic articles are often in English. Therefore, daily practice is a smart investment.", id: "Model opini B1.", why: "claim + reasons + linkers." }
        ],
        compare: "Opini ≠ daftar bullet. Perlu development.",
        commonErrors: [
          { wrong: "Because good for job.", right: "It is useful because it improves job chances.", why: "butuh klausa lengkap." }
        ],
        vocab: [
          { en: "essential", id: "sangat penting", ipa: "/ɪˈsenʃl/", ex: "essential skill" },
          { en: "therefore", id: "oleh karena itu", ipa: "/ˈðeəfɔːr/", ex: "Therefore, we should…" },
          { en: "however", id: "namun", ipa: "/haʊˈevər/", ex: "However, costs are high." },
          { en: "in addition", id: "selain itu", ipa: "/ɪn əˈdɪʃn/", ex: "In addition, …" }
        ],
        dialogue: "",
        summary: "Opinion + because + example + therefore. Linkers untuk kohesi.",
        guided: [
          { q: "Linker untuk contoh:", options: ["however", "for example", "although", "despite"], correct: 1, explain: "for example." },
          { q: "Best thesis opener:", options: ["Maybe good", "I believe that…", "Yes", "Because"], correct: 1, explain: "I believe that…" }
        ],
        independent: [
          { type: "write", q: "Paragraf 120 kata: Should students work part-time? Gunakan minimal 3 linker.", answer: "open", explain: "Struktur opini." }
        ],
        practice: "Outline 3 topik: social media, online class, English for career.",
        evaluation: [
          { q: "therefore menandai…", options: ["contoh", "akibat/simpulan", "kontras saja", "salam"], correct: 1, explain: "simpulan." },
          { q: "however menandai…", options: ["contoh", "kontras", "sebab", "waktu"], correct: 1, explain: "kontras." },
          { q: "Opini B1 sebaiknya punya…", options: ["hanya 1 kata", "alasan + contoh", "hanya daftar vocab", "tanpa posisi"], correct: 1, explain: "alasan+contoh." },
          { q: "I ___ finished my draft, so I can rest.", options: ["have", "has", "had", "having"], correct: 0, explain: "have finished." },
          { q: "If we ___ now, we ___ the deadline.", options: ["start / will meet", "will start / meet", "started / meet", "start / meet"], correct: 0, explain: "first conditional." }
        ],
        remedial: "Template: I think… because…. For example…. In addition…. Therefore…."
      }
    },
    {
      id: "b1-u08",
      title: "Unit 8: B1 Checkpoint & Mini Project",
      desc: "Review B1 + proyek opini 120–150 kata",
      tags: ["Review", "Writing", "Evaluation"],
      content: {
        objectives: [
          "Mengintegrasikan perfect, continuous past, conditionals, passive, relative, opini",
          "Menyelesaikan proyek tulis opini terstruktur",
          "Lulus evaluasi B1 untuk membuka B2"
        ],
        orientation: "Penutup B1. Tunjukkan kontrol grammar B1 dalam teks yang kohesif.",
        theory: `<p><strong>Checklist B1:</strong> present perfect · past continuous · first/second conditional · passive · relative clauses · opinion paragraph.</p>
<p><strong>Mini project:</strong> Essay pendek 120–150 kata: topik pilihan (online learning / part-time jobs / English for careers) dengan minimal 1 perfect, 1 conditional, 1 relative clause.</p>`,
        rules: ["Jangan mengorbankan kejelasan demi grammar 'pamer'."],
        examples: [
          { en: "Students who have practiced daily often improve faster. If universities provided more conversation clubs, learners would gain confidence. English is used in many internships; therefore, it should be a priority.", id: "Cuplikan project-level.", why: "relative + perfect + second conditional + passive feel." }
        ],
        compare: "B1 = bisa argumen sederhana + grammar rentang menengah. B2 = kontrol lebih fleksibel dan formal.",
        commonErrors: [],
        vocab: [
          { en: "integrate", id: "mengintegrasikan", ipa: "/ˈɪntɪɡreɪt/", ex: "integrate skills" },
          { en: "cohesion", id: "kohesi", ipa: "/kəʊˈhiːʒn/", ex: "paragraph cohesion" }
        ],
        dialogue: "",
        summary: "B1 siap jika pengalaman, narasi, syarat, passive, relative, dan opini terhubung rapi.",
        guided: [
          { q: "Linker akibat:", options: ["for example", "however", "therefore", "who"], correct: 2, explain: "therefore." }
        ],
        independent: [
          { type: "write", q: "PROJECT: 130–150 kata opini + syarat grammar di atas.", answer: "open", explain: "Self-check list tense." }
        ],
        practice: "Baca project keras 90 detik; catat 3 self-corrections.",
        evaluation: [
          { q: "I ___ here since 2021.", options: ["live", "have lived", "lived", "am living"], correct: 1, explain: "have lived." },
          { q: "I ___ when the phone rang.", options: ["studied", "was studying", "study", "am studying"], correct: 1, explain: "was studying." },
          { q: "If it rains, we ___ stay in.", options: ["would", "will", "are", "can to"], correct: 1, explain: "will (first)." },
          { q: "If I ___ time, I would travel.", options: ["have", "had", "has", "having"], correct: 1, explain: "had (second)." },
          { q: "The rules ___ last year.", options: ["changed", "were changed", "was changed", "are change"], correct: 1, explain: "were changed." },
          { q: "Students ___ practice daily improve.", options: ["which", "who", "where", "whose"], correct: 1, explain: "who." },
          { q: "I believe that English is essential ___ it opens opportunities.", options: ["however", "because", "therefore", "who"], correct: 1, explain: "because." },
          { q: "She has already ___.", options: ["submit", "submitted", "submitting", "submits"], correct: 1, explain: "submitted." }
        ],
        remedial: "Ulangi unit B1 dengan skor terendah; tulis ulang project setelah review."
      }
    }
  ],

b2: [
    {
      id: "b2-u01",
      title: "Unit 1: Review of Conditionals (0–2) & Mixed Basics",
      desc: "Menguasai zero, first, second conditional dan perbedaan maknanya",
      tags: ["Grammar", "Conditionals"],
      content: {
        objectives: [
          "Membedakan zero, first, dan second conditional dengan tepat",
          "Memilih bentuk conditional sesuai makna (fakta, kemungkinan, hipotetis)",
          "Menghindari kesalahan umum if + will / if + would"
        ],
        orientation: "Di B1 kamu sudah bertemu first & second conditional. Di B2 kamu harus mengontrolnya dengan sadar — termasuk kapan memakai zero conditional untuk fakta ilmiah/kebiasaan.",
        theory: `<p><strong>Zero conditional</strong> dipakai untuk fakta umum atau kebiasaan: <em>If + present, present</em>. Contoh: If you heat water to 100°C, it boils.</p>
<p><strong>First conditional</strong> untuk kemungkinan nyata di masa depan: <em>If + present, will + V1</em>. Contoh: If it rains tomorrow, we will stay home.</p>
<p><strong>Second conditional</strong> untuk situasi tidak nyata / hipotetis sekarang: <em>If + past, would + V1</em>. Contoh: If I had more time, I would learn Japanese.</p>
<p>Ingat: setelah <em>if</em> pada first conditional, jangan pakai <em>will</em>. Setelah <em>if</em> pada second, jangan pakai <em>would</em>.</p>`,
        rules: [
          "Zero: If + present simple, present simple (fakta/kebiasaan)",
          "First: If + present simple, will + base verb (kemungkinan nyata)",
          "Second: If + past simple, would + base verb (hipotetis sekarang)",
          "Jangan: If it will rain... / If I would have..."
        ],
        examples: [
          { en: "If you mix blue and yellow, you get green.", id: "Jika kamu mencampur biru dan kuning, kamu mendapat hijau.", why: "Zero — fakta umum." },
          { en: "If she studies harder, she will pass the exam.", id: "Jika dia belajar lebih giat, dia akan lulus ujian.", why: "First — kemungkinan nyata." },
          { en: "If I were the president, I would invest more in education.", id: "Jika saya presiden, saya akan berinvestasi lebih banyak di pendidikan.", why: "Second — tidak nyata; were formal untuk semua subjek." },
          { en: "If the train is late, I will call you.", id: "Jika keretanya terlambat, saya akan meneleponmu.", why: "First — rencana bergantung kondisi." }
        ],
        compare: "First = mungkin terjadi. Second = dibayangkan / tidak mungkin atau sangat kecil kemungkinannya sekarang.",
        commonErrors: [
          { wrong: "If it will rain, we will cancel.", right: "If it rains, we will cancel.", why: "Jangan will setelah if di first conditional." },
          { wrong: "If I would be rich, I would travel.", right: "If I were rich, I would travel.", why: "Second memakai past di klausa if, bukan would." }
        ],
        vocab: [
          { en: "hypothetical", id: "hipotetis", ipa: "/ˌhaɪpəˈθetɪkl/", ex: "This is a hypothetical situation." },
          { en: "likelihood", id: "kemungkinan", ipa: "/ˈlaɪklihʊd/", ex: "There is a high likelihood of rain." },
          { en: "outcome", id: "hasil / akibat", ipa: "/ˈaʊtkʌm/", ex: "The outcome depends on your effort." },
          { en: "condition", id: "syarat", ipa: "/kənˈdɪʃn/", ex: "Under this condition, we can proceed." }
        ],
        dialogue: [
          { speaker: "A", en: "What would you do if you won a scholarship abroad?", id: "Apa yang akan kamu lakukan jika mendapat beasiswa luar negeri?" },
          { speaker: "B", en: "If I won one, I would accept it immediately and prepare my documents.", id: "Jika saya mendapatnya, saya akan langsung menerimanya dan menyiapkan dokumen." }
        ],
        summary: "Zero = fakta. First = mungkin. Second = bayangan. Kontrol bentuk di klausa if.",
        guided: [
          { q: "If water _____ 0°C, it freezes.", options: ["reaches", "will reach", "would reach", "reached"], correct: 0, explain: "Zero conditional: present + present." },
          { q: "If I _____ more free time, I would join the debate club.", options: ["have", "had", "will have", "would have"], correct: 1, explain: "Second: if + past." },
          { q: "If the teacher _____ early, we will start the quiz.", options: ["arrives", "will arrive", "arrived", "would arrive"], correct: 0, explain: "First: if + present, will..." }
        ],
        independent: [
          { q: "Rewrite: 'I don't have a car, so I don't drive to campus.' → Second conditional.", hint: "If I had..." }
        ],
        practice: "Tulis 4 kalimat: 1 zero, 1 first, 2 second tentang kehidupan kampusmu.",
        evaluation: [
          { q: "If you heat ice, it _____.", options: ["melts", "will melt", "would melt", "melted"], correct: 0, explain: "Zero conditional." },
          { q: "If it _____ tomorrow, the match will be postponed.", options: ["rains", "will rain", "rained", "would rain"], correct: 0, explain: "First conditional." },
          { q: "If I _____ you, I would accept the internship.", options: ["am", "was", "were", "be"], correct: 2, explain: "Second; were preferred." },
          { q: "Which is incorrect?", options: ["If she studies, she will pass.", "If she will study, she will pass.", "If she studied, she would pass.", "If you heat metal, it expands."], correct: 1, explain: "will tidak boleh setelah if di first." },
          { q: "Second conditional mainly expresses:", options: ["past facts", "scientific laws", "unreal present/future ideas", "completed actions"], correct: 2, explain: "Hipotetis." }
        ],
        remedial: "Buat tabel 3 kolom (zero/first/second) dan isi 3 contoh per kolom dari kehidupanmu."
      }
    },
    {
      id: "b2-u02",
      title: "Unit 2: Passive Voice for Formal & Academic Style",
      desc: "Passive di berbagai tense + kapan memakainya dalam tulisan formal",
      tags: ["Grammar", "Academic Writing"],
      content: {
        objectives: [
          "Membentuk passive di present, past, present perfect, dan future",
          "Memilih active vs passive sesuai fokus informasi",
          "Memakai passive untuk gaya akademik yang objektif"
        ],
        orientation: "Dalam teks akademik dan laporan, passive sering dipakai agar fokus pada proses/hasil, bukan pelaku. B2 menuntut kontrol ini, bukan hanya menghafal rumus be + V3.",
        theory: `<p><strong>Rumus dasar:</strong> Object + be (sesuai tense) + past participle (V3) (+ by agent, opsional).</p>
<p>Present: The report <em>is written</em> every semester.<br>
Past: The lab <em>was cleaned</em> yesterday.<br>
Present perfect: The results <em>have been published</em>.<br>
Future: The policy <em>will be announced</em> next week.<br>
Modal: The form <em>must be submitted</em> online.</p>
<p>Pakai passive jika pelaku tidak penting, tidak diketahui, atau ingin terdengar objektif. Pakai active jika pelaku penting.</p>`,
        rules: [
          "be harus sesuai tense; V3 tidak berubah",
          "by + agent hanya jika perlu",
          "Jangan overuse passive — tulisan jadi berat",
          "Dalam methods/results akademik, passive sangat umum"
        ],
        examples: [
          { en: "The data were collected from 200 students.", id: "Data dikumpulkan dari 200 mahasiswa.", why: "Fokus pada data, bukan peneliti." },
          { en: "A new library will be opened in July.", id: "Perpustakaan baru akan dibuka pada Juli.", why: "Future passive." },
          { en: "The assignment must be submitted before Friday.", id: "Tugas harus dikumpulkan sebelum Jumat.", why: "Modal + passive." },
          { en: "Several errors have been identified in the draft.", id: "Beberapa kesalahan telah diidentifikasi dalam draf.", why: "Present perfect passive." }
        ],
        compare: "Active: Researchers collected the data (pelaku jelas). Passive: The data were collected (proses/hasil yang ditonjolkan).",
        commonErrors: [
          { wrong: "The data was collected by we.", right: "The data were collected by us. / We collected the data.", why: "by + object pronoun; data often plural in academic English." },
          { wrong: "The essay has wrote by the student.", right: "The essay has been written by the student.", why: "Perfect passive: has/have been + V3." }
        ],
        vocab: [
          { en: "submit", id: "mengumpulkan / menyerahkan", ipa: "/səbˈmɪt/", ex: "Submit the form online." },
          { en: "publish", id: "menerbitkan", ipa: "/ˈpʌblɪʃ/", ex: "The paper was published last year." },
          { en: "conduct", id: "melakukan (penelitian)", ipa: "/kənˈdʌkt/", ex: "The study was conducted in 2024." },
          { en: "objective", id: "objektif / tidak subjektif", ipa: "/əbˈdʒektɪv/", ex: "Academic tone should be objective." }
        ],
        dialogue: [
          { speaker: "A", en: "Why is this paragraph mostly passive?", id: "Mengapa paragraf ini banyak passive?" },
          { speaker: "B", en: "Because the writer wants to sound objective and focus on the process.", id: "Karena penulis ingin terdengar objektif dan fokus pada proses." }
        ],
        summary: "Passive = be + V3. Pakai untuk fokus hasil/proses dan gaya formal; jangan berlebihan.",
        guided: [
          { q: "The results _____ last Monday.", options: ["published", "were published", "was publish", "have publish"], correct: 1, explain: "Past passive." },
          { q: "The form _____ before the deadline.", options: ["must submit", "must be submit", "must be submitted", "must submitted"], correct: 2, explain: "Modal passive." },
          { q: "Best academic version:", options: ["I collected the samples carefully.", "The samples were collected carefully.", "Someone collected the samples carefully.", "Collecting the samples carefully happened."], correct: 1, explain: "Passive fokus pada samples." }
        ],
        independent: [
          { q: "Ubah ke passive: 'The committee will announce the winners tomorrow.'" }
        ],
        practice: "Tulis 5 kalimat passive tentang prosedur lab atau tugas kampus (campur tense).",
        evaluation: [
          { q: "Choose the correct passive: 'They have finished the report.'", options: ["The report has finished.", "The report has been finished.", "The report was been finished.", "The report have been finished."], correct: 1, explain: "has been + V3." },
          { q: "When is passive preferred in academic writing?", options: ["When the actor is the main focus", "When the process/result is the main focus", "Always", "Never"], correct: 1, explain: "Fokus proses/hasil." },
          { q: "The policy _____ next month.", options: ["will announce", "will be announced", "will be announce", "is announce"], correct: 1, explain: "Future passive." },
          { q: "Incorrect form:", options: ["was written", "has been written", "must be written", "has wrote"], correct: 3, explain: "has wrote salah." },
          { q: "Agent 'by...' is:", options: ["always required", "optional and used when needed", "never used", "only for present tense"], correct: 1, explain: "Opsional." }
        ],
        remedial: "Ambil 5 kalimat active dari artikel berita, ubah ke passive, lalu putuskan mana yang lebih natural."
      }
    },
    {
      id: "b2-u03",
      title: "Unit 3: Relative Clauses — Defining & Non-defining",
      desc: "who/which/that/whose + koma; menggabungkan ide dengan presisi",
      tags: ["Grammar", "Cohesion"],
      content: {
        objectives: [
          "Membedakan defining vs non-defining relative clauses",
          "Memakai who, which, that, whose dengan tepat",
          "Menghindari koma yang salah pada defining clauses"
        ],
        orientation: "Relative clause membuat tulisan B2 lebih padat dan dewasa. Salah koma atau salah relative pronoun bisa mengubah makna.",
        theory: `<p><strong>Defining</strong> (tanpa koma) = informasi penting untuk mengidentifikasi noun.<br>
The students <em>who submitted early</em> received feedback first.</p>
<p><strong>Non-defining</strong> (dengan koma) = informasi tambahan; noun sudah jelas.<br>
My advisor, <em>who studied in Australia</em>, recommended this journal.</p>
<p><strong>that</em> biasanya hanya untuk defining. <em>which</em> bisa keduanya (non-defining sering which). <em>whose</em> untuk possession.</p>`,
        rules: [
          "Defining: no commas; that/who/which ok",
          "Non-defining: commas required; avoid that",
          "whose = possession for people and things",
          "Jangan buang koma pada non-defining"
        ],
        examples: [
          { en: "The book that I borrowed is overdue.", id: "Buku yang saya pinjam sudah lewat tempo.", why: "Defining — identifying which book." },
          { en: "Bandung, which is known for its cool weather, attracts many students.", id: "Bandung, yang dikenal cuacanya sejuk, menarik banyak mahasiswa.", why: "Non-defining — extra info." },
          { en: "The researcher whose paper won the award will speak tomorrow.", id: "Peneliti yang makalahnya menang akan berbicara besok.", why: "whose = possession." },
          { en: "Students who practice daily improve faster.", id: "Mahasiswa yang berlatih setiap hari meningkat lebih cepat.", why: "Defining." }
        ],
        compare: "Defining membatasi makna noun. Non-defining menambah informasi tanpa membatasi identitas noun.",
        commonErrors: [
          { wrong: "My father that lives in Medan is a teacher.", right: "My father, who lives in Medan, is a teacher.", why: "Non-defining (hanya satu ayah) → koma + who, bukan that." },
          { wrong: "The app, that crashes often, needs an update.", right: "The app that crashes often needs an update. OR The app, which crashes often, needs an update.", why: "Defining: no comma + that/which. Non-defining: comma + which." }
        ],
        vocab: [
          { en: "clause", id: "klausa", ipa: "/klɔːz/", ex: "A relative clause adds information." },
          { en: "define", id: "mendefinisikan / membatasi", ipa: "/dɪˈfaɪn/", ex: "The clause defines which students." },
          { en: "additional", id: "tambahan", ipa: "/əˈdɪʃənl/", ex: "This is additional information." },
          { en: "precise", id: "presisi / tepat", ipa: "/prɪˈsaɪs/", ex: "Be precise with commas." }
        ],
        dialogue: [
          { speaker: "A", en: "Should I put commas before who here?", id: "Apakah saya perlu koma sebelum who di sini?" },
          { speaker: "B", en: "Only if the clause is extra information, not essential.", id: "Hanya jika klausanya info tambahan, bukan inti." }
        ],
        summary: "Defining = penting, tanpa koma. Non-defining = tambahan, pakai koma. that jarang di non-defining.",
        guided: [
          { q: "The laptop _____ I bought last year is still fast.", options: ["who", "which/that", "whose", "where"], correct: 1, explain: "Thing → which/that." },
          { q: "Dr. Sari, _____ teaches linguistics, published a new book.", options: ["that", "who", "which", "whose"], correct: 1, explain: "Non-defining person → who + commas." },
          { q: "Defining relative clauses usually:", options: ["need commas", "do not need commas", "only use whose", "cannot use that"], correct: 1, explain: "Tanpa koma." }
        ],
        independent: [
          { q: "Gabungkan: 'I met a student. Her research is about climate policy.' pakai whose." }
        ],
        practice: "Tulis 3 defining dan 3 non-defining relative clauses tentang kampusmu.",
        evaluation: [
          { q: "Correct non-defining sentence:", options: ["Jakarta that is crowded is my hometown.", "Jakarta, which is crowded, is my hometown.", "Jakarta, that is crowded, is my hometown.", "Jakarta which is crowded is my hometown."], correct: 1, explain: "Non-defining: comma + which." },
          { q: "The teacher _____ class I attend is strict.", options: ["who", "which", "whose", "that"], correct: 2, explain: "whose class." },
          { q: "that is mainly used in:", options: ["non-defining clauses", "defining clauses", "only questions", "only past tense"], correct: 1, explain: "Defining." },
          { q: "Which needs commas?", options: ["Students who arrive late wait outside", "My roommate who is from Bali cooks well", "My roommate, who is from Bali, cooks well", "Apps that save time are popular"], correct: 2, explain: "Non-defining about a specific roommate." },
          { q: "Relative clauses help mainly with:", options: ["pronunciation", "cohesion and precision", "spelling only", "listening speed"], correct: 1, explain: "Kohesi & presisi." }
        ],
        remedial: "Ambil 5 kalimat dari esaimu, gabungkan pakai relative clauses, lalu tandai defining vs non-defining."
      }
    },
    {
      id: "b2-u04",
      title: "Unit 4: Reported Speech (Statements, Questions, Commands)",
      desc: "Mengubah direct speech ke reported speech dengan backshift yang tepat",
      tags: ["Grammar", "Communication"],
      content: {
        objectives: [
          "Melakukan tense backshift dengan benar",
          "Melaporkan pernyataan, pertanyaan, dan perintah",
          "Menyesuaikan pronoun, time, dan place expressions"
        ],
        orientation: "Reported speech penting untuk ringkasan diskusi, wawancara, dan penulisan akademik. B2 menuntut backshift yang konsisten, bukan hanya 'kata dia bahwa...'.",
        theory: `<p>Jika reporting verb past (said, told, asked), tense biasanya mundur satu langkah:<br>
Present → Past; Present perfect / Past → Past perfect; will → would; can → could.</p>
<p>Pernyataan: He said (that) he was tired.<br>
Pertanyaan yes/no: She asked if/whether I had finished.<br>
Pertanyaan Wh-: He asked where I lived.<br>
Perintah: She told me to submit the form. / He asked me not to be late.</p>
<p>Sesuaikan juga pronoun dan penanda waktu: today→that day, tomorrow→the next day, here→there.</p>`,
        rules: [
          "said vs told: told butuh objek (told me)",
          "Questions: if/whether atau word order pernyataan (bukan do/does)",
          "Commands: tell/ask + object + to-infinitive",
          "No backshift jika reporting verb present atau fakta masih benar (kadang opsional)"
        ],
        examples: [
          { en: "Direct: 'I am preparing the slides.' → She said she was preparing the slides.", id: "Dia bilang dia sedang menyiapkan slide.", why: "Present continuous → past continuous." },
          { en: "Direct: 'Have you read the article?' → He asked if I had read the article.", id: "Dia bertanya apakah saya sudah membaca artikel itu.", why: "Present perfect → past perfect; if untuk yes/no." },
          { en: "Direct: 'Submit the draft tomorrow.' → The lecturer told us to submit the draft the next day.", id: "Dosen menyuruh kami mengumpulkan draf keesokan harinya.", why: "Command + time change." },
          { en: "Direct: 'Where do you study?' → She asked where I studied.", id: "Dia bertanya di mana saya kuliah.", why: "Wh-question; word order pernyataan." }
        ],
        compare: "Direct speech mengutip kata asli. Reported speech merangkum dengan penyesuaian tense/pronoun/waktu.",
        commonErrors: [
          { wrong: "He asked where do I live.", right: "He asked where I lived.", why: "Bukan word order pertanyaan." },
          { wrong: "She told that she was busy.", right: "She said that she was busy. / She told me that she was busy.", why: "told butuh objek." }
        ],
        vocab: [
          { en: "report", id: "melaporkan", ipa: "/rɪˈpɔːt/", ex: "Report what the speaker said." },
          { en: "claim", id: "mengklaim", ipa: "/kleɪm/", ex: "He claimed that the data were accurate." },
          { en: "admit", id: "mengakui", ipa: "/ədˈmɪt/", ex: "She admitted that she was wrong." },
          { en: "inquire", id: "menanyakan (formal)", ipa: "/ɪnˈkwaɪə/", ex: "He inquired whether seats were available." }
        ],
        dialogue: [
          { speaker: "A", en: "What did the coordinator say about the deadline?", id: "Apa kata koordinator tentang tenggat?" },
          { speaker: "B", en: "She told us to submit everything by Friday.", id: "Dia menyuruh kami mengumpulkan semuanya sebelum Jumat." }
        ],
        summary: "Backshift tense, rapikan pronoun/waktu, dan bedakan statement/question/command.",
        guided: [
          { q: "Direct: 'I can help.' → He said he _____ help.", options: ["can", "could", "will", "may"], correct: 1, explain: "can → could." },
          { q: "Direct: 'Are you ready?' → She asked _____ I was ready.", options: ["that", "if", "what", "to"], correct: 1, explain: "Yes/no → if/whether." },
          { q: "Direct: 'Don't open the file.' → He told me _____ the file.", options: ["to not open", "not to open", "don't open", "not opening"], correct: 1, explain: "Negative command: not to + V1." }
        ],
        independent: [
          { q: "Ubah ke reported speech: 'I will send the notes tomorrow,' said Raka." }
        ],
        practice: "Rekam 5 kalimat teman (direct), lalu tulis reported version-nya.",
        evaluation: [
          { q: "'I have finished.' → She said she _____ finished.", options: ["has", "had", "have", "was"], correct: 1, explain: "Present perfect → past perfect." },
          { q: "Correct reported question:", options: ["He asked where did I go.", "He asked where I had gone.", "He asked where had I gone.", "He asked where I did go."], correct: 1, explain: "Pernyataan order + backshift." },
          { q: "She _____ me to wait outside.", options: ["said", "told", "asked that", "told that"], correct: 1, explain: "told + object + to." },
          { q: "today in reported speech often becomes:", options: ["today", "that day", "this day", "the today"], correct: 1, explain: "Time shift." },
          { q: "No backshift is sometimes possible when:", options: ["the reporting verb is past", "the situation is still true / reporting verb is present", "always", "never"], correct: 1, explain: "Fakta masih berlaku / reporting present." }
        ],
        remedial: "Buat 8 pasangan direct → reported (2 statement, 3 question, 3 command)."
      }
    },
    {
      id: "b2-u05",
      title: "Unit 5: Modals in the Past (must/can't/should/could have)",
      desc: "Spekulasi dan penilaian terhadap kejadian lampau",
      tags: ["Grammar", "Nuance"],
      content: {
        objectives: [
          "Memakai must have / can't have untuk spekulasi lampau",
          "Memakai should have / could have untuk kritik dan kemungkinan yang tidak diambil",
          "Membedakan makna deduksi vs regret/advice after the fact"
        ],
        orientation: "B2 bukan hanya 'harus/boleh' di masa kini. Kamu perlu menilai masa lalu: kemungkinan, kepastian, penyesalan, dan peluang yang terlewat.",
        theory: `<p><strong>must have + V3</strong> = hampir pasti terjadi di masa lalu.<br>
She isn't here. She must have left early.</p>
<p><strong>can't/couldn't have + V3</strong> = hampir mustahil terjadi.<br>
He can't have forgotten — he confirmed yesterday.</p>
<p><strong>should have + V3</strong> = seharusnya terjadi tapi tidak (kritik/penyesalan).<br>
You should have revised the abstract.</p>
<p><strong>could have + V3</strong> = ada kemungkinan/peluang tapi tidak terjadi.<br>
We could have finished earlier if we had planned better.</p>`,
        rules: [
          "must have ≠ obligation di masa lalu (itu had to)",
          "should have sering berisi penilaian negatif terhadap pilihan lampau",
          "could have = peluang yang ada tetapi tidak diambil",
          "Form: modal + have + past participle"
        ],
        examples: [
          { en: "The lights are off. They must have gone home.", id: "Lampunya mati. Mereka pasti sudah pulang.", why: "Deduksi kuat." },
          { en: "She can't have cheated; the camera was on.", id: "Dia tidak mungkin menyontek; kameranya menyala.", why: "Hampir mustahil." },
          { en: "You should have backed up your files.", id: "Seharusnya kamu mem-backup file-mu.", why: "Kritik/penyesalan." },
          { en: "I could have joined the exchange program, but I missed the deadline.", id: "Saya sebenarnya bisa ikut program pertukaran, tapi kelewatan tenggat.", why: "Peluang terlewat." }
        ],
        compare: "must have = deduksi. should have = penilaian 'seharusnya'. could have = peluang yang tidak diambil.",
        commonErrors: [
          { wrong: "You must have to submit it yesterday.", right: "You had to submit it yesterday. / You must have submitted it yesterday.", why: "Obligation lampau = had to; deduksi = must have + V3." },
          { wrong: "He should had studied more.", right: "He should have studied more.", why: "should have + V3, bukan had." }
        ],
        vocab: [
          { en: "deduction", id: "kesimpulan logis", ipa: "/dɪˈdʌkʃn/", ex: "This is a logical deduction." },
          { en: "regret", id: "penyesalan", ipa: "/rɪˈɡret/", ex: "She expressed regret." },
          { en: "missed opportunity", id: "kesempatan terlewat", ipa: "/mɪst ɒpəˈtjuːnəti/", ex: "It was a missed opportunity." },
          { en: "speculate", id: "berspekulasi", ipa: "/ˈspekjuleɪt/", ex: "We can only speculate about the cause." }
        ],
        dialogue: [
          { speaker: "A", en: "The lab is empty. What happened?", id: "Lab-nya kosong. Ada apa?" },
          { speaker: "B", en: "They must have finished early. Or they could have moved to another room.", id: "Mereka pasti sudah selesai lebih awal. Atau mungkin pindah ke ruangan lain." }
        ],
        summary: "Modal + have + V3 untuk menilai masa lalu: kepastian, ketidakmungkinan, penyesalan, peluang terlewat.",
        guided: [
          { q: "His bag is gone. He _____ left.", options: ["must have", "must has", "should", "can"], correct: 0, explain: "Deduksi." },
          { q: "You _____ told me earlier.", options: ["should have", "must have", "can have", "will have"], correct: 0, explain: "Penyesalan/kritik." },
          { q: "She _____ forgotten; she confirmed twice.", options: ["must have", "can't have", "should have", "will have"], correct: 1, explain: "Hampir mustahil." }
        ],
        independent: [
          { q: "Buat 1 kalimat must have, 1 can't have, 1 should have tentang kejadian di kelas kemarin." }
        ],
        practice: "Tulis paragraf singkat (80–100 kata) berspekulasi mengapa seorang teman absen, memakai minimal 3 modal perfect.",
        evaluation: [
          { q: "must have + V3 expresses:", options: ["future plans", "strong past deduction", "permission", "habit"], correct: 1, explain: "Deduksi kuat masa lalu." },
          { q: "You _____ checked the rubric before writing.", options: ["should have", "must have to", "can have", "will have"], correct: 0, explain: "Seharusnya." },
          { q: "He _____ the message; his phone was offline.", options: ["must have received", "can't have received", "should receive", "could receives"], correct: 1, explain: "Mustahil menerima." },
          { q: "Incorrect form:", options: ["could have gone", "should have gone", "must have gone", "should had gone"], correct: 3, explain: "should had salah." },
          { q: "could have often implies:", options: ["certainty", "a possible action that did not happen", "obligation now", "permission now"], correct: 1, explain: "Peluang yang tidak diambil." }
        ],
        remedial: "Ubah 5 penyesalan pribadi menjadi kalimat should have / could have."
      }
    },
    {
      id: "b2-u06",
      title: "Unit 6: Wish & If Only for Regret and Preference",
      desc: "wish/if only untuk penyesalan masa lalu dan keinginan sekarang",
      tags: ["Grammar", "Expression"],
      content: {
        objectives: [
          "Memakai wish + past untuk keinginan sekarang yang tidak nyata",
          "Memakai wish + past perfect untuk penyesalan masa lalu",
          "Membedakan wish dari hope"
        ],
        orientation: "Wish dan if only memberi nuansa emosional yang penting di B2: penyesalan, keinginan, dan ketidakpuasan terhadap realitas.",
        theory: `<p><strong>Keinginan sekarang (unreal present):</strong> wish / if only + past simple.<br>
I wish I knew the answer. (sekarang saya tidak tahu)<br>
If only this campus were closer to the station.</p>
<p><strong>Penyesalan masa lalu:</strong> wish / if only + past perfect.<br>
I wish I had applied earlier.<br>
If only we had checked the requirements.</p>
<p><strong>Keluhan tentang kebiasaan orang lain:</strong> wish + would.<br>
I wish you would stop interrupting.</p>
<p><strong>hope</strong> dipakai untuk hal yang masih mungkin: I hope you pass. (bukan I wish you pass)</p>`,
        rules: [
          "wish + past = sekarang tidak nyata",
          "wish + past perfect = penyesalan lampau",
          "wish + would = keinginan perubahan perilaku (sering keluhan)",
          "Jangan campur dengan hope untuk situasi unreal"
        ],
        examples: [
          { en: "I wish I had more confidence in presentations.", id: "Andai saya punya lebih banyak percaya diri saat presentasi.", why: "Unreal present." },
          { en: "If only I had saved the document.", id: "Andai saja saya menyimpan dokumen itu.", why: "Regret about the past." },
          { en: "I wish the professor would upload the slides earlier.", id: "Andai dosen mengunggah slide lebih awal.", why: "wish + would untuk perubahan." },
          { en: "I hope the results are released soon.", id: "Saya berharap hasilnya segera diumumkan.", why: "Hope — masih mungkin." }
        ],
        compare: "wish = tidak nyata / penyesalan. hope = harapan yang masih terbuka.",
        commonErrors: [
          { wrong: "I wish I will get the scholarship.", right: "I hope I get the scholarship. / I wish I could get the scholarship.", why: "Harapan mungkin → hope; unreal → wish + past/modal past." },
          { wrong: "I wish I studied harder yesterday.", right: "I wish I had studied harder yesterday.", why: "Past regret → past perfect." }
        ],
        vocab: [
          { en: "regret", id: "menyesali", ipa: "/rɪˈɡret/", ex: "I regret not practicing more." },
          { en: "preference", id: "preferensi", ipa: "/ˈprefərəns/", ex: "This expresses a preference for a different reality." },
          { en: "unreal", id: "tidak nyata", ipa: "/ʌnˈrɪəl/", ex: "It describes an unreal situation." },
          { en: "complaint", id: "keluhan", ipa: "/kəmˈpleɪnt/", ex: "wish + would often softens a complaint." }
        ],
        dialogue: [
          { speaker: "A", en: "I wish I had joined the English club last semester.", id: "Andai saya ikut klub English semester lalu." },
          { speaker: "B", en: "If only we both had. We could have practiced together.", id: "Andai kita berdua ikut. Kita bisa berlatih bersama." }
        ],
        summary: "wish/if only + past (sekarang), + past perfect (lampau), + would (perubahan perilaku). Hope untuk yang masih mungkin.",
        guided: [
          { q: "I wish I _____ bilingual.", options: ["am", "was/were", "will be", "have been"], correct: 1, explain: "Unreal present." },
          { q: "If only I _____ the email earlier.", options: ["sent", "had sent", "have sent", "send"], correct: 1, explain: "Past regret." },
          { q: "I _____ you feel better soon.", options: ["wish", "hope", "wish that will", "if only"], correct: 1, explain: "Masih mungkin → hope." }
        ],
        independent: [
          { q: "Tulis 2 wish tentang sekarang dan 2 if only tentang masa lalu terkait studi." }
        ],
        practice: "Tulis jurnal singkat 100 kata memakai minimal 4 struktur wish/if only.",
        evaluation: [
          { q: "I wish I _____ more time yesterday.", options: ["have", "had", "had had", "will have"], correct: 2, explain: "Past perfect untuk penyesalan lampau." },
          { q: "I wish you _____ making noise.", options: ["stop", "would stop", "stopped to", "have stopped"], correct: 1, explain: "wish + would." },
          { q: "Correct pair:", options: ["wish = possible hope", "hope = unreal regret", "wish + past perfect = past regret", "if only cannot be used for present"], correct: 2, explain: "Past regret." },
          { q: "I hope she _____ the test.", options: ["passes", "passed unreal", "would passed", "had pass"], correct: 0, explain: "Hope + present untuk masa depan dekat." },
          { q: "If only the internet _____ more stable.", options: ["is", "were", "will be", "has been"], correct: 1, explain: "Unreal present." }
        ],
        remedial: "Ubah 5 kalimat 'saya menyesal...' menjadi wish/if only yang akurat."
      }
    },
    {
      id: "b2-u07",
      title: "Unit 7: Argument Essay Structure & Cohesion",
      desc: "Kerangka esai argumen 150–220 kata + linking devices B2",
      tags: ["Writing", "Academic"],
      content: {
        objectives: [
          "Menyusun esai argumen dengan thesis, reasons, examples, conclusion",
          "Memakai linking devices untuk kohesi antar kalimat dan paragraf",
          "Menulis 150–220 kata dengan posisi yang jelas"
        ],
        orientation: "B2 writing menuntut argumen terstruktur, bukan hanya opini satu paragraf. Kamu belajar membangun posisi, mendukungnya, dan menutup dengan rapi.",
        theory: `<p><strong>Struktur dasar:</strong></p>
<p>1) Introduction — topik + thesis (posisimu)<br>
2) Body 1 — alasan utama + contoh<br>
3) Body 2 — alasan kedua / counterpoint singkat + respons<br>
4) Conclusion — ringkas posisi + implikasi</p>
<p><strong>Linking devices berguna:</strong> furthermore, in addition, however, on the other hand, therefore, as a result, for instance, in conclusion.</p>
<p>Hindari mengulang kata yang sama terus; jaga satu ide utama per paragraf.</p>`,
        rules: [
          "Thesis harus jelas di awal",
          "Setiap body paragraph punya satu fokus",
          "Contoh harus relevan, bukan cerita panjang tanpa poin",
          "Conclusion jangan menambah ide baru besar"
        ],
        examples: [
          { en: "Thesis: Universities should provide more practical English courses because students need workplace communication skills.", id: "Contoh thesis jelas.", why: "Posisi + alasan utama." },
          { en: "Furthermore, internships often require confident speaking in meetings.", id: "Contoh linking + support.", why: "Furthermore menambah alasan." },
          { en: "However, some argue that general English is enough; nevertheless, job interviews demand more specific skills.", id: "Counter + response.", why: "Nuansa B2." },
          { en: "In conclusion, practical courses better prepare graduates for real communication demands.", id: "Penutup ringkas.", why: "Restate tanpa ide baru." }
        ],
        compare: "Paragraf opini B1 = satu blok sederhana. Esai B2 = multi-paragraf dengan thesis, support, dan kohesi eksplisit.",
        commonErrors: [
          { wrong: "In conclusion, and also another point is...", right: "In conclusion, the main argument is...", why: "Conclusion bukan tempat menambah argumen baru panjang." },
          { wrong: "I think... I think... I think...", right: "Gunakan variasi: In my view / This suggests / It is clear that...", why: "Kohesi & style." }
        ],
        vocab: [
          { en: "thesis", id: "tesis / pernyataan posisi", ipa: "/ˈθiːsɪs/", ex: "State your thesis clearly." },
          { en: "cohesion", id: "kohesi", ipa: "/kəʊˈhiːʒn/", ex: "Cohesion links ideas smoothly." },
          { en: "counterargument", id: "sanggahan / argumen lawan", ipa: "/ˈkaʊntərɑːɡjumənt/", ex: "Address one counterargument." },
          { en: "implication", id: "implikasi", ipa: "/ˌɪmplɪˈkeɪʃn/", ex: "Explain the implication briefly." }
        ],
        dialogue: [
          { speaker: "A", en: "Does my essay need a counterargument?", id: "Apakah esai saya perlu counterargument?" },
          { speaker: "B", en: "At B2, a short counterpoint plus your response makes it stronger.", id: "Di B2, counterpoint singkat plus responsmu membuatnya lebih kuat." }
        ],
        summary: "Thesis jelas → alasan + contoh → (opsional) counter → kesimpulan. Linking devices menjaga alur.",
        guided: [
          { q: "A strong thesis should:", options: ["only ask a question", "state a clear position", "list many topics", "avoid opinion"], correct: 1, explain: "Posisi jelas." },
          { q: "Best linker to add support:", options: ["however", "furthermore", "in contrast", "on the other hand"], correct: 1, explain: "Furthermore menambah." },
          { q: "Conclusion should mainly:", options: ["introduce a new reason", "restate and close", "tell a long story", "ask the reader random questions"], correct: 1, explain: "Restate & close." }
        ],
        independent: [
          { q: "Buat outline 4 bagian untuk topik: 'Should group projects be graded individually as well?'" }
        ],
        practice: "Tulis esai 160–200 kata: 'Online learning should remain part of university education.' Sertakan minimal 5 linker.",
        evaluation: [
          { q: "Main purpose of a thesis statement:", options: ["to conclude", "to state the writer's position", "to give an example only", "to define a word"], correct: 1, explain: "Posisi penulis." },
          { q: "However is typically used to:", options: ["add similar support", "show contrast", "give an example", "sequence events"], correct: 1, explain: "Kontras." },
          { q: "A body paragraph at B2 should focus on:", options: ["many unrelated ideas", "one main reason with support", "only definitions", "jokes"], correct: 1, explain: "Satu fokus." },
          { q: "Counterargument is useful because it:", options: ["confuses the reader", "shows awareness of other views", "replaces the thesis", "removes examples"], correct: 1, explain: "Kesadaran sudut pandang lain." },
          { q: "Best final sentence type:", options: ["brand-new argument", "clear closure linked to thesis", "unrelated quote", "list of vocabulary"], correct: 1, explain: "Closure." }
        ],
        remedial: "Tulis ulang satu esai lama: tandai thesis, linker, dan satu counterpoint."
      }
    },
    {
      id: "b2-u08",
      title: "Unit 8: B2 Checkpoint — Integrated Review & Mini Essay",
      desc: "Review grammar B2 + esai argumen singkat sebagai evaluasi level",
      tags: ["Evaluation", "Writing", "Grammar"],
      content: {
        objectives: [
          "Menunjukkan kontrol conditionals, passive, relative clauses, reported speech, dan modal perfect",
          "Menulis mini argument essay 160–200 kata",
          "Mencapai ambang kelulusan untuk membuka level C1"
        ],
        orientation: "Unit penutup B2. Kamu menggabungkan grammar dan writing. Lulus evaluasi ini menandai kesiapan menuju C1.",
        theory: `<p><strong>Checklist B2:</strong></p>
<ul>
<li>Conditionals (0–2 + mixed awareness)</li>
<li>Passive untuk gaya formal</li>
<li>Defining & non-defining relative clauses</li>
<li>Reported speech dengan backshift</li>
<li>Modal perfect (must/should/could have)</li>
<li>Wish / if only</li>
<li>Argument essay structure + cohesion</li>
</ul>
<p>Evaluasi menguji pemahaman pilihan bentuk, bukan hafalan istilah saja.</p>`,
        rules: [
          "Baca soal evaluasi dengan teliti",
          "Pada writing, pastikan thesis dan linker terlihat",
          "Grammar accuracy lebih penting daripada kosakata langka"
        ],
        examples: [
          { en: "If the policy had been explained earlier, fewer students would have missed the deadline.", id: "Contoh mixed feel / advanced conditional awareness.", why: "Hubungan masa lalu–sekarang." },
          { en: "The guidelines, which were updated last week, must be followed by all applicants.", id: "Non-defining + passive + modal.", why: "Integrasi struktur B2." },
          { en: "I wish I had practiced reported speech more before the quiz.", id: "Wish + past perfect.", why: "Regret." },
          { en: "In conclusion, structured practice leads to more reliable B2 performance.", id: "Penutup esai.", why: "Closure." }
        ],
        compare: "B1 = kontrol menengah terpisah. B2 = menggabungkan struktur dalam teks yang kohesif dan lebih formal.",
        commonErrors: [
          { wrong: "Menulis esai tanpa thesis.", right: "Nyatakan posisi di introduction.", why: "Tanpa thesis argumen kabur." },
          { wrong: "Mencampur defining/non-defining commas.", right: "Defining tanpa koma; non-defining dengan koma.", why: "Kesalahan B2 klasik." }
        ],
        vocab: [
          { en: "integrated", id: "terpadu", ipa: "/ˈɪntɪɡreɪtɪd/", ex: "This is an integrated review." },
          { en: "threshold", id: "ambang batas", ipa: "/ˈθreʃhəʊld/", ex: "Reach the pass threshold." },
          { en: "consistent", id: "konsisten", ipa: "/kənˈsɪstənt/", ex: "Keep tense consistent." },
          { en: "reliable", id: "dapat diandalkan", ipa: "/rɪˈlaɪəbl/", ex: "Aim for reliable accuracy." }
        ],
        dialogue: [
          { speaker: "A", en: "Am I ready for C1?", id: "Apakah saya siap ke C1?" },
          { speaker: "B", en: "If you can argue clearly and control these B2 structures, yes — with continued practice.", id: "Jika kamu bisa berargumen jelas dan mengontrol struktur B2 ini, ya — dengan latihan lanjutan." }
        ],
        summary: "B2 siap jika grammar rentang menengah-atas terkontrol dan esai argumen terstruktur.",
        guided: [
          { q: "Which best shows B2 control?", options: ["only present simple sentences", "a paragraph using relative clauses and clear linkers", "random advanced words without grammar", "only memorized dialogues"], correct: 1, explain: "Kontrol struktur + kohesi." },
          { q: "You should have checked the rubric. This expresses:", options: ["future plan", "past regret/criticism", "permission", "zero conditional"], correct: 1, explain: "should have." },
          { q: "Non-defining relative clauses need:", options: ["no commas", "commas", "only that", "question marks"], correct: 1, explain: "Pakai koma." }
        ],
        independent: [
          { q: "Tulis thesis + 2 supporting points untuk: 'University students should learn presentation skills.'" }
        ],
        practice: "Kerjakan mini essay 160–200 kata, lalu self-check: thesis, 5 linker, 2 struktur B2 (mis. passive/relative).",
        evaluation: [
          { q: "If the instructions _____ clearer, fewer students would have made mistakes.", options: ["are", "were", "had been", "will be"], correct: 2, explain: "Past condition affecting past result (advanced awareness)." },
          { q: "The proposal _____ by the committee yesterday.", options: ["reviewed", "was reviewed", "has review", "was review"], correct: 1, explain: "Past passive." },
          { q: "My supervisor, _____ advice I follow, suggested this journal.", options: ["who", "whose", "which", "that"], correct: 1, explain: "whose advice." },
          { q: "She asked _____ the deadline had been extended.", options: ["that", "if", "what", "to"], correct: 1, explain: "Reported yes/no question." },
          { q: "I wish I _____ the optional workshop last week.", options: ["attend", "attended", "had attended", "would attend"], correct: 2, explain: "Past regret." },
          { q: "Best thesis:", options: ["Presentation skills?", "Presentation skills are useful and universities should train students in them.", "I like presentations.", "Many people talk."], correct: 1, explain: "Posisi jelas." },
          { q: "Furthermore is used to:", options: ["contrast", "add support", "conclude only", "ask a question"], correct: 1, explain: "Menambah support." },
          { q: "B2 writing should prioritize:", options: ["rare vocabulary only", "clear structure and controlled grammar", "as many idioms as possible", "no examples"], correct: 1, explain: "Struktur + kontrol grammar." }
        ],
        remedial: "Review unit dengan skor terendah; tulis ulang mini essay setelah memperbaiki thesis dan linker."
      }
    }
  ],
  c1: [
    {
      id: "c1-u01",
      title: "Unit 1: Nominalization & Academic Concision",
      desc: "Mengubah verb/adjective menjadi noun phrase untuk gaya akademik padat",
      tags: ["Academic Writing", "Style"],
      content: {
        objectives: [
          "Mengubah klausa menjadi nominalization yang natural",
          "Menulis kalimat akademik yang lebih padat tanpa kehilangan makna",
          "Menghindari nominalization berlebihan yang membuat teks kaku"
        ],
        orientation: "C1 academic writing sering menonjolkan proses dan konsep, bukan pelaku. Nominalization adalah alat utama untuk itu.",
        theory: `<p><strong>Nominalization</strong> = mengubah kata kerja/sifat menjadi bentuk nomina.</p>
<p>Contoh:<br>
We analyzed the data → <em>The analysis of the data</em><br>
The policy failed → <em>The failure of the policy</em><br>
Students improved rapidly → <em>Students' rapid improvement</em></p>
<p>Manfaat: teks lebih padat, objektif, dan cocok laporan/esai akademik. Risiko: terlalu banyak nominalization membuat tulisan berat dan abstrak. Seimbangkan dengan kalimat aktif yang jelas.</p>`,
        rules: [
          "Pilih nominalization untuk konsep/proses penting",
          "Pertahankan kejelasan subjek jika pelaku relevan",
          "Hindari string nomina yang terlalu panjang",
          "Kombinasikan dengan passive dan linking yang tepat"
        ],
        examples: [
          { en: "The implementation of the new curriculum led to measurable gains.", id: "Penerapan kurikulum baru menghasilkan peningkatan terukur.", why: "Fokus pada proses implementation." },
          { en: "Their refusal to revise the draft delayed publication.", id: "Penolakan mereka merevisi draf menunda publikasi.", why: "refusal nominalizes the act." },
          { en: "A careful evaluation of the sources is essential.", id: "Evaluasi sumber yang cermat sangat penting.", why: "evaluation sebagai head noun." },
          { en: "Rapid urbanization has intensified housing pressure.", id: "Urbanisasi cepat memperparah tekanan perumahan.", why: "Concise academic style." }
        ],
        compare: "Spoken/informal: People moved to cities quickly and housing became scarce. Academic: Rapid urbanization intensified housing scarcity.",
        commonErrors: [
          { wrong: "The doing of the research was careful.", right: "The research was conducted carefully. / Careful research design was evident.", why: "Nominalization harus natural, bukan literal." },
          { wrong: "The improvement of the improving students...", right: "The improvement of the students...", why: "Hindari dobel yang membingungkan." }
        ],
        vocab: [
          { en: "implementation", id: "penerapan", ipa: "/ˌɪmplɪmenˈteɪʃn/", ex: "Implementation takes time." },
          { en: "assessment", id: "penilaian", ipa: "/əˈsesmənt/", ex: "Continuous assessment is useful." },
          { en: "assumption", id: "asumsi", ipa: "/əˈsʌmpʃn/", ex: "Challenge that assumption." },
          { en: "constraint", id: "kendala / batasan", ipa: "/kənˈstreɪnt/", ex: "Budget constraints limited the study." }
        ],
        dialogue: [
          { speaker: "A", en: "Why does this paragraph sound more academic?", id: "Mengapa paragraf ini terdengar lebih akademik?" },
          { speaker: "B", en: "Because processes are nominalized and the focus is on results, not personal actions.", id: "Karena proses dinominalisasi dan fokusnya pada hasil, bukan aksi personal." }
        ],
        summary: "Nominalization memadatkan ide akademik. Pakai strategis, bukan berlebihan.",
        guided: [
          { q: "Best nominalization of 'They decided to expand the program':", options: ["They did a decide", "Their decision to expand the program", "Deciding them expand", "The program expand decision"], correct: 1, explain: "decision to expand..." },
          { q: "Academic concision prioritizes:", options: ["longer stories", "dense precise phrasing", "slang", "repetition"], correct: 1, explain: "Padat & presisi." },
          { q: "Overusing nominalization can make writing:", options: ["always better", "heavy and unclear", "more spoken", "funnier"], correct: 1, explain: "Bisa berat." }
        ],
        independent: [
          { q: "Ubah 4 kalimat personal tentang studi menjadi versi nominalized akademik." }
        ],
        practice: "Tulis 120 kata tentang 'digital distraction' dengan minimal 6 nominalizations yang natural.",
        evaluation: [
          { q: "Nominalization mainly helps writing become:", options: ["more emotional", "more concise and academic", "more informal", "shorter only by deleting verbs randomly"], correct: 1, explain: "Padat & akademik." },
          { q: "Choose the best academic version:", options: ["We looked at the data and saw a rise.", "An examination of the data revealed an increase.", "Data look rise.", "We seeing increase data."], correct: 1, explain: "examination/revealed." },
          { q: "Which is unnatural?", options: ["the failure of the plan", "the happening of the event occurrence", "the expansion of the campus", "the assessment of learning"], correct: 1, explain: "Terlalu literal/awkward." },
          { q: "A key risk of heavy nominalization:", options: ["too much clarity", "opacity and stiffness", "perfect spoken style", "no vocabulary growth"], correct: 1, explain: "Bisa kaku." },
          { q: "Best practice:", options: ["nominalize everything", "balance nominal style with clarity", "never nominalize", "only use adjectives"], correct: 1, explain: "Seimbang." }
        ],
        remedial: "Ambil 1 paragraf esai lama; buat versi lebih padat dengan 5 nominalization, lalu bandingkan keterbacaan."
      }
    },
    {
      id: "c1-u02",
      title: "Unit 2: Advanced Clause Control — Participle, Cleft, Inversion",
      desc: "Participle clauses, cleft sentences, dan inversion untuk penekanan & kepaduan",
      tags: ["Grammar", "Advanced Style"],
      content: {
        objectives: [
          "Memakai participle clauses untuk menghubungkan ide dengan efisien",
          "Memakai cleft sentences untuk menekankan informasi",
          "Mengenali inversion setelah negative adverbials"
        ],
        orientation: "Di C1, kontrol klausa menentukan apakah tulisan terasa sophisticated atau sekadar benar secara grammar.",
        theory: `<p><strong>Participle clauses:</strong> Having reviewed the literature, the team refined the question.<br>
Concerned about validity, the authors added a second measure.</p>
<p><strong>Cleft sentences:</strong> It was the methodology that raised concerns.<br>
What students need most is sustained feedback.</p>
<p><strong>Inversion:</strong> Rarely have results been so consistent.<br>
Not only did the intervention improve scores, but it also increased motivation.</p>
<p>Pakai struktur ini untuk penekanan dan variasi, bukan untuk memamerkan kerumitan.</p>`,
        rules: [
          "Participle clause harus berhubungan jelas dengan subjek utama",
          "Cleft dipakai saat penekanan benar-benar dibutuhkan",
          "Inversion formal; cocok writing/presentation, jarang chat santai",
          "Jangan menumpuk ketiga struktur dalam satu kalimat"
        ],
        examples: [
          { en: "Having completed the pilot study, we adjusted the instrument.", id: "Setelah menyelesaikan studi pilot, kami menyesuaikan instrumen.", why: "Participle clause untuk urutan." },
          { en: "It is feedback quality that predicts progress most strongly.", id: "Kualitas feedback-lah yang paling kuat memprediksi progres.", why: "Cleft menekankan feedback quality." },
          { en: "What matters is not speed alone but accuracy under pressure.", id: "Yang penting bukan hanya kecepatan, melainkan akurasi di bawah tekanan.", why: "Wh-cleft." },
          { en: "Only after the revision did the argument become coherent.", id: "Hanya setelah revisi argumen menjadi koheren.", why: "Inversion after only after..." }
        ],
        compare: "Basic: We finished the pilot and then adjusted the instrument. Advanced: Having finished the pilot, we adjusted the instrument.",
        commonErrors: [
          { wrong: "Walking to campus, the rain started.", right: "Walking to campus, I got caught in the rain. / As I was walking...", why: "Dangling participle — subjek harus cocok." },
          { wrong: "Rarely the results are consistent.", right: "Rarely are the results consistent.", why: "Inversion: auxiliary before subject." }
        ],
        vocab: [
          { en: "emphasis", id: "penekanan", ipa: "/ˈemfəsɪs/", ex: "This structure adds emphasis." },
          { en: "coherence", id: "koherensi", ipa: "/kəʊˈhɪərəns/", ex: "The paragraph lacks coherence." },
          { en: "refinement", id: "penyempurnaan", ipa: "/rɪˈfaɪnmənt/", ex: "After refinement, the model improved." },
          { en: "intervention", id: "intervensi", ipa: "/ˌɪntəˈvenʃn/", ex: "The intervention was effective." }
        ],
        dialogue: [
          { speaker: "A", en: "Does inversion sound natural in an essay?", id: "Apakah inversion terdengar natural di esai?" },
          { speaker: "B", en: "In formal academic writing, yes — if used sparingly for emphasis.", id: "Di tulisan akademik formal, ya — jika dipakai hemat untuk penekanan." }
        ],
        summary: "Participle, cleft, dan inversion adalah alat penekanan & efisiensi. Pakai tepat sasaran.",
        guided: [
          { q: "Having _____ the data, the researchers revised the claim.", options: ["analyze", "analyzed", "analyzing", "analysis"], correct: 1, explain: "Having + V3." },
          { q: "It was the sample size _____ limited generalization.", options: ["what", "that", "who", "whose"], correct: 1, explain: "Cleft: it was X that..." },
          { q: "Not only _____ the scores rise, but engagement improved.", options: ["did", "does", "were", "had"], correct: 0, explain: "Not only + auxiliary + subject." }
        ],
        independent: [
          { q: "Tulis 2 participle clauses, 2 cleft, 1 inversion tentang pengalaman kuliah." }
        ],
        practice: "Revisi 1 paragraf esaimu: sisipkan 1 participle clause, 1 cleft, dan 1 inversion yang natural.",
        evaluation: [
          { q: "Dangling participle problem means:", options: ["the participle has no clear subject match", "too many adjectives", "missing articles only", "wrong spelling"], correct: 0, explain: "Subjek tidak cocok." },
          { q: "What students need is practice. This is a:", options: ["zero conditional", "wh-cleft", "passive", "relative only"], correct: 1, explain: "Wh-cleft." },
          { q: "Rarely _____ such clear patterns emerged.", options: ["have", "has", "did have always", "having"], correct: 0, explain: "Inversion with rarely." },
          { q: "Participle clauses mainly improve:", options: ["pronunciation", "sentence efficiency and flow", "handwriting", "listening only"], correct: 1, explain: "Efisiensi & alur." },
          { q: "Best advice:", options: ["use inversion in every sentence", "use advanced structures purposefully", "avoid all complex clauses", "replace all verbs with nouns"], correct: 1, explain: "Purposeful use." }
        ],
        remedial: "Cari 5 kalimat di artikel akademik yang memakai participle/cleft/inversion; tiru polanya dengan topikmu."
      }
    },
    {
      id: "c1-u03",
      title: "Unit 3: Hedging, Stance & Academic Caution",
      desc: "Menulis klaim hati-hati dengan may, might, suggest, appear, relatively",
      tags: ["Academic Writing", "Pragmatics"],
      content: {
        objectives: [
          "Memakai hedging untuk klaim yang proporsional",
          "Menunjukkan stance tanpa overclaim",
          "Membedakan strong claim vs cautious academic claim"
        ],
        orientation: "Penulis C1 tidak hanya 'benar', tetapi bertanggung jawab secara epistemik: tahu kapan harus berhati-hati.",
        theory: `<p><strong>Hedging</strong> mengurangi absolutisme klaim.</p>
<p>Contoh alat:<br>
modals: may, might, could<br>
verbs: suggest, indicate, appear, seem, tend to<br>
adverbs: relatively, largely, potentially, arguably<br>
phrases: it is possible that, to some extent, the data appear to</p>
<p>Strong: This proves that X causes Y.<br>
Hedged: The findings suggest that X may contribute to Y.</p>`,
        rules: [
          "Sesuaikan kekuatan klaim dengan kekuatan bukti",
          "Jangan hedge segalanya sampai argumen lemah",
          "Kombinasikan hedge dengan data/contoh konkret",
          "Hindari 'always/never/proves' tanpa dasar kuat"
        ],
        examples: [
          { en: "The results appear to support the initial hypothesis.", id: "Hasilnya tampak mendukung hipotesis awal.", why: "appear to = cautious." },
          { en: "This may indicate a relationship rather than direct causation.", id: "Ini mungkin menunjukkan hubungan, bukan penyebab langsung.", why: "may + rather than." },
          { en: "Students tend to perform better with spaced practice.", id: "Mahasiswa cenderung lebih baik dengan latihan berjarak.", why: "tend to menghindari absolut." },
          { en: "Arguably, feedback timing is as important as feedback quantity.", id: "Bisa dibilang, waktu feedback sama pentingnya dengan jumlahnya.", why: "Arguably marks stance." }
        ],
        compare: "Overclaim: X proves Y in all cases. C1: The evidence suggests X may influence Y under certain conditions.",
        commonErrors: [
          { wrong: "This proves students always improve.", right: "This suggests many students may improve under similar conditions.", why: "Terlalu absolut." },
          { wrong: "It might possibly perhaps seem maybe true.", right: "It may be true. / The data suggest it is true.", why: "Jangan menumpuk hedge." }
        ],
        vocab: [
          { en: "hedge", id: "melemahkan klaim secara hati-hati", ipa: "/hedʒ/", ex: "Academic writers often hedge claims." },
          { en: "stance", id: "posisi/sikap penulis", ipa: "/stæns/", ex: "Your stance should be clear but fair." },
          { en: "tentative", id: "sementara / tidak absolut", ipa: "/ˈtentətɪv/", ex: "a tentative conclusion" },
          { en: "causation", id: "hubungan sebab-akibat", ipa: "/kɔːˈzeɪʃn/", ex: "Correlation is not causation." }
        ],
        dialogue: [
          { speaker: "A", en: "Can I write 'this proves' in my paper?", id: "Bisakah saya menulis 'this proves' di makalah?" },
          { speaker: "B", en: "Only with very strong evidence. Otherwise use suggest or indicate.", id: "Hanya jika buktinya sangat kuat. Kalau tidak, pakai suggest atau indicate." }
        ],
        summary: "Hedging menyesuaikan klaim dengan bukti. Stance tetap jelas, tetapi tidak berlebihan.",
        guided: [
          { q: "Best hedged version:", options: ["This proves the method works for everyone.", "The findings suggest the method may work in similar contexts.", "This always works.", "Nothing works."], correct: 1, explain: "suggest + may." },
          { q: "tend to expresses:", options: ["absolute certainty", "general tendency", "prohibition", "past perfect"], correct: 1, explain: "Kecenderungan." },
          { q: "Over-hedging makes claims:", options: ["stronger", "weaker and vague", "funnier", "more informal only"], correct: 1, explain: "Bisa kabur." }
        ],
        independent: [
          { q: "Ubah 5 klaim absolut menjadi versi hedged yang masih bermakna." }
        ],
        practice: "Tulis 150 kata tentang efek media sosial pada fokus belajar; minimal 8 hedging devices.",
        evaluation: [
          { q: "Hedging is used to:", options: ["hide all opinions", "match claim strength to evidence", "avoid vocabulary", "remove examples"], correct: 1, explain: "Proporsi klaim-bukti." },
          { q: "Strongest claim marker:", options: ["may", "might", "proves", "appears to"], correct: 2, explain: "proves sangat kuat." },
          { q: "Best academic alternative to 'proves':", options: ["suggests", "screams", "guesses randomly", "denies"], correct: 0, explain: "suggests." },
          { q: "Arguably signals:", options: ["pure fact with no debate", "a defensible but contestable stance", "a joke", "a command"], correct: 1, explain: "Stance yang bisa diperdebatkan." },
          { q: "Good principle:", options: ["never take a position", "take a position with appropriate caution", "always use always/never", "avoid data"], correct: 1, explain: "Posisi + kehati-hatian." }
        ],
        remedial: "Highlight semua always/never/prove di drafmu; ganti jika bukti tidak mendukung."
      }
    },
    {
      id: "c1-u04",
      title: "Unit 4: Discourse Markers & Text Architecture",
      desc: "Penanda wacana tingkat lanjut untuk membangun argumen panjang",
      tags: ["Writing", "Cohesion"],
      content: {
        objectives: [
          "Memakai discourse markers untuk mengatur langkah argumen",
          "Membangun paragraf yang berperan jelas dalam keseluruhan teks",
          "Menghindari linker yang dipaksakan"
        ],
        orientation: "C1 writing bukan kumpulan kalimat bagus, melainkan arsitektur ide. Discourse markers adalah rambu di arsitektur itu.",
        theory: `<p>Kelompok penanda berguna:</p>
<p><strong>Adding:</strong> moreover, furthermore, in addition<br>
<strong>Contrasting:</strong> however, nevertheless, by contrast, conversely<br>
<strong>Result:</strong> therefore, consequently, thus, as a result<br>
<strong>Exemplifying:</strong> for instance, to illustrate, specifically<br>
<strong>Refocusing:</strong> in terms of, with regard to, as for<br>
<strong>Conceding:</strong> granted, admittedly, while it is true that</p>
<p>Yang penting bukan jumlah linker, tetapi apakah setiap kalimat punya peran logis.</p>`,
        rules: [
          "Satu paragraf = satu gerakan argumen",
          "Linker harus mencerminkan hubungan yang benar",
          "Jangan mulai setiap kalimat dengan linker",
          "Gunakan concession untuk menunjukkan kedewasaan argumen"
        ],
        examples: [
          { en: "Admittedly, online platforms increase access; nevertheless, depth of engagement varies widely.", id: "Memang platform daring meningkatkan akses; meskipun begitu, kedalaman engagement sangat bervariasi.", why: "Concession + contrast." },
          { en: "With regard to assessment, continuous tasks may reduce last-minute cramming.", id: "Terkait asesmen, tugas berkelanjutan dapat mengurangi belajar dadakan.", why: "Refocus." },
          { en: "Consequently, curriculum design should align practice with evaluation.", id: "Akibatnya, desain kurikulum harus menyelaraskan latihan dengan evaluasi.", why: "Result marker." },
          { en: "To illustrate, students who spaced reviews retained terminology longer.", id: "Sebagai ilustrasi, mahasiswa yang mereview berjarak lebih lama mengingat istilah.", why: "Exemplify." }
        ],
        compare: "B2: however/furthermore dasar. C1: concession, refocusing, dan kontrol peran paragraf dalam teks panjang.",
        commonErrors: [
          { wrong: "However, and moreover, but therefore...", right: "Pilih satu hubungan logis yang tepat.", why: "Linker bertumpuk membingungkan." },
          { wrong: "Using 'furthermore' to introduce a contradiction", right: "Gunakan however/nevertheless untuk kontras.", why: "Linker harus sesuai makna." }
        ],
        vocab: [
          { en: "discourse", id: "wacana", ipa: "/ˈdɪskɔːs/", ex: "Academic discourse has conventions." },
          { en: "concession", id: "pengakuan poin lawan", ipa: "/kənˈseʃn/", ex: "A concession strengthens credibility." },
          { en: "align", id: "menyelaraskan", ipa: "/əˈlaɪn/", ex: "Align practice with goals." },
          { en: "architecture", id: "arsitektur (struktur)", ipa: "/ˈɑːkɪtektʃə/", ex: "Text architecture matters at C1." }
        ],
        dialogue: [
          { speaker: "A", en: "How many linkers should I use?", id: "Berapa banyak linker yang harus saya pakai?" },
          { speaker: "B", en: "As many as the logic needs — not one per sentence by force.", id: "Sebanyak yang dibutuhkan logika — bukan satu per kalimat secara paksa." }
        ],
        summary: "Discourse markers menata langkah argumen. Prioritaskan logika, bukan dekorasi.",
        guided: [
          { q: "Admittedly is mainly used for:", options: ["examples", "concession", "definitions", "titles"], correct: 1, explain: "Concession." },
          { q: "Best marker for contrast:", options: ["moreover", "nevertheless", "for instance", "specifically"], correct: 1, explain: "Contrast." },
          { q: "A paragraph at C1 should:", options: ["mix unrelated goals", "perform one clear argumentative move", "avoid topic sentences", "only list words"], correct: 1, explain: "Satu gerakan argumen." }
        ],
        independent: [
          { q: "Susun outline 5 paragraf esai C1 tentang AI in education; tulis discourse role tiap paragraf." }
        ],
        practice: "Tulis 180–220 kata dengan minimal 1 concession, 1 contrast, 1 result, 1 example marker.",
        evaluation: [
          { q: "Moreover typically:", options: ["contrasts", "adds support", "concedes", "ends the essay"], correct: 1, explain: "Add support." },
          { q: "Granted/admittedly introduce:", options: ["random jokes", "a conceded point", "a definition only", "a citation format"], correct: 1, explain: "Concession." },
          { q: "Consequently signals:", options: ["contrast", "result", "example", "topic change only"], correct: 1, explain: "Result." },
          { q: "Forced linkers often cause:", options: ["better logic", "artificial flow", "perfect cohesion", "shorter essays automatically"], correct: 1, explain: "Alur artifisial." },
          { q: "C1 text architecture emphasizes:", options: ["isolated sentences", "roles of paragraphs in the whole argument", "only vocabulary lists", "no conclusions"], correct: 1, explain: "Peran paragraf." }
        ],
        remedial: "Warnai draf esai: hijau = support, merah = contrast, biru = result, kuning = example. Perbaiki yang kosong."
      }
    },
    {
      id: "c1-u05",
      title: "Unit 5: Critical Reading & Inference",
      desc: "Membaca teks padat: claim, evidence, assumption, implication",
      tags: ["Reading", "Critical Thinking"],
      content: {
        objectives: [
          "Memisahkan claim, evidence, dan assumption",
          "Menarik inference yang berdasar",
          "Menilai kekuatan argumen dalam teks autentik"
        ],
        orientation: "C1 reading bukan hanya 'paham arti kata', tetapi mengevaluasi bagaimana argumen dibangun dan apa yang tersirat.",
        theory: `<p><strong>Claim</strong> = pernyataan posisi/kesimpulan penulis.<br>
<strong>Evidence</strong> = data, contoh, kutipan, temuan yang mendukung.<br>
<strong>Assumption</strong> = hal yang dianggap benar tanpa dibuktikan penuh.<br>
<strong>Implication</strong> = konsekuensi yang mengikuti jika claim diterima.</p>
<p>Inference yang baik ditopang teks, bukan spekulasi bebas. Tanyakan: Apa yang dinyatakan? Apa buktinya? Apa yang diambil sebagai given? Apa akibatnya?</p>`,
        rules: [
          "Tandai claim secara eksplisit sebelum mengevaluasi",
          "Bedakan fakta yang dilaporkan dari interpretasi penulis",
          "Inference harus bisa ditunjuk kembali ke petunjuk tekstual",
          "Kritik asumsi, bukan hanya opini selera"
        ],
        examples: [
          { en: "Claim: Flexible deadlines improve learning quality.", id: "Contoh claim.", why: "Posisi yang bisa diuji." },
          { en: "Evidence: In a campus survey, 68% reported deeper revision when given one extension.", id: "Contoh evidence.", why: "Data mendukung." },
          { en: "Assumption: Students will use extra time for revision rather than delay.", id: "Contoh assumption.", why: "Perlu diuji." },
          { en: "Implication: Assessment policy may need redesign.", id: "Contoh implication.", why: "Konsekuensi kebijakan." }
        ],
        compare: "Literal comprehension: What does the sentence say? Critical reading: How strong is the argument and what is missing?",
        commonErrors: [
          { wrong: "The author is wrong because I disagree.", right: "The author's claim is weakly supported because the sample is limited.", why: "Kritik berbasis bukti." },
          { wrong: "Inference without textual basis", right: "Point to the lines that justify the inference.", why: "Harus berdasar teks." }
        ],
        vocab: [
          { en: "inference", id: "inferensi / simpulan tersirat", ipa: "/ˈɪnfərəns/", ex: "Make a careful inference." },
          { en: "assumption", id: "asumsi", ipa: "/əˈsʌmpʃn/", ex: "Question the assumption." },
          { en: "implication", id: "implikasi", ipa: "/ˌɪmplɪˈkeɪʃn/", ex: "Consider the implications." },
          { en: "warrant", id: "dasar penghubung claim-evidence", ipa: "/ˈwɒrənt/", ex: "The warrant is unclear." }
        ],
        dialogue: [
          { speaker: "A", en: "I understand every sentence, but I still can't critique the article.", id: "Saya paham setiap kalimat, tapi masih sulit mengkritik artikelnya." },
          { speaker: "B", en: "Map claim, evidence, and assumptions first. Critique becomes easier.", id: "Petakan claim, evidence, dan asumsi dulu. Kritik jadi lebih mudah." }
        ],
        summary: "Critical reading = claim + evidence + assumption + implication, dengan inference yang berdasar.",
        guided: [
          { q: "An assumption is:", options: ["always proven data", "something taken as true without full proof", "a title", "a citation format"], correct: 1, explain: "Dianggap benar tanpa bukti penuh." },
          { q: "A good inference must be:", options: ["dramatic", "supported by textual cues", "unrelated to the text", "only emotional"], correct: 1, explain: "Berdasar teks." },
          { q: "Evidence differs from claim because evidence:", options: ["is the position itself", "supports the position", "is always an opinion", "cannot be measured"], correct: 1, explain: "Mendukung posisi." }
        ],
        independent: [
          { q: "Ambil 1 artikel opini; tulis claim, 2 evidence, 1 assumption, 1 implication." }
        ],
        practice: "Baca teks 300–400 kata; buat peta kritis 150 kata (claim–evidence–gaps).",
        evaluation: [
          { q: "Implication means:", options: ["a definition", "a likely consequence if the claim is accepted", "a grammar rule", "a synonym list"], correct: 1, explain: "Konsekuensi." },
          { q: "Weakest critique:", options: ["The sample is too small for the claim", "I don't like the topic", "The evidence does not cover key groups", "Alternative explanations are ignored"], correct: 1, explain: "Selera bukan kritik argumen." },
          { q: "Claim is best described as:", options: ["raw data only", "the author's position/conclusion", "a page number", "a dictionary entry"], correct: 1, explain: "Posisi/kesimpulan." },
          { q: "Critical reading at C1 prioritizes:", options: ["word-by-word translation only", "evaluating argument quality", "memorizing every example", "ignoring assumptions"], correct: 1, explain: "Kualitas argumen." },
          { q: "To justify an inference, you should:", options: ["point to textual support", "invent background stories", "change the topic", "delete evidence"], correct: 0, explain: "Dukungan tekstual." }
        ],
        remedial: "Latih 3 teks pendek: highlight claim dengan satu warna, evidence warna lain."
      }
    },
    {
      id: "c1-u06",
      title: "Unit 6: Formal Presentations & Spoken Academic Style",
      desc: "Struktur presentasi, signaling, dan register lisan formal",
      tags: ["Speaking", "Academic"],
      content: {
        objectives: [
          "Menyusun presentasi dengan opening, map, development, close",
          "Memakai signaling phrases untuk memandu audiens",
          "Menjaga register formal tanpa terdengar kaku berlebihan"
        ],
        orientation: "C1 speaking akademik menuntut kejelasan struktur lisan. Audiens tidak bisa 'scroll' mundur seperti saat membaca.",
        theory: `<p><strong>Kerangka:</strong> hook/context → purpose → roadmap → body points → summary → implications/Q&A.</p>
<p><strong>Signaling phrases:</strong><br>
Today I will argue that...<br>
First, I will outline...<br>
Turning to the second point...<br>
This leads to...<br>
In short...<br>
I am happy to take questions.</p>
<p>Gunakan pause, penekanan, dan signposting lebih banyak daripada tulisan. Hindari membaca naskah word-for-word.</p>`,
        rules: [
          "Sampaikan roadmap di awal",
          "Satu slide/poin = satu pesan utama",
          "Signpost saat pindah bagian",
          "Siapkan definisi istilah kunci untuk audiens campuran"
        ],
        examples: [
          { en: "I will focus on three constraints: time, access, and assessment design.", id: "Saya akan fokus pada tiga kendala...", why: "Roadmap jelas." },
          { en: "Turning now to assessment, the key issue is alignment.", id: "Beralih ke asesmen...", why: "Signpost transisi." },
          { en: "To put it briefly, policy without practice support rarely works.", id: "Singkatnya...", why: "Summary signal." },
          { en: "A practical implication is that staff training must accompany platform changes.", id: "Implikasi praktis...", why: "Close with implication." }
        ],
        compare: "Casual talk: free flow. Academic presentation: explicit structure and guided listening.",
        commonErrors: [
          { wrong: "No roadmap; jumping between points", right: "Preview structure and signal transitions.", why: "Audiens tersesat." },
          { wrong: "Reading dense slides aloud", right: "Speak to points; slides support, not replace speech.", why: "Engagement turun." }
        ],
        vocab: [
          { en: "roadmap", id: "peta jalan presentasi", ipa: "/ˈrəʊdmæp/", ex: "Give a clear roadmap." },
          { en: "signpost", id: "penanda arah wacana", ipa: "/ˈsaɪnpəʊst/", ex: "Signpost each transition." },
          { en: "implication", id: "implikasi", ipa: "/ˌɪmplɪˈkeɪʃn/", ex: "End with implications." },
          { en: "engagement", id: "keterlibatan audiens", ipa: "/ɪnˈɡeɪdʒmənt/", ex: "Maintain audience engagement." }
        ],
        dialogue: [
          { speaker: "A", en: "How formal should my language be?", id: "Seberapa formal bahasa saya?" },
          { speaker: "B", en: "Formal enough to be precise, clear enough to be followed in real time.", id: "Cukup formal untuk presisi, cukup jelas untuk diikuti secara real time." }
        ],
        summary: "Presentasi C1 = struktur eksplisit + signaling + register formal yang masih komunikatif.",
        guided: [
          { q: "A roadmap is given:", options: ["only at the end", "near the beginning", "never", "only in emails"], correct: 1, explain: "Di awal." },
          { q: "Turning to the next point is a:", options: ["hedge", "signpost", "citation", "title"], correct: 1, explain: "Signpost." },
          { q: "Dense word-for-word reading usually:", options: ["improves engagement", "reduces engagement", "is required at C1", "replaces Q&A"], correct: 1, explain: "Engagement turun." }
        ],
        independent: [
          { q: "Buat outline presentasi 4 menit tentang academic integrity." }
        ],
        practice: "Rekam presentasi 3–4 menit dengan roadmap + 3 signposts + closing implication.",
        evaluation: [
          { q: "Main reason for signposting:", options: ["to decorate speech", "to guide listeners through structure", "to avoid content", "to replace evidence"], correct: 1, explain: "Memandu pendengar." },
          { q: "Best opening element:", options: ["random joke only", "purpose + roadmap", "long autobiography", "unrelated news"], correct: 1, explain: "Purpose + roadmap." },
          { q: "C1 spoken academic style should be:", options: ["chaotic", "structured and precise", "identical to texting", "without examples"], correct: 1, explain: "Terstruktur & presisi." },
          { q: "An implication in the ending helps by:", options: ["adding a new unrelated topic", "showing why the talk matters", "removing the conclusion", "listing vocabulary"], correct: 1, explain: "Menunjukkan relevansi." },
          { q: "Slides should:", options: ["contain the full script", "support key points", "distract with dense text", "replace the speaker"], correct: 1, explain: "Support points." }
        ],
        remedial: "Transkrip 2 menit presentasimu; tandai di mana roadmap/signpost hilang, lalu rekam ulang."
      }
    },
    {
      id: "c1-u07",
      title: "Unit 7: Critical Response Writing (180–240 words)",
      desc: "Menulis tanggapan kritis: summary singkat + evaluasi argumen",
      tags: ["Writing", "Critical Response"],
      content: {
        objectives: [
          "Merangkum posisi teks sumber secara adil",
          "Mengevaluasi kekuatan dan celah argumen",
          "Menulis critical response 180–240 kata yang seimbang"
        ],
        orientation: "Critical response C1 bukan review emosional. Kamu merepresentasikan argumen lawan dengan adil, lalu menilai kualitasnya.",
        theory: `<p><strong>Struktur yang efektif:</strong></p>
<p>1) Brief neutral summary of the source claim<br>
2) Evaluation of evidence/logic (strengths)<br>
3) Limitations, assumptions, or alternative views<br>
4) Your reasoned stance / implication</p>
<p>Gunakan reporting verbs netral (argues, contends, suggests) sebelum penilaianmu (however, this overlooks, a stronger explanation is...).</p>`,
        rules: [
          "Jangan misrepresent sumber",
          "Bedakan summary dari evaluation",
          "Dukung kritik dengan alasan, bukan selera",
          "Tutup dengan stance yang proporsional"
        ],
        examples: [
          { en: "The author contends that mandatory attendance improves outcomes.", id: "Contoh reporting netral.", why: "contends = fair summary." },
          { en: "While the survey data are useful, the sample is limited to one faculty.", id: "Kekuatan + batasan.", why: "Balanced evaluation." },
          { en: "This argument assumes students skip class mainly due to low motivation.", id: "Mengungkap assumption.", why: "Critical move." },
          { en: "A more convincing account would also consider workload design.", id: "Alternatif yang konstruktif.", why: "Bukan hanya menolak." }
        ],
        compare: "Opinion paragraph: what I think. Critical response: what the text claims + how well it is supported + my reasoned evaluation.",
        commonErrors: [
          { wrong: "Long summary, almost no evaluation", right: "Keep summary short; spend space on critique.", why: "Response harus kritis." },
          { wrong: "Attacking the writer personally", right: "Evaluate claims and evidence.", why: "Ad hominem lemah." }
        ],
        vocab: [
          { en: "contend", id: "berpendapat / berargumen", ipa: "/kənˈtend/", ex: "The author contends that..." },
          { en: "overlook", id: "mengabaikan", ipa: "/ˌəʊvəˈlʊk/", ex: "The analysis overlooks cost." },
          { en: "limitation", id: "keterbatasan", ipa: "/ˌlɪmɪˈteɪʃn/", ex: "A key limitation is sample size." },
          { en: "reasoned", id: "berdasar alasan", ipa: "/ˈriːznd/", ex: "a reasoned response" }
        ],
        dialogue: [
          { speaker: "A", en: "Can I fully reject the article?", id: "Bisakah saya menolak artikelnya sepenuhnya?" },
          { speaker: "B", en: "Yes, if you justify it with evidence and logic — not just preference.", id: "Ya, jika kamu justifikasi dengan bukti dan logika — bukan sekadar preferensi." }
        ],
        summary: "Critical response = fair summary + evaluation of logic/evidence + reasoned stance.",
        guided: [
          { q: "First move in a critical response is usually:", options: ["personal insult", "fair brief summary", "random memories", "only conclusion"], correct: 1, explain: "Summary adil." },
          { q: "overlooks means:", options: ["emphasizes", "fails to consider", "proves", "translates"], correct: 1, explain: "Mengabaikan." },
          { q: "A strong critique targets:", options: ["the writer's personality", "claims, evidence, assumptions", "font choice only", "word count only"], correct: 1, explain: "Claim/evidence/assumption." }
        ],
        independent: [
          { q: "Buat outline critical response untuk klaim: 'All lectures should be replaced by videos.'" }
        ],
        practice: "Tulis critical response 200–240 kata terhadap satu opini di media kampus.",
        evaluation: [
          { q: "Fair summary should be:", options: ["exaggerated", "neutral and brief", "longer than evaluation always", "written in slang"], correct: 1, explain: "Netral & singkat." },
          { q: "Best evaluative sentence:", options: ["This is stupid.", "The evidence is limited to one context, so generalization is risky.", "I hate this topic.", "The author is bad."], correct: 1, explain: "Kritik berbasis alasan." },
          { q: "Reporting verb 'contends' is useful to:", options: ["insult", "present the author's position", "end the essay", "avoid summary"], correct: 1, explain: "Menyajikan posisi." },
          { q: "Critical response at C1 requires:", options: ["only summary", "summary plus reasoned evaluation", "only emojis", "no stance"], correct: 1, explain: "Summary + evaluasi." },
          { q: "A constructive limitation statement often:", options: ["stops at rejection", "points to what is missing and why it matters", "ignores evidence", "copies the source"], correct: 1, explain: "Celah + mengapa penting." }
        ],
        remedial: "Tulis ulang satu response lama: 40% summary, 60% evaluation."
      }
    },
    {
      id: "c1-u08",
      title: "Unit 8: C1 Checkpoint — Integrated Academic Performance",
      desc: "Review C1 + critical response / short academic task sebagai evaluasi level",
      tags: ["Evaluation", "Academic"],
      content: {
        objectives: [
          "Mengintegrasikan nominalization, hedging, clause control, dan critical evaluation",
          "Menyelesaikan tugas akademik singkat setara C1",
          "Mencapai ambang untuk membuka C2"
        ],
        orientation: "Checkpoint C1 menguji apakah kamu bisa menulis dan berpikir akademik secara konsisten, bukan hanya mengenal istilah advanced.",
        theory: `<p><strong>Checklist C1:</strong></p>
<ul>
<li>Nominalization & concision</li>
<li>Participle/cleft/inversion (digunakan tepat)</li>
<li>Hedging & stance control</li>
<li>Discourse architecture</li>
<li>Critical reading moves</li>
<li>Critical response quality</li>
</ul>
<p>Evaluasi menekankan kejelasan argumen, proporsi klaim-bukti, dan kontrol register formal.</p>`,
        rules: [
          "Utamakan kejelasan sebelum kekompleksan",
          "Setiap klaim kuat butuh dukungan",
          "Tunjukkan kontrol, bukan pamer struktur"
        ],
        examples: [
          { en: "The available evidence suggests that structured feedback may accelerate progress, although transfer to new tasks remains uneven.", id: "Contoh hedging + concession.", why: "C1 balance." },
          { en: "Having examined the constraints, we can now assess the policy implications.", id: "Participle + academic move.", why: "Flow." },
          { en: "It is assessment design that often determines whether flexibility helps or harms learning.", id: "Cleft for emphasis.", why: "Focus." },
          { en: "In critical terms, the article underestimates workload effects.", id: "Evaluative academic stance.", why: "Critique." }
        ],
        compare: "B2 = argumen terstruktur dengan grammar menengah-atas. C1 = kontrol gaya akademik, kehati-hatian klaim, dan evaluasi kritis.",
        commonErrors: [
          { wrong: "Advanced grammar with unclear position", right: "Clear stance first, then sophisticated support.", why: "Style tanpa argumen lemah." },
          { wrong: "Absolute claims without evidence", right: "Hedge or support strongly.", why: "Tidak proporsional." }
        ],
        vocab: [
          { en: "consistency", id: "konsistensi", ipa: "/kənˈsɪstənsi/", ex: "Aim for consistency across the text." },
          { en: "transfer", id: "transfer (ilmu ke konteks baru)", ipa: "/ˈtrænsfɜː/", ex: "Transfer remains uneven." },
          { en: "underestimate", id: "meremehkan", ipa: "/ˌʌndərˈestɪmeɪt/", ex: "Do not underestimate workload." },
          { en: "threshold", id: "ambang", ipa: "/ˈθreʃhəʊld/", ex: "Cross the C1 threshold." }
        ],
        dialogue: [
          { speaker: "A", en: "Is complex grammar enough for C1?", id: "Apakah grammar kompleks cukup untuk C1?" },
          { speaker: "B", en: "No. You need controlled style plus critical clarity.", id: "Tidak. Kamu butuh gaya terkontrol plus kejelasan kritis." }
        ],
        summary: "C1 siap jika argumen akademikmu hati-hati, terstruktur, dan kritis secara konsisten.",
        guided: [
          { q: "C1 writing prioritizes:", options: ["complexity without clarity", "clarity with controlled sophistication", "slang density", "no evaluation"], correct: 1, explain: "Jelas + sophisticated terkontrol." },
          { q: "A checkpoint task often combines:", options: ["only spelling", "language control and critical reasoning", "only listening speed", "drawing"], correct: 1, explain: "Bahasa + nalar kritis." },
          { q: "Best final standard:", options: ["sound impressive", "be precise, supported, and readable", "use inversion always", "avoid stance"], correct: 1, explain: "Presisi + support + readable." }
        ],
        independent: [
          { q: "Self-audit satu esai: tandai hedging, nominalization, dan satu critical evaluation move." }
        ],
        practice: "Tulis critical response 200–240 kata + 1 paragraf refleksi tentang struktur yang kamu pakai.",
        evaluation: [
          { q: "Nominalization at C1 should be:", options: ["constant and heavy", "strategic for concision", "avoided completely", "used only in speech"], correct: 1, explain: "Strategis." },
          { q: "Hedging is most appropriate when:", options: ["evidence is limited or conditional", "evidence is absolute and total", "writing fiction only", "greeting friends"], correct: 0, explain: "Bukti terbatas/bersyarat." },
          { q: "Critical response needs:", options: ["summary only", "summary and evaluation", "emojis", "no source reference"], correct: 1, explain: "Summary + evaluation." },
          { q: "Inversion and clefts are best used:", options: ["in every line", "for targeted emphasis", "never in academic work", "only in titles"], correct: 1, explain: "Penekanan tertarget." },
          { q: "A C1-level academic paragraph typically shows:", options: ["random ideas", "controlled stance and cohesion", "only bullet fragments", "no connectors"], correct: 1, explain: "Stance + kohesi." },
          { q: "Weak C1 performance often comes from:", options: ["clear argument", "style display without support", "fair hedging", "relevant examples"], correct: 1, explain: "Pamer style tanpa support." },
          { q: "Best description of C1 readiness:", options: ["can memorize scripts only", "can handle formal academic tasks with control and critical clarity", "knows alphabet", "avoids all complex sentences"], correct: 1, explain: "Kontrol formal + clarity kritis." }
        ],
        remedial: "Pilih unit C1 terlemah; ulang evaluation + tulis ulang 1 critical paragraph."
      }
    }
  ],
  c2: [
    {
      id: "c2-u01",
      title: "Unit 1: Register Shifting — Formal, Neutral, Informal Control",
      desc: "Menggeser register secara sadar tanpa kehilangan presisi",
      tags: ["Style", "Pragmatics"],
      content: {
        objectives: [
          "Mengenali fitur formal, netral, dan informal",
          "Menggeser satu pesan ke tiga register yang tepat",
          "Menghindari campur register yang tidak disengaja"
        ],
        orientation: "C2 bukan hanya 'lebih sulit', tetapi kontrol penuh terhadap situasi: siapa audiens, tujuan, dan jarak sosial.",
        theory: `<p><strong>Formal:</strong> nominalization, passive, precise lexis, fewer contractions.<br>
<strong>Neutral:</strong> clear standard prose for general educated audiences.<br>
<strong>Informal:</strong> contractions, phrasal verbs, personal tone, simpler syntax.</p>
<p>Contoh pesan yang sama:<br>
Formal: Further clarification is required before the proposal can be approved.<br>
Neutral: We need more clarification before we can approve the proposal.<br>
Informal: We still need you to clear a few things up before we can say yes.</p>`,
        rules: [
          "Pilih register dari situasi, bukan dari 'kata-kata keren'",
          "Jaga konsistensi dalam satu teks/situasi",
          "Informal bukan berarti tidak presisi",
          "Formal bukan berarti bertele-tele"
        ],
        examples: [
          { en: "Formal: The committee expressed reservations regarding the timeline.", id: "Komite menyampaikan keberatan terkait linimasa.", why: "Lexis formal." },
          { en: "Neutral: The committee had concerns about the timeline.", id: "Komite punya kekhawatiran tentang linimasa.", why: "Netral jelas." },
          { en: "Informal: The team wasn't thrilled about the schedule.", id: "Tim kurang sreg dengan jadwalnya.", why: "Informal natural." },
          { en: "Shifted carefully: Applicants must submit evidence. / Please send your evidence. / Send us what you've got to back this up.", id: "Satu makna, tiga register.", why: "Control." }
        ],
        compare: "C1: mostly formal academic control. C2: flexible movement across registers with intention.",
        commonErrors: [
          { wrong: "Mixing slang into a formal report", right: "Keep formal reports consistent; shift only when the situation changes.", why: "Campur tak sadar merusak ethos." },
          { wrong: "Using opaque formal words in casual mentoring", right: "Choose accessible precision.", why: "Register harus fit audience." }
        ],
        vocab: [
          { en: "register", id: "register / ragam bahasa", ipa: "/ˈredʒɪstə/", ex: "Adjust your register." },
          { en: "ethos", id: "kredibilitas penutur", ipa: "/ˈiːθɒs/", ex: "Inconsistent register weakens ethos." },
          { en: "opaque", id: "sulit ditembus / tidak transparan", ipa: "/əʊˈpeɪk/", ex: "Avoid opaque wording." },
          { en: "accessible", id: "mudah diakses", ipa: "/əkˈsesəbl/", ex: "Keep precision accessible." }
        ],
        dialogue: [
          { speaker: "A", en: "Should I always sound formal to seem advanced?", id: "Haruskah saya selalu formal agar terlihat advanced?" },
          { speaker: "B", en: "No. Advanced means choosing the right register, not the heaviest one.", id: "Tidak. Advanced berarti memilih register yang tepat, bukan yang paling berat." }
        ],
        summary: "C2 = kontrol pergeseran register yang disengaja, konsisten, dan sesuai situasi.",
        guided: [
          { q: "Best formal option:", options: ["We gotta fix this.", "This issue requires immediate attention.", "Fix it now lol.", "Thing bad."], correct: 1, explain: "Formal." },
          { q: "Register should be chosen by:", options: ["audience and purpose", "random preference", "only word length", "font size"], correct: 0, explain: "Audiens & tujuan." },
          { q: "Inconsistent register often weakens:", options: ["ethos", "spelling only", "punctuation only", "paper size"], correct: 0, explain: "Ethos." }
        ],
        independent: [
          { q: "Tulis 1 pesan permintaan revisi dalam formal, neutral, dan informal." }
        ],
        practice: "Ambil email formal; buat versi neutral dan informal tanpa mengubah makna inti.",
        evaluation: [
          { q: "Informal register typically features:", options: ["no meaning", "contractions and more personal tone", "only passive voice", "legal citations"], correct: 1, explain: "Kontraksi & personal." },
          { q: "Formal writing prefers:", options: ["gotta/wanna", "precise lexical choices", "random emojis", "incomplete fragments always"], correct: 1, explain: "Leksikon presisi." },
          { q: "C2 control means:", options: ["one register forever", "intentional shifting when needed", "avoiding all informal speech", "using the longest words"], correct: 1, explain: "Pergeseran disengaja." },
          { q: "A report to a dean should usually be:", options: ["highly informal", "formal or carefully neutral-formal", "full of slang", "emoji-based"], correct: 1, explain: "Formal." },
          { q: "Best principle:", options: ["style over situation", "situation guides style", "always maximal complexity", "never adapt"], correct: 1, explain: "Situasi memandu gaya." }
        ],
        remedial: "Rekam 1 penjelasan topik ke teman vs ke dosen; bandingkan pilihan leksikon dan sintaksis."
      }
    },
    {
      id: "c2-u02",
      title: "Unit 2: Nuance — Connotation, Understatement, Emphasis",
      desc: "Mengelola makna halus, penekanan, dan understatement",
      tags: ["Semantics", "Style"],
      content: {
        objectives: [
          "Membedakan denotation vs connotation",
          "Memakai understatement dan emphasis secara efektif",
          "Menghindari pejorative/loaded language yang tidak disengaja"
        ],
        orientation: "Di C2, pilihan kata membawa sikap. Nuansa yang salah bisa mengubah diplomasi menjadi provokasi.",
        theory: `<p><strong>Denotation</strong> = makna kamus. <strong>Connotation</strong> = asosiasi sikap/emosi.</p>
<p>slim vs skinny; firm vs stubborn; assertive vs aggressive.</p>
<p><strong>Understatement:</strong> The results were not ideal. (justru sangat buruk)<br>
<strong>Emphasis:</strong> precisely, crucially, entirely, unmistakably</p>
<p>Penulis C2 memilih force of expression sesuai tujuan retorika: menajamkan, melembutkan, atau menjaga jarak.</p>`,
        rules: [
          "Cek konotasi sebelum kata 'synonym' dipakai",
          "Understatement sering lebih kuat di konteks formal",
          "Emphasis berlebihan membuat teks terasa memaksa",
          "Loaded language harus disadari, bukan tidak sengaja"
        ],
        examples: [
          { en: "The policy was ambitious. (neutral-positive) vs The policy was unrealistic. (negative)", id: "Konotasi berbeda.", why: "Sikap berubah." },
          { en: "The delay was unfortunate. (understatement for a serious failure)", id: "Understatement.", why: "Melembutkan/menyindir tergantung konteks." },
          { en: "Crucially, the comparison group was absent.", id: "Emphasis pada kelemahan metodologis.", why: "Crucially menajamkan." },
          { en: "She is meticulous / nitpicking — choose by stance.", id: "Konotasi evaluasi.", why: "Sikap penulis." }
        ],
        compare: "Basic synonym use: same meaning. C2: same denotation, different social/evaluative force.",
        commonErrors: [
          { wrong: "Calling a careful reviewer 'nitpicking' in a formal response", right: "Choose meticulous/detailed unless critique is intended.", why: "Konotasi pejoratif." },
          { wrong: "Overusing extremely/totally/absolutely", right: "Reserve emphasis for key points.", why: "Inflasi penekanan." }
        ],
        vocab: [
          { en: "connotation", id: "konotasi", ipa: "/ˌkɒnəˈteɪʃn/", ex: "Check the connotation." },
          { en: "understatement", id: "pernyataan yang digentlekan", ipa: "/ˈʌndəsteɪtmənt/", ex: "That is an understatement." },
          { en: "loaded language", id: "bahasa bermuatan sikap", ipa: "/ˈləʊdɪd ˈlæŋɡwɪdʒ/", ex: "Avoid loaded language." },
          { en: "pejorative", id: "berkonotasi merendahkan", ipa: "/pɪˈdʒɒrətɪv/", ex: "a pejorative term" }
        ],
        dialogue: [
          { speaker: "A", en: "Is 'cheap' okay for low-cost services?", id: "Apakah 'cheap' oke untuk layanan berbiaya rendah?" },
          { speaker: "B", en: "In formal contexts, affordable or cost-effective is safer; cheap can sound negative.", id: "Di konteks formal, affordable/cost-effective lebih aman; cheap bisa terdengar negatif." }
        ],
        summary: "Nuansa C2 = kontrol konotasi, understatement, dan emphasis sesuai tujuan retorika.",
        guided: [
          { q: "skinny compared with slim is often more:", options: ["neutral-positive", "negative/pejorative", "formal academic", "technical only"], correct: 1, explain: "Konotasi lebih negatif." },
          { q: "Understatement can be used to:", options: ["only confuse", "soften or intensify ironically", "replace evidence", "avoid all evaluation"], correct: 1, explain: "Melembutkan/efek ironis." },
          { q: "Loaded language carries:", options: ["no attitude", "strong evaluative attitude", "only grammar tense", "page numbers"], correct: 1, explain: "Sikap evaluatif." }
        ],
        independent: [
          { q: "Pilih 8 pasangan sinonim; tulis perbedaan konotasi dan konteks aman pemakaian." }
        ],
        practice: "Revisi 1 paragraf opini: netralkan loaded words, pertahankan argument force.",
        evaluation: [
          { q: "Denotation is:", options: ["dictionary core meaning", "emotional association only", "font style", "speech volume"], correct: 0, explain: "Makna inti." },
          { q: "Connotation is:", options: ["spelling variant", "associative/evaluative meaning", "punctuation", "word count"], correct: 1, explain: "Asosiasi/evaluatif." },
          { q: "Best formal alternative to 'bad results':", options: ["disastrous garbage", "suboptimal outcomes", "totally dead", "lol fail"], correct: 1, explain: "suboptimal outcomes." },
          { q: "Excessive emphasis markers often:", options: ["improve subtlety", "reduce credibility", "fix grammar", "create citations"], correct: 1, explain: "Kredibilitas turun." },
          { q: "C2 nuance control requires:", options: ["ignoring audience", "conscious lexical attitude management", "only long sentences", "avoiding evaluation forever"], correct: 1, explain: "Manajemen sikap leksikal." }
        ],
        remedial: "Highlight semua adjective evaluatif di teksmu; ganti yang konotasinya tidak kamu maksud."
      }
    },
    {
      id: "c2-u03",
      title: "Unit 3: Idioms, Collocations & Natural Precision",
      desc: "Kolokasi natural dan idiom yang tepat situasi, bukan sekadar 'advanced words'",
      tags: ["Vocabulary", "Fluency"],
      content: {
        objectives: [
          "Memakai collocation yang natural di konteks akademik/profesional",
          "Memilih idiom yang sesuai register",
          "Menghindari forced 'fancy' vocabulary"
        ],
        orientation: "C2 vocabulary terasa natural karena kolokasi tepat, bukan karena kata terpanjang menang.",
        theory: `<p><strong>Collocation:</strong> make a decision (bukan do a decision), strong evidence, pose a challenge, address a gap, draw a distinction.</p>
<p><strong>Idiom caution:</strong> banyak idiom informal. Di akademik, pilih yang netral/terbatas: on balance, at stake, in light of, beyond the scope.</p>
<p>Presisi natural > ornament. Jika sinonim merusak collocation, jangan dipaksa.</p>`,
        rules: [
          "Pelajari kata bersama pasangannya",
          "Uji apakah idiom cocok di formal writing",
          "Prioritaskan kejelasan jika ragu",
          "Bangun bank collocation dari bacaan autentik"
        ],
        examples: [
          { en: "The findings pose a challenge to existing models.", id: "Temuan ini menantang model yang ada.", why: "pose a challenge = natural." },
          { en: "In light of the new data, the claim needs revision.", id: "Mengingat data baru...", why: "Formal idiom/phrase." },
          { en: "On balance, the benefits outweigh the drawbacks.", id: "Secara keseluruhan...", why: "Measured stance phrase." },
          { en: "This issue lies beyond the scope of the present paper.", id: "Di luar cakupan makalah ini.", why: "Academic formula." }
        ],
        compare: "Learner English: do a decision, big evidence. Natural: make a decision, strong/compelling evidence.",
        commonErrors: [
          { wrong: "do a research", right: "do research / conduct research", why: "Collocation." },
          { wrong: "Using playground idioms in a journal-style essay", right: "Prefer academic phrases or neutral wording.", why: "Register mismatch." }
        ],
        vocab: [
          { en: "collocation", id: "kolokasi", ipa: "/ˌkɒləˈkeɪʃn/", ex: "Learn collocations, not isolated words." },
          { en: "compelling", id: "kuat / meyakinkan", ipa: "/kəmˈpelɪŋ/", ex: "compelling evidence" },
          { en: "outweigh", id: "lebih besar daripada", ipa: "/ˌaʊtˈweɪ/", ex: "Benefits outweigh risks." },
          { en: "scope", id: "cakupan", ipa: "/skəʊp/", ex: "beyond the scope" }
        ],
        dialogue: [
          { speaker: "A", en: "I replaced every simple word with a rare synonym.", id: "Saya ganti semua kata sederhana dengan sinonim langka." },
          { speaker: "B", en: "That often breaks collocations. Natural precision beats rare words.", id: "Itu sering merusak kolokasi. Presisi natural mengalahkan kata langka." }
        ],
        summary: "C2 lexis = collocation natural + idiom yang register-appropriate.",
        guided: [
          { q: "Natural choice:", options: ["do a decision", "make a decision", "perform decide", "decision make"], correct: 1, explain: "make a decision." },
          { q: "strong evidence is a:", options: ["broken collocation", "natural collocation", "informal only idiom", "grammar tense"], correct: 1, explain: "Natural collocation." },
          { q: "beyond the scope is suitable for:", options: ["very informal chats only", "academic framing", "nursery rhymes", "sports cheers"], correct: 1, explain: "Academic." }
        ],
        independent: [
          { q: "Kumpulkan 15 collocation akademik dari 1 artikel; buat kalimatmu sendiri." }
        ],
        practice: "Tulis 150 kata review singkat memakai minimal 10 collocation autentik.",
        evaluation: [
          { q: "Best academic phrase:", options: ["do an assumption", "make an assumption", "assume a make", "assumptioning"], correct: 1, explain: "make an assumption." },
          { q: "Forced rare synonyms often:", options: ["improve collocation", "damage naturalness", "fix register issues", "create perfect idiom use"], correct: 1, explain: "Merusak naturalness." },
          { q: "on balance is useful to:", options: ["introduce a measured overall judgment", "greet someone", "cite a URL", "mark past perfect"], correct: 0, explain: "Judgment terukur." },
          { q: "pose a challenge collocates with problems that:", options: ["are presented to existing ideas", "are always solved instantly", "are informal jokes", "are titles only"], correct: 0, explain: "Menantang ide existing." },
          { q: "C2 vocabulary goal:", options: ["longest words possible", "natural precise combinations", "avoid all fixed phrases", "use only slang"], correct: 1, explain: "Kombinasi natural-presisi." }
        ],
        remedial: "Edit 1 esai: ganti broken collocations dengan bentuk kamus/korpus yang natural."
      }
    },
    {
      id: "c2-u04",
      title: "Unit 4: Irony, Distance & Rhetorical Positioning",
      desc: "Mengatur jarak retoris, ironi terbatas, dan posisi penulis yang sofistikated",
      tags: ["Rhetoric", "Advanced Style"],
      content: {
        objectives: [
          "Mengenali jarak penulis terhadap klaim (close vs detached)",
          "Memakai ironi/understatement dengan aman di konteks formal",
          "Menempatkan posisi tanpa dogmatisme"
        ],
        orientation: "Penulis C2 bisa dekat atau berjarak terhadap materi. Kontrol jarak ini adalah bagian dari mature rhetoric.",
        theory: `<p><strong>Close stance:</strong> We must act now.<br>
<strong>Detached stance:</strong> One possible response is to reconsider the incentive structure.</p>
<p>Irony/understatement di formal writing harus hati-hati dan jarang. Lebih aman: let the contrast do the work.</p>
<p>Reporting + evaluation separation membantu jarak:<br>
The authors claim X. However, the design leaves Y unresolved.</p>`,
        rules: [
          "Pisahkan deskripsi dari evaluasi saat perlu objektivitas",
          "Ironi berisiko di audiens lintas budaya",
          "Posisi kuat tetap butuh dukungan",
          "Jarak retoris dipilih sesuai genre"
        ],
        examples: [
          { en: "The proposal is optimistic about timelines.", id: "Understatement kritis.", why: "Soft critique." },
          { en: "It is difficult to see how the conclusion follows from such limited data.", id: "Detached but sharp.", why: "Distance + critique." },
          { en: "We argue for a narrower claim that can actually be supported.", id: "Positioning with humility.", why: "Mature stance." },
          { en: "The authors claim a breakthrough; the evidence indicates an incremental gain.", id: "Contrast as rhetoric.", why: "Tanpa sarkasme kasar." }
        ],
        compare: "Aggressive rhetoric attacks. C2 rhetoric calibrates distance and force.",
        commonErrors: [
          { wrong: "Sarcasm in a formal academic response", right: "Use measured contrast and evidence.", why: "Sarkasme merusak formal ethos." },
          { wrong: "No visible position at all", right: "C2 still takes positions, but with calibration.", why: "Bukan netralitas kosong." }
        ],
        vocab: [
          { en: "rhetoric", id: "retorika", ipa: "/ˈretərɪk/", ex: "Rhetorical control matters." },
          { en: "detached", id: "berjarak / tidak emosional", ipa: "/dɪˈtætʃt/", ex: "a detached tone" },
          { en: "calibrate", id: "menyelaraskan secara presisi", ipa: "/ˈkælɪbreɪt/", ex: "Calibrate your claims." },
          { en: "incremental", id: "bertahap / kecil tapi nyata", ipa: "/ˌɪŋkrəˈmentl/", ex: "an incremental improvement" }
        ],
        dialogue: [
          { speaker: "A", en: "Can I be ironic in a journal review?", id: "Bisakah saya ironis di review jurnal?" },
          { speaker: "B", en: "Only very carefully. Measured critique is safer and clearer.", id: "Hanya sangat hati-hati. Kritik terukur lebih aman dan jelas." }
        ],
        summary: "C2 rhetoric mengatur jarak dan kekuatan klaim dengan sadar, bukan sekadar 'lebih tegas'.",
        guided: [
          { q: "Detached stance often uses:", options: ["only insults", "impersonal framing and careful evaluation", "emojis", "no verbs"], correct: 1, explain: "Framing impersonal + evaluasi hati-hati." },
          { q: "Irony in formal academic texts is:", options: ["always required", "high-risk and rare", "the main cohesion tool", "a citation style"], correct: 1, explain: "Berisiko & jarang." },
          { q: "Calibrating a claim means:", options: ["making it extreme", "matching force to evidence and purpose", "deleting the claim", "translating it"], correct: 1, explain: "Menyelaraskan kekuatan klaim." }
        ],
        independent: [
          { q: "Tulis ulang 1 kritik agresif menjadi versi detached tetapi tajam." }
        ],
        practice: "Buat 180 kata response dengan posisi jelas, jarak formal, tanpa sarkasme.",
        evaluation: [
          { q: "Rhetorical distance refers to:", options: ["page margins", "how close/attached the writer is to the claim", "font spacing", "audio volume"], correct: 1, explain: "Kedekatan penulis pada klaim." },
          { q: "A mature C2 critique is usually:", options: ["personal and abusive", "evidence-based and calibrated", "purely ironic", "position-free"], correct: 1, explain: "Berbasis bukti & terukur." },
          { q: "The authors claim X; the data show Y. This pattern mainly creates:", options: ["confusion only", "controlled contrast", "a greeting", "a title page"], correct: 1, explain: "Kontras terkontrol." },
          { q: "Optimistic about timelines can function as:", options: ["neutral praise only", "soft critique via understatement", "a data table", "a collocation error always"], correct: 1, explain: "Understatement kritis." },
          { q: "C2 positioning avoids:", options: ["all stance", "uncalibrated dogmatism", "examples", "structure"], correct: 1, explain: "Dogmatisme tak terukur." }
        ],
        remedial: "Ambil 1 teks opini; tulis ulang 2 versi: close stance dan detached stance."
      }
    },
    {
      id: "c2-u05",
      title: "Unit 5: Synthesis Writing — Integrating Multiple Sources",
      desc: "Mensintesis beberapa sumber menjadi argumen utuh, bukan ringkasan beruntun",
      tags: ["Writing", "Research Skills"],
      content: {
        objectives: [
          "Menggabungkan minimal 2–3 sumber dalam satu argumen",
          "Menunjukkan hubungan: support, contrast, extend, challenge",
          "Menulis synthesis 220–280 kata yang kohesif"
        ],
        orientation: "Synthesis C2 bukan 'A bilang... B bilang...'. Kamu membangun klaimmu dengan sumber sebagai bahan, bukan pengganti pikiran.",
        theory: `<p><strong>Langkah:</strong></p>
<p>1) Identifikasi titik temu/konflik antar sumber<br>
2) Susun klaimmu sendiri<br>
3) Pakai sumber untuk support / qualify / challenge<br>
4) Tunjukkan apa yang muncul dari gabungan itu</p>
<p>Frasa berguna: taken together; in contrast to; building on; this complicates; a convergent finding is...</p>`,
        rules: [
          "Jangan summarize source-by-source tanpa thesis",
          "Setiap sumber harus punya fungsi retoris",
          "Tandai persetujuan/pertentangan dengan akurat",
          "Akhiri dengan insight sintesis, bukan kutipan terakhir saja"
        ],
        examples: [
          { en: "Taken together, the studies suggest timing matters as much as intensity.", id: "Gabungan studi...", why: "Synthesis move." },
          { en: "While A emphasizes access, B shows that access without guidance yields limited gains.", id: "Contrast + integrate.", why: "Fungsi sumber berbeda." },
          { en: "Building on A's framework, B provides classroom evidence that refines the model.", id: "Extend.", why: "Bukan sekadar setuju." },
          { en: "This convergence strengthens the case for blended support systems.", id: "Insight after synthesis.", why: "Nilai tambah penulis." }
        ],
        compare: "Summary list: source parade. Synthesis: your argument using sources as evidence relations.",
        commonErrors: [
          { wrong: "Paragraphs that only restate each author separately", right: "Organize by idea relations, not by author order.", why: "Itu summary, bukan synthesis." },
          { wrong: "Forcing agreement where sources conflict", right: "Acknowledge conflict and interpret it.", why: "Akurasi akademik." }
        ],
        vocab: [
          { en: "synthesis", id: "sintesis", ipa: "/ˈsɪnθəsɪs/", ex: "Write a synthesis, not a list." },
          { en: "convergence", id: "titik temu", ipa: "/kənˈvɜːdʒəns/", ex: "a convergence of findings" },
          { en: "qualify", id: "membatasi / menyertai syarat", ipa: "/ˈkwɒlɪfaɪ/", ex: "qualify a claim" },
          { en: "refines", id: "menyempurnakan", ipa: "/rɪˈfaɪnz/", ex: "evidence that refines the model" }
        ],
        dialogue: [
          { speaker: "A", en: "I summarized three articles. Is that synthesis?", id: "Saya meringkas tiga artikel. Apakah itu synthesis?" },
          { speaker: "B", en: "Only if you connect them into your own coherent claim.", id: "Hanya jika kamu menghubungkan mereka menjadi klaimmu yang koheren." }
        ],
        summary: "Synthesis = argumenmu + relasi antar sumber (support/contrast/extend/challenge).",
        guided: [
          { q: "Synthesis should be organized mainly by:", options: ["author order only", "idea relations", "alphabet", "page count"], correct: 1, explain: "Relasi ide." },
          { q: "Taken together signals:", options: ["a greeting", "combined interpretation", "a citation error", "past perfect"], correct: 1, explain: "Interpretasi gabungan." },
          { q: "If sources conflict, a C2 writer should:", options: ["hide the conflict", "acknowledge and interpret it", "delete one source silently", "stop writing"], correct: 1, explain: "Akui & interpretasikan." }
        ],
        independent: [
          { q: "Pilih 2 opini berbeda; tulis 1 paragraf sintesis 120 kata dengan claim sendiri." }
        ],
        practice: "Tulis synthesis 240–280 kata dari 3 sumber singkat (boleh artikel/opini), dengan insight penutup.",
        evaluation: [
          { q: "Source-by-source summary without a thesis is:", options: ["strong synthesis", "weak synthesis / mere listing", "perfect C2 form", "a cleft sentence"], correct: 1, explain: "Listing lemah." },
          { q: "Building on Source A means:", options: ["ignoring A", "extending A's contribution", "copying A entirely", "deleting B"], correct: 1, explain: "Memperluas kontribusi A." },
          { q: "A convergent finding is one that:", options: ["appears across sources in a similar direction", "is unique and unsupported", "is always false", "is a title only"], correct: 0, explain: "Titik temu." },
          { q: "In synthesis, each source should have:", options: ["no role", "a rhetorical function", "identical wording", "only dates"], correct: 1, explain: "Fungsi retoris." },
          { q: "Best ending for synthesis:", options: ["a new unrelated story", "an insight from the combination of sources", "a random quote with no link", "only bibliography"], correct: 1, explain: "Insight sintesis." }
        ],
        remedial: "Ambil draf summary beruntun; susun ulang berdasarkan 2–3 tema relasi."
      }
    },
    {
      id: "c2-u06",
      title: "Unit 6: C2 Checkpoint — Near-Native Control Task",
      desc: "Evaluasi terpadu: register, nuance, synthesis, dan presisi retoris",
      tags: ["Evaluation", "Proficiency"],
      content: {
        objectives: [
          "Menunjukkan kontrol register dan nuance dalam satu produk tulis",
          "Mensintesis ide dengan presisi near-native",
          "Menyelesaikan checkpoint C2 secara konsisten"
        ],
        orientation: "Checkpoint C2 menilai fleksibilitas dan presisi: apakah kamu bisa terdengar tepat, natural, dan tajam secara bersamaan.",
        theory: `<p><strong>Checklist C2:</strong></p>
<ul>
<li>Register shifting on purpose</li>
<li>Connotation/nuance control</li>
<li>Natural collocations</li>
<li>Calibrated rhetoric</li>
<li>Genuine synthesis</li>
</ul>
<p>Near-native bukan berarti tanpa aksen atau tanpa kesalahan kecil, melainkan kontrol pilihan bahasa yang andal di situasi menuntut.</p>`,
        rules: [
          "Pilih kekuatan klaim dengan sadar",
          "Jaga naturalness di atas ornament",
          "Tunjukkan fleksibilitas, bukan satu gaya kaku"
        ],
        examples: [
          { en: "On balance, the policy is defensible, though its timeline remains optimistic.", id: "Nuanced evaluation.", why: "Measured C2 tone." },
          { en: "In formal terms, further verification is required; simply put, we are not ready to scale.", id: "Register shift controlled in one move.", why: "Flexible clarity." },
          { en: "Taken together, the sources complicate any single-cause explanation.", id: "Synthesis insight.", why: "C2 move." },
          { en: "The term 'cheap' is avoided here in favor of 'cost-efficient' to prevent negative connotations.", id: "Meta-awareness of nuance.", why: "Proficiency." }
        ],
        compare: "C1: strong academic control. C2: flexible, nuanced, situation-sensitive control across styles and sources.",
        commonErrors: [
          { wrong: "Trying to sound native by forcing idioms", right: "Prefer accurate natural collocations and clear stance.", why: "Forced idiom = unnatural." },
          { wrong: "One rigid formal style for every audience", right: "Adapt register deliberately.", why: "C2 = flexibility." }
        ],
        vocab: [
          { en: "near-native", id: "mendekati native", ipa: "/ˌnɪə ˈneɪtɪv/", ex: "near-native control" },
          { en: "calibrated", id: "terukur", ipa: "/ˈkælɪbreɪtɪd/", ex: "a calibrated claim" },
          { en: "defensible", id: "dapat dibela secara rasional", ipa: "/dɪˈfensəbl/", ex: "a defensible position" },
          { en: "complicate", id: "membuat lebih kompleks / tidak sederhana", ipa: "/ˈkɒmplɪkeɪt/", ex: "The findings complicate the claim." }
        ],
        dialogue: [
          { speaker: "A", en: "What does C2 feel like in practice?", id: "Seperti apa C2 dalam praktik?" },
          { speaker: "B", en: "Like having choices — and choosing well for the situation.", id: "Seperti punya banyak pilihan — dan memilih dengan tepat untuk situasinya." }
        ],
        summary: "C2 checkpoint = fleksibilitas register, nuance, synthesis, dan presisi retoris yang konsisten.",
        guided: [
          { q: "C2 emphasizes:", options: ["only grammar drills", "flexible precise control across situations", "memorizing one essay", "avoiding all style choices"], correct: 1, explain: "Kontrol fleksibel-presisi." },
          { q: "Forced idioms usually sound:", options: ["native-perfect", "unnatural", "more academic automatically", "neutral always"], correct: 1, explain: "Tidak natural." },
          { q: "A calibrated claim is:", options: ["extreme by default", "matched to evidence and purpose", "never evaluative", "only humorous"], correct: 1, explain: "Sesuai bukti & tujuan." }
        ],
        independent: [
          { q: "Self-check satu teks panjang: register consistency, connotation, collocations, synthesis moves." }
        ],
        practice: "Tulis 260–300 kata synthesis + evaluation dengan register formal terkontrol dan 1 shift netral yang disengaja di bagian implikasi praktis.",
        evaluation: [
          { q: "Register shifting at C2 should be:", options: ["accidental", "intentional and situation-led", "constant slang", "forbidden"], correct: 1, explain: "Disengaja." },
          { q: "Natural collocations matter because they:", options: ["only increase word count", "signal proficient control", "replace arguments", "remove nuance"], correct: 1, explain: "Sinyal kontrol proficient." },
          { q: "Synthesis at C2 requires:", options: ["listing authors only", "integrating sources into your claim", "avoiding all sources", "copying one source"], correct: 1, explain: "Integrasi ke klaim sendiri." },
          { q: "Nuance control includes:", options: ["ignoring connotation", "managing evaluative force of words", "using any synonym freely", "deleting adjectives always"], correct: 1, explain: "Manajemen kekuatan evaluatif." },
          { q: "A near-native feature is:", options: ["never adapting style", "reliable situational language choices", "perfect handwriting", "no vocabulary growth"], correct: 1, explain: "Pilihan bahasa situasional yang andal." },
          { q: "Best C2 priority order:", options: ["ornament > clarity", "clarity and precision > ornament", "irony > evidence", "length > meaning"], correct: 1, explain: "Clarity & precision dulu." },
          { q: "Checkpoint success looks like:", options: ["random advanced forms", "coherent nuanced performance under task demands", "only multiple-choice luck", "avoiding synthesis"], correct: 1, explain: "Performa nuansa yang koheren." }
        ],
        remedial: "Pilih kelemahan tertinggi (register/nuance/synthesis); tulis ulang checkpoint section terkait."
      }
    }
  ]
};

// Expose pass threshold
if (typeof window !== "undefined") {
  window.CEFR_ORDER = CEFR_ORDER;
  window.CEFR_META = CEFR_META;
  window.UNIT_PASS_SCORE = UNIT_PASS_SCORE;
  window.LEARN_PATH = LEARN_PATH;
}
