/**
 * Netlify Function — LinguaPro AI proxy (Tutor + Speaking Call)
 * Env: GEMINI_API_KEY. Optional: GEMINI_MODEL
 * Modes: body.mode = "tutor" (default) | "speaking" | "speaking_eval"
 */
const DEFAULT_MODELS = [
  "gemini-3.8-flash",
  "gemini-3.5-flash-lite",
  "gemini-3.6-flash"
];

exports.handler = async function (event) {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: corsHeaders(), body: "" };
  }
  if (event.httpMethod !== "POST") {
    return json(405, { error: "Method not allowed" });
  }

  const apiKey = (process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || "").trim();
  if (!apiKey) {
    return json(503, {
      error: "API_NOT_CONFIGURED",
      message:
        "AI belum dikonfigurasi. Netlify → Environment variables → GEMINI_API_KEY, lalu Redeploy."
    });
  }

  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch {
    return json(400, { error: "Invalid JSON", message: "Body harus JSON valid." });
  }

  const mode = String(body.mode || "tutor").toLowerCase();
  const message = String(body.message || "").trim();
  const history = Array.isArray(body.history) ? body.history.slice(-16) : [];
  const userName = String(body.userName || "student").slice(0, 40);
  const level = String(body.level || "a1").slice(0, 20);
  const topic = String(body.topic || "free").slice(0, 80);

  if (!message && mode !== "speaking") {
    return json(400, { error: "EMPTY", message: "Pesan kosong." });
  }
  if (message.length > 6000) {
    return json(400, { error: "TOO_LONG", message: "Pesan terlalu panjang." });
  }

  const systemPrompt = buildSystemPrompt(mode, level, userName, topic);

  const contents = [];
  contents.push({
    role: "user",
    parts: [{ text: systemPrompt + "\n\nConfirm you understood the role in one short sentence." }]
  });
  contents.push({
    role: "model",
    parts: [{ text: "Understood. I will stay in role and respond helpfully." }]
  });

  history.forEach((h) => {
    if (!h || !h.text) return;
    contents.push({
      role: h.role === "user" ? "user" : "model",
      parts: [{ text: String(h.text).slice(0, 1500) }]
    });
  });

  contents.push({
    role: "user",
    parts: [{ text: message || "(start the conversation)" }]
  });

  const preferred = (process.env.GEMINI_MODEL || "").trim();
  const models = preferred
    ? [preferred, ...DEFAULT_MODELS.filter((m) => m !== preferred)]
    : DEFAULT_MODELS.slice();

  const payload = {
    contents,
    generationConfig: {
      temperature: mode === "speaking" ? 0.85 : 0.7,
      maxOutputTokens: mode === "speaking_eval" ? 1200 : 512,
      topP: 0.9
    }
  };

  let lastError = null;

  for (const model of models) {
    const url =
      "https://generativelanguage.googleapis.com/v1beta/models/" +
      encodeURIComponent(model) +
      ":generateContent";
    try {
      const resp = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": apiKey
        },
        body: JSON.stringify(payload)
      });
      const data = await resp.json().catch(() => ({}));
      if (!resp.ok) {
        const errMsg =
          (data.error && (data.error.message || data.error.status)) ||
          "HTTP " + resp.status;
        lastError = model + ": " + String(errMsg).slice(0, 240);
        if (resp.status === 401 || resp.status === 403) {
          return json(502, {
            error: "AUTH_ERROR",
            message: "API key ditolak. Cek GEMINI_API_KEY. " + String(errMsg).slice(0, 160)
          });
        }
        if (resp.status === 429) {
          return json(429, {
            error: "RATE_LIMIT",
            message: "Rate limit Gemini. Coba lagi nanti."
          });
        }
        continue;
      }
      const text = extractText(data);
      if (!text) {
        lastError = model + ": empty response";
        continue;
      }
      return json(200, { reply: text, model });
    } catch (e) {
      lastError = model + ": " + (e.message || "network");
    }
  }

  return json(502, {
    error: "UPSTREAM_ERROR",
    message: "Gemini gagal. " + (lastError || "unknown")
  });
};

function buildSystemPrompt(mode, level, userName, topic) {
  if (mode === "speaking" || mode === "free_call") {
    return (
      "You are a friendly English conversation partner AND light tutor for Indonesian university students on LinguaPro.\n" +
      "Student name: " + userName + ". CEFR level: " + level + ". Topic preference: " + topic + ".\n\n" +
      "RULES:\n" +
      "1. Speak natural phone-call English (1–3 short sentences). Text will be read aloud.\n" +
      "2. Always react to their last message first (empathy or comment), THEN ask one follow-up.\n" +
      "3. No fixed scripts. Never ignore what they said.\n" +
      "4. Match CEFR " + level + ": A1–A2 very simple words; B1+ more natural.\n" +
      "5. Do not correct every error. Only brief correction if meaning breaks or they ask.\n" +
      "6. Never repeat the same question twice in a row.\n" +
      "7. Plain spoken English only — no markdown, bullets, or HTML.\n" +
      "8. Under 45 words. Sound warm and curious, like a real conversation partner."
    );
  }
  if (mode === "speaking_exam") {
    return (
      "You are an IELTS-style speaking examiner for practice (NOT official IELTS).\n" +
      "Student level: " + level + ". Name: " + userName + ".\n" +
      "Ask ONE clear question only. No feedback yet. Plain English. Under 40 words. No markdown."
    );
  }
  if (mode === "speaking_eval") {
    return (
      "You evaluate a practice English speaking session for Indonesian students (NOT official IELTS scores).\n" +
      "Level claimed: " + level + ".\n" +
      "Given the transcript, reply in HTML simple tags (strong, br, ul, li) with:\n" +
      "1) Short overall comment\n" +
      "2) Fluency/coherence (based on transcript length & structure only)\n" +
      "3) Grammar notes with 1–2 corrected examples\n" +
      "4) Vocabulary notes\n" +
      "5) Relevance to questions\n" +
      "6) Pronunciation: state clearly that only speech-to-text transcript was available, so pronunciation was NOT measured acoustically\n" +
      "7) Practice recommendations\n" +
      "8) Approximate practice band 0–9 as ESTIMATE only — label it as unofficial\n" +
      "Be honest and encouraging. Bahasa Indonesia allowed for explanations."
    );
  }
  // tutor default
  return (
    "Kamu adalah AI English Tutor di aplikasi LinguaPro untuk mahasiswa Indonesia.\n" +
    "Level siswa: " + level + ". Nama: " + userName + ".\n\n" +
    "Aturan WAJIB:\n" +
    "1. Jawab sesuai pertanyaan — jangan template generik.\n" +
    "2. Koreksi kalimat: (a) versi benar, (b) daftar kesalahan spesifik, (c) penjelasan Bahasa Indonesia, (d) 1–2 contoh serupa.\n" +
    "3. Penjelasan grammar: Bahasa Indonesia, pola/rumus, minimal 3 contoh English + arti.\n" +
    "4. Soal latihan: 3–5 soal konkret + kunci di akhir.\n" +
    "5. Format HTML sederhana: strong, br, ul, li, em. Tanpa markdown code fence.\n" +
    "6. Jangan hanya bilang cek subject-verb agreement tanpa menunjukkan kesalahan konkret."
  );
}

function extractText(data) {
  try {
    const parts =
      data &&
      data.candidates &&
      data.candidates[0] &&
      data.candidates[0].content &&
      data.candidates[0].content.parts;
    if (!parts || !parts.length) return "";
    return parts.map((p) => (p && p.text ? p.text : "")).join("").trim();
  } catch {
    return "";
  }
}

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
}

function json(status, obj) {
  return {
    statusCode: status,
    headers: { "Content-Type": "application/json", ...corsHeaders() },
    body: JSON.stringify(obj)
  };
}
