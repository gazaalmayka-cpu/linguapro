/* ========== DATA: Questions, Lessons, Mock Tests ========== */

const PLACEMENT_QUESTIONS = [
  {
    id: 1,
    type: "grammar",
    question: "She _____ to the library every Saturday.",
    options: ["go", "goes", "going", "gone"],
    correct: 1
  },
  {
    id: 2,
    type: "grammar",
    question: "If I _____ rich, I would travel the world.",
    options: ["am", "was", "were", "be"],
    correct: 2
  },
  {
    id: 3,
    type: "vocab",
    question: "What is the synonym of 'happy'?",
    options: ["sad", "joyful", "angry", "tired"],
    correct: 1
  },
  {
    id: 4,
    type: "grammar",
    question: "They have been friends _____ ten years.",
    options: ["since", "for", "during", "from"],
    correct: 1
  },
  {
    id: 5,
    type: "reading",
    passage: "Climate change is one of the most pressing issues of our time. Rising temperatures, melting ice caps, and extreme weather events are affecting communities worldwide.",
    question: "According to the passage, climate change is:",
    options: ["not important", "a pressing issue", "only about ice", "a local problem"],
    correct: 1
  },
  {
    id: 6,
    type: "grammar",
    question: "I wish I _____ speak French fluently.",
    options: ["can", "could", "will", "would"],
    correct: 1
  },
  {
    id: 7,
    type: "vocab",
    question: "The opposite of 'increase' is:",
    options: ["rise", "grow", "decrease", "expand"],
    correct: 2
  },
  {
    id: 8,
    type: "grammar",
    question: "The book _____ by J.K. Rowling is very popular.",
    options: ["write", "wrote", "written", "writing"],
    correct: 2
  },
  {
    id: 9,
    type: "reading",
    passage: "Many students struggle with time management. Creating a daily schedule and prioritizing tasks can significantly improve productivity and reduce stress.",
    question: "What can help students improve productivity?",
    options: ["sleeping more", "creating a schedule", "avoiding tasks", "watching TV"],
    correct: 1
  },
  {
    id: 10,
    type: "grammar",
    question: "Neither John nor his friends _____ coming to the party.",
    options: ["is", "are", "was", "be"],
    correct: 1
  },
  {
    id: 11,
    type: "vocab",
    question: "'Ubiquitous' most nearly means:",
    options: ["rare", "everywhere", "expensive", "dangerous"],
    correct: 1
  },
  {
    id: 12,
    type: "grammar",
    question: "By the time we arrived, the movie _____.",
    options: ["starts", "started", "had started", "has started"],
    correct: 2
  },
  {
    id: 13,
    type: "grammar",
    question: "She suggested that he _____ the report carefully.",
    options: ["reads", "read", "reading", "to read"],
    correct: 1
  },
  {
    id: 14,
    type: "reading",
    passage: "Artificial intelligence is transforming industries from healthcare to finance. While it offers tremendous benefits, ethical concerns about privacy and job displacement remain significant challenges.",
    question: "What are the challenges mentioned regarding AI?",
    options: ["cost and speed", "privacy and job displacement", "only privacy", "only benefits"],
    correct: 1
  },
  {
    id: 15,
    type: "vocab",
    question: "To 'mitigate' means to:",
    options: ["make worse", "make less severe", "ignore", "celebrate"],
    correct: 1
  }
];

const GRAMMAR_LESSONS = {
  beginner: [
    {
      id: "b1",
      title: "Present Simple Tense",
      explanation: "Present Simple digunakan untuk kebiasaan, fakta umum, dan rutinitas. Bentuk dasar: Subject + V1 (s/es untuk he/she/it).",
      examples: [
        { en: "I study English every day.", id: "Saya belajar bahasa Inggris setiap hari." },
        { en: "She works at a hospital.", id: "Dia bekerja di rumah sakit." },
        { en: "Water boils at 100°C.", id: "Air mendidih pada 100°C." }
      ],
      quiz: [
        { q: "He _____ coffee every morning.", opts: ["drink", "drinks", "drinking"], ans: 1 },
        { q: "They _____ to school by bus.", opts: ["goes", "go", "going"], ans: 1 }
      ]
    },
    {
      id: "b2",
      title: "Present Continuous",
      explanation: "Present Continuous (am/is/are + V-ing) untuk kegiatan yang sedang berlangsung saat ini atau sementara.",
      examples: [
        { en: "I am studying right now.", id: "Saya sedang belajar sekarang." },
        { en: "They are playing football.", id: "Mereka sedang bermain sepak bola." }
      ],
      quiz: [
        { q: "Look! It _____.", opts: ["rains", "is raining", "rain"], ans: 1 },
        { q: "She _____ a book at the moment.", opts: ["reads", "is reading", "read"], ans: 1 }
      ]
    },
    {
      id: "b3",
      title: "Articles (a/an/the)",
      explanation: "A/An untuk benda singular yang belum spesifik. The untuk benda yang sudah spesifik atau unik.",
      examples: [
        { en: "I saw a cat. The cat was black.", id: "Saya melihat seekor kucing. Kucing itu hitam." },
        { en: "The sun rises in the east.", id: "Matahari terbit di timur." }
      ],
      quiz: [
        { q: "I need _____ umbrella.", opts: ["a", "an", "the"], ans: 1 },
        { q: "_____ moon looks beautiful tonight.", opts: ["A", "An", "The"], ans: 2 }
      ]
    },
    {
      id: "b4",
      title: "Past Simple",
      explanation: "Past Simple untuk kejadian yang sudah selesai di masa lalu. Regular: V+ed. Irregular: bentuk khusus (go→went).",
      examples: [
        { en: "I visited Bali last year.", id: "Saya mengunjungi Bali tahun lalu." },
        { en: "She went to the market yesterday.", id: "Dia pergi ke pasar kemarin." }
      ],
      quiz: [
        { q: "They _____ a movie last night.", opts: ["watch", "watched", "watching"], ans: 1 },
        { q: "He _____ home early.", opts: ["go", "goes", "went"], ans: 2 }
      ]
    },
    {
      id: "b5",
      title: "Prepositions of Place",
      explanation: "In (di dalam), On (di atas permukaan), At (di titik spesifik).",
      examples: [
        { en: "The book is on the table.", id: "Buku itu di atas meja." },
        { en: "She lives in Jakarta.", id: "Dia tinggal di Jakarta." },
        { en: "Meet me at the station.", id: "Temui saya di stasiun." }
      ],
      quiz: [
        { q: "The keys are _____ the drawer.", opts: ["on", "in", "at"], ans: 1 },
        { q: "I am _____ home now.", opts: ["in", "on", "at"], ans: 2 }
      ]
    }
  ],
  intermediate: [
    {
      id: "i1",
      title: "Present Perfect",
      explanation: "Have/Has + V3. Digunakan untuk pengalaman, kejadian yang baru selesai, atau yang masih relevan sekarang.",
      examples: [
        { en: "I have visited Japan twice.", id: "Saya sudah mengunjungi Jepang dua kali." },
        { en: "She has just finished her homework.", id: "Dia baru saja menyelesaikan PR-nya." }
      ],
      quiz: [
        { q: "They _____ never _____ sushi.", opts: ["have / eaten", "has / eaten", "have / ate"], ans: 0 },
        { q: "He _____ to Paris.", opts: ["has been", "have been", "was been"], ans: 0 }
      ]
    },
    {
      id: "i2",
      title: "Conditionals (Type 1 & 2)",
      explanation: "Type 1: If + present, will + V1 (real possibility). Type 2: If + past, would + V1 (unreal/hypothetical).",
      examples: [
        { en: "If it rains, I will stay home.", id: "Jika hujan, saya akan tinggal di rumah." },
        { en: "If I were you, I would study harder.", id: "Jika saya jadi kamu, saya akan belajar lebih giat." }
      ],
      quiz: [
        { q: "If she studies, she _____ pass.", opts: ["will", "would", "would have"], ans: 0 },
        { q: "If I _____ a bird, I would fly.", opts: ["am", "was", "were"], ans: 2 }
      ]
    },
    {
      id: "i3",
      title: "Passive Voice",
      explanation: "Object menjadi subject. Be + V3. Digunakan saat pelaku tidak penting atau tidak diketahui.",
      examples: [
        { en: "The letter was written by John.", id: "Surat itu ditulis oleh John." },
        { en: "English is spoken worldwide.", id: "Bahasa Inggris digunakan di seluruh dunia." }
      ],
      quiz: [
        { q: "The cake _____ by my mother.", opts: ["made", "was made", "is make"], ans: 1 },
        { q: "This book _____ in 2020.", opts: ["published", "was published", "publishing"], ans: 1 }
      ]
    },
    {
      id: "i4",
      title: "Relative Clauses",
      explanation: "Who (orang), Which (benda), That (orang/benda), Where (tempat). Memberikan info tambahan tentang noun.",
      examples: [
        { en: "The student who won the prize is my friend.", id: "Mahasiswa yang memenangkan hadiah adalah temanku." },
        { en: "This is the book which I recommended.", id: "Ini adalah buku yang saya rekomendasikan." }
      ],
      quiz: [
        { q: "The man _____ lives next door is a doctor.", opts: ["which", "who", "where"], ans: 1 },
        { q: "I like the movie _____ we watched.", opts: ["who", "where", "that"], ans: 2 }
      ]
    },
    {
      id: "i5",
      title: "Modals (can, could, should, must)",
      explanation: "Can (kemampuan/izin), Could (kemampuan lampau/permintaan sopan), Should (saran), Must (keharusan kuat).",
      examples: [
        { en: "You should see a doctor.", id: "Kamu sebaiknya ke dokter." },
        { en: "Students must submit the assignment.", id: "Mahasiswa harus mengumpulkan tugas." }
      ],
      quiz: [
        { q: "You _____ smoke here. It's prohibited.", opts: ["should", "must not", "can"], ans: 1 },
        { q: "_____ you help me, please?", opts: ["Should", "Must", "Could"], ans: 2 }
      ]
    }
  ],
  advanced: [
    {
      id: "a1",
      title: "Conditionals Type 3 & Mixed",
      explanation: "Type 3: If + past perfect, would have + V3 (past unreal). Mixed: kombinasi type 2 & 3.",
      examples: [
        { en: "If I had studied, I would have passed.", id: "Jika saya belajar, saya pasti lulus." },
        { en: "If I had taken that job, I would be rich now.", id: "Jika saya mengambil pekerjaan itu, saya kaya sekarang." }
      ],
      quiz: [
        { q: "If she _____ harder, she would have won.", opts: ["practiced", "had practiced", "practices"], ans: 1 },
        { q: "If I _____ you, I would have called.", opts: ["knew", "had known", "know"], ans: 1 }
      ]
    },
    {
      id: "a2",
      title: "Reported Speech",
      explanation: "Mengubah direct speech ke indirect. Tenses mundur satu tingkat. Say/tell + that clause.",
      examples: [
        { en: "He said, 'I am tired.' → He said that he was tired.", id: "Dia bilang dia lelah." },
        { en: "She told me, 'I will come.' → She told me that she would come.", id: "Dia bilang akan datang." }
      ],
      quiz: [
        { q: "He said, 'I live in Bali.' → He said he _____ in Bali.", opts: ["lives", "lived", "live"], ans: 1 },
        { q: "She said, 'I can swim.' → She said she _____ swim.", opts: ["can", "could", "will"], ans: 1 }
      ]
    },
    {
      id: "a3",
      title: "Inversion & Emphasis",
      explanation: "Rarely, Never, Not only, Hardly + auxiliary + subject untuk penekanan formal.",
      examples: [
        { en: "Never have I seen such beauty.", id: "Belum pernah saya melihat keindahan seperti itu." },
        { en: "Not only did she pass, but she also got the highest score.", id: "Tidak hanya lulus, dia juga dapat nilai tertinggi." }
      ],
      quiz: [
        { q: "Rarely _____ such a talented musician.", opts: ["we see", "do we see", "we do see"], ans: 1 },
        { q: "Not only _____ late, but he also forgot the documents.", opts: ["he was", "was he", "he is"], ans: 1 }
      ]
    },
    {
      id: "a4",
      title: "Subjunctive Mood",
      explanation: "Digunakan setelah suggest, recommend, insist, demand + that + base form (tanpa -s).",
      examples: [
        { en: "I suggest that he study harder.", id: "Saya sarankan dia belajar lebih giat." },
        { en: "It is essential that she be present.", id: "Sangat penting bahwa dia hadir." }
      ],
      quiz: [
        { q: "The teacher recommended that she _____ the exam.", opts: ["takes", "take", "took"], ans: 1 },
        { q: "It is crucial that every student _____ on time.", opts: ["arrives", "arrive", "arrived"], ans: 1 }
      ]
    }
  ],
  pro: [
    {
      id: "p1",
      title: "Cleft Sentences & Fronting",
      explanation: "It is/was ... that/who untuk fokus. What-clause untuk emphasis. Fronting object/adverbial.",
      examples: [
        { en: "It was John who broke the vase.", id: "John-lah yang memecahkan vas itu." },
        { en: "What I need is a quiet place to study.", id: "Yang saya butuhkan adalah tempat tenang untuk belajar." }
      ],
      quiz: [
        { q: "_____ was the manager who approved the plan.", opts: ["It", "There", "What"], ans: 0 },
        { q: "_____ I really want is success.", opts: ["It", "What", "That"], ans: 1 }
      ]
    },
    {
      id: "p2",
      title: "Advanced Nominalization",
      explanation: "Mengubah verb/adjective menjadi noun untuk gaya akademik yang lebih formal dan padat.",
      examples: [
        { en: "The implementation of the policy led to improvement.", id: "Implementasi kebijakan tersebut menyebabkan peningkatan." },
        { en: "His refusal to cooperate was unexpected.", id: "Penolakannya untuk bekerja sama tidak terduga." }
      ],
      quiz: [
        { q: "The _____ of the project was delayed. (complete)", opts: ["complete", "completion", "completing"], ans: 1 },
        { q: "Her _____ of the theory was brilliant. (analyze)", opts: ["analysis", "analyze", "analyzing"], ans: 0 }
      ]
    },
    {
      id: "p3",
      title: "Discourse Markers & Cohesion",
      explanation: "Furthermore, Nevertheless, Consequently, In contrast, Conversely — untuk academic writing yang kohesif.",
      examples: [
        { en: "The results were inconclusive. Nevertheless, the study provides valuable insights.", id: "Hasilnya tidak konklusif. Namun demikian, studi ini memberikan insight berharga." },
        { en: "Demand increased. Consequently, prices rose.", id: "Permintaan naik. Akibatnya, harga naik." }
      ],
      quiz: [
        { q: "Sales fell. _____, the company remained profitable.", opts: ["Consequently", "Nevertheless", "Furthermore"], ans: 1 },
        { q: "The data supports the hypothesis. _____, further research is needed.", opts: ["However", "Therefore", "Moreover"], ans: 0 }
      ]
    }
  ]
};

const READING_PASSAGES = [
  {
    title: "The Benefits of Reading",
    text: "Reading is one of the most effective ways to expand knowledge and improve cognitive abilities. Studies have shown that regular reading can enhance vocabulary, improve concentration, and even reduce stress levels. For university students, reading academic journals and literature is essential for developing critical thinking skills. Moreover, fiction reading can increase empathy by allowing readers to experience different perspectives and cultures. In an age dominated by short-form digital content, the ability to engage with longer texts remains a valuable skill for academic and professional success.",
    questions: [
      { q: "What is one benefit of regular reading mentioned in the passage?", opts: ["It decreases vocabulary", "It can reduce stress", "It makes people lazy", "It reduces empathy"], ans: 1 },
      { q: "Why is reading important for university students?", opts: ["To pass time", "To develop critical thinking", "To avoid studying", "Only for fiction"], ans: 1 },
      { q: "What does the passage say about fiction reading?", opts: ["It is useless", "It can increase empathy", "It is only for children", "It decreases concentration"], ans: 1 }
    ]
  },
  {
    title: "Remote Work Revolution",
    text: "The COVID-19 pandemic accelerated the adoption of remote work across industries. What was once considered a rare privilege has become a standard option for many knowledge workers. Companies have reported mixed results: some note increased productivity and employee satisfaction, while others struggle with collaboration and company culture. Hybrid models, combining office and remote days, have emerged as a popular compromise. Experts predict that flexible work arrangements will continue to evolve, requiring new management strategies and digital tools to maintain team cohesion and innovation.",
    questions: [
      { q: "What accelerated remote work adoption?", opts: ["New technology only", "The COVID-19 pandemic", "Government policy", "Employee demands alone"], ans: 1 },
      { q: "What is a hybrid model?", opts: ["Fully remote", "Fully office-based", "Combining office and remote days", "Working only weekends"], ans: 2 },
      { q: "What do experts predict about flexible work?", opts: ["It will disappear", "It will continue to evolve", "It is temporary", "Only for tech companies"], ans: 1 }
    ]
  },
  {
    title: "Sustainable Fashion",
    text: "The fashion industry is one of the largest polluters globally, contributing significantly to carbon emissions and textile waste. In response, a growing movement toward sustainable fashion has gained momentum among consumers and brands alike. Sustainable fashion emphasizes ethical production, eco-friendly materials, and longer product lifecycles. Second-hand shopping, clothing rental services, and brands using recycled fabrics are becoming increasingly popular. However, challenges remain, including higher costs and the difficulty of verifying genuine sustainability claims versus greenwashing.",
    questions: [
      { q: "Why is the fashion industry criticized?", opts: ["It is too expensive", "It is a major polluter", "It is not stylish", "It only uses natural materials"], ans: 1 },
      { q: "What does sustainable fashion emphasize?", opts: ["Fast production", "Ethical production and eco-friendly materials", "Cheaper clothes only", "Disposable fashion"], ans: 1 },
      { q: "What is 'greenwashing' implied as?", opts: ["Real sustainability", "False sustainability claims", "A type of fabric", "A shopping method"], ans: 1 }
    ]
  }
];

const LISTENING_SCRIPTS = [
  {
    title: "University Orientation",
    script: "Welcome to the university orientation session. My name is Sarah, and I'll be guiding you through today's program. First, we'll visit the main library, which is open from 8 AM to 10 PM on weekdays. Then, we'll head to the student center where you can find the cafeteria, study rooms, and the career services office. Don't forget to pick up your student ID cards at the administration building before 4 PM. Finally, there will be a Q&A session with senior students at 3 PM in Hall B. Are there any questions so far?",
    questions: [
      { q: "What time does the library close on weekdays?", opts: ["8 PM", "9 PM", "10 PM", "11 PM"], ans: 2 },
      { q: "Where can students get their ID cards?", opts: ["Library", "Student center", "Administration building", "Hall B"], ans: 2 },
      { q: "When is the Q&A session?", opts: ["2 PM", "3 PM", "4 PM", "5 PM"], ans: 1 }
    ]
  },
  {
    title: "Climate Change Lecture",
    script: "Today we will discuss the primary causes of climate change. The burning of fossil fuels—coal, oil, and natural gas—releases large amounts of carbon dioxide into the atmosphere. Deforestation also plays a significant role because trees absorb CO2. Additionally, industrial agriculture contributes methane through livestock and rice production. Scientists agree that limiting global temperature rise to 1.5 degrees Celsius requires rapid reductions in greenhouse gas emissions. Individual actions such as reducing meat consumption and using public transport can collectively make a difference.",
    questions: [
      { q: "What is a primary cause of climate change mentioned?", opts: ["Recycling", "Burning fossil fuels", "Planting trees", "Using solar panels"], ans: 1 },
      { q: "Why is deforestation a problem?", opts: ["Trees release CO2", "Trees absorb CO2", "It creates jobs", "It is beautiful"], ans: 1 },
      { q: "What temperature limit do scientists mention?", opts: ["1.0°C", "1.5°C", "2.0°C", "2.5°C"], ans: 1 }
    ]
  },
  {
    title: "Job Interview Tips",
    script: "Preparing for a job interview requires careful planning. First, research the company thoroughly—understand their mission, recent projects, and company culture. Second, practice common interview questions, but avoid memorizing answers word for word. Instead, prepare key points you want to communicate. Dress professionally and arrive at least 10 to 15 minutes early. During the interview, maintain eye contact, listen carefully, and ask thoughtful questions at the end. Finally, send a thank-you email within 24 hours after the interview to express your continued interest.",
    questions: [
      { q: "How early should you arrive for an interview?", opts: ["5 minutes", "10-15 minutes", "30 minutes", "On time exactly"], ans: 1 },
      { q: "What should you do after the interview?", opts: ["Call immediately", "Send a thank-you email within 24 hours", "Wait a week", "Nothing"], ans: 1 },
      { q: "What is advised about answering questions?", opts: ["Memorize word for word", "Prepare key points", "Say as little as possible", "Only yes/no answers"], ans: 1 }
    ]
  },
  {
    title: "Library Opening Hours",
    script: "Attention all students. The central library will extend its opening hours during the final examination period. From next Monday, the library will open at 7 AM and close at midnight from Monday to Friday. On weekends, it will operate from 9 AM to 8 PM. Group study rooms can be booked online up to 48 hours in advance. Please remember that food and drinks are not allowed in the quiet zones on the third floor. If you need research assistance, librarians are available at the help desk until 9 PM.",
    questions: [
      { q: "What time does the library open on weekdays during exams?", opts: ["6 AM", "7 AM", "8 AM", "9 AM"], ans: 1 },
      { q: "Until when can you book group study rooms in advance?", opts: ["24 hours", "48 hours", "72 hours", "1 week"], ans: 1 },
      { q: "Where are food and drinks not allowed?", opts: ["Entire library", "Quiet zones on the third floor", "Help desk", "Weekends only"], ans: 1 }
    ]
  },
  {
    title: "Healthy Study Habits",
    script: "Many students underestimate the importance of sleep and breaks while studying. Research shows that the brain consolidates memory most effectively during sleep. Aim for seven to eight hours each night, especially before an exam. The Pomodoro technique—twenty-five minutes of focused work followed by a five-minute break—can improve concentration. Additionally, studying in shorter sessions over several days is more effective than one long cramming session. Stay hydrated and avoid excessive caffeine late in the evening.",
    questions: [
      { q: "How many hours of sleep are recommended?", opts: ["5-6", "7-8", "9-10", "4-5"], ans: 1 },
      { q: "What is the Pomodoro work interval?", opts: ["15 minutes", "25 minutes", "45 minutes", "60 minutes"], ans: 1 },
      { q: "What study approach is more effective?", opts: ["One long cramming session", "Shorter sessions over several days", "Only all-nighters", "Studying without breaks"], ans: 1 }
    ]
  },
  {
    title: "Campus Cafeteria Announcement",
    script: "Good morning. This is an announcement regarding the student cafeteria. Starting this Wednesday, a new vegetarian and vegan menu will be available every day. The salad bar will be expanded, and we will offer plant-based protein options. Prices for the standard meal plan remain unchanged. Breakfast is served from 7 to 9:30 AM, lunch from 11:30 AM to 2 PM, and dinner from 5:30 to 8 PM. Students with allergies should speak to the staff; allergen information is clearly labeled on each dish.",
    questions: [
      { q: "When does the new vegetarian menu start?", opts: ["Monday", "Tuesday", "Wednesday", "Friday"], ans: 2 },
      { q: "When is lunch served?", opts: ["10–12", "11:30 AM–2 PM", "12–3 PM", "1–3 PM"], ans: 1 },
      { q: "Where can students find allergen information?", opts: ["Only online", "Labeled on each dish", "At the library", "Not available"], ans: 1 }
    ]
  }
];

const WRITING_PROMPTS = [
  {
    type: "opinion",
    title: "Technology in Education",
    prompt: "Some people believe that technology has improved the quality of education, while others argue it has created more distractions. Discuss both views and give your own opinion. Write at least 150 words.",
    minWords: 150
  },
  {
    type: "problem-solution",
    title: "Traffic Congestion",
    prompt: "Traffic congestion is a major problem in many cities. What are the causes of this problem, and what measures can be taken to solve it? Write at least 150 words.",
    minWords: 150
  },
  {
    type: "advantage-disadvantage",
    title: "Studying Abroad",
    prompt: "More and more students are choosing to study abroad. What are the advantages and disadvantages of studying in a foreign country? Write at least 150 words.",
    minWords: 150
  },
  {
    type: "ielts-task2",
    title: "IELTS Writing Task 2",
    prompt: "In many countries, the amount of crime is increasing. What do you think are the main causes of crime? How can we deal with this problem? Give reasons for your answer and include any relevant examples from your own knowledge or experience. Write at least 250 words.",
    minWords: 250
  }
];

const SPEAKING_PROMPTS = [
  {
    part: "Part 1 - Introduction",
    prompt: "Tell me about your hometown. What do you like most about it? Has it changed much in recent years?",
    tips: "Speak for 1-2 minutes. Mention specific places, food, or culture. Use past tense when talking about changes."
  },
  {
    part: "Part 2 - Cue Card",
    prompt: "Describe a book that had a significant impact on you. You should say: what the book was about, when you read it, why it was important to you, and explain how it influenced your life or thinking.",
    tips: "You have 1 minute to prepare. Speak for 1-2 minutes. Structure: intro → content → personal impact → conclusion."
  },
  {
    part: "Part 3 - Discussion",
    prompt: "Do you think reading habits are changing among young people? How might technology affect the future of books? Should schools require students to read more classic literature?",
    tips: "Give extended answers. Support opinions with reasons and examples. Compare past and present if relevant."
  },
  {
    part: "TOEFL Independent",
    prompt: "Some people prefer to work in teams, while others prefer to work independently. Which do you prefer and why? Include specific reasons and examples in your response.",
    tips: "Speak for 45-60 seconds. State preference clearly, give 2 reasons with examples, conclude briefly."
  }
];

/* IELTS Mock Sections */
const IELTS_LISTENING = [
  {
    section: 1,
    title: "Section 1 — Accommodation Enquiry (Conversation)",
    difficulty: "Easy",
    script: "A: Good morning, I'm calling about the student apartment advertised on the university housing board. B: Good morning. We have a double room available on Maple Street, about ten minutes' walk from campus. The rent is one hundred and fifty pounds per week, including gas, electricity and water. A: Does that include internet as well? B: Yes, high-speed wifi is included. There is a shared kitchen and a laundry room in the basement. A: Is a deposit required? B: Yes, a deposit of four weeks' rent is required, refundable at the end of the tenancy if there is no damage. A: Could I view the room this weekend? B: Certainly. How about Saturday at two o'clock? A: Perfect. My name is James Carter. B: I'll put you down for two p.m. on Saturday, Mr Carter. Please bring a form of ID.",
    questions: [
      { q: "Where is the apartment located?", opts: ["Oak Avenue", "Maple Street", "Campus Road", "Library Lane"], ans: 1 },
      { q: "How much is the weekly rent?", opts: ["£120", "£150", "£180", "£200"], ans: 1 },
      { q: "What is NOT included in the rent?", opts: ["Gas", "Wifi", "Food", "Water"], ans: 2 },
      { q: "How large is the deposit?", opts: ["Two weeks' rent", "Three weeks' rent", "Four weeks' rent", "One month's rent only"], ans: 2 },
      { q: "When is the viewing?", opts: ["Friday 2 pm", "Saturday 2 pm", "Sunday 2 pm", "Saturday 3 pm"], ans: 1 },
      { q: "What should the caller bring?", opts: ["Cash only", "A form of ID", "A guarantor form", "Nothing"], ans: 1 },
      { q: "How far is the apartment from campus?", opts: ["5 minutes by bus", "10 minutes' walk", "20 minutes' walk", "Next door"], ans: 1 },
      { q: "Where is the laundry room?", opts: ["First floor", "Basement", "Shared kitchen", "Outside"], ans: 1 },
      { q: "What type of room is available?", opts: ["Single", "Double", "Studio", "Shared dorm"], ans: 1 },
      { q: "Is the deposit refundable?", opts: ["Never", "Yes, if no damage", "Only after 1 year", "Partially always"], ans: 1 }
    ]
  },
  {
    section: 2,
    title: "Section 2 — Campus Facilities (Monologue)",
    difficulty: "Easy-Medium",
    script: "Welcome to the orientation tour. On your right is the Science Building, home to biology, chemistry and physics laboratories. The main library is open from eight a.m. until ten p.m. on weekdays, and until six p.m. on Saturdays. During the examination period it stays open twenty-four hours. The Sports Complex is a five-minute walk north of the library. Membership costs thirty pounds per semester for students and includes the gym, pool and group fitness classes. Yoga is free on Tuesdays and Thursdays at six p.m. The student health centre is located behind the administration block; appointments can be booked online or by phone. Finally, the careers office on the second floor of the Student Union offers CV workshops every Wednesday afternoon.",
    questions: [
      { q: "Which subjects are in the Science Building?", opts: ["History only", "Biology, chemistry, physics", "Law and business", "Art and design"], ans: 1 },
      { q: "Normal weekday library closing time?", opts: ["8 pm", "9 pm", "10 pm", "Midnight"], ans: 2 },
      { q: "When is the library open 24 hours?", opts: ["Always", "Exam period", "Weekends", "Summer only"], ans: 1 },
      { q: "Student sports membership cost per semester?", opts: ["£20", "£30", "£40", "£50"], ans: 1 },
      { q: "Free yoga days?", opts: ["Mon & Wed", "Tue & Thu", "Fri only", "Weekends"], ans: 1 },
      { q: "Where is the health centre?", opts: ["Inside the library", "Behind administration", "Sports complex", "Student Union ground floor"], ans: 1 },
      { q: "CV workshops are held when?", opts: ["Monday morning", "Wednesday afternoon", "Friday evening", "Sunday"], ans: 1 },
      { q: "Sports complex is how far from the library?", opts: ["Next door", "5-minute walk north", "10-minute bus", "Across town"], ans: 1 },
      { q: "Saturday library closes at?", opts: ["4 pm", "6 pm", "8 pm", "10 pm"], ans: 1 },
      { q: "How can health appointments be booked?", opts: ["Only in person", "Online or by phone", "Email only", "Through lecturers"], ans: 1 }
    ]
  },
  {
    section: 3,
    title: "Section 3 — Academic Discussion (Conversation)",
    difficulty: "Medium",
    script: "Tutor: So, Maya and Tom, how is your group project on urban air quality progressing? Maya: We've collected data from five monitoring stations, but the readings from the industrial zone look inconsistent. Tom: I think the sensors there might need recalibration. The literature suggests particulate matter spikes during morning rush hour. Tutor: Good point. Have you controlled for weather variables such as wind speed and humidity? Maya: Not yet. We planned to use multiple regression, but we're unsure which software to use. Tutor: SPSS or R would both work. I'd recommend R if you want transferable skills. Tom: Could we extend the deadline by a week? We need time to clean the dataset. Tutor: I can give you four extra days, but not a full week. Submit a short progress report by Friday.",
    questions: [
      { q: "What is the project topic?", opts: ["Water pollution", "Urban air quality", "Traffic noise", "Climate policy"], ans: 1 },
      { q: "How many monitoring stations?", opts: ["Three", "Four", "Five", "Six"], ans: 2 },
      { q: "Problem with industrial zone data?", opts: ["Missing", "Inconsistent", "Too high", "Encrypted"], ans: 1 },
      { q: "When do particulate spikes often occur?", opts: ["Midnight", "Morning rush hour", "Weekends", "Summer only"], ans: 1 },
      { q: "Which weather variables should be controlled?", opts: ["Only temperature", "Wind speed and humidity", "Rainfall only", "None"], ans: 1 },
      { q: "Software recommended by tutor for transferable skills?", opts: ["Excel", "SPSS only", "R", "Python only"], ans: 2 },
      { q: "Extension granted?", opts: ["Full week", "Four extra days", "No extension", "Two weeks"], ans: 1 },
      { q: "What must be submitted by Friday?", opts: ["Final report", "Progress report", "Raw data only", "Nothing"], ans: 1 },
      { q: "Who suggested sensor recalibration?", opts: ["Tutor", "Maya", "Tom", "A lab technician"], ans: 2 },
      { q: "Analysis method mentioned?", opts: ["T-test only", "Multiple regression", "Chi-square", "ANOVA only"], ans: 1 }
    ]
  },
  {
    section: 4,
    title: "Section 4 — Lecture: Memory & Learning",
    difficulty: "Medium-Hard",
    script: "In today's lecture we examine how memory supports academic learning. Short-term or working memory holds a limited amount of information for roughly fifteen to thirty seconds, typically around seven items. Long-term memory has a much larger capacity and can store information for years. Encoding is the process of moving information into long-term storage; it is strengthened by elaborative rehearsal—linking new ideas to existing knowledge—rather than mere repetition. Sleep plays a critical role in consolidation: studies show that students who sleep after studying outperform those who remain awake. Retrieval practice, or testing yourself, is more effective than rereading notes. Finally, spaced practice over several days beats massed practice, commonly known as cramming.",
    questions: [
      { q: "Working memory duration is typically?", opts: ["1–2 seconds", "15–30 seconds", "Several hours", "One day"], ans: 1 },
      { q: "Approximate capacity of working memory?", opts: ["3 items", "7 items", "15 items", "Unlimited"], ans: 1 },
      { q: "What is encoding?", opts: ["Forgetting", "Moving info to long-term memory", "Sleeping", "Reading aloud only"], ans: 1 },
      { q: "Elaborative rehearsal means?", opts: ["Repeating word for word", "Linking new ideas to existing knowledge", "Writing once", "Highlighting only"], ans: 1 },
      { q: "How does sleep help learning?", opts: ["It erases memory", "It aids consolidation", "It has no effect", "Only for athletes"], ans: 1 },
      { q: "Retrieval practice is?", opts: ["Rereading notes", "Testing yourself", "Listening to lectures only", "Group chat"], ans: 1 },
      { q: "Spaced practice is better than?", opts: ["Sleep", "Massed practice / cramming", "Exercise", "Diet"], ans: 1 },
      { q: "Long-term memory capacity is described as?", opts: ["Very limited", "Much larger / can last years", "Same as working memory", "Only visual"], ans: 1 },
      { q: "Students who sleep after studying?", opts: ["Do worse", "Outperform those who stay awake", "Same results", "Only in math"], ans: 1 },
      { q: "Mere repetition is less effective than?", opts: ["Ignoring material", "Elaborative rehearsal", "Cramming only", "Skipping sleep"], ans: 1 }
    ]
  }
];

const IELTS_READING = [
  {
    title: "Passage 1 — The Rise of Remote Work",
    difficulty: "Medium",
    text: "Remote work, once a niche arrangement, expanded dramatically after 2020. Organisations discovered that many knowledge tasks could be performed outside traditional offices. Advocates point to reduced commuting time, greater flexibility for carers, and access to a wider talent pool. Critics warn of weakened company culture, difficulties in mentoring junior staff, and the risk of overwork when boundaries between home and office blur. Hybrid models—mixing office and remote days—have become a common compromise. Research by several business schools suggests productivity often remains stable or rises slightly for experienced employees, but collaboration on complex, creative projects may suffer without periodic face-to-face contact. Policymakers are now examining implications for urban planning, as demand for central office space softens while suburban and rural broadband needs grow.",
    questions: [
      { q: "Remote work expanded most dramatically after which year?", opts: ["2010", "2015", "2020", "2022"], ans: 2 },
      { q: "Which is cited as an advantage of remote work?", opts: ["Stronger office culture", "Reduced commuting time", "Easier mentoring", "More central offices"], ans: 1 },
      { q: "What do critics worry about regarding junior staff?", opts: ["Higher salaries", "Mentoring difficulties", "Too much flexibility", "Less commuting"], ans: 1 },
      { q: "Hybrid models combine?", opts: ["Only remote days", "Office and remote days", "Night and day shifts", "Full-time and freelance"], ans: 1 },
      { q: "For experienced employees, productivity often?", opts: ["Collapses", "Remains stable or rises slightly", "Is never measured", "Only falls"], ans: 1 },
      { q: "Complex creative collaboration may need?", opts: ["No meetings", "Periodic face-to-face contact", "Only email", "Total isolation"], ans: 1 },
      { q: "Urban planning implications include?", opts: ["More factories", "Softer demand for central offices", "Banning remote work", "Closing broadband"], ans: 1 },
      { q: "Broadband needs are growing in?", opts: ["Only city centres", "Suburban and rural areas", "Airports only", "Nowhere"], ans: 1 },
      { q: "A risk when home/office boundaries blur?", opts: ["Underwork", "Overwork", "No work", "Only benefits"], ans: 1 },
      { q: "Wider talent pool is mentioned as?", opts: ["A criticism", "An advantage", "Irrelevant", "Illegal"], ans: 1 }
    ]
  },
  {
    title: "Passage 2 — Coral Reefs and Climate Stress",
    difficulty: "Medium-Hard",
    text: "Coral reefs occupy less than one per cent of the ocean floor yet support roughly a quarter of all marine species. They are built by tiny polyps that secrete calcium carbonate skeletons. When sea temperatures rise beyond a narrow tolerance range, corals expel the symbiotic algae that give them colour and much of their energy—a process called bleaching. If stress persists, corals can die. Ocean acidification, caused by the uptake of atmospheric carbon dioxide, further reduces the availability of carbonate ions needed for skeleton building. Local pressures such as overfishing, destructive coastal development and pollution compound global climate stress. Scientists estimate that without sharp cuts in greenhouse gas emissions and stronger local protection, the majority of warm-water reefs could experience severe degradation by mid-century, threatening fisheries, coastal protection and tourism economies that millions of people depend on.",
    questions: [
      { q: "Coral reefs support about what share of marine species?", opts: ["1%", "10%", "25%", "50%"], ans: 2 },
      { q: "What do coral polyps secrete?", opts: ["Plastic", "Calcium carbonate", "Oil", "Salt only"], ans: 1 },
      { q: "Bleaching occurs when corals?", opts: ["Gain more algae", "Expel symbiotic algae", "Grow faster", "Move to deep water"], ans: 1 },
      { q: "Ocean acidification is linked to?", opts: ["Plastic waste", "Atmospheric CO2 uptake", "Overfishing only", "Tourism"], ans: 1 },
      { q: "Acidification reduces ions needed for?", opts: ["Photosynthesis only", "Skeleton building", "Swimming", "Migration"], ans: 1 },
      { q: "Local pressures mentioned include?", opts: ["Only climate", "Overfishing, development, pollution", "Space travel", "None"], ans: 1 },
      { q: "Without action, severe degradation may hit most reefs by?", opts: ["2030", "Mid-century", "2200", "Next year"], ans: 1 },
      { q: "Reefs provide coastal protection and?", opts: ["Nothing else", "Fisheries and tourism value", "Only decoration", "Mining"], ans: 1 },
      { q: "Share of ocean floor occupied by reefs?", opts: ["10%", "Less than 1%", "25%", "Half"], ans: 1 },
      { q: "Symbiotic algae provide corals with?", opts: ["Only colour", "Colour and much of their energy", "Predators", "Sand"], ans: 1 }
    ]
  },
  {
    title: "Passage 3 — The Psychology of Habit Formation",
    difficulty: "Hard",
    text: "Habits are automatic behaviours triggered by contextual cues. According to the cue–routine–reward model popularised in behavioural science, a cue in the environment initiates a routine that delivers a reward, gradually wiring the loop into the basal ganglia. Implementation intentions—specific plans of the form “When situation X occurs, I will perform response Y”—have been shown in meta-analyses to improve follow-through on goals such as exercise and study schedules. However, motivation alone is a weak predictor of long-term change; altering the surrounding environment often matters more. For example, placing fruit at eye level increases healthy snacking more reliably than simply resolving to eat better. Digital tools that send timely reminders can help, yet excessive notifications may produce alert fatigue. Researchers caution that habit formation typically requires weeks of consistent repetition, and that slips should be treated as data rather than moral failure if sustainable change is the aim.",
    questions: [
      { q: "Habits are described as?", opts: ["Fully conscious always", "Automatic behaviours triggered by cues", "Random actions", "Only bad behaviours"], ans: 1 },
      { q: "The model mentioned is?", opts: ["Only reward", "Cue–routine–reward", "Punishment only", "IQ–effort–luck"], ans: 1 },
      { q: "Implementation intentions take the form?", opts: ["I hope to...", "When X, I will Y", "Maybe later", "Never plan"], ans: 1 },
      { q: "Motivation alone is?", opts: ["The strongest predictor", "A weak predictor of long-term change", "Irrelevant always", "Illegal"], ans: 1 },
      { q: "Placing fruit at eye level is an example of?", opts: ["Ignoring environment", "Changing the environment", "Punishment", "Only willpower"], ans: 1 },
      { q: "Excessive notifications may cause?", opts: ["Perfect focus", "Alert fatigue", "Better sleep", "Higher IQ"], ans: 1 },
      { q: "Habit formation typically needs?", opts: ["One day", "Weeks of consistent repetition", "No repetition", "Only theory"], ans: 1 },
      { q: "Slips should be treated as?", opts: ["Moral failure only", "Data", "Reason to quit forever", "Illegal"], ans: 1 },
      { q: "Where are habit loops gradually wired?", opts: ["Only the skin", "Basal ganglia", "Hair", "Nails"], ans: 1 },
      { q: "Meta-analyses support implementation intentions for?", opts: ["Nothing", "Goals like exercise and study", "Only diet pills", "Sleep deprivation"], ans: 1 }
    ]
  }
];

const IELTS_WRITING = [
  {
    task: 1,
    title: "Academic Task 1 — Describe the chart",
    prompt: "The chart below shows the percentage of households in owned and rented accommodation in England and Wales between 1918 and 2011.\\n\\nSummarise the information by selecting and reporting the main features, and make comparisons where relevant.\\n\\nWrite at least 150 words.\\n\\n(Data summary for practice: Owned housing rose from about 23% in 1918 to a peak near 69% in 2001, then dipped slightly by 2011. Rented accommodation fell from roughly 77% to around 31% over the same long period, with a small rise after 2001.)"
  },
  {
    task: 2,
    title: "Academic Task 2 — Essay",
    prompt: "Some people think that the best way to reduce crime is to give longer prison sentences. Others believe there are better alternative ways of reducing crime.\\n\\nDiscuss both these views and give your own opinion.\\n\\nGive reasons for your answer and include any relevant examples from your own knowledge or experience.\\n\\nWrite at least 250 words."
  }
];

const IELTS_SPEAKING = [
  {
    part: 1,
    prompt: "Let's talk about your studies. What subjects are you studying? Why did you choose your major? What do you find most difficult about your course? Do you prefer studying alone or with others?"
  },
  {
    part: 2,
    prompt: "Describe a skill you would like to learn. You should say: what the skill is, why you want to learn it, how you would learn it, and explain how this skill might help you in the future.\\n\\nYou have 1 minute to prepare. Speak for 1–2 minutes."
  },
  {
    part: 3,
    prompt: "What kinds of skills are most important for young people in your country today? Has technology changed the skills people need at work? Should schools focus more on practical skills or academic knowledge? How can adults keep learning after they start working?"
  }
];

/* TOEFL Mock */
const TOEFL_READING = [
  {
    title: "Passage — Bioturbation in Marine Sediments",
    difficulty: "Hard (TOEFL-level)",
    text: "Bioturbation refers to the disturbance of sediment by living organisms such as worms, crustaceans and burrowing fish. This biological reworking mixes organic matter and minerals, influences oxygen penetration, and affects how quickly carbon is buried or returned to the water column. In coastal mudflats, intense bioturbation can enhance nutrient recycling and support productive food webs. Conversely, in deep-sea environments where food is scarce, bioturbation rates are lower but still critical for redistributing the limited organic material that reaches the seafloor. Human activities—bottom trawling, dredging and coastal construction—can either amplify or suppress natural bioturbation, with consequences for carbon sequestration and benthic biodiversity. Recent models suggest that protecting bioturbating communities may be an under-appreciated tool in climate-mitigation strategies that rely on blue-carbon ecosystems such as mangroves and seagrass meadows.",
    questions: [
      { q: "Bioturbation is best defined as?", opts: ["Chemical pollution only", "Sediment disturbance by living organisms", "Wave action alone", "Fishing quotas"], ans: 1 },
      { q: "Which organisms are mentioned as bioturbators?", opts: ["Only birds", "Worms, crustaceans, burrowing fish", "Only plankton", "Land mammals"], ans: 1 },
      { q: "In coastal mudflats, intense bioturbation can?", opts: ["Stop all life", "Enhance nutrient recycling", "Eliminate oxygen", "Freeze sediment"], ans: 1 },
      { q: "Deep-sea bioturbation rates are described as?", opts: ["Higher than coasts", "Lower but still critical", "Zero", "Illegal"], ans: 1 },
      { q: "Human activities listed include?", opts: ["Only swimming", "Bottom trawling, dredging, construction", "Reading", "Photography only"], ans: 1 },
      { q: "Blue-carbon ecosystems mentioned?", opts: ["Deserts", "Mangroves and seagrass meadows", "Mountains", "Cities"], ans: 1 },
      { q: "Protecting bioturbators may help?", opts: ["Only tourism ads", "Climate-mitigation via carbon sequestration", "Increase trawling", "Remove oxygen"], ans: 1 },
      { q: "Bioturbation affects oxygen?", opts: ["Never", "By influencing oxygen penetration", "Only on land", "Only in space"], ans: 1 },
      { q: "Organic matter in the deep sea is?", opts: ["Abundant", "Limited", "Infinite", "Only plastic"], ans: 1 },
      { q: "The passage suggests models about?", opts: ["Ignoring bioturbation", "Protecting bioturbating communities", "Banning science", "Ending all fishing tomorrow only"], ans: 1 }
    ]
  },
  {
    title: "Passage — Cognitive Load in Digital Learning",
    difficulty: "Hard",
    text: "Cognitive load theory distinguishes intrinsic load (complexity of the material), extraneous load (poor instructional design), and germane load (effort devoted to schema building). When online courses flood learners with animations, pop-ups and simultaneous narration plus text, extraneous load rises and learning suffers. Studies comparing segmented video lessons with continuous lectures find better retention when students control pacing and pause to summarise. Dual-coding theory further suggests that well-aligned verbal and visual channels can expand effective working-memory capacity, but redundant on-screen text that duplicates speech often harms rather than helps. Designers are therefore advised to eliminate non-essential visuals, signal key structures, and align spoken words with corresponding diagrams in time. For assessment, frequent low-stakes retrieval practice reduces load during final exams by strengthening long-term memory traces in advance.",
    questions: [
      { q: "Intrinsic load refers to?", opts: ["Poor design", "Complexity of the material", "Only animations", "Exam stress only"], ans: 1 },
      { q: "Extraneous load is caused by?", opts: ["Good design", "Poor instructional design", "Student motivation only", "Sleep"], ans: 1 },
      { q: "Germane load relates to?", opts: ["Distraction", "Schema building effort", "Ignoring content", "Noise"], ans: 1 },
      { q: "Segmented video lessons often yield?", opts: ["Worse retention", "Better retention when students control pacing", "No difference", "Only entertainment"], ans: 1 },
      { q: "Redundant on-screen text that duplicates speech often?", opts: ["Helps always", "Harms learning", "Is required by law", "Increases germane load only"], ans: 1 },
      { q: "Designers should eliminate?", opts: ["All diagrams", "Non-essential visuals", "All speech", "Assessments"], ans: 1 },
      { q: "Dual-coding involves?", opts: ["Only text", "Verbal and visual channels", "Only audio silence", "One channel only"], ans: 1 },
      { q: "Low-stakes retrieval practice helps by?", opts: ["Increasing panic", "Strengthening long-term memory before finals", "Removing all tests", "Adding pop-ups"], ans: 1 },
      { q: "Signaling key structures is advised to?", opts: ["Confuse learners", "Support learning design", "Raise extraneous load only", "Ban videos"], ans: 1 },
      { q: "Working memory is mentioned in relation to?", opts: ["Infinite capacity always", "Dual-coding expanding effective capacity", "Only sleep", "Ignoring visuals"], ans: 1 }
    ]
  }
];

const TOEFL_LISTENING = [
  {
    title: "Conversation — Office Hours",
    difficulty: "Medium",
    script: "Student: Professor Lee, I wanted to ask about the research paper outline. I'm struggling to narrow my topic on renewable energy policy. Professor: You might focus on one country or one technology, for example solar feed-in tariffs in Germany. Student: That helps. Is it acceptable to use policy briefs from government websites? Professor: Yes, as long as you evaluate them critically and balance them with peer-reviewed sources. The draft is due in two weeks, and peer review happens the week after. Student: Could I get an extension if my data request is delayed? Professor: Only if you email me before the deadline with documentation. Otherwise the late policy applies—five percent per day.",
    questions: [
      { q: "What is the student's problem?", opts: ["Finding the classroom", "Narrowing the research topic", "Paying fees", "Missing a test"], ans: 1 },
      { q: "Professor suggests focusing on?", opts: ["Every country", "One country or one technology", "Only history", "No topic"], ans: 1 },
      { q: "Example topic mentioned?", opts: ["Coal in Australia", "Solar feed-in tariffs in Germany", "Oil prices only", "Nuclear fusion"], ans: 1 },
      { q: "Government policy briefs are?", opts: ["Banned", "Acceptable with critical evaluation + peer-reviewed sources", "The only sources allowed", "Required exclusively"], ans: 1 },
      { q: "Draft due in?", opts: ["Two days", "Two weeks", "Two months", "Next year"], ans: 1 },
      { q: "Extension possible if?", opts: ["Never", "Email before deadline with documentation", "Ask after deadline", "Always automatic"], ans: 1 },
      { q: "Late penalty?", opts: ["None", "Five percent per day", "Fifty percent flat", "Resubmit free"], ans: 1 }
    ]
  },
  {
    title: "Lecture — Urban Heat Islands",
    difficulty: "Hard",
    script: "Today we discuss the urban heat island effect: cities tend to be warmer than surrounding rural areas. Dark surfaces such as asphalt absorb and re-radiate heat, while reduced vegetation means less cooling from evapotranspiration. Waste heat from vehicles and air conditioning adds to the load. Night-time temperatures often show the greatest rural–urban difference because rural areas cool faster under clear skies. Mitigation strategies include reflective cool roofs, urban tree canopy expansion, and permeable pavements. Some cities have measured temperature reductions of one to two degrees Celsius in neighbourhoods where these measures are combined. Public health matters because heatwaves amplified by urban heat islands increase hospital admissions for cardiovascular and respiratory conditions, especially among the elderly.",
    questions: [
      { q: "Urban heat islands mean cities are?", opts: ["Colder than rural areas", "Warmer than surrounding rural areas", "The same temperature", "Always rainy"], ans: 1 },
      { q: "Dark asphalt tends to?", opts: ["Reflect all heat", "Absorb and re-radiate heat", "Create ice", "Cool the air always"], ans: 1 },
      { q: "Less vegetation means less cooling from?", opts: ["Traffic", "Evapotranspiration", "Street lights", "Subways"], ans: 1 },
      { q: "Greatest rural–urban difference often at?", opts: ["Noon only", "Night-time", "Sunrise only", "Winter only"], ans: 1 },
      { q: "Mitigation includes?", opts: ["More asphalt only", "Cool roofs, trees, permeable pavements", "Removing all parks", "Banning AC only without alternatives"], ans: 1 },
      { q: "Combined measures have reduced temps by about?", opts: ["10–20°C", "1–2°C", "0.01°C", "50°C"], ans: 1 },
      { q: "Heatwaves in cities especially affect?", opts: ["Only athletes", "Elderly regarding heart and respiratory admissions", "No one", "Only tourists"], ans: 1 },
      { q: "Waste heat sources mentioned?", opts: ["Only oceans", "Vehicles and air conditioning", "Only forests", "Snow"], ans: 1 }
    ]
  }
];

const TOEFL_SPEAKING = [
  {
    task: 1,
    prompt: "Some people prefer to study in the morning; others prefer the evening. Which do you prefer and why? Speak for about 45 seconds. Use specific reasons and examples."
  },
  {
    task: 2,
    prompt: "Do you agree or disagree with the following statement? It is more important for students to understand ideas and concepts than it is for them to learn facts. Use details and examples in your response."
  },
  {
    task: 3,
    prompt: "Integrated style: A university plans to close the small campus bookstore and rely only on online ordering. Explain how the man feels about this plan and why. (In practice, summarise a short reading + conversation; for this demo, argue both student concerns: loss of immediate access vs convenience of online prices.)"
  },
  {
    task: 4,
    prompt: "Integrated style: Using points from a lecture on 'keystone species', explain what a keystone species is and give one example of how its removal affects an ecosystem."
  }
];

const TOEFL_WRITING = [
  {
    task: "integrated",
    title: "Integrated Writing",
    prompt: "Reading passage (summary): Online education is cheaper, more flexible, and equally effective as in-person learning according to several studies.\\n\\nLecture (summary): The professor challenges these points—dropout rates are higher online, lab sciences suffer without physical facilities, and employers in some fields still prefer traditional degrees.\\n\\nQuestion: Summarise the points made in the lecture, explaining how they cast doubt on the points in the reading. Write 150–225 words."
  },
  {
    task: "independent",
    title: "Independent Writing",
    prompt: "Do you agree or disagree with the following statement?\\n\\nGrades (marks) encourage students to learn.\\n\\nUse specific reasons and examples to support your answer. Write at least 300 words."
  }
];

function shuffle(array) {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function getRandomItems(arr, n) {
  return shuffle(arr).slice(0, n);
}

/* ========== STRUCTURED LEARN PATH ========== */
const LEARN_PATH_LEGACY = {
  beginner: [
    {
      id: "beg-1",
      title: "Unit 1: Greetings & Introductions",
      desc: "Memperkenalkan diri, sapaan formal & informal",
      tags: ["Speaking", "Vocab"],
      content: {
        type: "mixed",
        theory: "Dalam Bahasa Inggris, sapaan berubah tergantung formalitas. 'Hi/Hey' informal; 'Good morning/How do you do' lebih formal.",
        vocab: [
          { en: "Nice to meet you", id: "Senang bertemu denganmu", ex: "Nice to meet you, I'm Andi." },
          { en: "Where are you from?", id: "Kamu dari mana?", ex: "Where are you from? I'm from Jakarta." },
          { en: "What do you do?", id: "Apa pekerjaanmu?", ex: "What do you do? I'm a student." },
          { en: "Have a nice day", id: "Semoga harimu menyenangkan", ex: "Bye! Have a nice day." }
        ],
        practice: "Perkenalkan dirimu dalam 4–5 kalimat: nama, asal, jurusan, hobi."
      }
    },
    {
      id: "beg-2",
      title: "Unit 2: Daily Routines",
      desc: "Present Simple untuk kebiasaan sehari-hari",
      tags: ["Grammar", "Vocab"],
      content: {
        type: "mixed",
        theory: "Present Simple: I/You/We/They + V1; He/She/It + V1+s/es. Dipakai untuk rutinitas dan fakta.",
        vocab: [
          { en: "wake up", id: "bangun tidur", ex: "I wake up at 6 AM." },
          { en: "commute", id: "pergi kerja/kuliah", ex: "She commutes by bus." },
          { en: "usually", id: "biasanya", ex: "I usually study in the evening." },
          { en: "rarely", id: "jarang", ex: "He rarely eats fast food." }
        ],
        practice: "Tulis 5 kalimat tentang rutinitas harianmu memakai Present Simple."
      }
    },
    {
      id: "beg-3",
      title: "Unit 3: Numbers, Time & Dates",
      desc: "Menyebut waktu, tanggal, dan angka",
      tags: ["Listening", "Vocab"],
      content: {
        type: "mixed",
        theory: "Waktu: It's half past three (15:30). Tanggal: the 22nd of October. Tahun dibaca dua-dua: twenty twenty-six.",
        vocab: [
          { en: "quarter past", id: "15 menit lewat", ex: "It's quarter past nine." },
          { en: "quarter to", id: "15 menit menuju", ex: "It's quarter to ten." },
          { en: "appointment", id: "janji temu", ex: "I have an appointment at 2 PM." },
          { en: "deadline", id: "batas waktu", ex: "The deadline is next Friday." }
        ],
        practice: "Ucapkan 3 janji imajiner dengan hari dan jam yang berbeda."
      }
    },
    {
      id: "beg-4",
      title: "Unit 4: Describing People & Places",
      desc: "Adjective dasar + there is/are",
      tags: ["Writing", "Vocab"],
      content: {
        type: "mixed",
        theory: "Urutan adjective kasar: opinion → size → age → color. There is (singular) / There are (plural).",
        vocab: [
          { en: "crowded", id: "ramai/penuh", ex: "The campus is crowded in the morning." },
          { en: "spacious", id: "luas", ex: "Our classroom is spacious." },
          { en: "friendly", id: "ramah", ex: "The lecturers are friendly." },
          { en: "convenient", id: "praktis/nyaman", ex: "The dorm is convenient for students." }
        ],
        practice: "Deskripsikan kampus atau kosanmu dalam 6–8 kalimat."
      }
    },
    {
      id: "beg-5",
      title: "Unit 5: Shopping & Food",
      desc: "Dialog di kafe, restoran, toko",
      tags: ["Speaking", "Listening"],
      content: {
        type: "mixed",
        theory: "Pola order: I'd like... / Can I have... / Could I get... Polite request memakai could/would.",
        vocab: [
          { en: "I'd like...", id: "Saya mau...", ex: "I'd like a iced coffee, please." },
          { en: "bill / check", id: "tagihan", ex: "Could I have the bill, please?" },
          { en: "take away", id: "bungkus", ex: "For here or take away?" },
          { en: "change", id: "kembalian", ex: "Here's your change." }
        ],
        practice: "Simulasikan memesan makanan di kafe (4–6 giliran dialog)."
      }
    }
  ],
  intermediate: [
    {
      id: "int-1",
      title: "Unit 1: Past Experiences",
      desc: "Past Simple vs Present Perfect",
      tags: ["Grammar", "Speaking"],
      content: {
        type: "mixed",
        theory: "Past Simple = waktu spesifik selesai. Present Perfect = pengalaman / masih relevan tanpa waktu spesifik.",
        vocab: [
          { en: "have you ever...", id: "pernahkah kamu...", ex: "Have you ever been abroad?" },
          { en: "recently", id: "baru-baru ini", ex: "I've recently started yoga." },
          { en: "in the past", id: "di masa lalu", ex: "In the past, I lived in Bandung." },
          { en: "milestone", id: "tonggak penting", ex: "Graduating was a major milestone." }
        ],
        practice: "Ceritakan 2 pengalaman penting: satu dengan Past Simple, satu Present Perfect."
      }
    },
    {
      id: "int-2",
      title: "Unit 2: Opinions & Arguments",
      desc: "Memberi pendapat + supporting reasons",
      tags: ["Writing", "Speaking"],
      content: {
        type: "mixed",
        theory: "Struktur opini: claim → reason → example → mini-conclusion. Gunakan I believe / In my view / It seems that...",
        vocab: [
          { en: "from my perspective", id: "dari sudut pandang saya", ex: "From my perspective, online classes are flexible." },
          { en: "on the other hand", id: "di sisi lain", ex: "On the other hand, face-to-face is more interactive." },
          { en: "compelling", id: "meyakinkan", ex: "That's a compelling argument." },
          { en: "drawback", id: "kekurangan", ex: "One drawback is the cost." }
        ],
        practice: "Tulis paragraf opini: 'Should university be free?' (80–120 kata)."
      }
    },
    {
      id: "int-3",
      title: "Unit 3: Academic Reading Skills",
      desc: "Skimming, scanning, inference",
      tags: ["Reading"],
      content: {
        type: "mixed",
        theory: "Skimming = ide utama cepat. Scanning = cari detail spesifik. Inference = simpulkan yang tidak tertulis eksplisit.",
        vocab: [
          { en: "main idea", id: "ide pokok", ex: "The main idea of the paragraph is..." },
          { en: "supporting detail", id: "detail pendukung", ex: "Find two supporting details." },
          { en: "infer", id: "menyimpulkan", ex: "We can infer that the author disagrees." },
          { en: "tone", id: "nada tulisan", ex: "The tone is critical but fair." }
        ],
        practice: "Baca satu artikel pendek berita, tulis main idea + 2 detail + 1 inference."
      }
    },
    {
      id: "int-4",
      title: "Unit 4: Conditionals in Real Life",
      desc: "Type 0, 1, 2 untuk situasi nyata & hipotetis",
      tags: ["Grammar", "Speaking"],
      content: {
        type: "mixed",
        theory: "Type 1: real future (If + present, will). Type 2: unreal now (If + past, would). Type 0: facts (If + present, present).",
        vocab: [
          { en: "provided that", id: "asalkan", ex: "You can join provided that you register." },
          { en: "unless", id: "kecuali jika", ex: "I won't go unless it stops raining." },
          { en: "suppose", id: "andaikan", ex: "Suppose you won the lottery, what would you do?" },
          { en: "as long as", id: "selama", ex: "You can stay as long as you help." }
        ],
        practice: "Buat 2 kalimat Type 1 dan 2 Type 2 tentang rencana kuliah/karier."
      }
    },
    {
      id: "int-5",
      title: "Unit 5: Email & Formal Writing",
      desc: "Struktur email formal untuk dosen/HR",
      tags: ["Writing"],
      content: {
        type: "mixed",
        theory: "Formal email: Subject jelas → Salutation → Purpose → Body → Polite close → Sign-off (Best regards).",
        vocab: [
          { en: "I am writing to...", id: "Saya menulis untuk...", ex: "I am writing to inquire about..." },
          { en: "I would appreciate it if...", id: "Saya akan menghargai jika...", ex: "I would appreciate it if you could reply by Friday." },
          { en: "Please find attached", id: "Terlampir", ex: "Please find attached my CV." },
          { en: "at your earliest convenience", id: "secepatnya bila memungkinkan", ex: "Please respond at your earliest convenience." }
        ],
        practice: "Tulis email formal ke dosen meminta rekomendasi magang (120–150 kata)."
      }
    }
  ],
  advanced: [
    {
      id: "adv-1",
      title: "Unit 1: Academic Vocabulary",
      desc: "Academic Word List — subset penting",
      tags: ["Vocab", "Writing"],
      content: {
        type: "mixed",
        theory: "Kata akademik sering dari Latin/Greek. Gunakan nominalization: decide → decision, analyze → analysis.",
        vocab: [
          { en: "significant", id: "penting/bermakna", ex: "There was a significant increase in enrollment." },
          { en: "constitute", id: "merupakan", ex: "These factors constitute a major challenge." },
          { en: "imply", id: "menyiratkan", ex: "The data imply a causal relationship." },
          { en: "framework", id: "kerangka", ex: "We need a theoretical framework." },
          { en: "subsequent", id: "berikutnya", ex: "Subsequent studies confirmed the findings." },
          { en: "robust", id: "kuat/andal", ex: "The methodology is robust." }
        ],
        practice: "Tulis 5 kalimat akademik memakai minimal 5 kata di atas."
      }
    },
    {
      id: "adv-2",
      title: "Unit 2: Essay Structure (IELTS Task 2)",
      desc: "Intro – Body – Conclusion yang band 7+",
      tags: ["Writing"],
      content: {
        type: "mixed",
        theory: "Intro: paraphrase + thesis. Body: topic sentence + explain + example. Conclusion: ringkas stance, no new ideas.",
        vocab: [
          { en: "it is widely argued that", id: "banyak yang berpendapat bahwa", ex: "It is widely argued that technology improves education." },
          { en: "a case in point", id: "contoh yang relevan", ex: "A case in point is Finland's education system." },
          { en: "to a large extent", id: "sebagian besar", ex: "To a large extent, success depends on motivation." },
          { en: "nonetheless", id: "meskipun demikian", ex: "Nonetheless, challenges remain." }
        ],
        practice: "Outline essay 4 paragraf untuk: 'Is remote work better for productivity?'"
      }
    },
    {
      id: "adv-3",
      title: "Unit 3: Listening for Detail & Attitude",
      desc: "Ciri IELTS/TOEFL listening tingkat tinggi",
      tags: ["Listening"],
      content: {
        type: "mixed",
        theory: "Dengarkan signal: however, actually, what I mean is... Attitude: positive/negative/neutral dari tone & word choice.",
        vocab: [
          { en: "to put it another way", id: "dengan kata lain", ex: "To put it another way, we need more data." },
          { en: "frankly", id: "terus terang", ex: "Frankly, the results were disappointing." },
          { en: "underestimate", id: "meremehkan", ex: "Don't underestimate the difficulty." },
          { en: "nuance", id: "nuansa", ex: "There is an important nuance here." }
        ],
        practice: "Dengarkan satu podcast singkat (English), catat 3 detail + attitude pembicara."
      }
    },
    {
      id: "adv-4",
      title: "Unit 4: Complex Grammar for Band 7+",
      desc: "Relative clauses, inversion, conditionals type 3",
      tags: ["Grammar", "Writing"],
      content: {
        type: "mixed",
        theory: "Inversion: Not only... but also / Rarely have I... Type 3: If + past perfect, would have + V3.",
        vocab: [
          { en: "whereby", id: "yang dengannya", ex: "a system whereby students choose courses" },
          { en: "albeit", id: "meskipun", ex: "The plan worked, albeit slowly." },
          { en: "notwithstanding", id: "meski ada", ex: "Notwithstanding the risks, they proceeded." },
          { en: "insofar as", id: "sejauh", ex: "Insofar as the data allow, we conclude..." }
        ],
        practice: "Tulis 3 kalimat memakai relative clause non-defining dan 1 kalimat inversion."
      }
    },
    {
      id: "adv-5",
      title: "Unit 5: Speaking Fluency Strategies",
      desc: "Fillers alami, paraphrase, extend answers",
      tags: ["Speaking"],
      content: {
        type: "mixed",
        theory: "Hindari diam panjang: gunakan 'That's an interesting question...' / 'What I mean is...'. Extend: reason + example + contrast.",
        vocab: [
          { en: "off the top of my head", id: "secara spontan", ex: "Off the top of my head, I'd say..." },
          { en: "to be honest", id: "terus terang", ex: "To be honest, I haven't thought about it much." },
          { en: "it depends", id: "tergantung", ex: "It depends on the context." },
          { en: "for instance", id: "contohnya", ex: "For instance, in my hometown..." }
        ],
        practice: "Jawab 1 menit: 'Describe a skill you want to learn and why.'"
      }
    }
  ],
  pro: [
    {
      id: "pro-1",
      title: "Unit 1: Rhetorical Precision",
      desc: "Hedging, boosting, stance markers",
      tags: ["Writing", "Academic"],
      content: {
        type: "mixed",
        theory: "Hedging: may, might, appear to, it is likely that. Boosting: clearly, undoubtedly (pakai hemat). Stance menunjukkan posisi penulis.",
        vocab: [
          { en: "arguably", id: "bisa dibilang", ex: "Arguably, this is the most effective method." },
          { en: "tentatively", id: "secara sementara", ex: "We tentatively conclude that..." },
          { en: "it stands to reason", id: "masuk akal bahwa", ex: "It stands to reason that demand will rise." },
          { en: "caveat", id: "catatan/pembatas", ex: "One caveat is the small sample size." }
        ],
        practice: "Ubah 3 klaim kuat menjadi versi ber-hedging yang akademik."
      }
    },
    {
      id: "pro-2",
      title: "Unit 2: IELTS/TOEFL Score Push",
      desc: "Strategi band 8 / TOEFL 110+",
      tags: ["Exam"],
      content: {
        type: "mixed",
        theory: "Band 8 writing: rare errors, precise vocab, fully developed ideas. Speaking: flexible structures, natural pace, clear pronunciation.",
        vocab: [
          { en: "calibrated", id: "terselaras", ex: "a carefully calibrated argument" },
          { en: "salient", id: "menonjol/penting", ex: "the most salient point" },
          { en: "nuance", id: "nuansa", ex: "appreciate the nuance" },
          { en: "articulate", id: "mengungkapkan dengan jelas", ex: "She articulated her position clearly." }
        ],
        practice: "Revisi satu paragraph essay lama: ganti 5 kata biasa dengan pilihan lebih precise."
      }
    },
    {
      id: "pro-3",
      title: "Unit 3: Debate & Critical Response",
      desc: "Menanggapi argumen lawan secara elegan",
      tags: ["Speaking", "Writing"],
      content: {
        type: "mixed",
        theory: "Concession + rebuttal: 'While it is true that..., this overlooks...' Steelman lawan dulu, baru kritik.",
        vocab: [
          { en: "on the contrary", id: "sebaliknya", ex: "On the contrary, the evidence suggests..." },
          { en: "this overlooks", id: "ini mengabaikan", ex: "This overlooks demographic change." },
          { en: "a more plausible explanation", id: "penjelasan lebih masuk akal", ex: "A more plausible explanation is..." },
          { en: "granting that", id: "meski mengakui bahwa", ex: "Granting that costs are high, benefits outweigh them." }
        ],
        practice: "Tulis rebuttal 100 kata terhadap: 'Social media only harms students.'"
      }
    },
    {
      id: "pro-4",
      title: "Unit 4: Style & Register Control",
      desc: "Beralih formal ↔ semi-formal dengan tepat",
      tags: ["Writing"],
      content: {
        type: "mixed",
        theory: "Academic: avoid contractions, phrasal verbs berlebih, dan 'get'. Prefer: obtain, demonstrate, indicate, constitute.",
        vocab: [
          { en: "get better → improve", id: "menjadi lebih baik", ex: "Results improved significantly." },
          { en: "find out → determine", id: "menemukan", ex: "The study determined the cause." },
          { en: "a lot of → a substantial number of", id: "banyak", ex: "A substantial number of participants..." },
          { en: "about → approximately", id: "kira-kira", ex: "Approximately 40% agreed." }
        ],
        practice: "Ubah paragraf informal menjadi register akademik (min. 80 kata)."
      }
    }
  ]
};

const VOCAB_BANK = {
  beginner: [
    { en: "appointment", id: "janji temu", ex: "I have an appointment at 3." },
    { en: "borrow", id: "meminjam", ex: "Can I borrow your pen?" },
    { en: "careful", id: "hati-hati", ex: "Be careful on the road." },
    { en: "delicious", id: "enak", ex: "This food is delicious." },
    { en: "emergency", id: "darurat", ex: "Call 119 in an emergency." },
    { en: "furniture", id: "perabot", ex: "We need new furniture." },
    { en: "generous", id: "dermawan", ex: "She is very generous." },
    { en: "hungry", id: "lapar", ex: "I'm hungry after class." },
    { en: "invite", id: "mengundang", ex: "I'd like to invite you." },
    { en: "journey", id: "perjalanan", ex: "Have a safe journey." }
  ],
  intermediate: [
    { en: "achieve", id: "mencapai", ex: "She achieved her goals." },
    { en: "benefit", id: "manfaat", ex: "Exercise has many benefits." },
    { en: "consequence", id: "akibat", ex: "Think about the consequences." },
    { en: "efficient", id: "efisien", ex: "This method is more efficient." },
    { en: "frequent", id: "sering", ex: "He makes frequent trips." },
    { en: "indicate", id: "menunjukkan", ex: "The results indicate progress." },
    { en: "maintain", id: "mempertahankan", ex: "Maintain a healthy diet." },
    { en: "opportunity", id: "kesempatan", ex: "This is a great opportunity." },
    { en: "prefer", id: "lebih suka", ex: "I prefer tea to coffee." },
    { en: "require", id: "memerlukan", ex: "The job requires experience." }
  ],
  advanced: [
    { en: "ambiguous", id: "ambigu", ex: "The statement is ambiguous." },
    { en: "compel", id: "memaksa/mendesak", ex: "The evidence compelled him to act." },
    { en: "diminish", id: "berkurang", ex: "Trust can diminish quickly." },
    { en: "elaborate", id: "merinci", ex: "Could you elaborate on that?" },
    { en: "feasible", id: "layak dilakukan", ex: "Is this plan feasible?" },
    { en: "hypothesis", id: "hipotesis", ex: "We tested the hypothesis." },
    { en: "inevitable", id: "tidak terelakkan", ex: "Change is inevitable." },
    { en: "justify", id: "membenarkan", ex: "How do you justify this decision?" },
    { en: "notion", id: "gagasan", ex: "The notion of freedom varies." },
    { en: "reluctant", id: "enggan", ex: "He was reluctant to agree." }
  ],
  pro: [
    { en: "albeit", id: "meskipun", ex: "The plan worked, albeit slowly." },
    { en: "corollary", id: "akibat wajar", ex: "A corollary of the theory is..." },
    { en: "ephemeral", id: "sementara/fana", ex: "Fame can be ephemeral." },
    { en: "juxtapose", id: "menjajarkan", ex: "The film juxtaposes past and present." },
    { en: "nuance", id: "nuansa", ex: "Appreciate the nuance in her argument." },
    { en: "paradigm", id: "paradigma", ex: "A new paradigm in education." },
    { en: "pragmatic", id: "pragmatis", ex: "We need a pragmatic solution." },
    { en: "quintessential", id: "paling khas", ex: "She is the quintessential leader." },
    { en: "substantiate", id: "membuktikan", ex: "Can you substantiate this claim?" },
    { en: "ubiquitous", id: "ada di mana-mana", ex: "Smartphones are ubiquitous." }
  ]
};


// Expand curriculum — more units per level

// expandLearnPath disabled — CEFR curriculum in curriculum.js
