/**
 * LinguaPro CEFR Curriculum
 * A1 → A2 → B1 → B2 → C1 → C2
 * Each unit: objectives, deep theory, examples, errors, vocab, dialogue,
 * guided + independent practice, evaluation, remedial hints
 */

const CEFR_ORDER = ["a1", "a2", "b1", "b2", "c1", "c2"];

const CEFR_META = {
  a1: {
    label: "Beginner (A1)",
    goal: "Memahami dan memakai ungkapan sehari-hari sangat dasar: perkenalan, needs sederhana, percakapan lambat.",
    prereq: null
  },
  a2: {
    label: "Elementary (A2)",
    goal: "Rutinitas, pengalaman singkat, deskripsi sederhana tentang keluarga, belanja, pekerjaan, perjalanan.",
    prereq: "a1"
  },
  b1: {
    label: "Intermediate (B1)",
    goal: "Menangani situasi travel, opini sederhana, narasi kejadian, teks factual singkat.",
    prereq: "a2"
  },
  b2: {
    label: "Upper-Intermediate (B2)",
    goal: "Argumen terstruktur, teks kompleks umum, interaksi spontan dengan penutur native.",
    prereq: "b1"
  },
  c1: {
    label: "Advanced (C1)",
    goal: "Bahasa fleksibel untuk akademik/profesional, teks panjang, nuance, register.",
    prereq: "b2"
  },
  c2: {
    label: "Proficiency (C2)",
    goal: "Hampir native-like: ringkas, presisi, idiom, wacana akademik/profesional tingkat tinggi.",
    prereq: "c1"
  }
};

/** Pass threshold for unit evaluation (0–1) */
const UNIT_PASS_SCORE = 0.8;

const LEARN_PATH = {
  a1: [
    {
      id: "a1-u01",
      title: "Unit 1: Alphabet, Sounds & Basic Pronunciation",
      desc: "Huruf, bunyi dasar, dan cara membaca kata sederhana",
      tags: ["Pronunciation", "Foundation"],
      content: {
        objectives: [
          "Mengenali 26 huruf alfabet English dan bunyi dasar",
          "Membedakan vowel pendek vs panjang pada kata sederhana",
          "Mengeja nama dan kata umum dengan keras"
        ],
        orientation: "Sebelum grammar, kamu perlu bisa membaca dan mengucapkan huruf. Unit ini fondasi A1 — jangan dilewati.",
        theory: `<p><strong>Alphabet English</strong> punya 26 huruf: A–Z. Nama huruf berbeda dari cara membacanya dalam kata.</p>
<p>Contoh: huruf <em>A</em> namanya /eɪ/, tapi dalam kata <em>cat</em> berbunyi /æ/.</p>
<p><strong>Vowels (vokal):</strong> A E I O U — sering berubah bunyi. <strong>Consonants:</strong> huruf lain.</p>
<p><strong>Stress:</strong> dalam kata 2 suku kata, biasanya suku kata pertama lebih kuat: <em>TA-ble</em>, <em>WIN-dow</em>.</p>
<p>Latih: ucapkan pelan → normal. Rekam suara sendiri jika bisa.</p>`,
        rules: [
          "Ucapkan nama huruf berbeda dari bunyi dalam kata",
          "Vowel panjang sering diikuti silent e: cake /keɪk/",
          "Huruf C: /k/ sebelum a/o/u (cat), /s/ sebelum e/i/y (city)"
        ],
        examples: [
          { en: "A B C D E", id: "Ei-bi-si-di-i", why: "Ini nama huruf, bukan bunyi dalam kata." },
          { en: "cat — /kæt/", id: "kucing", why: "A pendek /æ/, bukan /eɪ/." },
          { en: "name — /neɪm/", id: "nama", why: "A panjang karena pola vowel + consonant + e." },
          { en: "ship vs sheep", id: "kapal vs domba", why: "/ɪ/ pendek vs /iː/ panjang — beda arti." }
        ],
        compare: "<strong>/ɪ/ vs /iː/</strong>: ship (kapal) ≠ sheep (domba). <strong>/æ/ vs /e/</strong>: bag ≠ beg.",
        commonErrors: [
          { wrong: "Mengucapkan 'name' seperti 'nam'", right: "name /neɪm/", why: "A di open syllable sering diftong /eɪ/." },
          { wrong: "Mengeja C-A-T sebagai 'ce-a-te'", right: "C-A-T = /siː/ /eɪ/ /tiː/", why: "Pakai nama huruf English, bukan ejaan Indonesia." }
        ],
        vocab: [
          { en: "letter", id: "huruf", ipa: "/ˈletər/", ex: "How many letters are in the alphabet?", exId: "Ada berapa huruf dalam alfabet?" },
          { en: "alphabet", id: "alfabet", ipa: "/ˈælfəbet/", ex: "The English alphabet has 26 letters.", exId: "Alfabet English punya 26 huruf." },
          { en: "spell", id: "mengeja", ipa: "/spel/", ex: "Please spell your name.", exId: "Tolong eja namamu." },
          { en: "vowel", id: "huruf vokal", ipa: "/ˈvaʊəl/", ex: "A, E, I, O, and U are vowels.", exId: "A, E, I, O, dan U adalah vokal." },
          { en: "consonant", id: "huruf konsonan", ipa: "/ˈkɒnsənənt/", ex: "B is a consonant.", exId: "B adalah konsonan." },
          { en: "sound", id: "bunyi", ipa: "/saʊnd/", ex: "This sound is long.", exId: "Bunyi ini panjang." },
          { en: "pronounce", id: "mengucapkan", ipa: "/prəˈnaʊns/", ex: "How do you pronounce this word?", exId: "Bagaimana cara mengucapkan kata ini?" },
          { en: "pronunciation", id: "pelafalan", ipa: "/prəˌnʌnsiˈeɪʃn/", ex: "Check the pronunciation carefully.", exId: "Periksa pelafalan dengan saksama." },
          { en: "repeat", id: "mengulang", ipa: "/rɪˈpiːt/", ex: "Please repeat after me.", exId: "Tolong ulangi setelah saya." },
          { en: "slowly", id: "pelan-pelan", ipa: "/ˈsləʊli/", ex: "Can you say it slowly?", exId: "Bisakah kamu mengucapkannya pelan-pelan?" },
          { en: "clearly", id: "dengan jelas", ipa: "/ˈklɪəli/", ex: "Please speak clearly.", exId: "Tolong bicara dengan jelas." },
          { en: "name", id: "nama", ipa: "/neɪm/", ex: "What is your name?", exId: "Siapa namamu?" },
          { en: "word", id: "kata", ipa: "/wɜːd/", ex: "Spell this word, please.", exId: "Eja kata ini, tolong." },
          { en: "syllable", id: "suku kata", ipa: "/ˈsɪləbl/", ex: "Table has two syllables.", exId: "Table punya dua suku kata." },
          { en: "stress", id: "tekanan (pada suku kata)", ipa: "/stres/", ex: "The stress is on the first syllable.", exId: "Tekanannya di suku kata pertama." },
          { en: "silent", id: "tidak dilafalkan", ipa: "/ˈsaɪlənt/", ex: "The e in name is silent.", exId: "Huruf e di name tidak dilafalkan." },
          { en: "capital", id: "huruf kapital", ipa: "/ˈkæpɪtl/", ex: "Start with a capital letter.", exId: "Mulai dengan huruf kapital." },
          { en: "lowercase", id: "huruf kecil", ipa: "/ˈləʊəkeɪs/", ex: "Write it in lowercase.", exId: "Tulis dengan huruf kecil." },
          { en: "ship", id: "kapal", ipa: "/ʃɪp/", ex: "The ship is big.", exId: "Kapalnya besar. (bunyi /ɪ/ pendek)" },
          { en: "sheep", id: "domba", ipa: "/ʃiːp/", ex: "I see a sheep.", exId: "Saya melihat seekor domba. (bunyi /iː/ panjang)" }
        ],
        dialogues: [
          {
            title: "Menanyakan ejaan nama",
            lines: [
              { sp: "A", en: "Hi! What is your name?", id: "Hai! Siapa namamu?" },
              { sp: "B", en: "My name is Rina.", id: "Nama saya Rina." },
              { sp: "A", en: "How do you spell that?", id: "Bagaimana cara mengejanya?" },
              { sp: "B", en: "R-I-N-A.", id: "R-I-N-A." },
              { sp: "A", en: "Thank you!", id: "Terima kasih!" }
            ],
            tips: "Ungkapan kunci: How do you spell that? = Bagaimana mengejanya? Dipakai saat nama atau kata baru."
          },
          {
            title: "Meminta seseorang mengeja kata",
            lines: [
              { sp: "A", en: "How do you spell \"book\"?", id: "Bagaimana mengeja kata book?" },
              { sp: "B", en: "B-O-O-K.", id: "B-O-O-K." },
              { sp: "A", en: "Can you say it slowly, please?", id: "Bisakah kamu ucapkan pelan-pelan?" },
              { sp: "B", en: "Sure. B… O… O… K.", id: "Tentu. B… O… O… K." },
              { sp: "A", en: "Got it. Thanks!", id: "Mengerti. Terima kasih!" }
            ],
            tips: "Can you say it slowly, please? = permintaan sopan agar diucapkan pelan."
          },
          {
            title: "Mengklarifikasi bunyi huruf",
            lines: [
              { sp: "A", en: "Is this /ɪ/ or /iː/? Ship or sheep?", id: "Ini /ɪ/ atau /iː/? Ship atau sheep?" },
              { sp: "B", en: "It's /ɪ/. Ship — S-H-I-P.", id: "Ini /ɪ/. Ship — S-H-I-P." },
              { sp: "A", en: "And sheep?", id: "Kalau sheep?" },
              { sp: "B", en: "Sheep is /iː/. The vowel is longer.", id: "Sheep itu /iː/. Vokalnya lebih panjang." },
              { sp: "A", en: "Please repeat after me: ship, sheep.", id: "Tolong ulangi setelah saya: ship, sheep." },
              { sp: "B", en: "Ship. Sheep.", id: "Ship. Sheep." }
            ],
            tips: "Repeat after me = ulangi setelah saya. Berguna saat latihan pelafalan."
          }
        ],
        dialogue: "A: How do you spell \"book\"?\\nB: B-O-O-K.\\nA: Thank you.",
        vocabPractice: [
          { type: "match", q: "Arti dari \"spell\"?", options: ["mengeja", "huruf", "vokal", "pelan"], correct: 0, explain: "spell = mengeja." },
          { type: "match", q: "\"vowel\" artinya…", options: ["konsonan", "huruf vokal", "suku kata", "ejaan"], correct: 1, explain: "vowel = huruf vokal (A E I O U)." },
          { type: "match", q: "IPA /ʃiːp/ paling dekat dengan…", options: ["ship", "sheep", "shop", "shape"], correct: 1, explain: "/iː/ panjang = sheep." },
          { type: "gap", q: "Please ___ your name. (spell / letter / sound)", answer: "spell", explain: "spell your name = eja namamu." },
          { type: "gap", q: "A, E, I, O, U are ___.", answer: "vowels", explain: "vowels = vokal." },
          { type: "pron", q: "Mana pelafalan yang benar untuk \"name\"?", options: ["/næm/", "/neɪm/", "/niːm/", "/nɒm/"], correct: 1, explain: "name = /neɪm/ (vowel panjang + silent e)." },
          { type: "pron", q: "Minimal pair: mana yang berbunyi /ɪ/ pendek?", options: ["sheep", "ship", "sheet", "cheap"], correct: 1, explain: "ship = /ʃɪp/." },
          { type: "match", q: "\"Repeat after me\" artinya…", options: ["Tulis namamu", "Ulangi setelah saya", "Baca pelan", "Huruf kapital"], correct: 1, explain: "Permintaan menirukan ucapan." }
        ],
        dialoguePractice: [
          { q: "Seseorang bilang: \"My name is Budi.\" Respon terbaik untuk minta ejaan:", options: ["How do you spell that?", "What is book?", "Good night", "How many letters?"], correct: 0, explain: "How do you spell that? = minta ejaan." },
          { q: "Kamu ingin orang mengucapkan lebih pelan. Katakan:", options: ["Spell the alphabet", "Can you say it slowly, please?", "What is a vowel?", "Capital letter"], correct: 1, explain: "Can you say it slowly, please?" },
          { q: "Guru bilang: \"Please repeat after me.\" Artinya kamu harus…", options: ["Menulis huruf", "Menirukan ucapannya", "Menutup buku", "Menghitung sampai 26"], correct: 1, explain: "Menirukan / mengulang ucapan." }
        ],

        summary: "Hafalkan nama huruf. Latih minimal pairs (ship/sheep). Biasakan spell nama sendiri.",
        guided: [
          { q: "Nama huruf B dalam English adalah…", options: ["be", "bi", "/biː/", "ba"], correct: 2, explain: "Huruf B dibaca /biː/." },
          { q: "Kata mana yang punya vowel panjang /iː/?", options: ["ship", "sheep", "sit", "bit"], correct: 1, explain: "sheep = /ʃiːp/." },
          { q: "Cara mengeja 'cat' yang benar:", options: ["C-A-T", "K-A-T", "C-E-T", "S-A-T"], correct: 0, explain: "C-A-T." }
        ],
        independent: [
          { type: "spell", q: "Spell the word: TABLE", answer: "T-A-B-L-E", explain: "T-A-B-L-E" },
          { type: "choose", q: "ship dan sheep bedanya terutama pada…", options: ["konsonan awal", "panjang vokal", "jumlah huruf", "stress"], correct: 1, explain: "Panjang vokal /ɪ/ vs /iː/." }
        ],
        practice: "Ucapkan dan tulis ejaan: your full name, city, and three school items (pen, book, bag).",
        evaluation: [
          { q: "Alphabet English punya berapa huruf?", options: ["24", "25", "26", "28"], correct: 2, explain: "26 huruf." },
          { q: "Pilih minimal pair yang benar:", options: ["cat / cut sama bunyi", "ship / sheep beda vokal", "pen / pan sama total", "book / look tak ada vokal"], correct: 1, explain: "ship/sheep beda panjang vokal." },
          { q: "Spell 'pen':", options: ["P-E-N", "P-A-N", "B-E-N", "P-E-M"], correct: 0, explain: "P-E-N." },
          { q: "Silent e di 'name' membuat A berbunyi…", options: ["pendek /æ/", "panjang /eɪ/", "hilang", "/iː/"], correct: 1, explain: "Pola VCe → vowel panjang." },
          { q: "Mana yang benar?", options: ["I spell my name", "I spelling my name", "I spells my name", "I to spell name"], correct: 0, explain: "Present simple: I spell…" }
        ],
        remedial: "Ulangi daftar huruf A–Z dengan audio (YouTube: English alphabet). Latih 5 kata: cat, name, ship, sheep, book."
      }
    },
    {
      id: "a1-u02",
      title: "Unit 2: Greetings & Introductions",
      desc: "Salam, perkenalan diri, formal vs informal",
      tags: ["Speaking", "Vocabulary"],
      content: {
        objectives: [
          "Mengucapkan salam sesuai waktu dan situasi",
          "Memperkenalkan nama, asal, dan menanyakan lawan bicara",
          "Membalas 'How are you?' dengan natural"
        ],
        orientation: "Percakapan dimulai dari salam. Salah salam = terasa kaku. Unit ini melatih otomatisasi.",
        theory: `<p><strong>Greetings</strong> = salam. Pilih formal (kerja, orang tua, guru) atau informal (teman).</p>
<p><strong>Formal:</strong> Good morning / Good afternoon / Good evening. Good night = pamit tidur, bukan salam datang.</p>
<p><strong>Informal:</strong> Hi / Hey / Hello.</p>
<p><strong>Perkenalan:</strong> I'm … / My name is … → Nice to meet you. → Nice to meet you too.</p>
<p><strong>How are you?</strong> Jawaban umum: I'm fine, thanks. And you? — bukan hanya "fine" tanpa timbal balik.</p>`,
        rules: [
          "Good night ≠ salam saat baru bertemu malam hari (pakai Good evening)",
          "I'm = I am (kontraksi)",
          "Setelah Nice to meet you, balas Nice to meet you too"
        ],
        examples: [
          { en: "Good morning, Mr. Lee.", id: "Selamat pagi, Pak Lee.", why: "Formal + title." },
          { en: "Hi! I'm Rina.", id: "Hai! Aku Rina.", why: "Informal, langsung nama." },
          { en: "Nice to meet you.", id: "Senang berkenalan.", why: "Standar setelah perkenalan." },
          { en: "I'm fine, thank you. And you?", id: "Baik, terima kasih. Bagaimana denganmu?", why: "Jawaban lengkap + tanya balik." }
        ],
        compare: "<strong>Good evening</strong> (salam datang malam) vs <strong>Good night</strong> (pamit). <strong>How are you?</strong> (basa-basi) vs <strong>How do you do?</strong> (sangat formal, jarang).",
        commonErrors: [
          { wrong: "Good night, teacher! (saat masuk kelas malam)", right: "Good evening, teacher.", why: "Good night untuk berpisah/tidur." },
          { wrong: "I fine", right: "I'm fine", why: "Perlu linking verb be: I am fine." }
        ],
        vocab: [
          { en: "hello", id: "halo", ipa: "/həˈloʊ/", ex: "Hello, everyone." },
          { en: "goodbye", id: "selamat tinggal", ipa: "/ɡʊdˈbaɪ/", ex: "Goodbye!" },
          { en: "meet", id: "bertemu", ipa: "/miːt/", ex: "Nice to meet you." },
          { en: "fine", id: "baik-baik saja", ipa: "/faɪn/", ex: "I'm fine." }
        ],
        dialogue: `A: Good morning!\nB: Good morning! How are you?\nA: I'm fine, thanks. And you?\nB: I'm good. My name is Budi. Nice to meet you.\nA: I'm Sari. Nice to meet you too.`,
        summary: "Pilih salam sesuai waktu & formalitas. I'm + name. Balas How are you dengan lengkap.",
        guided: [
          { q: "Salam formal pagi hari:", options: ["Hey", "Good morning", "Good night", "Yo"], correct: 1, explain: "Good morning formal/netral." },
          { q: "Yang benar:", options: ["I fine", "I'm fine", "Me fine", "I is fine"], correct: 1, explain: "I'm = I am." },
          { q: "Setelah 'Nice to meet you', balasan terbaik:", options: ["OK", "Nice to meet you too", "Yes", "Hello"], correct: 1, explain: "too = juga." }
        ],
        independent: [
          { type: "write", q: "Tulis 3 baris perkenalan: salam + nama + Nice to meet you.", answer: "open", explain: "Contoh: Hi, I'm Andi. Nice to meet you." }
        ],
        practice: "Rekam 20 detik: sapa, sebut nama, tanya how are you, jawab.",
        evaluation: [
          { q: "Good night dipakai untuk…", options: ["salam pagi", "pamit tidur/berpisah", "perkenalan", "belanja"], correct: 1, explain: "Pamit." },
          { q: "Lengkapi: ___ name is Rina.", options: ["I", "My", "Me", "Mine"], correct: 1, explain: "My name is…" },
          { q: "Formal ke dosen:", options: ["Hey prof", "Good morning, Professor", "Yo", "Night"], correct: 1, explain: "Good morning + title." },
          { q: "I'm = ", options: ["I was", "I am", "I be", "I are"], correct: 1, explain: "kontraksi I am." },
          { q: "Pilih dialog yang natural setelah kenalan:", options: ["Nice to meet you. / Bye only", "Nice to meet you. / Nice to meet you too", "Hello. / Table", "Fine. / Cat"], correct: 1, explain: "Timbal balik." }
        ],
        remedial: "Hafalkan 4 salam (morning/afternoon/evening/hi) + template: Hi, I'm ___. Nice to meet you."
      }
    },
    {
      id: "a1-u03",
      title: "Unit 3: Subject Pronouns & Verb Be",
      desc: "I/you/he/she/it/we/they + am/is/are",
      tags: ["Grammar", "Foundation"],
      content: {
        objectives: [
          "Memakai subject pronouns dengan benar",
          "Memilih am / is / are sesuai subject",
          "Membuat kalimat positif, negatif, dan tanya dengan be"
        ],
        orientation: "Tanpa 'be', kamu tidak bisa bilang siapa/apa/di mana. Ini grammar A1 paling penting.",
        theory: `<p><strong>Subject pronouns:</strong> I, you, he, she, it, we, they — menggantikan nama orang/benda sebagai subjek.</p>
<p><strong>Verb be:</strong></p>
<ul>
<li>I <strong>am</strong> (I'm)</li>
<li>you/we/they <strong>are</strong> (you're, we're, they're)</li>
<li>he/she/it <strong>is</strong> (he's, she's, it's)</li>
</ul>
<p><strong>Negatif:</strong> am not / is not (isn't) / are not (aren't).</p>
<p><strong>Tanya:</strong> Am I…? Is she…? Are they…?</p>
<p>Fungsi be: identitas (I am a student), sifat (She is tall), lokasi (We are here).</p>`,
        rules: [
          "Jangan: He are / She am / They is",
          "It untuk benda, hewan (umum), atau situasi: It's sunny",
          "You selalu are (tunggal maupun jamak)"
        ],
        examples: [
          { en: "I am a student.", id: "Saya seorang siswa.", why: "I + am." },
          { en: "She is from Bandung.", id: "Dia (pr) dari Bandung.", why: "She + is." },
          { en: "They are not teachers.", id: "Mereka bukan guru.", why: "They + are + not." },
          { en: "Are you ready?", id: "Apakah kamu siap?", why: "Are + subject + adj." }
        ],
        compare: "<strong>is</strong> (he/she/it) vs <strong>are</strong> (you/we/they). <strong>I'm not</strong> (bukan I amn't).",
        commonErrors: [
          { wrong: "He are happy", right: "He is happy", why: "He → is." },
          { wrong: "I is student", right: "I am a student", why: "I → am; perlu article a." }
        ],
        vocab: [
          { en: "student", id: "siswa/mahasiswa", ipa: "/ˈstuːdnt/", ex: "I am a student." },
          { en: "teacher", id: "guru", ipa: "/ˈtiːtʃər/", ex: "She is a teacher." },
          { en: "happy", id: "senang", ipa: "/ˈhæpi/", ex: "We are happy." },
          { en: "ready", id: "siap", ipa: "/ˈredi/", ex: "Are you ready?" }
        ],
        dialogue: `A: Are you a student?\nB: Yes, I am. I'm a student at UNPAD.\nA: Is she your friend?\nB: Yes, she is. Her name is Dina.`,
        summary: "I am · he/she/it is · you/we/they are. Negatif + not. Tanya: Be + subject?",
        guided: [
          { q: "She ___ a doctor.", options: ["am", "is", "are", "be"], correct: 1, explain: "She + is." },
          { q: "I ___ not tired.", options: ["is", "are", "am", "be"], correct: 2, explain: "I am not." },
          { q: "___ they students?", options: ["Is", "Are", "Am", "Be"], correct: 1, explain: "Are they…?" }
        ],
        independent: [
          { type: "fill", q: "He ___ my brother. (be)", answer: "is", explain: "He is." },
          { type: "fill", q: "We ___ in class. (be)", answer: "are", explain: "We are." }
        ],
        practice: "Tulis 6 kalimat: 2 positif, 2 negatif, 2 tanya memakai be tentang dirimu dan teman.",
        evaluation: [
          { q: "They ___ at home.", options: ["is", "am", "are", "be"], correct: 2, explain: "They are." },
          { q: "___ I late?", options: ["Is", "Am", "Are", "Be"], correct: 1, explain: "Am I…?" },
          { q: "It ___ cold today.", options: ["are", "am", "is", "be"], correct: 2, explain: "It is." },
          { q: "Negatif dari 'She is here':", options: ["She not is here", "She isn't here", "She aren't here", "She am not here"], correct: 1, explain: "isn't = is not." },
          { q: "You and I → pronoun:", options: ["I", "you", "we", "they"], correct: 2, explain: "we." }
        ],
        remedial: "Tabel: I am, you are, he is, she is, it is, we are, they are. Tulis 10x lalu buat kalimat sendiri."
      }
    },
    {
      id: "a1-u04",
      title: "Unit 4: Nouns, A/An/The & Demonstratives",
      desc: "Kata benda, artikel, this/that/these/those",
      tags: ["Grammar", "Vocabulary"],
      content: {
        objectives: [
          "Membedakan singular/plural nouns",
          "Memakai a/an/the secara dasar",
          "Memakai this/that/these/those sesuai jarak dan jumlah"
        ],
        orientation: "Artikel sering diabaikan pemula Indonesia karena bahasa Indonesia tidak punya sistem yang sama.",
        theory: `<p><strong>Noun</strong> = nama orang/benda/tempat. Singular (satu) vs plural (banyak, biasanya +s/-es).</p>
<p><strong>a</strong> + bunyi konsonan: a book, a university (/j/). <strong>an</strong> + bunyi vokal: an apple, an hour (/aʊ/).</p>
<p><strong>the</strong> = spesifik / sudah disebut / unik: the sun, the book on the table.</p>
<p><strong>this/these</strong> = dekat; <strong>that/those</strong> = jauh. this/that singular; these/those plural.</p>`,
        rules: [
          "a/an hanya singular countable",
          "Jangan a apple → an apple",
          "this book (dekat, 1) · these books (dekat, banyak)"
        ],
        examples: [
          { en: "This is a pen.", id: "Ini (dekat) sebuah pena.", why: "singular dekat + a." },
          { en: "Those are books.", id: "Itu (jauh) buku-buku.", why: "plural jauh." },
          { en: "An hour ago…", id: "Satu jam yang lalu…", why: "hour bunyi vokal." },
          { en: "I see a cat. The cat is black.", id: "Lihat kucing. Kucing itu hitam.", why: "kedua kali → the." }
        ],
        compare: "a/an (tidak spesifik) vs the (spesifik). this (dekat) vs that (jauh).",
        commonErrors: [
          { wrong: "a apple", right: "an apple", why: "bunyi vokal." },
          { wrong: "this books", right: "these books", why: "plural → these." }
        ],
        vocab: [
          { en: "book", id: "buku", ipa: "/bʊk/", ex: "This is my book." },
          { en: "apple", id: "apel", ipa: "/ˈæpl/", ex: "an apple" },
          { en: "table", id: "meja", ipa: "/ˈteɪbl/", ex: "that table" },
          { en: "keys", id: "kunci-kunci", ipa: "/kiːz/", ex: "these keys" }
        ],
        dialogue: `A: What is this?\nB: It's a phone.\nA: And those?\nB: Those are my keys.`,
        summary: "a/an singular · the spesifik · this/these dekat · that/those jauh.",
        guided: [
          { q: "___ orange (satu, tak spesifik)", options: ["a", "an", "the", "these"], correct: 1, explain: "an + vokal." },
          { q: "Buku-buku di sini (dekat):", options: ["that book", "this book", "these books", "those book"], correct: 2, explain: "these + plural." }
        ],
        independent: [
          { type: "fill", q: "___ sun is bright. (article)", answer: "The", explain: "unik → the." }
        ],
        practice: "Tunjuk 5 benda di sekitarmu: This is a… / Those are…",
        evaluation: [
          { q: "___ umbrella", options: ["a", "an", "these", "those"], correct: 1, explain: "an + u vokal." },
          { q: "Far + plural:", options: ["this", "that", "these", "those"], correct: 3, explain: "those." },
          { q: "I have ___ idea.", options: ["a", "an", "these", "-"], correct: 1, explain: "an idea." },
          { q: "Plural of 'box':", options: ["boxs", "boxes", "boxies", "boxen"], correct: 1, explain: "+es." },
          { q: "Second mention: I bought a bag. ___ bag is red.", options: ["A", "An", "The", "Those"], correct: 2, explain: "the." }
        ],
        remedial: "Latih a/an dengan 10 kata: book, apple, hour, university, pen, egg, chair, orange, house, uncle."
      }
    },
    {
      id: "a1-u05",
      title: "Unit 5: Possessives & Possessive Adjectives",
      desc: "my/your/his/her/its/our/their dan 's",
      tags: ["Grammar"],
      content: {
        objectives: [
          "Memakai possessive adjectives (my, your, …)",
          "Membentuk possessive dengan 's pada nama",
          "Membedakan its vs it's"
        ],
        orientation: "Possessive menjawab: milik siapa?",
        theory: `<p><strong>Possessive adjectives:</strong> my, your, his, her, its, our, their — diikuti noun: my book.</p>
<p><strong>'s:</strong> Rina's bag = tasnya Rina. Untuk plural regular: students' room.</p>
<p><strong>its</strong> = milik it. <strong>it's</strong> = it is / it has. Jangan tertukar.</p>`,
        rules: [
          "my + noun (bukan mine book)",
          "it's raining = it is raining",
          "The dog wagged its tail (bukan it's tail)"
        ],
        examples: [
          { en: "This is my phone.", id: "Ini ponsel saya.", why: "my + noun." },
          { en: "Her name is Lina.", id: "Namanya Lina.", why: "her untuk she." },
          { en: "Budi's car is new.", id: "Mobilnya Budi baru.", why: "nama + 's." },
          { en: "It's a cat. Its fur is white.", id: "Itu kucing. Bulunya putih.", why: "it's=it is; its=milik." }
        ],
        compare: "my (adjective) vs mine (pronoun: The book is mine). its vs it's.",
        commonErrors: [
          { wrong: "This is mine book", right: "This is my book", why: "mine tidak diikuti noun." },
          { wrong: "Its OK", right: "It's OK", why: "it is → it's." }
        ],
        vocab: [
          { en: "my", id: "punya saya", ipa: "/maɪ/", ex: "my bag" },
          { en: "your", id: "punya kamu", ipa: "/jɔːr/", ex: "your name" },
          { en: "their", id: "punya mereka", ipa: "/ðeər/", ex: "their house" },
          { en: "ours", id: "milik kami", ipa: "/aʊərz/", ex: "This is ours." }
        ],
        dialogue: `A: Is this your book?\nB: No, it's Rina's book. Mine is blue.`,
        summary: "my/your/his/her/its/our/their + noun. Nama + 's. its ≠ it's.",
        guided: [
          { q: "___ name is Tom. (he)", options: ["He", "His", "Him", "He's"], correct: 1, explain: "His name." },
          { q: "The city and ___ parks", options: ["it's", "its", "it", "their"], correct: 1, explain: "its = milik." }
        ],
        independent: [
          { type: "fill", q: "We love ___ school. (possessive)", answer: "our", explain: "our school." }
        ],
        practice: "Deskripsikan 4 benda: This is my/your/his…",
        evaluation: [
          { q: "She has a bag. It is ___ bag.", options: ["she", "her", "hers", "his"], correct: 1, explain: "her bag." },
          { q: "___ a nice day.", options: ["Its", "It's", "It", "His"], correct: 1, explain: "It's = it is." },
          { q: "Andi's sister =", options: ["Andi sister", "Andis sister", "Andi's sister", "Andi his sister"], correct: 2, explain: "'s." },
          { q: "They open ___ books.", options: ["they", "them", "their", "theirs"], correct: 2, explain: "their books." },
          { q: "The book is ___. (milik saya, tanpa noun)", options: ["my", "mine", "I", "me"], correct: 1, explain: "mine." }
        ],
        remedial: "Buat tabel pronoun → possessive: I→my, you→your, he→his, she→her, it→its, we→our, they→their."
      }
    },
    {
      id: "a1-u06",
      title: "Unit 6: Simple Present — Habits & Facts",
      desc: "Kalimat kebiasaan, fakta, +s pada he/she/it",
      tags: ["Grammar", "Writing"],
      content: {
        objectives: [
          "Membentuk simple present untuk kebiasaan dan fakta",
          "Menambah -s/-es pada he/she/it",
          "Membuat negatif dan pertanyaan dengan do/does"
        ],
        orientation: "Simple present = tense A1 paling sering dipakai untuk rutinitas.",
        theory: `<p><strong>Fungsi:</strong> kebiasaan (I eat rice every day), fakta (Water boils at 100°C), jadwal.</p>
<p><strong>Bentuk:</strong> I/you/we/they + V1 · he/she/it + V1+s/es</p>
<p><strong>Negatif:</strong> do not (don't) / does not (doesn't) + V1 — tanpa -s pada verb utama.</p>
<p><strong>Tanya:</strong> Do you…? Does she…?</p>`,
        rules: [
          "He works (bukan he work)",
          "She doesn't like (bukan doesn't likes)",
          "Do they live…? (bukan Are they live…?)"
        ],
        examples: [
          { en: "I study English every day.", id: "Saya belajar English setiap hari.", why: "kebiasaan." },
          { en: "She works in a bank.", id: "Dia bekerja di bank.", why: "she + works." },
          { en: "He doesn't drink coffee.", id: "Dia tidak minum kopi.", why: "doesn't + V1." },
          { en: "Do you live here?", id: "Apakah kamu tinggal di sini?", why: "Do + subject + V1." }
        ],
        compare: "Simple present (rutin) vs present continuous (sedang terjadi sekarang — unit nanti di A2).",
        commonErrors: [
          { wrong: "He go to school", right: "He goes to school", why: "+es." },
          { wrong: "She doesn't goes", right: "She doesn't go", why: "setelah does, V1 polos." }
        ],
        vocab: [
          { en: "usually", id: "biasanya", ipa: "/ˈjuːʒuəli/", ex: "I usually wake up at 6." },
          { en: "always", id: "selalu", ipa: "/ˈɔːlweɪz/", ex: "She always smiles." },
          { en: "never", id: "tidak pernah", ipa: "/ˈnevər/", ex: "I never smoke." },
          { en: "work", id: "bekerja", ipa: "/wɜːrk/", ex: "They work hard." }
        ],
        dialogue: `A: What do you do every morning?\nB: I drink tea and check my phone.\nA: Does your sister work?\nB: Yes, she works in a hospital.`,
        summary: "V1 / V1+s · don't/doesn't + V1 · Do/Does…?",
        guided: [
          { q: "He ___ English.", options: ["study", "studies", "studying", "studied"], correct: 1, explain: "he + studies." },
          { q: "She ___ not like tea. (do)", options: ["do", "does", "is", "are"], correct: 1, explain: "does not." }
        ],
        independent: [
          { type: "write", q: "3 kalimat kebiasaanmu (I…) dan 2 tentang teman (He/She…).", answer: "open", explain: "Cek -s pada he/she." }
        ],
        practice: "Tulis jadwal harian 5 kalimat simple present.",
        evaluation: [
          { q: "My brother ___ TV every night.", options: ["watch", "watches", "watching", "watched"], correct: 1, explain: "watches." },
          { q: "___ she play football?", options: ["Do", "Does", "Is", "Are"], correct: 1, explain: "Does she…?" },
          { q: "They ___ live here.", options: ["doesn't", "don't", "isn't", "aren't"], correct: 1, explain: "don't." },
          { q: "Water ___ at 100°C.", options: ["boil", "boils", "boiling", "boiled"], correct: 1, explain: "fakta: boils." },
          { q: "I ___ breakfast at 7.", options: ["eats", "eat", "eating", "ate"], correct: 1, explain: "I + eat." }
        ],
        remedial: "List verb: go→goes, watch→watches, study→studies, do→does, have→has. Buat 1 kalimat tiap verb."
      }
    },
    {
      id: "a1-u07",
      title: "Unit 7: Numbers, Time & Prepositions of Time/Place",
      desc: "Angka, jam, in/on/at, tempat dasar",
      tags: ["Vocabulary", "Listening"],
      content: {
        objectives: [
          "Menyebut angka dan jam",
          "Memakai in/on/at untuk waktu",
          "Memakai in/on/at/under/next to untuk tempat dasar"
        ],
        orientation: "Angka dan preposisi membuat janji dan lokasi bisa dipahami.",
        theory: `<p><strong>Jam:</strong> It's 7 o'clock. It's half past 7 (7:30). It's a quarter past 7 (7:15). It's a quarter to 8 (7:45).</p>
<p><strong>at</strong> + jam: at 5 pm. <strong>on</strong> + hari/tanggal: on Monday, on 5 May. <strong>in</strong> + bulan/tahun/periode: in June, in 2026, in the morning.</p>
<p><strong>Place:</strong> in a room, on a table, at school/at home (fixed phrases).</p>`,
        rules: [
          "at night · in the morning (bukan at morning)",
          "on the wall · in the box",
          "at 7:00 (bukan in 7:00)"
        ],
        examples: [
          { en: "The class starts at 8.", id: "Kelas mulai pukul 8.", why: "at + clock time." },
          { en: "I work on Monday.", id: "Saya kerja hari Senin.", why: "on + day." },
          { en: "She was born in 2004.", id: "Dia lahir tahun 2004.", why: "in + year." },
          { en: "The keys are on the table.", id: "Kunci di atas meja.", why: "on + surface." }
        ],
        compare: "in the morning vs at night. at school vs in the classroom.",
        commonErrors: [
          { wrong: "in Monday", right: "on Monday", why: "hari → on." },
          { wrong: "at morning", right: "in the morning", why: "frasa tetap." }
        ],
        vocab: [
          { en: "o'clock", id: "tepat … jam", ipa: "/əˈklɒk/", ex: "two o'clock" },
          { en: "half past", id: "setengah", ipa: "/hɑːf pɑːst/", ex: "half past three" },
          { en: "between", id: "di antara", ipa: "/bɪˈtwiːn/", ex: "between A and B" },
          { en: "next to", id: "di samping", ipa: "/nekst tuː/", ex: "next to the door" }
        ],
        dialogue: `A: What time is the meeting?\nB: At half past nine.\nA: Where?\nB: In room 12, next to the library.`,
        summary: "at + jam · on + hari · in + bulan/tahun. Place: in/on/at/next to.",
        guided: [
          { q: "___ 5 May", options: ["in", "on", "at", "to"], correct: 1, explain: "on + date." },
          { q: "___ night", options: ["in", "on", "at", "to"], correct: 2, explain: "at night." }
        ],
        independent: [
          { type: "fill", q: "The book is ___ the bag. (in/on/at)", answer: "in", explain: "in the bag." }
        ],
        practice: "Tulis 5 janji imajiner: day + time + place dengan preposisi benar.",
        evaluation: [
          { q: "I get up ___ 6 a.m.", options: ["in", "on", "at", "to"], correct: 2, explain: "at + time." },
          { q: "See you ___ Friday.", options: ["in", "on", "at", "to"], correct: 1, explain: "on Friday." },
          { q: "___ 2020", options: ["at", "on", "in", "to"], correct: 2, explain: "in + year." },
          { q: "The picture is ___ the wall.", options: ["in", "on", "at", "under"], correct: 1, explain: "on the wall." },
          { q: "Half past two =", options: ["1:30", "2:30", "2:15", "3:00"], correct: 1, explain: "2:30." }
        ],
        remedial: "Buat mind map: at (clock, night, school) · on (days, dates, surfaces) · in (months, years, containers)."
      }
    },
    {
      id: "a1-u08",
      title: "Unit 8: A1 Checkpoint — Conversation & Review",
      desc: "Gabungan skills A1 + evaluasi level",
      tags: ["Review", "Speaking", "Evaluation"],
      content: {
        objectives: [
          "Menggabungkan salam, be, present simple, dan preposisi dalam dialog",
          "Menunjukkan penguasaan minimal 80% pada evaluasi A1"
        ],
        orientation: "Unit penutup A1. Lulus evaluasi ini membuka A2.",
        theory: `<p>Review singkat A1: alphabet & sounds → greetings → pronouns + be → nouns/articles/demonstratives → possessives → simple present → numbers/time/prepositions.</p>
<p>Kompetensi percakapan: perkenalan, bilang jam, sebut lokasi, ceritakan rutinitas singkat (4–6 kalimat).</p>`,
        rules: ["Gunakan struktur yang sudah dipelajari; prioritaskan kejelasan daripada kalimat panjang."],
        examples: [
          { en: "Hi, I'm Ardi. I'm a student. I live in Depok. I study every morning at 7.", id: "Contoh monolog A1.", why: "be + present simple + time." }
        ],
        compare: "A1 = kalimat sederhana terpisah. Belum wajib complex sentences (meskipun, karena, …).",
        commonErrors: [
          { wrong: "I am study English", right: "I study English", why: "Jangan dobel verb (am + study)." }
        ],
        vocab: [
          { en: "review", id: "mengulas", ipa: "/rɪˈvjuː/", ex: "Let's review." },
          { en: "checkpoint", id: "titik periksa", ipa: "/ˈtʃekpɔɪnt/", ex: "A1 checkpoint" }
        ],
        dialogue: `A: Hello! What's your name?\nB: I'm Maya. Nice to meet you.\nA: Where do you live?\nB: I live in Bogor. I go to campus on Monday and Wednesday.`,
        summary: "A1 siap jika kamu bisa perkenalan + rutinitas + jam/tempat dengan be & present simple akurat.",
        guided: [
          { q: "I ___ a teacher. I ___ English.", options: ["am / teach", "is / teaches", "are / teach", "am / teaches"], correct: 0, explain: "I am · I teach." }
        ],
        independent: [
          { type: "write", q: "Tulis paragraf 5–7 kalimat tentang dirimu (nama, asal, studi, rutinitas, jam).", answer: "open", explain: "Cek be & -s." }
        ],
        practice: "Simulasi: perkenalan 30 detik tanpa teks.",
        evaluation: [
          { q: "She ___ from Bali. She ___ coffee.", options: ["is / like", "is / likes", "are / likes", "am / like"], correct: 1, explain: "is + likes." },
          { q: "___ you work ___ Monday?", options: ["Do / on", "Does / in", "Are / at", "Do / in"], correct: 0, explain: "Do you · on Monday." },
          { q: "This is ___ book. ___ a good book.", options: ["my / It's", "mine / Its", "my / Its", "me / It's"], correct: 0, explain: "my · It's." },
          { q: "The keys are ___ the table ___ the morning.", options: ["on / in", "in / on", "at / at", "on / at"], correct: 0, explain: "on the table · in the morning." },
          { q: "He ___ not ___ here.", options: ["do / live", "does / live", "does / lives", "is / live"], correct: 1, explain: "doesn't live." }
        ],
        remedial: "Kembali ke unit dengan skor terendah. Minimal ulangi Unit 3 (be) dan Unit 6 (present simple)."
      }
    }
  ],


  a2: [
    {
      id: "a2-u01",
      title: "Unit 1: Present Continuous & Now",
      desc: "Sedang terjadi vs kebiasaan — be + V-ing",
      tags: ["Grammar", "Speaking"],
      content: {
        objectives: [
          "Membentuk am/is/are + V-ing dengan benar",
          "Membedakan present continuous (sekarang/sementara) dari simple present (rutin)",
          "Mengajukan dan menjawab pertanyaan What are you doing?"
        ],
        orientation: "Di A1 kamu bilang kebiasaan (I study every day). Di A2 kamu bilang apa yang sedang terjadi sekarang. Dua tense ini sering tertukar.",
        theory: `<p><strong>Present continuous</strong> = <em>be + V-ing</em>.</p>
<ul>
<li>I <strong>am writing</strong> an email.</li>
<li>She <strong>is cooking</strong> now.</li>
<li>They <strong>are waiting</strong> outside.</li>
</ul>
<p><strong>Kapan dipakai?</strong></p>
<ol>
<li>Aksi sedang berlangsung sekarang: Look! It is raining.</li>
<li>Situasi sementara: I am staying with a friend this week.</li>
<li>Rencana dekat yang sudah diatur (kadang): I am meeting Ana at 5.</li>
</ol>
<p><strong>Simple present</strong> tetap untuk kebiasaan/fakta: I drink tea every morning.</p>
<p><strong>Stative verbs</strong> (jarang continuous): know, like, love, want, need, believe, understand, have (punya).</p>
<p>Salah: I am knowing him. Benar: I know him.</p>`,
        rules: [
          "Selalu ada be: I am studying (bukan I studying)",
          "V-ing: write→writing, run→running, swim→swimming, lie→lying",
          "Negatif: is not (isn't) + V-ing · Tanya: Are you + V-ing?"
        ],
        examples: [
          { en: "I am studying English right now.", id: "Saya sedang belajar English saat ini.", why: "right now → continuous." },
          { en: "She works in a bank, but today she is working from home.", id: "Kebiasaan vs sementara.", why: "works = rutin; is working = hari ini." },
          { en: "What are you doing?", id: "Sedang apa?", why: "Are + subject + V-ing." },
          { en: "I know the answer. (bukan I am knowing)", id: "Saya tahu jawabannya.", why: "know = stative." }
        ],
        compare: "<strong>I live in Jakarta</strong> (permanen) vs <strong>I am living with my uncle this month</strong> (sementara). <strong>every day</strong> → simple present; <strong>now / at the moment</strong> → continuous.",
        commonErrors: [
          { wrong: "I studying now", right: "I am studying now", why: "Wajib be (am/is/are)." },
          { wrong: "She is want a coffee", right: "She wants a coffee", why: "want stative → simple present." },
          { wrong: "Are you study?", right: "Are you studying? / Do you study?", why: "Continuous perlu V-ing; kebiasaan pakai Do." }
        ],
        vocab: [
          { en: "right now", id: "saat ini juga", ipa: "/raɪt naʊ/", ex: "I am busy right now." },
          { en: "at the moment", id: "saat ini", ipa: "/æt ðə ˈməʊmənt/", ex: "At the moment, I am working." },
          { en: "currently", id: "saat ini (lebih formal)", ipa: "/ˈkʌrəntli/", ex: "She is currently studying abroad." },
          { en: "temporary", id: "sementara", ipa: "/ˈtempəreri/", ex: "This is a temporary job." },
          { en: "look!", id: "lihat!", ipa: "/lʊk/", ex: "Look! The bus is coming." }
        ],
        dialogue: `A: Hi! What are you doing?\nB: I'm reading a report for class.\nA: Do you read reports every day?\nB: No. I usually watch videos, but today I am preparing for a quiz.`,
        summary: "be + V-ing untuk now/temporary. Simple present untuk habits. Stative verbs tidak continuous.",
        guided: [
          { q: "Look! He ___ the door.", options: ["open", "opens", "is opening", "opened"], correct: 2, explain: "Look! → aksi sekarang → is opening." },
          { q: "I ___ to campus every day, but today I ___ at home.", options: ["go / study", "go / am studying", "am going / study", "goes / am studying"], correct: 1, explain: "habit = go; today temporary = am studying." },
          { q: "___ you ___ lunch now?", options: ["Do / have", "Are / having", "Is / having", "Do / having"], correct: 1, explain: "Are you having…?" }
        ],
        independent: [
          { type: "write", q: "Tulis 3 kalimat present continuous (sekarang) dan 3 simple present (rutin) tentang harimu.", answer: "open", explain: "Cek be + V-ing vs V1." },
          { type: "choose", q: "Mana yang benar untuk 'tahu'?", options: ["I am knowing the answer", "I know the answer", "I knowing the answer", "I is know"], correct: 1, explain: "know stative." }
        ],
        practice: "Rekam 30 detik: ceritakan apa yang sedang kamu lakukan sekarang + 2 kebiasaan harianmu.",
        evaluation: [
          { q: "Quiet! The baby ___.", options: ["sleep", "sleeps", "is sleeping", "slept"], correct: 2, explain: "is sleeping." },
          { q: "She ___ English this semester (kelas sementara).", options: ["study", "studies", "is studying", "studied"], correct: 2, explain: "is studying." },
          { q: "I ___ this song. (tahu/mengenal)", options: ["am knowing", "know", "is know", "knowing"], correct: 1, explain: "stative know." },
          { q: "___ they ___ football right now?", options: ["Do / play", "Are / playing", "Is / playing", "Do / playing"], correct: 1, explain: "Are they playing?" },
          { q: "He ___ in Bandung, but this month he ___ in Jakarta.", options: ["lives / stays", "lives / is staying", "is living / stays", "live / is staying"], correct: 1, explain: "lives = permanen; is staying = sementara." }
        ],
        remedial: "Buat tabel: every day / usually → simple present; now / look! / this week → continuous. 10 kalimat campuran."
      }
    },
    {
      id: "a2-u02",
      title: "Unit 2: Past Simple — Regular & Irregular",
      desc: "Menceritakan kejadian lampau dengan V2 dan did",
      tags: ["Grammar", "Writing"],
      content: {
        objectives: [
          "Membentuk past simple regular (-ed) dan irregular umum",
          "Membuat negatif dan pertanyaan dengan did + V1",
          "Memakai time markers: yesterday, last week, ago"
        ],
        orientation: "Tanpa past simple kamu tidak bisa menjawab 'What did you do yesterday?' — skill A2 inti.",
        theory: `<p><strong>Fungsi:</strong> kejadian selesai di masa lalu dengan waktu spesifik (atau jelas sudah selesai).</p>
<p><strong>Regular:</strong> work→worked, play→played, study→studied, stop→stopped.</p>
<p><strong>Irregular (wajib hafal inti):</strong> go→went, have→had, do→did, see→saw, eat→ate, buy→bought, come→came, make→made, take→took, write→wrote, read→read /red/, give→gave, find→found, know→knew, think→thought, get→got, say→said, tell→told, leave→left, feel→felt.</p>
<p><strong>Negatif:</strong> did not (didn't) + V1 — <em>bukan</em> didn't went.</p>
<p><strong>Tanya:</strong> Did you go…? Yes, I did. / No, I didn't.</p>
<p><strong>Time:</strong> yesterday, last night/week/year, in 2020, two days ago, when I was a child.</p>`,
        rules: [
          "Did + subject + V1 (bukan Did you went?)",
          "I went (bukan I goed / I did went)",
          "She didn't like (bukan didn't liked)"
        ],
        examples: [
          { en: "I visited my grandma yesterday.", id: "Saya mengunjungi nenek kemarin.", why: "regular -ed + yesterday." },
          { en: "She went to Bali last year.", id: "Dia pergi ke Bali tahun lalu.", why: "went = irregular." },
          { en: "They didn't see the message.", id: "Mereka tidak melihat pesan itu.", why: "didn't + V1 (see)." },
          { en: "Did you finish the homework?", id: "Apakah kamu menyelesaikan PR?", why: "Did + V1." }
        ],
        compare: "Past simple = selesai + waktu jelas. Present perfect (B1) = pengalaman/waktu tak spesifik: I have visited Bali (bukan I have visited Bali yesterday).",
        commonErrors: [
          { wrong: "I did went home", right: "I went home / I did go home", why: "did + V1 atau V2 tanpa did." },
          { wrong: "She didn't went", right: "She didn't go", why: "setelah did, verb polos." },
          { wrong: "Did he ate?", right: "Did he eat?", why: "Did + V1." }
        ],
        vocab: [
          { en: "yesterday", id: "kemarin", ipa: "/ˈjestərdeɪ/", ex: "yesterday morning" },
          { en: "ago", id: "yang lalu", ipa: "/əˈɡəʊ/", ex: "three days ago" },
          { en: "last weekend", id: "akhir pekan lalu", ipa: "/lɑːst ˈwiːkend/", ex: "last weekend I stayed home." },
          { en: "suddenly", id: "tiba-tiba", ipa: "/ˈsʌdənli/", ex: "Suddenly it started to rain." },
          { en: "finally", id: "akhirnya", ipa: "/ˈfaɪnəli/", ex: "Finally we arrived." }
        ],
        dialogue: `A: What did you do last weekend?\nB: I went to the beach and ate seafood.\nA: Did you swim?\nB: No, I didn't. The water was cold.`,
        summary: "V2 untuk positif. didn't/Did + V1. Hafalkan irregular inti. Time markers lampau.",
        guided: [
          { q: "They ___ football last Sunday.", options: ["play", "played", "playing", "plays"], correct: 1, explain: "played (regular)." },
          { q: "___ you ___ the film yesterday?", options: ["Did / see", "Did / saw", "Do / see", "Are / see"], correct: 0, explain: "Did you see?" },
          { q: "He ___ not ___ coffee this morning.", options: ["did / drank", "did / drink", "does / drank", "was / drink"], correct: 1, explain: "didn't drink." }
        ],
        independent: [
          { type: "write", q: "Paragraf 6–8 kalimat tentang last weekend (minimal 3 irregular verbs).", answer: "open", explain: "Cek V2 dan didn't + V1." },
          { type: "fill", q: "She ___ (buy) a new bag two days ago.", answer: "bought", explain: "bought." }
        ],
        practice: "Ceritakan 1 kejadian penting tahun lalu (6 kalimat). Lalu ubah 2 kalimat menjadi negatif.",
        evaluation: [
          { q: "He ___ to campus by bus yesterday.", options: ["go", "goes", "went", "gone"], correct: 2, explain: "went." },
          { q: "___ she ___ the email?", options: ["Did / send", "Did / sent", "Does / send", "Was / send"], correct: 0, explain: "Did she send?" },
          { q: "We ___ a great time at the party.", options: ["have", "had", "has", "having"], correct: 1, explain: "had." },
          { q: "I ___ not ___ the question.", options: ["did / understood", "did / understand", "do / understood", "was / understand"], correct: 1, explain: "didn't understand." },
          { q: "They ___ home an hour ago.", options: ["leave", "left", "leaves", "leaving"], correct: 1, explain: "left." }
        ],
        remedial: "Hafalkan 20 irregular: go, have, do, see, eat, buy, come, make, take, write, read, give, find, know, think, get, say, tell, leave, feel. Buat 1 kalimat tiap kata."
      }
    },
    {
      id: "a2-u03",
      title: "Unit 3: Countable, Uncountable & Quantity",
      desc: "some/any/much/many/a lot of/a few/a little",
      tags: ["Grammar", "Vocabulary"],
      content: {
        objectives: [
          "Membedakan countable dan uncountable nouns",
          "Memilih many/much/a few/a little/a lot of dengan tepat",
          "Memakai some dan any dalam positif, negatif, dan tanya"
        ],
        orientation: "Kesalahan klasik penutur Indonesia: many waters, much books, informations.",
        theory: `<p><strong>Countable:</strong> bisa dihitung — book/books, apple/apples. Bisa a/an dan angka.</p>
<p><strong>Uncountable:</strong> tidak dihitung satuan dalam English biasa — water, rice, information, money, advice, furniture, news, homework, bread. Tidak pakai a/an; tidak plural biasa (*informations salah).</p>
<p><strong>many</strong> + countable · <strong>much</strong> + uncountable · <strong>a lot of</strong> + keduanya.</p>
<p><strong>a few</strong> + countable (sedikit tapi ada) · <strong>a little</strong> + uncountable.</p>
<p><strong>some</strong> sering di positif; <strong>any</strong> sering di negatif/tanya (Do you have any…? I don't have any…).</p>`,
        rules: [
          "How many apples? How much water/money/time?",
          "some information (bukan an information / informations)",
          "a few friends · a little sugar"
        ],
        examples: [
          { en: "There are many students in the hall.", id: "Ada banyak siswa di aula.", why: "many + countable plural." },
          { en: "There isn't much time left.", id: "Tidak banyak waktu tersisa.", why: "much + uncountable." },
          { en: "I need some advice.", id: "Saya perlu sedikit saran.", why: "advice uncountable." },
          { en: "Do we have any milk?", id: "Apakah kita punya susu?", why: "any di pertanyaan." }
        ],
        compare: "few (hampir tidak ada, bernada negatif) vs a few (ada beberapa). little vs a little — pola sama untuk uncountable.",
        commonErrors: [
          { wrong: "many informations", right: "a lot of information / much information", why: "information uncountable." },
          { wrong: "much books", right: "many books", why: "books countable." },
          { wrong: "a apple juice", right: "some apple juice / a glass of juice", why: "juice uncountable." }
        ],
        vocab: [
          { en: "advice", id: "saran", ipa: "/ədˈvaɪs/", ex: "Can I give you some advice?" },
          { en: "furniture", id: "perabot", ipa: "/ˈfɜːrnɪtʃər/", ex: "new furniture" },
          { en: "homework", id: "PR", ipa: "/ˈhəʊmwɜːrk/", ex: "a lot of homework" },
          { en: "a few", id: "beberapa", ipa: "/ə fjuː/", ex: "a few minutes" },
          { en: "a little", id: "sedikit", ipa: "/ə ˈlɪtl/", ex: "a little milk" }
        ],
        dialogue: `A: Do we have any eggs?\nB: We have a few eggs, but we don't have much milk.\nA: I'll buy some milk then.`,
        summary: "many/a few + count · much/a little + uncount · a lot of fleksibel · some/any.",
        guided: [
          { q: "How ___ sugar do you need?", options: ["many", "much", "few", "a"], correct: 1, explain: "much + uncountable." },
          { q: "There aren't ___ chairs here.", options: ["much", "many", "a little", "an"], correct: 1, explain: "many + countable." },
          { q: "I need ___ information about the course.", options: ["an", "many", "some", "few"], correct: 2, explain: "some information." }
        ],
        independent: [
          { type: "write", q: "List 5 countable + 5 uncountable di kampus/dapur. Buat 1 kalimat quantity untuk tiap kategori.", answer: "open", explain: "Cek many/much." }
        ],
        practice: "Deskripsikan isikulkas/tasmu pakai some, any, much, many, a few, a little (6 kalimat).",
        evaluation: [
          { q: "There isn't ___ milk.", options: ["many", "much", "few", "several"], correct: 1, explain: "much milk." },
          { q: "How ___ people came?", options: ["much", "many", "little", "a"], correct: 1, explain: "many people." },
          { q: "She gave me ___ useful advice.", options: ["a", "many", "some", "few"], correct: 2, explain: "some advice." },
          { q: "We have only ___ eggs left. (sedikit, countable)", options: ["a little", "a few", "much", "any"], correct: 1, explain: "a few eggs." },
          { q: "Is there ___ water in the bottle?", options: ["many", "few", "any", "several"], correct: 2, explain: "any." }
        ],
        remedial: "Kartu dua kolom Countable | Uncountable (20 kata). Latihan How much/How many 10x."
      }
    },
    {
      id: "a2-u04",
      title: "Unit 4: Comparatives & Superlatives",
      desc: "lebih… / paling… — -er/-est dan more/most",
      tags: ["Grammar", "Speaking"],
      content: {
        objectives: [
          "Membentuk comparative (-er / more) dan superlative (-est / most)",
          "Memakai than dan the + superlative",
          "Menguasai bentuk irregular: better, worse, best, worst"
        ],
        orientation: "Membandingkan orang, tempat, dan pilihan — skill percakapan A2 sangat sering.",
        theory: `<p><strong>Adjective pendek (1 suku kata):</strong> tall→taller→the tallest; big→bigger→the biggest.</p>
<p><strong>2 suku kata -y:</strong> happy→happier→the happiest.</p>
<p><strong>Panjang (2+ suku kata):</strong> more useful → the most useful; more expensive → the most expensive.</p>
<p><strong>Irregular:</strong> good→better→best; bad→worse→worst; far→farther/further→farthest/furthest.</p>
<p>Pola: A is <strong>adj-er than</strong> B. A is <strong>the adj-est</strong> in the group.</p>`,
        rules: [
          "than (bukan from) setelah comparative: taller than me",
          "the sebelum superlative: the tallest student",
          "Jangan more taller / the most tallest"
        ],
        examples: [
          { en: "This book is easier than that one.", id: "Buku ini lebih mudah daripada yang itu.", why: "easy → easier + than." },
          { en: "She is the most hardworking student in class.", id: "Dia siswa paling rajin di kelas.", why: "long adj → most." },
          { en: "My results are better than last semester.", id: "Hasil saya lebih baik dari semester lalu.", why: "better irregular." },
          { en: "This is the worst coffee I have ever had. (preview)", id: "Ini kopi terburuk…", why: "worst = superlative bad." }
        ],
        compare: "comparative = banding 2 hal; superlative = 3+ atau dalam grup. as…as untuk kesamaan: as tall as.",
        commonErrors: [
          { wrong: "more taller", right: "taller", why: "jangan dobel comparative." },
          { wrong: "the most cheapest", right: "the cheapest", why: "jangan dobel." },
          { wrong: "better that", right: "better than", why: "than." }
        ],
        vocab: [
          { en: "than", id: "daripada", ipa: "/ðæn/", ex: "bigger than" },
          { en: "better", id: "lebih baik", ipa: "/ˈbetər/", ex: "better than before" },
          { en: "worse", id: "lebih buruk", ipa: "/wɜːrs/", ex: "worse than yesterday" },
          { en: "the best", id: "yang terbaik", ipa: "/ðə best/", ex: "the best option" },
          { en: "expensive", id: "mahal", ipa: "/ɪkˈspensɪv/", ex: "more expensive" }
        ],
        dialogue: `A: Is the new phone better than your old one?\nB: Yes, it's faster and lighter. But it's more expensive.\nA: What's the best feature?\nB: The camera is the best part.`,
        summary: "-er/-est untuk pendek; more/most untuk panjang; better/worse irregular; than & the.",
        guided: [
          { q: "This bag is ___ than that bag. (cheap)", options: ["more cheap", "cheaper", "the cheapest", "cheapper"], correct: 1, explain: "cheaper." },
          { q: "She is ___ student in the team. (good)", options: ["better", "the best", "more good", "the goodest"], correct: 1, explain: "the best." },
          { q: "English is ___ than I thought. (interesting)", options: ["interestinger", "more interesting", "most interesting", "the more interesting"], correct: 1, explain: "more interesting." }
        ],
        independent: [
          { type: "write", q: "Bandingkan kota/kampus/mu dengan tempat lain (5 kalimat comparative + 2 superlative).", answer: "open", explain: "than / the." }
        ],
        practice: "Bandingkan 3 mata kuliah: mana lebih sulit, paling menarik, dll.",
        evaluation: [
          { q: "My brother is ___ than me.", options: ["more tall", "taller", "the tallest", "tallest"], correct: 1, explain: "taller than." },
          { q: "This is ___ café near campus.", options: ["the more popular", "the most popular", "most popular", "more popular"], correct: 1, explain: "the most popular." },
          { q: "His English is ___ than last year.", options: ["more good", "better", "best", "gooder"], correct: 1, explain: "better." },
          { q: "Avoid double comparative:", options: ["more easier", "easier", "more easy than more", "the more easiest"], correct: 1, explain: "easier saja." },
          { q: "A is as tall ___ B.", options: ["than", "as", "from", "that"], correct: 1, explain: "as…as." }
        ],
        remedial: "Tabel: adj → comparative → superlative untuk 15 kata (termasuk good/bad/far)."
      }
    },
    {
      id: "a2-u05",
      title: "Unit 5: Be Going To & Will (Future)",
      desc: "Rencana, niat, prediksi, keputusan spontan",
      tags: ["Grammar", "Speaking"],
      content: {
        objectives: [
          "Memakai be going to untuk rencana/niat/bukti",
          "Memakai will untuk keputusan spontan dan prediksi",
          "Membedakan kedua bentuk dalam konteks nyata"
        ],
        orientation: "A2 future: jangan hanya hafal will — pilih bentuk sesuai makna.",
        theory: `<p><strong>be going to</strong> + V1:</p>
<ul>
<li>Rencana/niat: I am going to study medicine.</li>
<li>Prediksi dengan bukti: Look at those clouds! It is going to rain.</li>
</ul>
<p><strong>will</strong> + V1:</p>
<ul>
<li>Keputusan spontan: The phone is ringing. I will answer it.</li>
<li>Prediksi/opini: I think she will pass.</li>
<li>Janji/tawaran: I will help you.</li>
</ul>
<p>Present continuous juga bisa untuk janji tetap: I am meeting the advisor at 10.</p>`,
        rules: [
          "going to + V1 (bukan going to going)",
          "will not = won't",
          "I will / I'll — kontraksi umum di spoken"
        ],
        examples: [
          { en: "I am going to apply for a scholarship next month.", id: "Saya berencana apply beasiswa bulan depan.", why: "rencana." },
          { en: "It is going to rain. (clouds)", id: "Akan hujan.", why: "bukti visual." },
          { en: "I'll get the door.", id: "Biar saya bukakan pintu.", why: "spontan." },
          { en: "I think you will enjoy this course.", id: "Menurut saya kamu akan menikmati kursus ini.", why: "prediksi opini." }
        ],
        compare: "going to = sudah ada niat/bukti; will = baru diputuskan / opini. Keduanya future — beda nuansa.",
        commonErrors: [
          { wrong: "I will going to study", right: "I am going to study / I will study", why: "jangan campur." },
          { wrong: "I going to buy", right: "I am going to buy", why: "perlu be." }
        ],
        vocab: [
          { en: "plan", id: "rencana", ipa: "/plæn/", ex: "My plan is clear." },
          { en: "probably", id: "kemungkinan besar", ipa: "/ˈprɒbəbli/", ex: "I will probably come." },
          { en: "promise", id: "janji", ipa: "/ˈprɒmɪs/", ex: "I promise I will call." },
          { en: "offer", id: "tawaran", ipa: "/ˈɒfər/", ex: "I'll offer my help." }
        ],
        dialogue: `A: Any plans for the weekend?\nB: I'm going to visit my cousin. What about you?\nA: I'm not sure. Maybe I'll just rest.\nB: Look at the sky — it's going to rain. Take an umbrella.`,
        summary: "going to = plan/evidence · will = spontaneous/prediction/promise.",
        guided: [
          { q: "I ___ visit my uncle this weekend. (sudah direncanakan)", options: ["will", "am going to", "go to", "going"], correct: 1, explain: "am going to." },
          { q: "Someone's at the door. I ___ open it.", options: ["am going to", "will", "going to", "opens"], correct: 1, explain: "spontan → will." },
          { q: "Look at the score! We ___.", options: ["will win", "are going to win", "win", "won"], correct: 1, explain: "bukti → going to." }
        ],
        independent: [
          { type: "write", q: "3 rencana (going to) + 2 keputusan spontan (will) + 1 prediksi.", answer: "open", explain: "Bedakan konteks." }
        ],
        practice: "Tanya teman: What are you going to do after graduation? Catat 5 jawaban.",
        evaluation: [
          { q: "She ___ start a new course in July. (rencana)", options: ["will", "is going to", "goes to", "going"], correct: 1, explain: "is going to." },
          { q: "The glass is on the edge! It ___.", options: ["will fall", "is going to fall", "falls", "fall"], correct: 1, explain: "bukti → going to." },
          { q: "I ___ help you with that bag.", options: ["am going to", "will", "going", "helps"], correct: 1, explain: "tawaran → will." },
          { q: "I think he ___ arrive late.", options: ["is going", "will", "going to", "goes"], correct: 1, explain: "opini → will." },
          { q: "We ___ not ___ to the party. (niat tidak datang)", options: ["will / going", "are / going to go", "are / go", "will / go to"], correct: 1, explain: "aren't going to go." }
        ],
        remedial: "Buat 10 situasi: tandai will atau going to + alasan singkat."
      }
    },
    {
      id: "a2-u06",
      title: "Unit 6: Modal Verbs — Can, Could, Should, Must",
      desc: "Kemampuan, izin, saran, kewajiban",
      tags: ["Grammar", "Speaking"],
      content: {
        objectives: [
          "Memakai can/can't untuk ability dan permission",
          "Memakai should untuk saran",
          "Memakai must/mustn't dan have to untuk kewajiban"
        ],
        orientation: "Modal membuat kalimat lebih natural: permintaan, saran, larangan.",
        theory: `<p><strong>can</strong> + V1: kemampuan / izin informal — I can swim. Can I sit here?</p>
<p><strong>could</strong>: lebih sopan / ability lampau — Could you help me? I could run fast when I was young.</p>
<p><strong>should</strong>: saran — You should sleep earlier.</p>
<p><strong>must</strong>: kewajiban kuat / kesimpulan — You must wear a helmet. You must be tired.</p>
<p><strong>mustn't</strong>: larangan — You mustn't smoke here.</p>
<p><strong>have to</strong>: kewajiban (sering dari aturan luar) — I have to submit the form today.</p>
<p>Modal + V1 polos: She can go (bukan can goes / can to go).</p>`,
        rules: [
          "modal + V1 tanpa to (kecuali have to / need to / ought to)",
          "Negatif: can't, shouldn't, mustn't",
          "Tanya: Can you…? Should I…?"
        ],
        examples: [
          { en: "I can speak three languages.", id: "Saya bisa tiga bahasa.", why: "ability." },
          { en: "You should review the notes.", id: "Kamu sebaiknya review catatan.", why: "saran." },
          { en: "Students must not cheat.", id: "Mahasiswa tidak boleh mencontek.", why: "larangan kuat." },
          { en: "I have to wake up at 5 on weekdays.", id: "Saya harus bangun jam 5.", why: "kewajiban rutin." }
        ],
        compare: "must (pembicara merasa wajib) vs have to (aturan/situasi). shouldn't (saran jangan) vs mustn't (dilarang).",
        commonErrors: [
          { wrong: "He can to swim", right: "He can swim", why: "tanpa to." },
          { wrong: "You should to go", right: "You should go", why: "tanpa to." },
          { wrong: "She musts study", right: "She must study", why: "modal tidak +s." }
        ],
        vocab: [
          { en: "ability", id: "kemampuan", ipa: "/əˈbɪləti/", ex: "language ability" },
          { en: "permission", id: "izin", ipa: "/pərˈmɪʃn/", ex: "ask for permission" },
          { en: "advice", id: "saran", ipa: "/ədˈvaɪs/", ex: "give advice" },
          { en: "obligation", id: "kewajiban", ipa: "/ˌɒblɪˈɡeɪʃn/", ex: "a strong obligation" }
        ],
        dialogue: `A: Can you help me with this form?\nB: Sure. You should fill section B carefully.\nA: Must I attach a photo?\nB: Yes, you have to. And you mustn't forget the signature.`,
        summary: "can ability/permission · should advice · must/have to obligation · mustn't prohibition · + V1.",
        guided: [
          { q: "You ___ eat more vegetables. (saran)", options: ["can", "should", "must to", "are"], correct: 1, explain: "should." },
          { q: "___ I open the window?", options: ["Should", "Must to", "Do", "Am"], correct: 0, explain: "Should I…?" },
          { q: "You ___ use your phone in the exam. (larangan)", options: ["shouldn't", "mustn't", "don't have", "can't to"], correct: 1, explain: "mustn't = dilarang." }
        ],
        independent: [
          { type: "write", q: "5 aturan kampus pakai must/mustn't/have to/should/can.", answer: "open", explain: "Modal + V1." }
        ],
        practice: "Roleplay: minta izin, beri saran belajar, sebut 2 kewajiban kuliah.",
        evaluation: [
          { q: "She ___ drive. She has a license.", options: ["can", "should to", "must to", "cans"], correct: 0, explain: "can." },
          { q: "You ___ see a doctor. (saran kuat)", options: ["can", "should", "are", "going"], correct: 1, explain: "should." },
          { q: "Students ___ upload the file today. (aturan)", options: ["can", "have to", "should to", "must to"], correct: 1, explain: "have to." },
          { q: "You ___ cheat. (larangan)", options: ["mustn't", "shouldn't to", "haven't to", "don't must"], correct: 0, explain: "mustn't." },
          { q: "___ you pass the salt?", options: ["Should", "Could", "Must", "Have"], correct: 1, explain: "Could you…? sopan." }
        ],
        remedial: "Tabel modal + contoh + fungsi. Latihan 10 transform affirmative→negative→question."
      }
    },
    {
      id: "a2-u07",
      title: "Unit 7: Present Perfect Intro (A2 bridge)",
      desc: "have/has + V3 untuk pengalaman dasar — ever/never",
      tags: ["Grammar"],
      content: {
        objectives: [
          "Membentuk have/has + past participle",
          "Memakai ever/never untuk pengalaman",
          "Mulai membedakan dari past simple (tanpa waktu spesifik)"
        ],
        orientation: "Pengantar B1. Di A2 cukup kuasai bentuk + ever/never + already/yet dasar.",
        theory: `<p><strong>Present perfect</strong> = have/has + V3 (past participle).</p>
<p>I <strong>have visited</strong> Bali. She <strong>has never tried</strong> sushi.</p>
<p><strong>ever</strong> di pertanyaan: Have you ever…? <strong>never</strong> di negatif pengalaman.</p>
<p><strong>already</strong> (sudah) · <strong>yet</strong> (belum, di tanya/negatif).</p>
<p>Jika ada waktu lampau spesifik (yesterday, in 2019) → biasanya <strong>past simple</strong>.</p>`,
        rules: [
          "have/has + V3 (gone, seen, done, written, eaten…)",
          "Have you ever been to…?",
          "I have already finished. / I haven't finished yet."
        ],
        examples: [
          { en: "I have never eaten raw fish.", id: "Saya belum pernah makan ikan mentah.", why: "never + perfect." },
          { en: "Have you ever been abroad?", id: "Pernahkah kamu ke luar negeri?", why: "ever di tanya." },
          { en: "She has already submitted the form.", id: "Dia sudah mengumpulkan formulir.", why: "already." },
          { en: "I went to Bali in 2022. (bukan have gone … in 2022)", id: "Waktu spesifik → past simple.", why: "in 2022." }
        ],
        compare: "Have you seen that film? (pengalaman) vs Did you see it yesterday? (waktu jelas).",
        commonErrors: [
          { wrong: "I have saw", right: "I have seen", why: "V3 = seen." },
          { wrong: "I have gone there yesterday", right: "I went there yesterday", why: "yesterday → past simple." }
        ],
        vocab: [
          { en: "ever", id: "pernah (tanya)", ipa: "/ˈevər/", ex: "Have you ever…?" },
          { en: "never", id: "tidak pernah", ipa: "/ˈnevər/", ex: "I have never…" },
          { en: "already", id: "sudah", ipa: "/ɔːlˈredi/", ex: "already done" },
          { en: "yet", id: "belum", ipa: "/jet/", ex: "not yet" }
        ],
        dialogue: `A: Have you ever tried online courses?\nB: Yes, I have. I took one last year.\nA: Have you finished this week's module yet?\nB: Not yet. I've already done the quiz, though.`,
        summary: "have/has + V3 · ever/never/already/yet · past simple jika waktu spesifik.",
        guided: [
          { q: "___ you ever ___ Japan?", options: ["Did / visit", "Have / visited", "Have / visit", "Do / visited"], correct: 1, explain: "Have you ever visited?" },
          { q: "She has ___ finished.", options: ["yet", "ago", "already", "yesterday"], correct: 2, explain: "already." }
        ],
        independent: [
          { type: "write", q: "5 kalimat: 3 never/ever experience + 2 already/yet tentang tugas kuliah.", answer: "open", explain: "V3 benar." }
        ],
        practice: "Interview: 5 pertanyaan Have you ever…? ke teman/diri sendiri.",
        evaluation: [
          { q: "I ___ this movie three times.", options: ["saw", "have seen", "see", "seeing"], correct: 1, explain: "have seen." },
          { q: "___ he finished ___?", options: ["Has / yet", "Did / yet", "Has / yesterday", "Does / already"], correct: 0, explain: "Has… yet?" },
          { q: "We ___ there in 2019.", options: ["have gone", "went", "have went", "go"], correct: 1, explain: "in 2019 → went." },
          { q: "Past participle of write:", options: ["wrote", "written", "writed", "writing"], correct: 1, explain: "written." },
          { q: "I have ___ tried skydiving.", options: ["ever", "never", "yet", "ago"], correct: 1, explain: "never." }
        ],
        remedial: "List V3: gone, seen, done, written, eaten, taken, been, had, bought, made. 1 kalimat perfect tiap kata."
      }
    },
    {
      id: "a2-u08",
      title: "Unit 8: A2 Checkpoint & Mini Project",
      desc: "Review A2 + proyek: cerita weekend + rencana",
      tags: ["Review", "Writing", "Speaking", "Evaluation"],
      content: {
        objectives: [
          "Menggabungkan continuous, past, quantity, comparative, future, modal, perfect intro",
          "Menyelesaikan mini project tertulis/lisan 8–10 kalimat",
          "Lulus evaluasi A2 (≥80%) untuk membuka B1"
        ],
        orientation: "Penutup A2. Tunjukkan kamu bisa ceritakan lalu, sekarang, dan rencana dengan grammar yang tepat.",
        theory: `<p><strong>Checklist A2:</strong> present continuous · past simple · quantity · comparative · going to/will · modals · present perfect intro.</p>
<p><strong>Mini project:</strong> Tulis atau rekam monolog: (1) apa yang kamu lakukan sekarang, (2) last weekend, (3) rencana bulan depan, (4) satu saran untuk teman belajar English.</p>`,
        rules: ["Campur tense dengan sadar — jangan semua present simple."],
        examples: [
          { en: "Right now I am reviewing A2 grammar. Last Saturday I visited a museum. I am going to take the B1 path next. You should practice a little every day.", id: "Model mini project.", why: "continuous + past + going to + should." }
        ],
        compare: "A2 = kalimat lebih bervariasi dari A1, masih konkret dan personal.",
        commonErrors: [
          { wrong: "Yesterday I am going to the mall", right: "Yesterday I went to the mall", why: "yesterday → past." }
        ],
        vocab: [
          { en: "review", id: "mengulas", ipa: "/rɪˈvjuː/", ex: "review the units" },
          { en: "project", id: "proyek", ipa: "/ˈprɒdʒekt/", ex: "mini project" },
          { en: "checkpoint", id: "titik periksa", ipa: "/ˈtʃekpɔɪnt/", ex: "A2 checkpoint" }
        ],
        dialogue: `A: How was your weekend?\nB: Great. I went hiking. What are you doing now?\nA: I'm finishing the A2 project. I'm going to start B1 next week.`,
        summary: "A2 siap jika past, now, future, modal, dan quantity dipakai akurat dalam teks pendek.",
        guided: [
          { q: "I ___ TV when you texted me yesterday evening. (preview continuous past — optional feel)", options: ["watch", "watched", "was watching", "am watching"], correct: 2, explain: "was watching (bridge ke B1)." }
        ],
        independent: [
          { type: "write", q: "MINI PROJECT: 8–10 kalimat (now + last weekend + plan + one should-advice).", answer: "open", explain: "Minimal 4 tense/modal berbeda." }
        ],
        practice: "Baca keras mini project 1 menit tanpa membaca teks penuh.",
        evaluation: [
          { q: "Look! Someone ___ at the door.", options: ["knock", "knocks", "is knocking", "knocked"], correct: 2, explain: "is knocking." },
          { q: "We ___ a movie last night.", options: ["see", "saw", "seen", "seeing"], correct: 1, explain: "saw." },
          { q: "There isn't ___ milk left.", options: ["many", "much", "few", "several"], correct: 1, explain: "much." },
          { q: "This phone is ___ than mine.", options: ["more cheap", "cheaper", "the cheapest", "cheap"], correct: 1, explain: "cheaper." },
          { q: "I ___ apply next month. (rencana)", options: ["will", "am going to", "go", "going"], correct: 1, explain: "am going to." },
          { q: "You ___ revise before the quiz. (saran)", options: ["can to", "should", "must to", "are"], correct: 1, explain: "should." },
          { q: "Have you ever ___ to Singapore?", options: ["go", "went", "been", "going"], correct: 2, explain: "been." },
          { q: "She ___ not ___ the email yet.", options: ["has / send", "has / sent", "have / sent", "did / sent"], correct: 1, explain: "has not sent / hasn't sent." }
        ],
        remedial: "Identifikasi unit A2 dengan skor terendah; ulangi evaluasi unit itu sebelum level exam."
      }
    }
  ],

  b1: [
    {
      id: "b1-u01",
      title: "Unit 1: Present Perfect — Experience & Result",
      desc: "have/has + V3, ever/never/already/yet/just/since/for",
      tags: ["Grammar", "Speaking"],
      content: {
        objectives: [
          "Memakai present perfect untuk pengalaman dan hasil yang relevan sekarang",
          "Memakai since/for dengan tepat",
          "Memilih present perfect vs past simple secara sadar"
        ],
        orientation: "B1: masa lalu yang masih 'terhubung' ke sekarang. Ini fondasi akademik & percakapan natural.",
        theory: `<p><strong>Bentuk:</strong> have/has + past participle (V3).</p>
<p><strong>Fungsi utama:</strong></p>
<ol>
<li>Pengalaman hidup (waktu tak spesifik): I have visited three countries.</li>
<li>Hasil sekarang: She has lost her keys (jadi sekarang tidak punya).</li>
<li>Dengan since/for: I have lived here since 2020 / for five years.</li>
</ol>
<p><strong>Signal:</strong> ever, never, already, yet, just, recently, so far, since, for.</p>
<p><strong>Past simple</strong> jika waktu selesai & disebut: I visited Japan in 2019.</p>
<p>been to vs gone to: She has gone to the lab (masih di sana). She has been to the lab (pernah, sudah kembali).</p>`,
        rules: [
          "since + titik waktu; for + durasi",
          "Jangan present perfect + yesterday/last year",
          "has untuk he/she/it; have untuk I/you/we/they"
        ],
        examples: [
          { en: "I have never tried rock climbing.", id: "Saya belum pernah panjat tebing.", why: "never + pengalaman." },
          { en: "She has just finished her thesis draft.", id: "Dia baru saja menyelesaikan draf tesis.", why: "just + result." },
          { en: "We have studied here for two years.", id: "Kami belajar di sini selama dua tahun.", why: "for + durasi." },
          { en: "I saw that film yesterday.", id: "Saya menonton film itu kemarin.", why: "yesterday → past simple." }
        ],
        compare: "Have you eaten? (masih relevan sekarang) vs Did you eat at 7? (waktu spesifik). since 2020 vs for 4 years.",
        commonErrors: [
          { wrong: "I have seen him yesterday", right: "I saw him yesterday", why: "yesterday memaksa past simple." },
          { wrong: "She has went", right: "She has gone", why: "V3 = gone." },
          { wrong: "I live here since 2020", right: "I have lived here since 2020", why: "since + perfect." }
        ],
        vocab: [
          { en: "recently", id: "baru-baru ini", ipa: "/ˈriːsntli/", ex: "I have recently changed majors." },
          { en: "so far", id: "sejauh ini", ipa: "/səʊ fɑːr/", ex: "So far, so good." },
          { en: "since", id: "sejak", ipa: "/sɪns/", ex: "since Monday" },
          { en: "for", id: "selama", ipa: "/fɔːr/", ex: "for a week" },
          { en: "just", id: "baru saja", ipa: "/dʒʌst/", ex: "has just arrived" }
        ],
        dialogue: `A: Have you ever worked part-time?\nB: Yes, I have. I worked at a café in 2023.\nA: Have you submitted the application yet?\nB: I've already uploaded the CV, but I haven't written the essay yet.`,
        summary: "have/has + V3 untuk experience/result/since-for; past simple untuk finished time.",
        guided: [
          { q: "She ___ in Medan ___ 2019.", options: ["lives / since", "has lived / since", "has lived / for", "lived / for"], correct: 1, explain: "has lived since 2019." },
          { q: "___ you ___ lunch yet?", options: ["Did / have", "Have / had", "Has / have", "Do / had"], correct: 1, explain: "Have you had…?" },
          { q: "I ___ this book last night.", options: ["have finished", "finished", "has finished", "finish"], correct: 1, explain: "last night → finished." }
        ],
        independent: [
          { type: "write", q: "Paragraf 8 kalimat: pengalaman kuliah (perfect) + 2 detail waktu spesifik (past simple).", answer: "open", explain: "Campur sadar." }
        ],
        practice: "Diskusi: 6 pertanyaan Have you ever…? dilanjutkan When…? (past simple).",
        evaluation: [
          { q: "I ___ this course three times.", options: ["took", "have taken", "take", "taking"], correct: 1, explain: "have taken (experience)." },
          { q: "He ___ to the library. He will be back soon.", options: ["has been", "has gone", "went", "goes"], correct: 1, explain: "has gone = masih di sana." },
          { q: "We ___ here ___ five years.", options: ["are / since", "have been / for", "have been / since", "were / for"], correct: 1, explain: "have been for five years." },
          { q: "___ she already ___ the email?", options: ["Has / sent", "Did / sent", "Has / send", "Have / sent"], correct: 0, explain: "Has she already sent…?" },
          { q: "They ___ the museum on Monday.", options: ["have visited", "visited", "visit", "are visiting"], correct: 1, explain: "on Monday → visited." }
        ],
        remedial: "Dua kolom: Perfect signals vs Past simple signals. 15 kalimat sorting + production."
      }
    },
    {
      id: "b1-u02",
      title: "Unit 2: Past Continuous & Interrupted Past",
      desc: "was/were + V-ing dan when/while",
      tags: ["Grammar", "Writing"],
      content: {
        objectives: [
          "Membentuk past continuous",
          "Menceritakan aksi yang sedang berlangsung saat diganggu aksi lain",
          "Memakai when dan while dengan tepat"
        ],
        orientation: "Narasi B1: bukan hanya daftar kejadian, tapi latar + gangguan.",
        theory: `<p><strong>Past continuous:</strong> was/were + V-ing.</p>
<p>I <strong>was studying</strong> when the power went out.</p>
<p><strong>when</strong> + past simple (aksi pendek); <strong>while</strong> + past continuous (latar panjang).</p>
<p>While I was walking home, it started to rain.</p>
<p>Dua continuous paralel: While I was cooking, he was setting the table.</p>`,
        rules: [
          "was (I/he/she/it) · were (you/we/they)",
          "when + shorter action (often past simple)",
          "while + longer background (continuous)"
        ],
        examples: [
          { en: "I was reading when she called.", id: "Saya sedang membaca saat dia menelepon.", why: "latar + gangguan." },
          { en: "While we were waiting, the bus arrived.", id: "Sementara kami menunggu, bus datang.", why: "while + continuous." },
          { en: "They were not listening to the lecture.", id: "Mereka tidak sedang mendengarkan kuliah.", why: "negatif continuous." }
        ],
        compare: "Past simple = urutan kejadian selesai. Past continuous = latar/proses di masa lalu.",
        commonErrors: [
          { wrong: "I was study", right: "I was studying", why: "V-ing." },
          { wrong: "When I was arrived…", right: "When I arrived…", why: "arrive singkat → past simple." }
        ],
        vocab: [
          { en: "while", id: "sementara/saat", ipa: "/waɪl/", ex: "while I was sleeping" },
          { en: "when", id: "ketika", ipa: "/wen/", ex: "when the phone rang" },
          { en: "suddenly", id: "tiba-tiba", ipa: "/ˈsʌdənli/", ex: "Suddenly the lights went out." }
        ],
        dialogue: `A: What were you doing at 8 last night?\nB: I was finishing my assignment when my laptop froze.\nA: Oh no. What did you do then?\nB: I restarted it and continued.`,
        summary: "was/were + V-ing untuk latar; when/while mengatur hubungan waktu.",
        guided: [
          { q: "She ___ TV when I ___ home.", options: ["watched / came", "was watching / came", "was watching / was coming", "watch / come"], correct: 1, explain: "latar continuous + came short." },
          { q: "___ we were studying, the fire alarm ___.", options: ["When / was ringing", "While / rang", "While / was ringing", "When / rings"], correct: 1, explain: "While + continuous, rang short." }
        ],
        independent: [
          { type: "write", q: "Cerita 6–8 kalimat: satu latar continuous + 2 gangguan past simple.", answer: "open", explain: "when/while." }
        ],
        practice: "Ceritakan kejadian lucu/kaget minggu lalu dengan past continuous.",
        evaluation: [
          { q: "I ___ dinner when you texted.", options: ["cooked", "was cooking", "am cooking", "cook"], correct: 1, explain: "was cooking." },
          { q: "While they ___, it ___ to rain.", options: ["walked / started", "were walking / started", "were walking / was starting", "walk / starts"], correct: 1, explain: "were walking / started." },
          { q: "What ___ you ___ at 9 p.m.?", options: ["did / do", "were / doing", "are / doing", "was / do"], correct: 1, explain: "were you doing?" },
          { q: "He ___ not ___ attention.", options: ["was / pay", "was / paying", "did / paying", "were / pay"], correct: 1, explain: "was not paying." },
          { q: "When the teacher ___, the students ___.", options: ["was entering / talked", "entered / were talking", "entered / talked", "was entering / were talking"], correct: 1, explain: "entered short; were talking background." }
        ],
        remedial: "10 pasangan when/while — lengkapi tense."
      }
    },
    {
      id: "b1-u03",
      title: "Unit 3: First Conditional & Future Time Clauses",
      desc: "If + present, will; when/as soon as/until",
      tags: ["Grammar", "Speaking"],
      content: {
        objectives: [
          "Membentuk first conditional untuk situasi realistis",
          "Memakai when/as soon as/until + present untuk future meaning",
          "Membedakan will vs going to dalam konteks syarat"
        ],
        orientation: "Syarat nyata di masa depan — rencana, peringatan, janji.",
        theory: `<p><strong>First conditional:</strong> If + present simple, will + V1.</p>
<p>If it rains, we will cancel the picnic.</p>
<p>If-clause bisa di belakang: We will cancel if it rains.</p>
<p><strong>Future time clauses:</strong> When I arrive, I will call you. (bukan when I will arrive)</p>
<p>as soon as, until, before, after + present untuk arti future.</p>`,
        rules: [
          "If + present (bukan if + will) di first conditional",
          "Koma jika if di depan",
          "when/as soon as + present, will di main clause"
        ],
        examples: [
          { en: "If I pass the test, I will apply for the exchange.", id: "Jika lulus, saya akan apply exchange.", why: "first conditional." },
          { en: "As soon as she finishes, she will email us.", id: "Segera setelah selesai, dia akan email.", why: "finishes = present form, future meaning." },
          { en: "I won't leave until you arrive.", id: "Saya tidak pergi sampai kamu datang.", why: "until + present." }
        ],
        compare: "First conditional = mungkin terjadi. Second conditional (nanti) = hipotetis sekarang.",
        commonErrors: [
          { wrong: "If it will rain…", right: "If it rains…", why: "if-clause present." },
          { wrong: "When I will see him…", right: "When I see him…", why: "time clause present." }
        ],
        vocab: [
          { en: "as soon as", id: "segera setelah", ipa: "/əz suːn əz/", ex: "as soon as possible" },
          { en: "unless", id: "kecuali jika", ipa: "/ənˈles/", ex: "unless you hurry" },
          { en: "in case", id: "jaga-jaga jika", ipa: "/ɪn keɪs/", ex: "in case it rains" }
        ],
        dialogue: `A: What will you do if you get the scholarship?\nB: I'll study abroad. As soon as I receive the result, I'll tell you.\nA: And if you don't get it?\nB: Then I'll apply again next year.`,
        summary: "If/when/as soon as + present, will + V1 di main clause.",
        guided: [
          { q: "If she ___, we ___ start without her.", options: ["will be late / will", "is late / will", "is late / are", "late / will"], correct: 1, explain: "is late / will start." },
          { q: "I ___ you when I ___.", options: ["will call / will arrive", "will call / arrive", "call / arrive", "call / will arrive"], correct: 1, explain: "will call / arrive." }
        ],
        independent: [
          { type: "write", q: "6 first conditionals tentang kuliah + 3 kalimat as soon as/until.", answer: "open", explain: "Cek if-clause." }
        ],
        practice: "Roleplay rencana weekend dengan 4 if-sentences.",
        evaluation: [
          { q: "If it ___ sunny, we ___ go out.", options: ["will be / will", "is / will", "is / are", "be / will"], correct: 1, explain: "is / will." },
          { q: "As soon as he ___, the meeting ___.", options: ["will arrive / starts", "arrives / will start", "arrives / starts", "will arrive / will start"], correct: 1, explain: "arrives / will start." },
          { q: "I won't buy it ___ it is on sale.", options: ["if", "unless", "when will", "as"], correct: 1, explain: "unless = if not." },
          { q: "If you ___ hard, you ___ pass.", options: ["will study / pass", "study / will pass", "studied / pass", "study / pass"], correct: 1, explain: "study / will pass." },
          { q: "When the semester ___, I ___ travel.", options: ["will end / will", "ends / will", "ends / am", "end / will"], correct: 1, explain: "ends / will travel." }
        ],
        remedial: "20 sentence completion if/when/as soon as."
      }
    },
    {
      id: "b1-u04",
      title: "Unit 4: Second Conditional (Hypothetical)",
      desc: "If + past, would — situasi tidak nyata sekarang",
      tags: ["Grammar", "Speaking"],
      content: {
        objectives: [
          "Membentuk second conditional",
          "Memakai were untuk semua subject di formal hypothetical",
          "Membedakan first vs second conditional"
        ],
        orientation: "Mimpi, saran hipotetis, situasitak nyata — penting untuk opini B1.",
        theory: `<p><strong>Second conditional:</strong> If + past simple, would + V1.</p>
<p>If I <strong>had</strong> more time, I <strong>would learn</strong> another language.</p>
<p>If I <strong>were</strong> you, I would talk to the lecturer. (were formal untuk semua subject)</p>
<p>First = mungkin. Second = imajinasi / kecil kemungkinannya sekarang.</p>`,
        rules: [
          "If + past, would + V1 (bukan would di if-clause)",
          "If I were you… (saran klasik)",
          "could/might di main clause untuk nuansa"
        ],
        examples: [
          { en: "If I won a scholarship, I would study in Japan.", id: "Jika saya menang beasiswa, saya akan kuliah di Jepang.", why: "hipotetis." },
          { en: "If she knew the answer, she would tell us.", id: "Jika dia tahu, dia akan memberi tahu.", why: "sekarang dia tidak tahu." },
          { en: "If I were richer, I would travel more.", id: "Jika saya lebih kaya…", why: "were + would." }
        ],
        compare: "If it rains, I will stay (mungkin hari ini). If it rained, I would stay (imajinasi).",
        commonErrors: [
          { wrong: "If I would be rich…", right: "If I were rich…", why: "would tidak di if-clause second." },
          { wrong: "If he was you… (informal ok, formal were)", right: "If he were you…", why: "traditional subjunctive." }
        ],
        vocab: [
          { en: "hypothetical", id: "hipotetis", ipa: "/ˌhaɪpəˈθetɪkl/", ex: "a hypothetical situation" },
          { en: "imagine", id: "membayangkan", ipa: "/ɪˈmædʒɪn/", ex: "Imagine if…" },
          { en: "would", id: "akan (hipotetis)", ipa: "/wʊd/", ex: "I would go" }
        ],
        dialogue: `A: What would you do if you had a free year?\nB: I would travel and volunteer. What about you?\nA: If I were free, I would take online courses abroad.`,
        summary: "If + past, would + V1 untuk tidak nyata sekarang.",
        guided: [
          { q: "If I ___ more money, I ___ buy a laptop.", options: ["have / will", "had / would", "had / will", "have / would"], correct: 1, explain: "had / would." },
          { q: "If I ___ you, I ___ email the professor.", options: ["am / will", "were / would", "was / will", "were / will"], correct: 1, explain: "were / would." }
        ],
        independent: [
          { type: "write", q: "8 second conditionals tentang karier, belajar, dan kota.", answer: "open", explain: "If + past, would." }
        ],
        practice: "Diskusi kelompok: If you could change one campus rule…",
        evaluation: [
          { q: "If he ___ harder, he ___ better grades.", options: ["studies / will get", "studied / would get", "studied / will get", "study / would get"], correct: 1, explain: "studied / would get." },
          { q: "If I ___ a bird, I ___ fly home.", options: ["am / will", "were / would", "was / will", "were / will"], correct: 1, explain: "were / would." },
          { q: "First conditional memakai…", options: ["past + would", "present + will", "past + will", "present + would"], correct: 1, explain: "present + will." },
          { q: "If she ___ the truth, she would be upset.", options: ["knows", "knew", "know", "knowing"], correct: 1, explain: "knew." },
          { q: "I ___ help if I ___.", options: ["will / can", "would / could", "would / can", "will / could"], correct: 1, explain: "would / could." }
        ],
        remedial: "Transform 10 first conditionals menjadi second (ubah makna jadi hipotetis)."
      }
    },
    {
      id: "b1-u05",
      title: "Unit 5: Passive Voice (Present & Past)",
      desc: "be + V3 — fokus ke proses dan objek",
      tags: ["Grammar", "Academic"],
      content: {
        objectives: [
          "Mengubah active → passive di present dan past",
          "Memilih passive saat pelaku tidak penting",
          "Menulis kalimat formal singkat dengan passive"
        ],
        orientation: "Academic B1: laporan, berita, prosedur sering passive.",
        theory: `<p><strong>Passive:</strong> object + be + V3 (+ by agent).</p>
<p>Present: The report <strong>is written</strong> every semester.</p>
<p>Past: The report <strong>was written</strong> last week.</p>
<p>Dipakai saat: pelaku tidak diketahui/tidak penting; ingin fokus hasil; gaya formal.</p>
<p>by + agent opsional: The window was broken (by the storm).</p>`,
        rules: [
          "be menyesuaikan tense; V3 tetap",
          "was/were written (bukan was wrote)",
          "Jangan hilangkan be"
        ],
        examples: [
          { en: "English is spoken in many countries.", id: "English dipakai di banyak negara.", why: "focus language." },
          { en: "The emails were sent yesterday.", id: "Email dikirim kemarin.", why: "past passive." },
          { en: "The lab was cleaned this morning.", id: "Lab dibersihkan pagi ini.", why: "agent tidak penting." }
        ],
        compare: "Active: Someone cleaned the lab. Passive: The lab was cleaned.",
        commonErrors: [
          { wrong: "The letter was wrote", right: "The letter was written", why: "V3." },
          { wrong: "The data analyzed", right: "The data were/was analyzed", why: "perlu be." }
        ],
        vocab: [
          { en: "process", id: "proses", ipa: "/ˈprəʊses/", ex: "the process is repeated" },
          { en: "publish", id: "menerbitkan", ipa: "/ˈpʌblɪʃ/", ex: "was published" },
          { en: "conduct", id: "melakukan (riset)", ipa: "/kənˈdʌkt/", ex: "was conducted" }
        ],
        dialogue: `A: Has the schedule been posted?\nB: Yes, it was posted this morning on the portal.\nA: Great. The rooms are cleaned every Friday.`,
        summary: "be + V3; tense pada be; agent opsional.",
        guided: [
          { q: "The email ___ sent yesterday.", options: ["is", "was", "were", "be"], correct: 1, explain: "was sent." },
          { q: "These books ___ in 2020.", options: ["publish", "were published", "was published", "published"], correct: 1, explain: "were published." }
        ],
        independent: [
          { type: "write", q: "Ubah 6 kalimat active menjadi passive (3 present, 3 past).", answer: "open", explain: "Cek be + V3." }
        ],
        practice: "Tulis 5 prosedur lab/perpustakaan dalam passive.",
        evaluation: [
          { q: "The results ___ published last year.", options: ["was", "were", "are", "been"], correct: 1, explain: "were published." },
          { q: "Coffee ___ in many countries.", options: ["grows", "is grown", "grew", "growing"], correct: 1, explain: "is grown." },
          { q: "The window ___ by the storm.", options: ["broke", "was broken", "was broke", "broken"], correct: 1, explain: "was broken." },
          { q: "V3 of take:", options: ["took", "taken", "taked", "taking"], correct: 1, explain: "taken." },
          { q: "A new rule ___ next month. (rencana formal)", options: ["will introduce", "will be introduced", "is introduce", "introduced"], correct: 1, explain: "will be introduced." }
        ],
        remedial: "Tabel active↔passive untuk 12 kalimat."
      }
    },
    {
      id: "b1-u06",
      title: "Unit 6: Relative Clauses (who/which/that)",
      desc: "Menggabungkan informasi dalam satu kalimat",
      tags: ["Grammar", "Writing"],
      content: {
        objectives: [
          "Memakai who/which/that untuk defining clauses",
          "Menggabungkan dua kalimat pendek jadi satu",
          "Menghindari sentence fragments"
        ],
        orientation: "Tulisan B1 lebih padat: satu kalimat membawa dua informasi terkait.",
        theory: `<p><strong>who</strong> → orang; <strong>which</strong> → benda; <strong>that</strong> → keduanya (defining).</p>
<p>The student <strong>who called you</strong> is my classmate.</p>
<p>The book <strong>that I bought</strong> is useful.</p>
<p>Defining clause = informasi penting (tanpa koma). Non-defining (dengan koma) = info tambahan (lebih B2).</p>`,
        rules: [
          "who/which/that menggantikan subject/object di clause kedua",
          "Defining: tanpa koma",
          "Jangan dobel object: The book that I bought it (salah)"
        ],
        examples: [
          { en: "Students who study daily improve faster.", id: "Siswa yang belajar tiap hari lebih cepat maju.", why: "who + defining." },
          { en: "This is the app that helps me practice.", id: "Ini app yang membantu saya latihan.", why: "that." },
          { en: "The laptop which I use is old.", id: "Laptop yang saya pakai sudah tua.", why: "which/that." }
        ],
        compare: "Dua kalimat vs satu relative clause — kohesi meningkat.",
        commonErrors: [
          { wrong: "The man which lives here…", right: "The man who lives here…", why: "who untuk orang." },
          { wrong: "The book that I bought it", right: "The book that I bought", why: "jangan it." }
        ],
        vocab: [
          { en: "clause", id: "klausa", ipa: "/klɔːz/", ex: "relative clause" },
          { en: "define", id: "mendefinisikan", ipa: "/dɪˈfaɪn/", ex: "defining clause" },
          { en: "combine", id: "menggabungkan", ipa: "/kəmˈbaɪn/", ex: "combine sentences" }
        ],
        dialogue: `A: Do you know the tutor who teaches listening?\nB: Yes. She's the one that helped me last semester.`,
        summary: "who people · which things · that both · no comma in defining clauses.",
        guided: [
          { q: "The woman ___ called is a doctor.", options: ["which", "who", "where", "what"], correct: 1, explain: "who." },
          { q: "The course ___ I chose is hard.", options: ["who", "which", "where", "whose"], correct: 1, explain: "which/that." }
        ],
        independent: [
          { type: "write", q: "Gabungkan 8 pasang kalimat dengan who/which/that.", answer: "open", explain: "Tanpa koma defining." }
        ],
        practice: "Deskripsikan 4 teman/benda di sekitarmu dengan relative clause.",
        evaluation: [
          { q: "People ___ live abroad face challenges.", options: ["which", "who", "where", "what"], correct: 1, explain: "who." },
          { q: "This is the video ___ explains passive voice.", options: ["who", "which", "where", "whose"], correct: 1, explain: "which/that." },
          { q: "Avoid:", options: ["the book that I read", "the book that I read it", "the book which I read", "the book I read"], correct: 1, explain: "jangan it." },
          { q: "whose menunjuk…", options: ["tempat", "kepemilikan", "waktu", "cara"], correct: 1, explain: "possession." },
          { q: "The students ___ answers were correct smiled.", options: ["who", "which", "whose", "that"], correct: 2, explain: "whose answers." }
        ],
        remedial: "15 sentence-combining drills."
      }
    },
    {
      id: "b1-u07",
      title: "Unit 7: Opinion Paragraphs & Linking",
      desc: "Menulis opini 100–140 kata dengan kohesi",
      tags: ["Writing", "Academic"],
      content: {
        objectives: [
          "Menulis paragraf opini dengan thesis, alasan, contoh",
          "Memakai linking: because, for example, however, therefore, in addition",
          "Menghindari pengulangan dan kalimat tidak lengkap"
        ],
        orientation: "B1 writing akademik dasar — sebelum essay penuh B2.",
        theory: `<p><strong>Struktur:</strong> Opinion → Reason 1 + example → Reason 2 → Closing.</p>
<p><strong>Linking:</strong> because, so, for example, however, therefore, in addition, on the other hand.</p>
<p>Target: 100–140 kata, grammar B1 (perfect, conditional, relative boleh muncul).</p>`,
        rules: [
          "Satu ide utama per paragraf",
          "Setiap alasan butuh support (example/explanation)",
          "Closing jangan ide baru total"
        ],
        examples: [
          { en: "I believe learning English is essential for university students because it opens internship opportunities. For example, many companies require intermediate English. In addition, academic articles are often in English. Therefore, daily practice is a smart investment.", id: "Model opini B1.", why: "claim + reasons + linkers." }
        ],
        compare: "Opini ≠ daftar bullet. Perlu development.",
        commonErrors: [
          { wrong: "Because good for job.", right: "It is useful because it improves job chances.", why: "butuh klausa lengkap." }
        ],
        vocab: [
          { en: "essential", id: "sangat penting", ipa: "/ɪˈsenʃl/", ex: "essential skill" },
          { en: "therefore", id: "oleh karena itu", ipa: "/ˈðeəfɔːr/", ex: "Therefore, we should…" },
          { en: "however", id: "namun", ipa: "/haʊˈevər/", ex: "However, costs are high." },
          { en: "in addition", id: "selain itu", ipa: "/ɪn əˈdɪʃn/", ex: "In addition, …" }
        ],
        dialogue: "",
        summary: "Opinion + because + example + therefore. Linkers untuk kohesi.",
        guided: [
          { q: "Linker untuk contoh:", options: ["however", "for example", "although", "despite"], correct: 1, explain: "for example." },
          { q: "Best thesis opener:", options: ["Maybe good", "I believe that…", "Yes", "Because"], correct: 1, explain: "I believe that…" }
        ],
        independent: [
          { type: "write", q: "Paragraf 120 kata: Should students work part-time? Gunakan minimal 3 linker.", answer: "open", explain: "Struktur opini." }
        ],
        practice: "Outline 3 topik: social media, online class, English for career.",
        evaluation: [
          { q: "therefore menandai…", options: ["contoh", "akibat/simpulan", "kontras saja", "salam"], correct: 1, explain: "simpulan." },
          { q: "however menandai…", options: ["contoh", "kontras", "sebab", "waktu"], correct: 1, explain: "kontras." },
          { q: "Opini B1 sebaiknya punya…", options: ["hanya 1 kata", "alasan + contoh", "hanya daftar vocab", "tanpa posisi"], correct: 1, explain: "alasan+contoh." },
          { q: "I ___ finished my draft, so I can rest.", options: ["have", "has", "had", "having"], correct: 0, explain: "have finished." },
          { q: "If we ___ now, we ___ the deadline.", options: ["start / will meet", "will start / meet", "started / meet", "start / meet"], correct: 0, explain: "first conditional." }
        ],
        remedial: "Template: I think… because…. For example…. In addition…. Therefore…."
      }
    },
    {
      id: "b1-u08",
      title: "Unit 8: B1 Checkpoint & Mini Project",
      desc: "Review B1 + proyek opini 120–150 kata",
      tags: ["Review", "Writing", "Evaluation"],
      content: {
        objectives: [
          "Mengintegrasikan perfect, continuous past, conditionals, passive, relative, opini",
          "Menyelesaikan proyek tulis opini terstruktur",
          "Lulus evaluasi B1 untuk membuka B2"
        ],
        orientation: "Penutup B1. Tunjukkan kontrol grammar B1 dalam teks yang kohesif.",
        theory: `<p><strong>Checklist B1:</strong> present perfect · past continuous · first/second conditional · passive · relative clauses · opinion paragraph.</p>
<p><strong>Mini project:</strong> Essay pendek 120–150 kata: topik pilihan (online learning / part-time jobs / English for careers) dengan minimal 1 perfect, 1 conditional, 1 relative clause.</p>`,
        rules: ["Jangan mengorbankan kejelasan demi grammar 'pamer'."],
        examples: [
          { en: "Students who have practiced daily often improve faster. If universities provided more conversation clubs, learners would gain confidence. English is used in many internships; therefore, it should be a priority.", id: "Cuplikan project-level.", why: "relative + perfect + second conditional + passive feel." }
        ],
        compare: "B1 = bisa argumen sederhana + grammar rentang menengah. B2 = kontrol lebih fleksibel dan formal.",
        commonErrors: [],
        vocab: [
          { en: "integrate", id: "mengintegrasikan", ipa: "/ˈɪntɪɡreɪt/", ex: "integrate skills" },
          { en: "cohesion", id: "kohesi", ipa: "/kəʊˈhiːʒn/", ex: "paragraph cohesion" }
        ],
        dialogue: "",
        summary: "B1 siap jika pengalaman, narasi, syarat, passive, relative, dan opini terhubung rapi.",
        guided: [
          { q: "Linker akibat:", options: ["for example", "however", "therefore", "who"], correct: 2, explain: "therefore." }
        ],
        independent: [
          { type: "write", q: "PROJECT: 130–150 kata opini + syarat grammar di atas.", answer: "open", explain: "Self-check list tense." }
        ],
        practice: "Baca project keras 90 detik; catat 3 self-corrections.",
        evaluation: [
          { q: "I ___ here since 2021.", options: ["live", "have lived", "lived", "am living"], correct: 1, explain: "have lived." },
          { q: "I ___ when the phone rang.", options: ["studied", "was studying", "study", "am studying"], correct: 1, explain: "was studying." },
          { q: "If it rains, we ___ stay in.", options: ["would", "will", "are", "can to"], correct: 1, explain: "will (first)." },
          { q: "If I ___ time, I would travel.", options: ["have", "had", "has", "having"], correct: 1, explain: "had (second)." },
          { q: "The rules ___ last year.", options: ["changed", "were changed", "was changed", "are change"], correct: 1, explain: "were changed." },
          { q: "Students ___ practice daily improve.", options: ["which", "who", "where", "whose"], correct: 1, explain: "who." },
          { q: "I believe that English is essential ___ it opens opportunities.", options: ["however", "because", "therefore", "who"], correct: 1, explain: "because." },
          { q: "She has already ___.", options: ["submit", "submitted", "submitting", "submits"], correct: 1, explain: "submitted." }
        ],
        remedial: "Ulangi unit B1 dengan skor terendah; tulis ulang project setelah review."
      }
    }
  ],

  b2: [
    {
      id: "b2-u01",
      title: "Unit 1: Passive Voice & Formal Style",
      desc: "be + V3 untuk akademik",
      tags: ["Grammar", "Academic"],
      content: {
        objectives: ["Mengubah active→passive di present/past", "Memilih passive saat agent tidak penting"],
        orientation: "B2 akademik: fokus proses/hasil.",
        theory: `<p>Passive: object + be + V3 (+ by agent). The report was written (by the team).</p>
<p>Dipakai di lab report, news, academic writing saat pelaku kurang penting.</p>`,
        rules: ["was written (bukan was wrote)", "by + agent opsional"],
        examples: [
          { en: "The data were analyzed carefully.", id: "Data dianalisis dengan saksama.", why: "passive past." }
        ],
        compare: "Active menekankan pelaku; passive menekankan aksi/objek.",
        commonErrors: [{ wrong: "The letter was wrote", right: "The letter was written", why: "V3." }],
        vocab: [
          { en: "conduct", id: "melakukan (riset)", ipa: "/kənˈdʌkt/", ex: "conduct a study" },
          { en: "analyze", id: "menganalisis", ipa: "/ˈænəlaɪz/", ex: "analyze data" }
        ],
        dialogue: "",
        summary: "be + V3; formal tone.",
        guided: [{ q: "The email ___ sent yesterday.", options: ["is", "was", "were", "be"], correct: 1, explain: "was sent." }],
        independent: [{ type: "write", q: "Ubah 5 kalimat active ke passive.", answer: "open", explain: "Cek tense be." }],
        practice: "Tulis 1 paragraf metode riset singkat (passive-heavy).",
        evaluation: [
          { q: "The results ___ published in 2024.", options: ["was", "were", "are", "been"], correct: 1, explain: "were published." },
          { q: "English ___ in many countries.", options: ["speaks", "is spoken", "spoke", "speaking"], correct: 1, explain: "is spoken." },
          { q: "Agent opsional diawali…", options: ["with", "by", "from", "of"], correct: 1, explain: "by." },
          { q: "A new policy ___ next year. (rencana formal)", options: ["will introduce", "will be introduced", "is introduce", "introduced"], correct: 1, explain: "will be introduced." },
          { q: "V3 of 'take':", options: ["took", "taken", "taked", "taking"], correct: 1, explain: "taken." }
        ],
        remedial: "Tabel tense passive: am/is/are + V3 · was/were + V3 · will be + V3."
      }
    },
    {
      id: "b2-u02",
      title: "Unit 2: Relative Clauses & Cohesion",
      desc: "who/which/that, linking devices",
      tags: ["Grammar", "Writing"],
      content: {
        objectives: ["Menggabungkan kalimat dengan relative pronouns", "Meningkatkan kohesi paragraf"],
        orientation: "Kalimat B2 lebih padat dan terhubung.",
        theory: `<p>who (orang), which (benda), that (keduanya, defining). The student who called is my friend.</p>
<p>Linking: however, therefore, in addition, although, despite.</p>`,
        rules: ["Comma untuk non-defining clauses."],
        examples: [{ en: "The course, which starts in July, is full.", id: "Non-defining which.", why: "info tambahan." }],
        compare: "although (clause) vs despite (noun/gerund).",
        commonErrors: [{ wrong: "Despite he was tired…", right: "Although he was tired… / Despite being tired…", why: "despite ≠ subject + verb langsung." }],
        vocab: [
          { en: "however", id: "namun", ipa: "/haʊˈevər/", ex: "However, costs rose." },
          { en: "therefore", id: "oleh karena itu", ipa: "/ˈðeəfɔːr/", ex: "Therefore, we stopped." }
        ],
        dialogue: "",
        summary: "Relative clauses + linkers = teks B2.",
        guided: [{ q: "The book ___ I bought is excellent.", options: ["who", "which", "where", "whose"], correct: 1, explain: "which/that." }],
        independent: [{ type: "write", q: "Gabungkan 6 pasang kalimat dengan who/which + 1 paragraf dengan however/therefore.", answer: "open", explain: "Kohesi." }],
        practice: "Edit paragraf kasar menjadi relatif + linker.",
        evaluation: [
          { q: "Students ___ study daily improve faster.", options: ["which", "who", "where", "what"], correct: 1, explain: "who." },
          { q: "___ the rain, the match continued. (despite)", options: ["Despite", "Although", "However", "Because"], correct: 0, explain: "Despite + noun." },
          { q: "It was expensive; ___, we bought it.", options: ["therefore", "however", "because", "who"], correct: 1, explain: "however." },
          { q: "Defining clause biasanya…", options: ["wajib koma", "tanpa koma", "selalu which saja", "tanpa pronoun"], correct: 1, explain: "tanpa koma." },
          { q: "The laptop ___ battery is dead is mine.", options: ["who", "which", "whose", "whom"], correct: 2, explain: "whose." }
        ],
        remedial: "Latihan relative: 15 sentence combining."
      }
    },
    {
      id: "b2-u03",
      title: "Unit 3: B2 Checkpoint — Argument Essay Mini",
      desc: "Esai singkat 150–180 kata",
      tags: ["Writing", "Evaluation"],
      content: {
        objectives: ["Menulis esai singkat dengan 2 body reasons"],
        orientation: "Persiapan menuju C1 & IELTS Task 2 style (bukan tes IELTS penuh).",
        theory: `<p>Intro paraphrase + thesis · Body1 · Body2 · Conclusion. Academic tone, passive/relatives optional.</p>`,
        rules: [],
        examples: [],
        compare: "",
        commonErrors: [],
        vocab: [{ en: "thesis", id: "pernyataan posisi", ipa: "/ˈθiːsɪs/", ex: "clear thesis" }],
        dialogue: "",
        summary: "Argument terstruktur B2.",
        guided: [{ q: "Thesis sentence sebaiknya…", options: ["pertanyaan saja", "posisi jelas", "kutipan panjang", "daftar vocab"], correct: 1, explain: "posisi jelas." }],
        independent: [{ type: "write", q: "Essay 150 kata: Online learning vs face-to-face.", answer: "open", explain: "2 reasons." }],
        practice: "Outline 3 topik B2.",
        evaluation: [
          { q: "The policy ___ last month.", options: ["was introduced", "introduced", "was introduce", "introducing"], correct: 0, explain: "passive." },
          { q: "People ___ live abroad face challenges.", options: ["which", "who", "where", "whose"], correct: 1, explain: "who." },
          { q: "___ high costs, demand rose.", options: ["Although", "Despite", "However", "Because"], correct: 1, explain: "Despite + noun." },
          { q: "Cohesion device untuk hasil:", options: ["for example", "however", "therefore", "who"], correct: 2, explain: "therefore." },
          { q: "B2 writing prioritaskan…", options: ["hanya vocab susah", "struktur + clarity", "kalimat 1 kata", "tanpa thesis"], correct: 1, explain: "struktur + clarity." }
        ],
        remedial: "Template 4 paragraf; tulis ulang 1 topik."
      }
    }
  ],

  c1: [
    {
      id: "c1-u01",
      title: "Unit 1: Advanced Nominalization & Concision",
      desc: "Gaya akademik padat",
      tags: ["Academic", "Writing"],
      content: {
        objectives: ["Mengubah clause menjadi noun phrase", "Mengurangi wordiness"],
        orientation: "C1: presisi dan kepadatan.",
        theory: `<p>Nominalization: decide→decision, analyze→analysis. The analysis of the data revealed…</p>
<p>Hindari: It is important to note that… → Importantly, … / The data show…</p>`,
        rules: ["Jaga kejelasan; jangan nominalisasi berlebihan sampai gelap."],
        examples: [{ en: "Their refusal to negotiate prolonged the dispute.", id: "Nominalization padat.", why: "refusal = they refused." }],
        compare: "Spoken loose vs written dense.",
        commonErrors: [{ wrong: "The doing of the research…", right: "The research… / Conducting the research…", why: "gerund/noun natural." }],
        vocab: [
          { en: "nevertheless", id: "meski demikian", ipa: "/ˌnevəðəˈles/", ex: "Nevertheless, risks remain." },
          { en: "substantial", id: "besar/berarti", ipa: "/səbˈstænʃl/", ex: "substantial evidence" }
        ],
        dialogue: "",
        summary: "Padat, formal, akurat.",
        guided: [{ q: "They decided → Their ___", options: ["decide", "decision", "decidingly", "decidedness"], correct: 1, explain: "decision." }],
        independent: [{ type: "write", q: "Ubah 1 paragraf longgar menjadi versi C1 padat (120 kata).", answer: "open", explain: "Nominalization + cut filler." }],
        practice: "Edit abstract palsu menjadi concision tinggi.",
        evaluation: [
          { q: "Improve: 'People analyzed the data and they found errors.'", options: ["Analysis of the data revealed errors.", "Data was and errors.", "They data errors.", "Analyze found."], correct: 0, explain: "nominalization." },
          { q: "nevertheless ≈", options: ["so", "however", "because", "and"], correct: 1, explain: "contrast." },
          { q: "Wordy: 'due to the fact that' →", options: ["because", "despite", "who", "and"], correct: 0, explain: "because." },
          { q: "C1 tone menghindari…", options: ["presisi", "slang berlebihan", "kohesi", "contoh"], correct: 1, explain: "slang." },
          { q: "substantial evidence means…", options: ["bukti lemah", "bukti cukup besar", "tanpa bukti", "opini"], correct: 1, explain: "cukup besar." }
        ],
        remedial: "Latihan paraphrase akademik 10 kalimat."
      }
    },
    {
      id: "c1-u02",
      title: "Unit 2: C1 Checkpoint — Critical Response",
      desc: "Tanggapan kritis 180–220 kata",
      tags: ["Writing", "Evaluation"],
      content: {
        objectives: ["Menulis respons kritis dengan hedging dan evaluasi"],
        orientation: "C1: evaluasi klaim, bukan hanya setuju.",
        theory: `<p>Hedging: may, might, appears to, suggests. Evaluasi: strength of evidence, limitation.</p>`,
        rules: [],
        examples: [],
        compare: "",
        commonErrors: [],
        vocab: [{ en: "hedging", id: "penenangan klaim", ipa: "/ˈhedʒɪŋ/", ex: "academic hedging" }],
        dialogue: "",
        summary: "Critical + hedged + structured.",
        guided: [{ q: "Hedging example:", options: ["This proves always", "This may suggest", "This 100% true", "No need data"], correct: 1, explain: "may suggest." }],
        independent: [{ type: "write", q: "Critical paragraph on: Social media improves learning. (200 kata)", answer: "open", explain: "hedge + evaluate." }],
        practice: "Kritik 1 klaim berita dengan 2 batasan.",
        evaluation: [
          { q: "appears to indicate ≈", options: ["pasti mutlak", "terlihat mengindikasikan", "tidak ada hubungan", "slang"], correct: 1, explain: "hedge." },
          { q: "Nominalization of 'fail':", options: ["failingness", "failure", "failed", "fails"], correct: 1, explain: "failure." },
          { q: "C1 writing needs…", options: ["hanya emosi", "nuance + structure", "kalimat acak", "tanpa contoh"], correct: 1, explain: "nuance." },
          { q: "nevertheless digunakan untuk…", options: ["menambah contoh", "kontras", "menyapa", "jam"], correct: 1, explain: "kontras." },
          { q: "Limitation sentence example starts with…", options: ["This study is limited by…", "I hate…", "Randomly…", "Yo…"], correct: 0, explain: "limitation." }
        ],
        remedial: "Bank hedging phrases: may, might, could, seems, appears, suggests."
      }
    }
  ],

  c2: [
    {
      id: "c2-u01",
      title: "Unit 1: Stylistic Control & Register Shift",
      desc: "Menggeser register formal↔informal dengan presisi",
      tags: ["Style", "Advanced"],
      content: {
        objectives: ["Mengubah teks ke register berbeda tanpa ubah makna", "Mengontrol tone"],
        orientation: "C2: kendali gaya sadar.",
        theory: `<p>Register: formal academic, neutral professional, informal spoken. Pilih leksis, kontraksi, passive, idiom sesuai audiens.</p>`,
        rules: ["Jangan campur slang di abstract akademik."],
        examples: [
          { en: "Informal: Kids keep messing up the lab. → Formal: Students frequently compromise laboratory protocols.", id: "Register shift.", why: "leksis + tone." }
        ],
        compare: "Near-synonyms beda konotasi: cheap vs inexpensive vs affordable.",
        commonErrors: [{ wrong: "In conclusion, the stuff is cool.", right: "In conclusion, the findings are noteworthy.", why: "register." }],
        vocab: [
          { en: "register", id: "ragam bahasa", ipa: "/ˈredʒɪstər/", ex: "formal register" },
          { en: "nuance", id: "nuansa", ipa: "/ˈnjuːɑːns/", ex: "semantic nuance" }
        ],
        dialogue: "",
        summary: "C2 = kontrol register dan nuansa.",
        guided: [{ q: "Paling formal:", options: ["gonna", "will", "shall endeavour to", "wanna"], correct: 2, explain: "endeavour formal." }],
        independent: [{ type: "write", q: "Tulis 1 pesan ke teman lalu versi email ke dosen (sama isi).", answer: "open", explain: "Register shift." }],
        practice: "Paraphrase 5 kalimat ke 3 register.",
        evaluation: [
          { q: "affordable vs cheap — affordable lebih…", options: ["kasar", "netral-profesional", "slang", "salah eja"], correct: 1, explain: "lebih netral." },
          { q: "Academic abstract sebaiknya…", options: ["banyak kontraksi", "minim slang", "emoji", "basa gaul"], correct: 1, explain: "minim slang." },
          { q: "nuance penting di C2 karena…", options: ["mengabaikan makna", "membedakan makna halus", "menghapus grammar", "mengganti alphabet"], correct: 1, explain: "makna halus." },
          { q: "compromise protocols means…", options: ["memperkuat aturan", "melemahkan/melanggar protokol", "membeli protokol", "menerjemahkan"], correct: 1, explain: "melemahkan." },
          { q: "C2 writer mengontrol…", options: ["hanya spelling", "tone, register, precision", "hanya font", "hanya warna"], correct: 1, explain: "tone/register/precision." }
        ],
        remedial: "Baca 1 editorial + 1 chat; daftar beda leksis."
      }
    },
    {
      id: "c2-u02",
      title: "Unit 2: C2 Checkpoint — Synthesis Essay",
      desc: "Sintesis argumen 220–280 kata",
      tags: ["Writing", "Evaluation"],
      content: {
        objectives: ["Mensintesis 2 sudut pandang jadi posisi bernuansa"],
        orientation: "Puncak jalur umum sebelum track ujian (IELTS/TOEFL) terpisah.",
        theory: `<p>Synthesis: sajikan posisi A & B, evaluasi, posisikan diri dengan caveat. Bukan ringkasan polos.</p>`,
        rules: [],
        examples: [],
        compare: "",
        commonErrors: [],
        vocab: [{ en: "synthesis", id: "sintesis", ipa: "/ˈsɪnθəsɪs/", ex: "synthesis of views" }],
        dialogue: "",
        summary: "Sintesis bernuansa = C2 writing control.",
        guided: [{ q: "Synthesis essay harus…", options: ["hanya copy sumber", "mengintegrasikan & mengevaluasi", "tanpa posisi", "hanya daftar bullet"], correct: 1, explain: "integrasi + evaluasi." }],
        independent: [{ type: "write", q: "Sintesis 250 kata: AI in education — opportunity vs risk.", answer: "open", explain: "2 views + nuanced stance." }],
        practice: "Outline synthesis untuk 2 isu sosial.",
        evaluation: [
          { q: "Register akademik menghindari…", options: ["presisi", "slang", "kohesi", "contoh"], correct: 1, explain: "slang." },
          { q: "nuance stance berarti…", options: ["hitam-putih kaku", "posisi dengan caveat", "tanpa opini", "copy paste"], correct: 1, explain: "caveat." },
          { q: "therefore menandai…", options: ["contoh", "akibat/simpulan logis", "salam", "tanya"], correct: 1, explain: "simpulan." },
          { q: "C2 checkpoint fokus…", options: ["alphabet saja", "kontrol wacana & gaya", "hanya listening anak", "warna UI"], correct: 1, explain: "wacana & gaya." },
          { q: "Setelah C2, IELTS/TOEFL di LinguaPro adalah…", options: ["pengganti belajar bahasa", "jalur latihan ujian lanjutan", "A1 ulang", "menghapus grammar"], correct: 1, explain: "latihan ujian lanjutan." }
        ],
        remedial: "Baca model synthesis; tulis ulang dengan hedging."
      }
    }
  ]
};

// Expose pass threshold
if (typeof window !== "undefined") {
  window.CEFR_ORDER = CEFR_ORDER;
  window.CEFR_META = CEFR_META;
  window.UNIT_PASS_SCORE = UNIT_PASS_SCORE;
  window.LEARN_PATH = LEARN_PATH;
}
