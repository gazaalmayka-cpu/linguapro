/* ========== LinguaPro App Logic ========== */

const USERS_KEY = "linguapro_users";
const SESSION_KEY = "linguapro_session";

function getUsers() {
  try { return JSON.parse(localStorage.getItem(USERS_KEY) || "{}"); } catch { return {}; }
}
function saveUsers(u) { localStorage.setItem(USERS_KEY, JSON.stringify(u)); }
function getSessionEmail() { return localStorage.getItem(SESSION_KEY) || ""; }
function setSession(email) { localStorage.setItem(SESSION_KEY, email); }
function clearSession() { localStorage.removeItem(SESSION_KEY); }

function defaultUserData(name, email) {
  return {
    name: name || "",
    email: email || "",
    level: "a1",
    unlockedLevels: ["a1"],
    xp: 0,
    streak: 0,
    lastStudyDate: null,
    lessonsCompleted: [],
    goals: [],
    mockHistory: [],
    placementDone: false,
    placementScore: 0,
    bestMock: null,
    levelTestsPassed: [],
    vocabMastered: [],
    unitRecords: {},
    mistakes: [],
    learningTrack: null
  };
}

function loadState() {
  const email = getSessionEmail();
  if (!email) return defaultUserData("", "");
  const users = getUsers();
  if (!users[email]) return defaultUserData("", "");
  return { ...defaultUserData(users[email].name, email), ...(users[email].data || {}) };
}

function saveState() {
  const email = state.email || getSessionEmail();
  if (!email) return;
  const users = getUsers();
  if (!users[email]) return;
  users[email].name = state.name;
  users[email].data = { ...state };
  saveUsers(users);
}

function isLevelUnlocked(level) {
  return (state.unlockedLevels || ["beginner"]).includes(level);
}

function levelUnitProgress(level) {
  const units = (typeof LEARN_PATH !== "undefined" && LEARN_PATH[level]) ? LEARN_PATH[level] : [];
  if (!units.length) return 0;
  const done = units.filter(u => (state.lessonsCompleted || []).includes(u.id)).length;
  return Math.round((done / units.length) * 100);
}

function isReadyForLevelExam(level) {
  return levelUnitProgress(level) >= 70;
}

/** Stricter objective speaking score */
function objectiveSpeakingScore(text, themeKeywords) {
  const words = (text || "").trim().split(/\s+/).filter(Boolean);
  const n = words.length;
  const lower = (text || "").toLowerCase();
  let band = 3.0;
  const tips = [];
  if (n >= 80) band += 1.5;
  else if (n >= 50) band += 1.0;
  else if (n >= 30) band += 0.5;
  else if (n >= 15) band += 0.25;
  else tips.push("Jawaban terlalu pendek (target Part 2: 50–90+ kata).");

  const kws = (themeKeywords || []).map(k => String(k).toLowerCase()).filter(Boolean);
  let hits = 0;
  kws.forEach(k => { if (lower.includes(k)) hits++; });
  const rel = kws.length ? hits / kws.length : 0.5;
  if (rel >= 0.4) band += 1.2;
  else if (rel >= 0.2) band += 0.5;
  else if (rel > 0) band += 0.15;
  else { band -= 0.6; tips.push("Kurang sesuai tema pertanyaan — skor turun."); }

  if (/\b(because|which|that|when|if|although|while|however)\b/i.test(text)) band += 0.55;
  else tips.push("Tambah complex sentences.");
  if (/\b(would|could|should|might)\b/i.test(text)) band += 0.3;
  if (/\b(have|has|had)\s+\w+/i.test(text)) band += 0.25;

  const uniq = new Set(words.map(w => w.toLowerCase().replace(/[^a-z']/g, "")));
  const ratio = uniq.size / Math.max(n, 1);
  if (ratio > 0.7 && n > 20) band += 0.65;
  else if (ratio > 0.5) band += 0.3;
  else tips.push("Vocabulary kurang variatif.");

  const fillers = (lower.match(/\b(um+|uh+|like|you know)\b/g) || []).length;
  if (fillers > 5) { band -= 0.35; tips.push("Kurangi filler (um, like)."); }

  band = Math.max(2.0, Math.min(9.0, Math.round(band * 2) / 2));
  return { band, tips, n, hits, totalKw: kws.length };
}

let state = loadState();
let placementIndex = 0;
let placementAnswers = [];
let placementPool = [];
let currentPractice = null;
let currentMock = null;
let mockTimerInterval = null;
let mockTimeLeft = 0;
let speechUtterance = null;

// ---------- Init ----------
document.addEventListener("DOMContentLoaded", () => {
  setTimeout(() => {
    document.getElementById("loading-screen").classList.add("hidden");
    const email = getSessionEmail();
    state = loadState();
    if (email && state.placementDone && state.name) {
      showApp();
    } else if (email && state.name && !state.placementDone) {
      document.getElementById("onboarding").classList.remove("hidden");
      document.getElementById("step-auth").classList.add("hidden");
      document.getElementById("step-placement").classList.remove("hidden");
      placementPool = shuffle(PLACEMENT_QUESTIONS).map(q => {
        const indices = q.options.map((_, i) => i);
        const shuffledIdx = shuffle(indices);
        return { ...q, options: shuffledIdx.map(i => q.options[i]), correct: shuffledIdx.indexOf(q.correct) };
      });
      placementIndex = 0;
      placementAnswers = new Array(placementPool.length).fill(null);
      renderPlacementQuestion();
    } else {
      document.getElementById("onboarding").classList.remove("hidden");
      document.getElementById("step-auth").classList.remove("hidden");
    }
  }, 1200);

  // Nav
  document.querySelectorAll(".nav-item").forEach(item => {
    item.addEventListener("click", (e) => {
      e.preventDefault();
      navigateTo(item.dataset.page);
    });
  });

  // Grammar tabs
  document.querySelectorAll("#grammar-tabs .tab").forEach(tab => {
    tab.addEventListener("click", () => {
      document.querySelectorAll("#grammar-tabs .tab").forEach(t => t.classList.remove("active"));
      tab.classList.add("active");
      renderGrammar(tab.dataset.level);
    });
  });

  // Mock tabs
  document.querySelectorAll(".mock-tabs .tab").forEach(tab => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".mock-tabs .tab").forEach(t => t.classList.remove("active"));
      tab.classList.add("active");
      const type = tab.dataset.test;
      document.querySelectorAll(".mock-card").forEach(c => {
        c.style.display = c.dataset.type === type ? "block" : "none";
      });
    });
  });
});

// ---------- Onboarding ----------
function showAuthTab(tab) {
  document.getElementById("tab-login").classList.toggle("active", tab === "login");
  document.getElementById("tab-register").classList.toggle("active", tab === "register");
  document.getElementById("auth-login").classList.toggle("hidden", tab !== "login");
  document.getElementById("auth-register").classList.toggle("hidden", tab !== "register");
}

function doRegister() {
  const name = (document.getElementById("reg-name").value || "").trim();
  const email = (document.getElementById("reg-email").value || "").trim().toLowerCase();
  const pass = document.getElementById("reg-pass").value || "";
  if (!name || !email || pass.length < 6) {
    showToast("Isi nama, email, dan password min. 6 karakter!", "error");
    return;
  }
  const users = getUsers();
  if (users[email]) {
    showToast("Email sudah terdaftar! Silakan masuk.", "error");
    showAuthTab("login");
    document.getElementById("login-email").value = email;
    return;
  }
  const data = defaultUserData(name, email);
  users[email] = { name, pass, data };
  saveUsers(users);
  setSession(email);
  state = { ...data };
  saveState();
  showToast("Akun berhasil dibuat!", "success");
  document.getElementById("step-auth").classList.add("hidden");
  startPlacementFlow();
}

function doLogin() {
  const email = (document.getElementById("login-email").value || "").trim().toLowerCase();
  const pass = document.getElementById("login-pass").value || "";
  const users = getUsers();
  if (!users[email] || users[email].pass !== pass) {
    showToast("Email atau password salah!", "error");
    return;
  }
  setSession(email);
  state = { ...defaultUserData(users[email].name, email), ...(users[email].data || {}) };
  if (state.placementDone) {
    document.getElementById("onboarding").classList.add("hidden");
    showApp();
  } else {
    document.getElementById("step-auth").classList.add("hidden");
    startPlacementFlow();
  }
  showToast("Selamat datang kembali, " + state.name + "!", "success");
}

function doLogout() {
  if (!confirm("Logout dari akun ini?")) return;
  clearSession();
  location.reload();
}

function startPlacementFlow() {
  document.getElementById("step-placement").classList.remove("hidden");
  placementPool = shuffle(PLACEMENT_QUESTIONS).map(q => {
    const indices = q.options.map((_, i) => i);
    const shuffledIdx = shuffle(indices);
    return { ...q, options: shuffledIdx.map(i => q.options[i]), correct: shuffledIdx.indexOf(q.correct) };
  });
  placementIndex = 0;
  placementAnswers = new Array(placementPool.length).fill(null);
  renderPlacementQuestion();
}

function renderPlacementQuestion() {
  const q = placementPool[placementIndex];
  const total = placementPool.length;
  const container = document.getElementById("placement-question");
  let html = `<div class="q-number">Soal ${placementIndex + 1} · ${q.type.toUpperCase()}</div>`;
  if (q.passage) {
    html += `<div class="passage-box" style="margin-bottom:16px;font-size:0.95rem;background:#f1f5f9;color:#334155;border-radius:12px;padding:16px;"><em>${q.passage}</em></div>`;
  }
  html += `<div class="q-text">${q.question}</div>`;
  q.options.forEach((opt, i) => {
    const selected = placementAnswers[placementIndex] === i ? "selected" : "";
    html += `<div class="option ${selected}" onclick="selectPlacement(${i})">
      <span class="opt-letter">${String.fromCharCode(65 + i)}</span>
      <span>${opt}</span>
    </div>`;
  });
  container.innerHTML = html;

  document.getElementById("placement-bar").style.width = `${((placementIndex + 1) / total) * 100}%`;
  document.getElementById("placement-counter").textContent = `${placementIndex + 1} / ${total}`;
  document.getElementById("btn-prev-placement").disabled = placementIndex === 0;
  document.getElementById("btn-next-placement").textContent =
    placementIndex === total - 1 ? "Selesai ✓" : "Selanjutnya";
}

function selectPlacement(idx) {
  placementAnswers[placementIndex] = idx;
  renderPlacementQuestion();
}

function prevPlacement() {
  if (placementIndex > 0) {
    placementIndex--;
    renderPlacementQuestion();
  }
}

function nextPlacement() {
  if (placementAnswers[placementIndex] === null) {
    showToast("Pilih jawaban dulu!", "error");
    return;
  }
  if (placementIndex < placementPool.length - 1) {
    placementIndex++;
    renderPlacementQuestion();
  } else {
    finishPlacement();
  }
}

function finishPlacement() {
  let score = 0;
  placementPool.forEach((q, i) => {
    if (placementAnswers[i] === q.correct) score++;
  });
  state.placementScore = score;
  state.placementDone = true;

  const order = (typeof CEFR_ORDER !== "undefined") ? CEFR_ORDER : ["a1","a2","b1","b2","c1","c2"];
  if (score <= 4) state.level = "a1";
  else if (score <= 7) state.level = "a2";
  else if (score <= 10) state.level = "b1";
  else if (score <= 12) state.level = "b2";
  else if (score <= 14) state.level = "c1";
  else state.level = "c2";

  const idx = order.indexOf(state.level);
  state.unlockedLevels = order.slice(0, Math.max(0, idx) + 1);

  state.xp += score * 5;
  saveState();

  document.getElementById("step-placement").classList.add("hidden");
  document.getElementById("step-result").classList.remove("hidden");
  document.getElementById("result-level").textContent = capitalize(state.level);
  document.getElementById("result-score").textContent = score;

  const descs = {
    beginner: "Kamu masih di tahap fondasi. Fokus ke grammar dasar, vocabulary, dan sentence structure. Semangat!",
    intermediate: "Dasar kamu sudah kuat! Saatnya mendalami tense kompleks, conditionals, dan passive voice.",
    advanced: "Level tinggi! Kamu siap untuk academic writing, advanced grammar, dan persiapan IELTS/TOEFL serius.",
    pro: "Excellent! Kamu di level native-like. Fokus ke nuance, style, dan skor band 8+ / TOEFL 110+."
  };
  document.getElementById("result-desc").textContent = descs[state.level];
}

function goToDashboard() {
  document.getElementById("onboarding").classList.add("hidden");
  showApp();
}

function showApp() {
  document.getElementById("app").classList.remove("hidden");
  updateUI();
  navigateTo("dashboard");
  updateStreak();
}

// ---------- Navigation ----------
function navigateTo(page) {
  document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
  document.querySelectorAll(".nav-item").forEach(n => n.classList.remove("active"));
  const pageEl = document.getElementById(`page-${page}`);
  if (pageEl) pageEl.classList.add("active");
  const nav = document.querySelector(`.nav-item[data-page="${page}"]`);
  if (nav) nav.classList.add("active");

  if (page === "dashboard") renderDashboard();
  if (page === "grammar") renderGrammar(state.level);
  if (page === "learn") renderLearnPath(state.level);
  if (page === "vocab") renderVocabBank(state.level || "a1");
  if (page === "mistakes") renderMistakes();
  if (page === "writinglab") { /* static form */ }
  if (page === "goals") { renderGoals(); renderTrackStatus(); }
  if (page === "progress") { renderProgress(); setTimeout(renderProgressCompetencePatch, 0); }
  if (page === "aitutor") {
    loadAIHistory();
    renderAIHistory();
  }
  if (page === "aicall") backToCallLobby();
  if (page === "mocktest") {
    document.getElementById("mock-selection").classList.remove("hidden");
    document.getElementById("mock-runner").classList.add("hidden");
    document.getElementById("mock-result").classList.add("hidden");
  }
  if (page === "practice") {
    document.getElementById("practice-area").classList.add("hidden");
    document.querySelector(".skill-grid").style.display = "grid";
  }

  // Close sidebar on mobile
  document.getElementById("sidebar").classList.remove("open");
}

function toggleSidebar() {
  document.getElementById("sidebar").classList.toggle("open");
}

// ---------- UI Update ----------
function updateUI() {
  document.getElementById("sidebar-name").textContent = state.name || "Mahasiswa";
  document.getElementById("sidebar-level").textContent = capitalize(state.level);
  document.getElementById("user-avatar").textContent = (state.name || "M")[0].toUpperCase();
  document.getElementById("dash-name").textContent = state.name || "Mahasiswa";
  document.getElementById("dash-level").textContent = capitalize(state.level);
  document.getElementById("dash-lessons").textContent = state.lessonsCompleted.length;
  document.getElementById("xp-count").textContent = state.xp;
  document.getElementById("streak-count").textContent = state.streak;

  const goalPct = calcGoalProgress();
  document.getElementById("dash-goal").textContent = goalPct + "%";
  document.getElementById("dash-best").textContent = state.bestMock || "-";
}

function capitalize(s) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

function updateStreak() {
  const today = new Date().toDateString();
  if (state.lastStudyDate === today) return;
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  if (state.lastStudyDate === yesterday.toDateString()) {
    state.streak += 1;
  } else if (state.lastStudyDate !== today) {
    state.streak = 1;
  }
  state.lastStudyDate = today;
  saveState();
  updateUI();
}

// ---------- Dashboard ----------
function renderDashboard() {
  updateUI();
  const grid = document.getElementById("continue-grid");
  const items = [];
  if (state.lessonsCompleted.length < 3) {
    items.push({ icon: "fa-book", title: "Grammar " + capitalize(state.level), sub: "Lanjutkan pelajaran", page: "grammar" });
  }
  items.push({ icon: "fa-headphones", title: "Listening Practice", sub: "Latih telinga", page: "practice" });
  items.push({ icon: "fa-clipboard-list", title: "Mock Test", sub: "Uji kemampuanmu", page: "mocktest" });
  grid.innerHTML = items.map(i => `
    <div class="continue-card" onclick="navigateTo('${i.page}')">
      <div class="cc-icon"><i class="fas ${i.icon}"></i></div>
      <div>
        <h4>${i.title}</h4>
        <span>${i.sub}</span>
      </div>
    </div>
  `).join("");
}

// ---------- Grammar ----------
function renderGrammar(level) {
  if (!isLevelUnlocked(level)) {
    showToast("Level grammar ini terkunci.", "error");
    level = state.level;
  }
  document.querySelectorAll("#grammar-tabs .tab").forEach(t => {
    const lv = t.dataset.level;
    t.classList.toggle("locked", !isLevelUnlocked(lv));
    t.onclick = () => {
      if (!isLevelUnlocked(lv)) { showToast("🔒 Terkunci sampai level sebelumnya lulus ujian.", "error"); return; }
      document.querySelectorAll("#grammar-tabs .tab").forEach(x => x.classList.remove("active"));
      t.classList.add("active");
      renderGrammar(lv);
    };
  });
  const list = document.getElementById("grammar-list");
  const lessons = GRAMMAR_LESSONS[level] || [];
  list.innerHTML = lessons.map(lesson => {
    const done = (state.lessonsCompleted || []).includes(lesson.id);
    return `
      <div class="grammar-item" id="g-${lesson.id}">
        <div class="grammar-item-header" onclick="toggleGrammar('${lesson.id}')">
          <h3><i class="fas fa-bookmark"></i> ${lesson.title}</h3>
          <span class="status ${done ? 'done' : 'todo'}">${done ? 'Selesai' : 'Belum'}</span>
        </div>
        <div class="grammar-body" id="body-${lesson.id}">
          <div class="explanation">${lesson.explanation}</div>
          ${lesson.examples.map(ex => `
            <div class="example">
              <strong>${ex.en}</strong><br>
              <span style="color:var(--text-muted);font-size:0.9rem;">${ex.id}</span>
            </div>
          `).join("")}
          <div class="quiz-area">
            <h4>Mini Quiz</h4>
            ${lesson.quiz.map((qz, qi) => `
              <div style="margin-bottom:16px;">
                <p style="margin-bottom:8px;">${qi + 1}. ${qz.q}</p>
                ${qz.opts.map((o, oi) => `
                  <div class="option" style="padding:10px 14px;margin-bottom:6px;" onclick="checkGrammarQuiz('${lesson.id}', ${qi}, ${oi}, ${qz.ans}, this)">
                    <span class="opt-letter">${String.fromCharCode(65 + oi)}</span>
                    <span>${o}</span>
                  </div>
                `).join("")}
              </div>
            `).join("")}
            <button class="btn btn-primary btn-sm" onclick="completeLesson('${lesson.id}')">
              <i class="fas fa-check"></i> Tandai Selesai (+20 XP)
            </button>
          </div>
        </div>
      </div>
    `;
  }).join("");

  // Highlight current level tab
  document.querySelectorAll("#grammar-tabs .tab").forEach(t => {
    t.classList.toggle("active", t.dataset.level === level);
  });
}

function toggleGrammar(id) {
  const body = document.getElementById(`body-${id}`);
  body.classList.toggle("open");
}

function checkGrammarQuiz(lessonId, qIdx, optIdx, correct, el) {
  const parent = el.parentElement;
  parent.querySelectorAll(".option").forEach(o => {
    o.style.pointerEvents = "none";
    o.classList.remove("selected");
  });
  if (optIdx === correct) {
    el.classList.add("selected");
    el.style.borderColor = "var(--success)";
    el.style.background = "rgba(16,185,129,0.15)";
    showToast("Benar! 🎉", "success");
  } else {
    el.style.borderColor = "var(--danger)";
    el.style.background = "rgba(239,68,68,0.15)";
    parent.querySelectorAll(".option")[correct].style.borderColor = "var(--success)";
    parent.querySelectorAll(".option")[correct].style.background = "rgba(16,185,129,0.15)";
    showToast("Belum tepat, coba pelajari lagi.", "error");
  }
}

function completeLesson(id) {
  if (!state.lessonsCompleted.includes(id)) {
    state.lessonsCompleted.push(id);
    state.xp += 20;
    updateGoalProgress("lessons");
    saveState();
    updateUI();
    showToast("Lesson selesai! +20 XP", "success");
    const status = document.querySelector(`#g-${id} .status`);
    if (status) {
      status.textContent = "Selesai";
      status.className = "status done";
    }
  } else {
    showToast("Lesson ini sudah selesai sebelumnya.", "success");
  }
}

// ---------- Practice ----------
function startPractice(skill) {
  document.querySelector(".skill-grid").style.display = "none";
  const area = document.getElementById("practice-area");
  area.classList.remove("hidden");
  document.getElementById("practice-title").textContent = skill.charAt(0).toUpperCase() + skill.slice(1) + " Practice";

  currentPractice = { skill, answers: [], score: 0 };

  if (skill === "reading") startReading();
  else if (skill === "listening") startListening();
  else if (skill === "writing") startWriting();
  else if (skill === "speaking") startSpeaking();
}

function closePractice() {
  document.getElementById("practice-area").classList.add("hidden");
  document.querySelector(".skill-grid").style.display = "grid";
  currentPractice = null;
}

function startReading() {
  const passage = getRandomItems(READING_PASSAGES, 1)[0];
  currentPractice.data = passage;
  currentPractice.answers = new Array(passage.questions.length).fill(null);

  let html = `<div class="passage-box"><h4>${passage.title}</h4><p>${passage.text}</p></div>`;
  passage.questions.forEach((q, i) => {
    html += `<div style="margin-bottom:20px;">
      <p style="font-weight:500;margin-bottom:10px;">${i + 1}. ${q.q}</p>
      ${q.opts.map((o, oi) => `
        <div class="option" onclick="selectPracticeAnswer(${i}, ${oi}, this)">
          <span class="opt-letter">${String.fromCharCode(65 + oi)}</span>
          <span>${o}</span>
        </div>
      `).join("")}
    </div>`;
  });
  document.getElementById("practice-content").innerHTML = html;
  document.getElementById("practice-actions").innerHTML = `
    <button class="btn btn-primary" onclick="submitReading()"><i class="fas fa-check"></i> Submit Jawaban</button>
  `;
}

function selectPracticeAnswer(qIdx, optIdx, el) {
  currentPractice.answers[qIdx] = optIdx;
  const parent = el.parentElement;
  parent.querySelectorAll(".option").forEach(o => o.classList.remove("selected"));
  el.classList.add("selected");
}

function submitReading() {
  const passage = currentPractice.data;
  let correct = 0;
  passage.questions.forEach((q, i) => {
    if (currentPractice.answers[i] === q.ans) correct++;
  });
  const total = passage.questions.length;
  const pct = Math.round((correct / total) * 100);
  state.xp += correct * 10;
  updateGoalProgress("practice");
  saveState();
  updateUI();

  document.getElementById("practice-content").innerHTML += `
    <div class="feedback-box">
      <div class="score-line"><span>Skor Reading</span><strong>${correct}/${total} (${pct}%)</strong></div>
      <p style="color:var(--text-muted);">${pct >= 70 ? "Bagus! Comprehension kamu bagus." : "Perlu latihan lagi. Baca lebih teliti ya."}</p>
    </div>
  `;
  document.getElementById("practice-actions").innerHTML = `
    <button class="btn btn-primary" onclick="startReading()">Coba Passage Lain</button>
    <button class="btn btn-secondary" onclick="closePractice()">Kembali</button>
  `;
  showToast(`+${correct * 10} XP`, "success");
}

function startListening() {
  stopSpeech();
  const item = getRandomItems(LISTENING_SCRIPTS, 1)[0];
  currentPractice.data = item;
  currentPractice.answers = new Array(item.questions.length).fill(null);
  currentPractice.playing = false;

  let html = `
    <div class="listening-box">
      <h4>${item.title}</h4>
      <p style="color:var(--text-muted);margin-top:8px;">Klik Play — audio dibacakan dengan suara (berubah tiap kali). Dengarkan lalu jawab.</p>
      <div class="audio-wave" id="audio-wave">
        <span></span><span></span><span></span><span></span><span></span><span></span><span></span>
      </div>
      <div class="audio-controls">
        <button class="play-btn" id="play-btn" onclick="toggleListenPlay()"><i class="fas fa-play"></i></button>
        <span id="audio-status">Klik play untuk mendengarkan</span>
      </div>
      <div class="script-toggle" onclick="toggleScript()">Tampilkan / Sembunyikan Script</div>
      <div class="script-text" id="script-text">${item.script}</div>
    </div>
  `;
  item.questions.forEach((q, i) => {
    html += `<div style="margin-bottom:20px;">
      <p style="font-weight:500;margin-bottom:10px;">${i + 1}. ${q.q}</p>
      ${q.opts.map((o, oi) => `
        <div class="option" onclick="selectPracticeAnswer(${i}, ${oi}, this)">
          <span class="opt-letter">${String.fromCharCode(65 + oi)}</span>
          <span>${o}</span>
        </div>
      `).join("")}
    </div>`;
  });
  document.getElementById("practice-content").innerHTML = html;
  document.getElementById("practice-actions").innerHTML = `
    <button class="btn btn-primary" onclick="submitListening()"><i class="fas fa-check"></i> Submit Jawaban</button>
  `;
}

function getRandomVoice() {
  const voices = speechSynthesis.getVoices().filter(v => v.lang.startsWith("en"));
  if (voices.length === 0) return null;
  // Prefer US/GB voices, pick randomly
  const preferred = voices.filter(v => /en-US|en-GB|English/.test(v.lang + v.name));
  const pool = preferred.length ? preferred : voices;
  return pool[Math.floor(Math.random() * pool.length)];
}

function stopSpeech() {
  if (window.speechSynthesis) {
    speechSynthesis.cancel();
  }
  speechUtterance = null;
  if (currentPractice) currentPractice.playing = false;
  const wave = document.getElementById("audio-wave");
  if (wave) wave.classList.remove("playing");
}

function toggleListenPlay() {
  if (!window.speechSynthesis) {
    showToast("Browser tidak mendukung audio speech. Tampilkan script saja.", "error");
    document.getElementById("script-text").classList.add("show");
    return;
  }

  const btn = document.getElementById("play-btn");
  const status = document.getElementById("audio-status");
  const wave = document.getElementById("audio-wave");

  if (currentPractice.playing) {
    stopSpeech();
    btn.innerHTML = '<i class="fas fa-play"></i>';
    status.textContent = "Dijeda — klik play untuk lanjut";
    return;
  }

  // Ensure voices loaded
  const speak = () => {
    const text = currentPractice.data.script;
    speechUtterance = new SpeechSynthesisUtterance(text);
    speechUtterance.lang = "en-US";
    speechUtterance.rate = 0.9 + Math.random() * 0.15; // slight variation
    speechUtterance.pitch = 0.95 + Math.random() * 0.15;
    const voice = getRandomVoice();
    if (voice) speechUtterance.voice = voice;

    speechUtterance.onstart = () => {
      currentPractice.playing = true;
      btn.innerHTML = '<i class="fas fa-pause"></i>';
      status.textContent = voice ? `Memutar · ${voice.name.split(" ")[0]}...` : "Memutar audio...";
      if (wave) wave.classList.add("playing");
    };
    speechUtterance.onend = () => {
      currentPractice.playing = false;
      btn.innerHTML = '<i class="fas fa-redo"></i>';
      status.textContent = "Selesai. Jawab pertanyaan di bawah (atau putar ulang).";
      if (wave) wave.classList.remove("playing");
    };
    speechUtterance.onerror = () => {
      stopSpeech();
      btn.innerHTML = '<i class="fas fa-play"></i>';
      status.textContent = "Gagal memutar. Coba tampilkan script.";
    };

    speechSynthesis.speak(speechUtterance);
  };

  if (speechSynthesis.getVoices().length === 0) {
    speechSynthesis.onvoiceschanged = speak;
    // fallback
    setTimeout(speak, 300);
  } else {
    speak();
  }
}

function toggleScript() {
  document.getElementById("script-text").classList.toggle("show");
}

function submitListening() {
  const item = currentPractice.data;
  let correct = 0;
  item.questions.forEach((q, i) => {
    if (currentPractice.answers[i] === q.ans) correct++;
  });
  const total = item.questions.length;
  const pct = Math.round((correct / total) * 100);
  state.xp += correct * 10;
  updateGoalProgress("practice");
  saveState();
  updateUI();

  document.getElementById("practice-content").innerHTML += `
    <div class="feedback-box">
      <div class="score-line"><span>Skor Listening</span><strong>${correct}/${total} (${pct}%)</strong></div>
      <p style="color:var(--text-muted);">${pct >= 70 ? "Great listening skills!" : "Coba dengarkan lebih fokus dan catat keyword."}</p>
    </div>
  `;
  document.getElementById("practice-actions").innerHTML = `
    <button class="btn btn-primary" onclick="startListening()">Audio Lain</button>
    <button class="btn btn-secondary" onclick="closePractice()">Kembali</button>
  `;
  showToast(`+${correct * 10} XP`, "success");
}

function startWriting() {
  const prompt = getRandomItems(WRITING_PROMPTS, 1)[0];
  currentPractice.data = prompt;

  document.getElementById("practice-content").innerHTML = `
    <div class="writing-prompt">
      <h4>${prompt.title}</h4>
      <p style="margin-top:10px;">${prompt.prompt}</p>
    </div>
    <div class="writing-area">
      <textarea id="writing-text" placeholder="Tulis essay kamu di sini..." oninput="updateWordCount()"></textarea>
      <div class="word-count"><span id="word-count">0</span> words (min. ${prompt.minWords})</div>
    </div>
  `;
  document.getElementById("practice-actions").innerHTML = `
    <button class="btn btn-primary" onclick="submitWriting()"><i class="fas fa-paper-plane"></i> Submit & Dapatkan Feedback</button>
  `;
}

function updateWordCount() {
  const text = document.getElementById("writing-text").value.trim();
  const words = text ? text.split(/\s+/).length : 0;
  document.getElementById("word-count").textContent = words;
}

function submitWriting() {
  const text = document.getElementById("writing-text").value.trim();
  const words = text ? text.split(/\s+/).length : 0;
  const min = currentPractice.data.minWords;

  if (words < min * 0.5) {
    showToast(`Tulis minimal sekitar ${min} kata ya!`, "error");
    return;
  }

  // AI-style analysis
  const analysis = analyzeWriting(text, words, min);
  const score = analysis.score;

  state.xp += Math.round(score * 5);
  updateGoalProgress("practice");
  saveState();
  updateUI();

  document.getElementById("practice-content").innerHTML += `
    <div class="ai-feedback-box">
      <h4><i class="fas fa-robot"></i> AI Writing Feedback</h4>
      <div class="score-line" style="margin-bottom:14px;"><span>Estimated Band Score</span><strong style="color:var(--success);font-size:1.4rem;">${score.toFixed(1)}</strong></div>
      <div class="fb-item"><strong>Word count</strong>${words} kata ${words >= min ? "✓ mencapai minimum" : "(di bawah target " + min + ")"}</div>
      <div class="fb-item"><strong>Task Response</strong>${analysis.task}</div>
      <div class="fb-item"><strong>Coherence & Cohesion</strong>${analysis.cohesion}</div>
      <div class="fb-item"><strong>Lexical Resource</strong>${analysis.vocab}</div>
      <div class="fb-item"><strong>Grammatical Range</strong>${analysis.grammar}</div>
      ${analysis.tips.length ? `<div class="fb-item"><strong>Saran perbaikan</strong><ul style="margin:6px 0 0 16px;color:var(--text-muted);">${analysis.tips.map(t => `<li>${t}</li>`).join("")}</ul></div>` : ""}
    </div>
  `;
  document.getElementById("practice-actions").innerHTML = `
    <button class="btn btn-primary" onclick="startWriting()">Prompt Baru</button>
    <button class="btn btn-secondary" onclick="closePractice()">Kembali</button>
  `;
  showToast(`AI Feedback siap · Band ${score.toFixed(1)} · +${Math.round(score * 5)} XP`, "success");
}

function analyzeWriting(text, words, min) {
  let score = 4.5;
  const tips = [];
  const lower = text.toLowerCase();

  // Length
  if (words >= min) score += 1.0;
  else tips.push("Tulis lebih panjang agar mendekati batas minimum kata.");
  if (words >= min * 1.15) score += 0.5;

  // Structure / cohesion
  const hasConnectors = /\b(however|therefore|moreover|furthermore|in addition|on the other hand|in conclusion|firstly|secondly|finally|although|whereas|consequently|as a result)\b/i.test(text);
  const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 5);
  if (hasConnectors) score += 0.8;
  else tips.push("Tambahkan linking words (however, therefore, moreover, in conclusion) biar lebih kohesif.");
  if (sentences.length >= 4) score += 0.4;

  // Vocab variety (rough)
  const unique = new Set(lower.split(/\s+/).filter(w => w.length > 3));
  if (unique.size > words * 0.45) score += 0.6;
  else tips.push("Coba variasikan vocabulary — hindari mengulang kata yang sama terus.");

  // Grammar signals
  const hasComplex = /\b(which|who|that|although|because|if|when|while)\b/i.test(text);
  const hasPerfect = /\b(have|has|had)\s+\w+ed\b/i.test(text) || /\b(have|has)\s+been\b/i.test(text);
  if (hasComplex) score += 0.5;
  if (hasPerfect) score += 0.3;
  if (!hasComplex) tips.push("Gunakan relative clause atau complex sentence untuk naik band.");

  // Opinion / conclusion markers
  if (/\b(i (believe|think|agree|disagree)|in my opinion|it is clear that)\b/i.test(text)) score += 0.3;

  score = Math.min(9.0, Math.round(score * 2) / 2);

  const task = words >= min
    ? "Ide cukup dikembangkan dan relevan dengan topik."
    : "Pengembangan ide masih terbatas; perlu lebih banyak supporting detail.";
  const cohesion = hasConnectors
    ? "Ada penggunaan linking devices yang membantu alur."
    : "Organisasi ide ada, tapi cohesive devices masih kurang.";
  const vocab = unique.size > words * 0.45
    ? "Range vocabulary cukup baik untuk level ini."
    : "Lexical resource masih basic; perlu lebih banyak word choice yang akurat.";
  const grammar = hasComplex
    ? "Ada usaha memakai struktur kompleks."
    : "Mayoritas simple sentences — tingkatkan grammatical range.";

  if (score >= 7) tips.unshift("Sudah solid! Fokus ke precision dan less common vocabulary untuk band lebih tinggi.");
  else if (tips.length === 0) tips.push("Latihan konsisten akan menaikkan skor secara bertahap.");

  return { score, task, cohesion, vocab, grammar, tips };
}

let speechRecognition = null;
let speakingTranscript = "";

function startSpeaking() {
  stopSpeechRecognition();
  speakingTranscript = "";
  const prompt = getRandomItems(SPEAKING_PROMPTS, 1)[0];
  currentPractice.data = prompt;

  document.getElementById("practice-content").innerHTML = `
    <div class="speaking-prompt">
      <h3>${prompt.part}</h3>
      <p>${prompt.prompt}</p>
      <div class="speaking-tips"><strong>Tips:</strong> ${prompt.tips}</div>
    </div>
    <div class="mic-zone">
      <button class="mic-btn" id="mic-btn" onclick="toggleMic()"><i class="fas fa-microphone"></i></button>
      <div class="mic-status" id="mic-status">Klik mikrofon, izinkan akses mic, lalu berbicara dalam bahasa Inggris</div>
      <div class="transcript-box" id="transcript-box">
        <div class="label">Transkrip ucapanmu</div>
        <div id="transcript-text"><em style="color:var(--text-muted)">Belum ada — mulai bicara setelah klik mic</em></div>
      </div>
    </div>
  `;
  document.getElementById("practice-actions").innerHTML = `
    <button class="btn btn-primary" id="btn-score-speaking" onclick="scoreSpeakingAI()" disabled>
      <i class="fas fa-robot"></i> Dapatkan Feedback AI & Skor
    </button>
  `;
}

function stopSpeechRecognition() {
  if (speechRecognition) {
    try { speechRecognition.stop(); } catch (e) {}
    speechRecognition = null;
  }
}

function toggleMic() {
  const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRec) {
    showToast("Browser tidak mendukung speech recognition. Pakai Chrome/Edge.", "error");
    document.getElementById("transcript-text").innerHTML =
      "<em>Ketik jawabanmu di sini sebagai alternatif:</em><br><textarea id='manual-speech' rows='4' style='width:100%;margin-top:8px;padding:10px;border-radius:8px;background:var(--bg);color:var(--text);border:1px solid var(--border);'></textarea>";
    document.getElementById("btn-score-speaking").disabled = false;
    return;
  }

  const btn = document.getElementById("mic-btn");
  const status = document.getElementById("mic-status");

  if (speechRecognition) {
    stopSpeechRecognition();
    btn.classList.remove("recording");
    status.textContent = "Berhenti. Klik lagi untuk lanjut, atau minta feedback AI.";
    document.getElementById("btn-score-speaking").disabled = speakingTranscript.trim().length < 5;
    return;
  }

  speechRecognition = new SpeechRec();
  speechRecognition.lang = "en-US";
  speechRecognition.continuous = true;
  speechRecognition.interimResults = true;

  speechRecognition.onstart = () => {
    btn.classList.add("recording");
    status.textContent = "🎤 Mendengarkan... Bicara dalam English!";
  };

  speechRecognition.onresult = (event) => {
    let interim = "";
    let final = speakingTranscript;
    for (let i = event.resultIndex; i < event.results.length; i++) {
      const t = event.results[i][0].transcript;
      if (event.results[i].isFinal) final += t + " ";
      else interim += t;
    }
    speakingTranscript = final;
    document.getElementById("transcript-text").textContent =
      (final + (interim ? " " + interim : "")).trim() || "...";
    if (final.trim().length > 5) {
      document.getElementById("btn-score-speaking").disabled = false;
    }
  };

  speechRecognition.onerror = (e) => {
    status.textContent = "Error: " + (e.error || "mic") + " — coba lagi atau ketik manual.";
    btn.classList.remove("recording");
    if (e.error === "not-allowed") {
      showToast("Izinkan akses mikrofon di browser ya!", "error");
    }
  };

  speechRecognition.onend = () => {
    btn.classList.remove("recording");
    if (document.getElementById("mic-status")) {
      document.getElementById("mic-status").textContent = "Selesai merekam. Klik mic lagi atau minta skor AI.";
    }
    document.getElementById("btn-score-speaking").disabled = speakingTranscript.trim().length < 5;
  };

  try {
    speechRecognition.start();
  } catch (err) {
    showToast("Gagal start mic: " + err.message, "error");
  }
}

function scoreSpeakingAI() {
  stopSpeechRecognition();
  let text = speakingTranscript.trim();
  const manual = document.getElementById("manual-speech");
  if (manual && manual.value.trim()) text = manual.value.trim();

  if (!text || text.length < 5) {
    showToast("Belum ada ucapan yang tertangkap. Coba bicara lebih lama.", "error");
    return;
  }

  const promptText = (currentPractice.data && currentPractice.data.prompt) || "";
  const kws = promptText.toLowerCase().split(/\W+/).filter(w => w.length > 4);
  const analysis = objectiveSpeakingScore(text, kws);
  analysis.fluency = analysis.n >= 40 ? "Developed response." : "Perlu lebih extended.";
  analysis.vocab = analysis.band >= 6.5 ? "Lexical resource memadai." : "Vocabulary perlu diperkaya.";
  analysis.grammar = analysis.band >= 6 ? "Grammar cukup untuk level ini." : "Perkuat complex structures.";
  analysis.relevance = analysis.hits >= 2 ? "Cukup relevan ke tema." : "Kurang mengena ke tema — skor dikurangi.";
  analysis.band = analysis.band;
  state.xp += Math.round(analysis.band * 5);
  updateGoalProgress("practice");
  saveState();
  updateUI();

  document.getElementById("practice-content").innerHTML += `
    <div class="ai-feedback-box">
      <h4><i class="fas fa-robot"></i> AI Speaking Feedback</h4>
      <div class="score-line" style="margin-bottom:12px;">
        <span>Estimated Band Score</span>
        <strong style="color:var(--success);font-size:1.5rem;">${analysis.band.toFixed(1)}</strong>
      </div>
      <div class="fb-item"><strong>Yang kamu ucapkan</strong>"${text}"</div>
      <div class="fb-item"><strong>Fluency & length</strong>${analysis.fluency}</div>
      <div class="fb-item"><strong>Vocabulary</strong>${analysis.vocab}</div>
      <div class="fb-item"><strong>Grammar signals</strong>${analysis.grammar}</div>
      <div class="fb-item"><strong>Relevance to prompt</strong>${analysis.relevance}</div>
      ${analysis.tips.length ? `<div class="fb-item"><strong>Saran</strong><ul style="margin:6px 0 0 16px;color:var(--text-muted);">${analysis.tips.map(t => `<li>${t}</li>`).join("")}</ul></div>` : ""}
    </div>
  `;
  document.getElementById("practice-actions").innerHTML = `
    <button class="btn btn-primary" onclick="startSpeaking()">Prompt Baru</button>
    <button class="btn btn-secondary" onclick="closePractice()">Kembali</button>
  `;
  showToast(`Speaking Band ${analysis.band.toFixed(1)} · +${Math.round(analysis.band * 5)} XP`, "success");
}

function analyzeSpeaking(text, prompt) {
  const words = text.split(/\s+/).filter(Boolean);
  const n = words.length;
  const lower = text.toLowerCase();
  const tips = [];
  let band = 4.0;

  // Length / fluency proxy
  if (n >= 40) { band += 1.5; }
  else if (n >= 25) { band += 1.0; }
  else if (n >= 12) { band += 0.5; }
  else tips.push("Coba bicara lebih panjang (target 30–60 detik / 40+ kata).");

  const fluency = n >= 40 ? "Panjang jawaban cukup; terkesan developed." :
    n >= 20 ? "Cukup, tapi bisa lebih extended dengan contoh." :
    "Masih pendek — extend dengan reason + example.";

  // Vocab variety
  const unique = new Set(words.map(w => w.toLowerCase().replace(/[^a-z']/g, "")));
  const ratio = unique.size / Math.max(n, 1);
  if (ratio > 0.7 && n > 15) band += 0.8;
  else if (ratio > 0.5) band += 0.4;
  else tips.push("Variasikan vocabulary; hindari mengulang kata yang sama.");

  const vocab = ratio > 0.65 ? "Lexical range cukup baik." : "Lexical resource masih terbatas.";

  // Grammar signals
  const hasPast = /\b(was|were|had|went|did|ed)\b/i.test(text);
  const hasComplex = /\b(because|which|that|when|if|although|while)\b/i.test(text);
  const hasModal = /\b(would|could|should|might|can)\b/i.test(text);
  if (hasComplex) band += 0.5;
  if (hasModal) band += 0.3;
  if (hasPast) band += 0.2;
  if (!hasComplex) tips.push("Pakai complex sentences (because, which, although) untuk naik band.");

  const grammar = hasComplex
    ? "Ada indikasi struktur kompleks."
    : "Mayoritas simple sentences — tingkatkan range.";

  // Relevance: keyword overlap with prompt
  const promptWords = (prompt.prompt || "").toLowerCase().split(/\W+/).filter(w => w.length > 4);
  const hits = promptWords.filter(w => lower.includes(w)).length;
  if (hits >= 3) band += 0.6;
  else if (hits >= 1) band += 0.3;
  else tips.push("Hubungkan jawaban lebih jelas ke pertanyaan di prompt.");

  const relevance = hits >= 3 ? "Relevan dengan topik prompt." :
    hits >= 1 ? "Cukup relevan." : "Kurang mengena ke pertanyaan — fokus ulang ke prompt.";

  band = Math.min(9.0, Math.round(band * 2) / 2);
  if (band >= 7) tips.unshift("Bagus! Pertahankan pace natural dan tambah precise vocabulary.");
  if (tips.length === 0) tips.push("Latihan konsisten dengan timer 1–2 menit.");

  return { band, fluency, vocab, grammar, relevance, tips };
}

// ---------- Mock Tests ----------
function startMock(type) {
  currentMock = {
    type,
    mode: "full",
    sections: type === "ielts"
      ? ["listening", "reading", "writing", "speaking"]
      : ["reading", "listening", "speaking", "writing"],
    sectionIndex: 0,
    questions: [],
    answers: [],
    scores: {},
    qIndex: 0
  };
  loadMockSection();
}

function startMockSection(type) {
  const sections = type === "ielts"
    ? ["Listening", "Reading", "Writing", "Speaking"]
    : ["Reading", "Listening", "Speaking", "Writing"];
  const html = `
    <h3 style="margin-bottom:16px;">Pilih Section ${type.toUpperCase()}</h3>
    ${sections.map(s => `
      <button class="btn btn-outline" style="display:block;width:100%;margin-bottom:10px;justify-content:center;"
        onclick="startSingleSection('${type}', '${s.toLowerCase()}')">${s}</button>
    `).join("")}
  `;
  showModal(html);
}

function startSingleSection(type, section) {
  closeModal();
  currentMock = {
    type,
    mode: "section",
    sections: [section],
    sectionIndex: 0,
    questions: [],
    answers: [],
    scores: {},
    qIndex: 0
  };
  loadMockSection();
}

function loadMockSection() {
  const section = currentMock.sections[currentMock.sectionIndex];
  currentMock.currentSection = section;
  currentMock.qIndex = 0;
  currentMock.answers = [];

  // Speaking section → AI Call (phone-style) with objective scoring
  if (section === "speaking") {
    document.getElementById("mock-selection").classList.add("hidden");
    document.getElementById("mock-runner").classList.add("hidden");
    navigateTo("aicall");
    const mode = currentMock.type === "ielts" ? "ielts" : "interview";
    setTimeout(() => startAICall(mode), 400);
    // When call ends, finishMockSection will need scores — hook via call
    currentMock.awaitingCallScore = true;
    return;
  }

  let questions = [];
  if (currentMock.type === "ielts") {
    if (section === "listening") {
      IELTS_LISTENING.forEach(s => {
        s.questions.forEach(q => questions.push({ ...q, script: s.script, title: s.title }));
      });
    } else if (section === "reading") {
      IELTS_READING.forEach(p => {
        p.questions.forEach(q => questions.push({ ...q, passage: p.text, title: p.title }));
      });
    } else if (section === "writing") {
      questions = IELTS_WRITING.map(w => ({ type: "writing", ...w }));
    } else if (section === "speaking") {
      questions = IELTS_SPEAKING.map(s => ({ type: "speaking", ...s }));
    }
  } else {
    if (section === "reading") {
      TOEFL_READING.forEach(p => {
        p.questions.forEach(q => questions.push({ ...q, passage: p.text, title: p.title }));
      });
    } else if (section === "listening") {
      TOEFL_LISTENING.forEach(s => {
        s.questions.forEach(q => questions.push({ ...q, script: s.script, title: s.title }));
      });
    } else if (section === "speaking") {
      questions = TOEFL_SPEAKING.map(s => ({ type: "speaking", ...s }));
    } else if (section === "writing") {
      questions = TOEFL_WRITING.map(w => ({ type: "writing", ...w }));
    }
  }

  // Keep section order for realism; mild shuffle only within already-built list is optional
  currentMock.questions = questions;
  currentMock.answers = new Array(currentMock.questions.length).fill(null);

  // Realistic-ish timers (scaled for web practice)
  const n = questions.length;
  if (section === "writing") mockTimeLeft = 2400; // ~40 min
  else if (section === "speaking") mockTimeLeft = 900; // 15 min
  else if (section === "reading") mockTimeLeft = Math.max(1200, n * 60); // ~1 min/q
  else mockTimeLeft = Math.max(900, n * 45); // listening
  startMockTimer();

  document.getElementById("mock-selection").classList.add("hidden");
  document.getElementById("mock-result").classList.add("hidden");
  document.getElementById("mock-runner").classList.remove("hidden");
  document.getElementById("mock-type-label").textContent = currentMock.type.toUpperCase();
  document.getElementById("mock-section-label").textContent = capitalize(section);
  renderMockQuestion();
}

function startMockTimer() {
  if (mockTimerInterval) clearInterval(mockTimerInterval);
  updateMockTimerDisplay();
  mockTimerInterval = setInterval(() => {
    mockTimeLeft--;
    updateMockTimerDisplay();
    if (mockTimeLeft <= 0) {
      clearInterval(mockTimerInterval);
      finishMockSection();
    }
  }, 1000);
}

function updateMockTimerDisplay() {
  const m = Math.floor(mockTimeLeft / 60);
  const s = mockTimeLeft % 60;
  document.getElementById("mock-timer").textContent =
    `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

function renderMockQuestion() {
  const q = currentMock.questions[currentMock.qIndex];
  const total = currentMock.questions.length;
  document.getElementById("mock-q-counter").textContent = `${currentMock.qIndex + 1} / ${total}`;
  document.getElementById("mock-progress-bar").style.width = `${((currentMock.qIndex + 1) / total) * 100}%`;

  let html = "";
  if (q.type === "writing") {
    html = `
      <div class="writing-prompt">
        <h4>${q.title}</h4>
        <p style="margin-top:10px;white-space:pre-wrap;">${q.prompt}</p>
      </div>
      <div class="writing-area">
        <textarea id="mock-writing" placeholder="Tulis jawabanmu di sini..." rows="10"></textarea>
      </div>
    `;
  } else if (q.type === "speaking") {
    html = `
      <div class="speaking-prompt">
        <h3>Part ${q.part || q.task || ""}</h3>
        <p>${q.prompt}</p>
        <div class="speaking-tips">Siapkan jawaban 1–2 menit. Kamu bisa merekam diri atau berlatih keras.</div>
      </div>
      <div style="text-align:center;">
        <p style="color:var(--text-muted);">Setelah selesai praktik, klik Selanjutnya.</p>
      </div>
    `;
  } else {
    if (q.passage) {
      html += `<div class="passage-box"><h4>${q.title || ""}</h4><p>${q.passage}</p></div>`;
    }
    if (q.script) {
      html += `
        <div class="listening-box">
          <h4>${q.title || "Listening"}</h4>
          <div class="script-toggle" onclick="this.nextElementSibling.classList.toggle('show')">Tampilkan Script</div>
          <div class="script-text">${q.script}</div>
        </div>
      `;
    }
    html += `<p style="font-weight:500;margin:16px 0 12px;">${q.q}</p>`;
    q.opts.forEach((o, i) => {
      const sel = currentMock.answers[currentMock.qIndex] === i ? "selected" : "";
      html += `<div class="option ${sel}" onclick="selectMockAnswer(${i})">
        <span class="opt-letter">${String.fromCharCode(65 + i)}</span>
        <span>${o}</span>
      </div>`;
    });
  }

  document.getElementById("mock-content").innerHTML = html;
  document.getElementById("mock-prev").disabled = currentMock.qIndex === 0;
  document.getElementById("mock-next").textContent =
    currentMock.qIndex === total - 1 ? "Selesai Section" : "Selanjutnya";
}

function selectMockAnswer(idx) {
  currentMock.answers[currentMock.qIndex] = idx;
  renderMockQuestion();
}

function mockPrev() {
  if (currentMock.qIndex > 0) {
    currentMock.qIndex--;
    renderMockQuestion();
  }
}

function mockNext() {
  const q = currentMock.questions[currentMock.qIndex];
  if (q.type === "writing") {
    const text = document.getElementById("mock-writing")?.value || "";
    currentMock.answers[currentMock.qIndex] = text;
  } else if (q.type === "speaking") {
    currentMock.answers[currentMock.qIndex] = "practiced";
  }

  if (currentMock.qIndex < currentMock.questions.length - 1) {
    currentMock.qIndex++;
    renderMockQuestion();
  } else {
    finishMockSection();
  }
}

function finishMockSection() {
  clearInterval(mockTimerInterval);
  const section = currentMock.currentSection;
  const questions = currentMock.questions;
  let score = 0;
  let max = questions.length;

  if (section === "speaking") {
    // Speaking scored only via AI Call (objective). If skipped, mark incomplete.
    if (currentMock.scores.speaking == null) {
      currentMock.scores.speaking = 0;
      showToast("Speaking belum dinilai — skor 0. Gunakan AI Call untuk skor objektif.", "error");
    }
    score = currentMock.scores.speaking;
  } else if (section === "writing") {
    // Score from actual user answers (length + basic structure), NOT random
    let total = 0;
    let n = 0;
    questions.forEach((q, i) => {
      const ans = (currentMock.answers[i] || "").toString().trim();
      if (!ans) return;
      n++;
      const words = ans.split(/\s+/).filter(Boolean).length;
      let band = 4.0;
      if (words >= 150) band += 1.5;
      else if (words >= 80) band += 1.0;
      else if (words >= 40) band += 0.5;
      else band -= 0.5;
      if (/\b(however|therefore|furthermore|although|because)\b/i.test(ans)) band += 0.5;
      if (/\b(in conclusion|to conclude|overall)\b/i.test(ans)) band += 0.25;
      if (words < 20) band = Math.min(band, 3.5);
      total += Math.max(2, Math.min(9, band));
    });
    score = n ? Math.round((total / n) * 2) / 2 : 0;
    currentMock.scores[section] = score;
  } else {
    let correct = 0;
    questions.forEach((q, i) => {
      const right = q.ans !== undefined ? q.ans : q.correct;
      if (right !== undefined && currentMock.answers[i] === right) correct++;
    });
    if (max === 0) {
      score = 0;
    } else if (currentMock.type === "ielts") {
      const pct = correct / max;
      score = Math.min(9, Math.round(pct * 9 * 2) / 2);
    } else {
      score = Math.round((correct / max) * 30);
    }
    currentMock.scores[section] = score;
  }

  currentMock.sectionIndex++;
  if (currentMock.sectionIndex < currentMock.sections.length) {
    showToast(`Section ${section} selesai! Lanjut ke section berikutnya.`, "success");
    setTimeout(loadMockSection, 800);
  } else {
    showMockResult();
  }
}

function showMockResult() {
  document.getElementById("mock-runner").classList.add("hidden");
  document.getElementById("mock-result").classList.remove("hidden");

  const scores = currentMock.scores || {};
  const vals = Object.values(scores).filter((v) => typeof v === "number");
  if (!vals.length) {
    document.getElementById("mock-final-score").textContent = "—";
    document.getElementById("mock-score-desc").textContent = "Belum ada skor — selesaikan section dulu";
    document.getElementById("section-scores").innerHTML = "";
    return;
  }

  let overall;
  if (currentMock.type === "ielts") {
    overall = vals.reduce((a, b) => a + b, 0) / vals.length;
    overall = Math.round(overall * 2) / 2;
    document.getElementById("mock-final-score").textContent = overall.toFixed(1);
    document.getElementById("mock-score-desc").textContent = "IELTS Overall Band Score (dari section yang dikerjakan)";
  } else {
    overall = vals.reduce((a, b) => a + (b > 9 ? b : Math.round(b * 3.3)), 0);
    overall = Math.min(120, Math.round(overall));
    document.getElementById("mock-final-score").textContent = overall;
    document.getElementById("mock-score-desc").textContent = "TOEFL iBT Total (approx, section dikerjakan)";
  }

  // Section scores
  document.getElementById("section-scores").innerHTML = Object.entries(scores).map(([sec, sc]) => `
    <div class="section-score-card">
      <h4>${capitalize(sec)}</h4>
      <div class="score">${typeof sc === "number" ? (sc % 1 === 0 ? sc : sc.toFixed(1)) : sc}</div>
    </div>
  `).join("");

  // Save history
  const entry = {
    type: currentMock.type,
    score: overall,
    scores: { ...scores },
    date: new Date().toLocaleDateString("id-ID")
  };
  state.mockHistory.unshift(entry);
  if (!state.bestMock || overall > parseFloat(state.bestMock)) {
    state.bestMock = currentMock.type === "ielts" ? overall.toFixed(1) : String(overall);
  }
  state.xp += 50;
  updateGoalProgress("mock");
  saveState();
  updateUI();
  showToast("Mock test selesai! +50 XP", "success");
}

function exitMock() {
  clearInterval(mockTimerInterval);
  currentMock = null;
  document.getElementById("mock-runner").classList.add("hidden");
  document.getElementById("mock-result").classList.add("hidden");
  document.getElementById("mock-selection").classList.remove("hidden");
}

function reviewMock() {
  showToast("Fitur review detail akan segera hadir. Lihat skor section di atas!", "success");
}

// ---------- Goals ----------
function createGoal() {
  const type = document.getElementById("goal-type").value;
  const amount = parseInt(document.getElementById("goal-amount").value) || 1;
  const period = document.getElementById("goal-period").value;

  const labels = {
    lessons: "Selesaikan Lesson",
    minutes: "Belajar (menit)",
    practice: "Latihan Skills",
    mock: "Selesaikan Mock Test"
  };
  const periodLabels = { daily: "Harian", weekly: "Mingguan", monthly: "Bulanan" };

  const goal = {
    id: Date.now(),
    type,
    amount,
    period,
    progress: 0,
    label: `${labels[type]}: ${amount} (${periodLabels[period]})`,
    created: new Date().toISOString(),
    expires: getExpiry(period)
  };

  state.goals.push(goal);
  saveState();
  renderGoals();
  showToast("Target berhasil dibuat!", "success");
}

function getExpiry(period) {
  const d = new Date();
  if (period === "daily") d.setHours(23, 59, 59);
  else if (period === "weekly") d.setDate(d.getDate() + (7 - d.getDay()));
  else d.setMonth(d.getMonth() + 1, 0);
  return d.toISOString();
}

function updateGoalProgress(type) {
  const now = new Date();
  state.goals.forEach(g => {
    if (g.type === type && new Date(g.expires) > now) {
      g.progress = Math.min(g.amount, g.progress + 1);
    }
  });
  saveState();
}

function calcGoalProgress() {
  if (state.goals.length === 0) return 0;
  const active = state.goals.filter(g => new Date(g.expires) > new Date());
  if (active.length === 0) return 0;
  const avg = active.reduce((sum, g) => sum + (g.progress / g.amount) * 100, 0) / active.length;
  return Math.round(avg);
}

function renderGoals() {
  const list = document.getElementById("goals-list");
  if (state.goals.length === 0) {
    list.innerHTML = `<p class="empty-state">Belum ada target. Buat target pertamamu di atas!</p>`;
    return;
  }

  const now = new Date();
  list.innerHTML = state.goals.map(g => {
    const expired = new Date(g.expires) < now;
    const pct = Math.round((g.progress / g.amount) * 100);
    let status = "in-progress";
    let statusText = `${g.progress}/${g.amount}`;
    if (g.progress >= g.amount) {
      status = "achieved";
      statusText = "Tercapai ✓";
    } else if (expired) {
      status = "failed";
      statusText = "Tidak tercapai";
    }

    return `
      <div class="goal-item">
        <div class="goal-icon"><i class="fas fa-bullseye"></i></div>
        <div class="goal-info">
          <h4>${g.label}</h4>
          <div class="goal-meta">Berakhir: ${new Date(g.expires).toLocaleDateString("id-ID")}</div>
          <div class="goal-progress-bar"><div class="fill" style="width:${Math.min(100, pct)}%"></div></div>
        </div>
        <span class="goal-status ${status}">${statusText}</span>
      </div>
    `;
  }).join("");
}

// ---------- Progress ----------
function renderProgress() {
  const totalLessons = Object.values(GRAMMAR_LESSONS).flat().length;
  const pct = Math.round((state.lessonsCompleted.length / totalLessons) * 100) || 0;
  document.getElementById("overall-circle").setAttribute("stroke-dasharray", `${pct}, 100`);
  document.getElementById("overall-percent").textContent = pct + "%";
  document.getElementById("prog-xp").textContent = state.xp;
  document.getElementById("prog-streak").textContent = state.streak + " hari";
  document.getElementById("prog-lessons").textContent = state.lessonsCompleted.length;
  document.getElementById("prog-mocks").textContent = state.mockHistory.length;

  const hist = document.getElementById("score-history");
  if (state.mockHistory.length === 0) {
    hist.innerHTML = `<p class="empty-state">Belum ada mock test yang dikerjakan.</p>`;
  } else {
    hist.innerHTML = state.mockHistory.map(h => `
      <div class="history-item">
        <div class="h-left">
          <span class="h-badge ${h.type}">${h.type.toUpperCase()}</span>
          <span>${h.date}</span>
        </div>
        <div class="h-score">${typeof h.score === "number" ? (h.score % 1 === 0 ? h.score : h.score.toFixed(1)) : h.score}</div>
      </div>
    `).join("");
  }
}

// ---------- Utils ----------
function showToast(msg, type = "success") {
  const toast = document.getElementById("toast");
  toast.textContent = msg;
  toast.className = `toast ${type}`;
  toast.classList.remove("hidden");
  setTimeout(() => toast.classList.add("hidden"), 3000);
}

function showModal(html) {
  document.getElementById("modal-body").innerHTML = html;
  document.getElementById("modal").classList.remove("hidden");
}

function closeModal() {
  document.getElementById("modal").classList.add("hidden");
}

// ---------- Structured Learn Path ----------


// ---------- Vocab & Dialog phase (rich) ----------
function speakWord(text, rate) {
  if (!window.speechSynthesis || !text) {
    showToast("Text-to-speech tidak tersedia di browser ini.", "error");
    return;
  }
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(String(text));
  u.lang = "en-US";
  u.rate = rate || 0.9;
  const voices = window.speechSynthesis.getVoices();
  const en = voices.find(v => /en(-|_)US/i.test(v.lang)) || voices.find(v => /^en/i.test(v.lang));
  if (en) u.voice = en;
  window.speechSynthesis.speak(u);
}

function renderVocabDialogPhase(c, unit, level) {
  const vocab = c.vocab || [];
  const dialogues = c.dialogues || [];
  const nav = `
    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:22px;">
      <button class="btn btn-secondary" type="button" onclick="learnPhase=2;renderLearnPhase()"><i class="fas fa-arrow-left"></i> Kembali</button>
      <button class="btn btn-primary" type="button" onclick="learnPhase=4;renderLearnPhase()">Latihan terbimbing <i class="fas fa-arrow-right"></i></button>
    </div>`;

  const vocabHtml = vocab.map((v, i) => `
    <div class="vocab-card vocab-card-rich">
      <div class="en" style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
        <strong>${escapeHtml(v.en)}</strong>
        <small style="opacity:.75">${escapeHtml(v.ipa || "")}</small>
        <button type="button" class="btn btn-sm btn-secondary" title="Dengar pelafalan"
          onclick="speakWord(${JSON.stringify(v.en)})"><i class="fas fa-volume-up"></i></button>
      </div>
      <div class="id">${escapeHtml(v.id || "")}</div>
      <div class="ex" style="margin-top:6px;">
        <em>${escapeHtml(v.ex || "")}</em>
        ${v.exId ? `<br><span style="color:var(--text-muted);font-size:0.85rem;">${escapeHtml(v.exId)}</span>` : ""}
        ${v.ex ? `<button type="button" class="btn btn-sm btn-secondary" style="margin-top:6px;" onclick='speakWord(${JSON.stringify(v.ex)}, 0.85)'><i class="fas fa-volume-up"></i> Contoh</button>` : ""}
      </div>
    </div>`).join("");

  const dlgHtml = dialogues.length
    ? dialogues.map((d, di) => `
      <div class="dialog-block" style="margin-bottom:16px;padding:14px;background:var(--bg);border-radius:12px;border:1px solid var(--border);">
        <h5 style="margin:0 0 10px;color:var(--primary-light);">${di + 1}. ${escapeHtml(d.title || "Dialog")}</h5>
        ${(d.lines || []).map(ln => `
          <div style="margin-bottom:8px;">
            <strong>${escapeHtml(ln.sp || "")}:</strong>
            <button type="button" class="btn btn-sm btn-secondary" style="padding:2px 8px;margin-left:4px;" onclick='speakWord(${JSON.stringify(ln.en)})'><i class="fas fa-volume-up"></i></button>
            <div>${escapeHtml(ln.en || "")}</div>
            <div style="color:var(--text-muted);font-size:0.88rem;">${escapeHtml(ln.id || "")}</div>
          </div>`).join("")}
        ${d.tips ? `<p style="margin-top:10px;font-size:0.9rem;"><strong>Ungkapan penting:</strong> ${escapeHtml(d.tips)}</p>` : ""}
      </div>`).join("")
    : (c.dialogue
        ? `<pre style="white-space:pre-wrap;background:var(--bg);padding:14px;border-radius:12px;">${escapeHtml(c.dialogue)}</pre>`
        : "<p>Belum ada dialog.</p>");

  return `
    <h4 style="color:var(--primary-light);">1) Kosakata & pelafalan</h4>
    <p style="color:var(--text-muted);margin-bottom:12px;">Tekan ikon volume untuk mendengar (Text-to-Speech browser). Cocok untuk latihan alfabet & bunyi dasar.</p>
    <div class="vocab-grid">${vocabHtml}</div>

    <h4 style="margin-top:22px;color:var(--primary-light);">2) Dialog kontekstual</h4>
    <p style="color:var(--text-muted);">Baca, dengarkan tiap baris, pahami terjemahan, lalu coba latihan interaktif di bawah.</p>
    ${dlgHtml}

    <h4 style="margin-top:22px;color:var(--primary-light);">3) Latihan kosakata (satu soal per layar)</h4>
    <p style="color:var(--text-muted);">Kunci jawaban baru muncul setelah kamu menjawab.</p>
    <button class="btn btn-primary" type="button" onclick="startVocabDrill()"><i class="fas fa-play"></i> Mulai latihan kosakata</button>
    <div id="vocab-drill-area" style="margin-top:12px;"></div>

    <h4 style="margin-top:22px;color:var(--primary-light);">4) Latihan dialog interaktif</h4>
    <button class="btn btn-primary" type="button" onclick="startDialogDrill()"><i class="fas fa-comments"></i> Mulai latihan dialog</button>
    <div id="dialog-drill-area" style="margin-top:12px;"></div>

    ${c.summary ? `<div style="margin-top:18px;padding:12px;border:1px solid var(--border);border-radius:10px;"><strong>Ringkasan:</strong> ${c.summary}</div>` : ""}
    ${nav}`;
}

function startVocabDrill() {
  if (!learnCtx) return;
  const items = (learnCtx.unit.content.vocabPractice || []).slice();
  if (!items.length) {
    showToast("Latihan kosakata belum tersedia di unit ini.", "error");
    return;
  }
  window.__vocabDrill = { items, idx: 0, correct: 0, answered: false };
  renderVocabDrillQ();
}

function renderVocabDrillQ() {
  const st = window.__vocabDrill;
  const box = document.getElementById("vocab-drill-area");
  if (!st || !box) return;
  if (st.idx >= st.items.length) {
    const score = st.correct / st.items.length;
    box.innerHTML = `<div class="writing-prompt"><strong>Selesai.</strong> Skor: ${st.correct}/${st.items.length} (${Math.round(score * 100)}%).
      ${score >= 0.8 ? "Bagus!" : "Ulangi lagi untuk menguasai."}</div>
      <button class="btn btn-secondary btn-sm" type="button" onclick="startVocabDrill()">Ulangi latihan</button>`;
    // persist soft progress note (not unit mastery)
    state.vocabDrillScores = state.vocabDrillScores || {};
    const key = (learnCtx.level || "") + ":" + (learnCtx.unit.id || "");
    state.vocabDrillScores[key] = { correct: st.correct, total: st.items.length, at: new Date().toISOString() };
    saveState();
    return;
  }
  const it = st.items[st.idx];
  let opts = "";
  if (it.type === "gap") {
    opts = `<input id="vd-gap" type="text" placeholder="Ketik jawaban" style="width:100%;padding:10px;border-radius:10px;border:1px solid var(--border);background:var(--card);color:var(--text);">
      <button class="btn btn-primary btn-sm" style="margin-top:8px;" type="button" onclick="answerVocabGap()">Cek</button>`;
  } else {
    opts = (it.options || []).map((o, oi) =>
      `<button type="button" class="option adapt-opt" style="display:block;width:100%;text-align:left;margin-bottom:8px;" onclick="answerVocabOpt(${oi})">${String.fromCharCode(65 + oi)}. ${escapeHtml(o)}</button>`
    ).join("");
  }
  box.innerHTML = `
    <div style="padding:14px;background:var(--bg);border-radius:12px;border:1px solid var(--border);">
      <p style="font-size:0.85rem;color:var(--text-muted);">Soal ${st.idx + 1}/${st.items.length} · ${it.type || "mcq"}</p>
      <p style="font-weight:600;">${escapeHtml(it.q)}</p>
      <div id="vd-opts">${opts}</div>
      <div id="vd-fb" style="margin-top:10px;"></div>
      <button type="button" class="btn btn-primary hidden" id="vd-next" onclick="nextVocabDrill()">Soal berikutnya</button>
    </div>`;
}

function answerVocabOpt(oi) {
  const st = window.__vocabDrill;
  if (!st || st.answered) return;
  st.answered = true;
  const it = st.items[st.idx];
  const good = oi === it.correct;
  if (good) st.correct++;
  else {
    logMistake({
      q: it.q,
      correctOpt: (it.options || [])[it.correct],
      userAns: (it.options || [])[oi],
      explain: it.explain || "",
      level: learnCtx.level,
      unitId: learnCtx.unit.id,
      source: "vocab-drill"
    });
  }
  document.querySelectorAll("#vd-opts .adapt-opt").forEach(btn => {
    btn.disabled = true;
  });
  const fb = document.getElementById("vd-fb");
  if (fb) {
    fb.innerHTML = good
      ? `<span style="color:var(--success);font-weight:600;">Benar.</span> ${escapeHtml(it.explain || "")}`
      : `<span style="color:#f87171;font-weight:600;">Belum tepat.</span> Kunci: <strong>${escapeHtml((it.options || [])[it.correct] || "")}</strong>. ${escapeHtml(it.explain || "")}`;
  }
  const next = document.getElementById("vd-next");
  if (next) {
    next.classList.remove("hidden");
    next.textContent = st.idx >= st.items.length - 1 ? "Lihat hasil" : "Soal berikutnya";
  }
}

function answerVocabGap() {
  const st = window.__vocabDrill;
  if (!st || st.answered) return;
  const it = st.items[st.idx];
  const val = (document.getElementById("vd-gap") && document.getElementById("vd-gap").value || "").trim().toLowerCase();
  const ans = String(it.answer || "").trim().toLowerCase();
  st.answered = true;
  const good = val === ans || (ans.endsWith("s") && val === ans.slice(0, -1)) || (val + "s" === ans);
  if (good) st.correct++;
  else {
    logMistake({
      q: it.q,
      correctOpt: it.answer,
      userAns: val || "(kosong)",
      explain: it.explain || "",
      level: learnCtx.level,
      unitId: learnCtx.unit.id,
      source: "vocab-drill"
    });
  }
  const fb = document.getElementById("vd-fb");
  if (fb) {
    fb.innerHTML = good
      ? `<span style="color:var(--success);font-weight:600;">Benar.</span> ${escapeHtml(it.explain || "")}`
      : `<span style="color:#f87171;font-weight:600;">Belum tepat.</span> Kunci: <strong>${escapeHtml(it.answer || "")}</strong>. ${escapeHtml(it.explain || "")}`;
  }
  const next = document.getElementById("vd-next");
  if (next) next.classList.remove("hidden");
}

function nextVocabDrill() {
  const st = window.__vocabDrill;
  if (!st) return;
  st.idx++;
  st.answered = false;
  renderVocabDrillQ();
}

function startDialogDrill() {
  if (!learnCtx) return;
  const items = (learnCtx.unit.content.dialoguePractice || []).slice();
  if (!items.length) {
    showToast("Latihan dialog belum tersedia di unit ini.", "error");
    return;
  }
  window.__dialogDrill = { items, idx: 0, correct: 0, answered: false };
  renderDialogDrillQ();
}

function renderDialogDrillQ() {
  const st = window.__dialogDrill;
  const box = document.getElementById("dialog-drill-area");
  if (!st || !box) return;
  if (st.idx >= st.items.length) {
    box.innerHTML = `<div class="writing-prompt"><strong>Latihan dialog selesai.</strong> Benar ${st.correct}/${st.items.length}.</div>
      <button class="btn btn-secondary btn-sm" type="button" onclick="startDialogDrill()">Ulangi</button>`;
    return;
  }
  const it = st.items[st.idx];
  box.innerHTML = `
    <div style="padding:14px;background:var(--bg);border-radius:12px;border:1px solid var(--border);">
      <p style="font-size:0.85rem;color:var(--text-muted);">Dialog ${st.idx + 1}/${st.items.length}</p>
      <p style="font-weight:600;">${escapeHtml(it.q)}</p>
      <div id="dd-opts">${(it.options || []).map((o, oi) =>
        `<button type="button" class="option adapt-opt" style="display:block;width:100%;text-align:left;margin-bottom:8px;" onclick="answerDialogOpt(${oi})">${String.fromCharCode(65 + oi)}. ${escapeHtml(o)}</button>`
      ).join("")}</div>
      <div id="dd-fb" style="margin-top:10px;"></div>
      <button type="button" class="btn btn-primary hidden" id="dd-next" onclick="nextDialogDrill()">Lanjut</button>
    </div>`;
}

function answerDialogOpt(oi) {
  const st = window.__dialogDrill;
  if (!st || st.answered) return;
  st.answered = true;
  const it = st.items[st.idx];
  const good = oi === it.correct;
  if (good) st.correct++;
  else {
    logMistake({
      q: it.q,
      correctOpt: (it.options || [])[it.correct],
      userAns: (it.options || [])[oi],
      explain: it.explain || "",
      level: learnCtx.level,
      unitId: learnCtx.unit.id,
      source: "dialog-drill"
    });
  }
  document.querySelectorAll("#dd-opts .adapt-opt").forEach(b => { b.disabled = true; });
  const fb = document.getElementById("dd-fb");
  if (fb) {
    fb.innerHTML = good
      ? `<span style="color:var(--success);font-weight:600;">Tepat.</span> ${escapeHtml(it.explain || "")}`
      : `<span style="color:#f87171;font-weight:600;">Belum tepat.</span> Pilihan yang baik: <strong>${escapeHtml((it.options || [])[it.correct] || "")}</strong>. ${escapeHtml(it.explain || "")}`;
  }
  const next = document.getElementById("dd-next");
  if (next) next.classList.remove("hidden");
}

function nextDialogDrill() {
  const st = window.__dialogDrill;
  if (!st) return;
  st.idx++;
  st.answered = false;
  renderDialogDrillQ();
}


// ---------- CEFR Learn Path Engine ----------
function getUnitMasteryKey(level, unitId) {
  return level + "::" + unitId;
}

function getUnitRecord(level, unitId) {
  state.unitRecords = state.unitRecords || {};
  const k = getUnitMasteryKey(level, unitId);
  return state.unitRecords[k] || null;
}

function setUnitRecord(level, unitId, rec) {
  state.unitRecords = state.unitRecords || {};
  state.unitRecords[getUnitMasteryKey(level, unitId)] = rec;
  saveState();
}

function isUnitMastered(level, unitId) {
  const r = getUnitRecord(level, unitId);
  return r && r.passed === true;
}

function isUnitUnlocked(level, unitIndex) {
  if (!isLevelUnlocked(level)) return false;
  if (unitIndex === 0) return true;
  const units = (LEARN_PATH[level] || []);
  const prev = units[unitIndex - 1];
  if (!prev) return true;
  return isUnitMastered(level, prev.id);
}

function levelUnitProgress(level) {
  const units = (LEARN_PATH && LEARN_PATH[level]) ? LEARN_PATH[level] : [];
  if (!units.length) return 0;
  const done = units.filter(u => isUnitMastered(level, u.id)).length;
  return Math.round((done / units.length) * 100);
}

function isReadyForLevelExam(level) {
  return levelUnitProgress(level) >= 80;
}

function renderLearnPath(level) {
  const order = (typeof CEFR_ORDER !== "undefined") ? CEFR_ORDER : ["a1","a2","b1","b2","c1","c2"];
  if (!level) level = state.level || "a1";
  if (!isLevelUnlocked(level)) {
    showToast("Level " + level.toUpperCase() + " terkunci. Selesaikan level sebelumnya.", "error");
    level = state.level || "a1";
  }

  document.querySelectorAll("#learn-tabs .tab").forEach(t => {
    const lv = t.dataset.level;
    t.classList.toggle("active", lv === level);
    t.classList.toggle("locked", !isLevelUnlocked(lv));
    t.onclick = () => {
      if (!isLevelUnlocked(lv)) {
        showToast("🔒 Selesaikan & lulus evaluasi level sebelumnya.", "error");
        return;
      }
      renderLearnPath(lv);
    };
  });

  const meta = (typeof CEFR_META !== "undefined" && CEFR_META[level]) ? CEFR_META[level] : {};
  const goalEl = document.getElementById("cefr-goal");
  if (goalEl) {
    goalEl.innerHTML = meta.label
      ? `<strong>${meta.label}</strong> — ${meta.goal || ""}`
      : "";
  }

  document.getElementById("learn-lesson").classList.add("hidden");
  document.getElementById("learn-path").classList.remove("hidden");

  const units = LEARN_PATH[level] || [];
  const path = document.getElementById("learn-path");
  const pct = levelUnitProgress(level);
  const passedLevel = (state.levelTestsPassed || []).includes(level);

  let banner = `
    <div class="level-exam-banner">
      <div>
        <strong>Progres ${ (meta.label || level).toString() }: ${pct}%</strong>
        <p style="font-size:0.85rem;color:var(--text-muted);margin:4px 0 0;">
          Unit terbuka berurutan. Evaluasi unit minimal ${Math.round((typeof UNIT_PASS_SCORE!=="undefined"?UNIT_PASS_SCORE:0.8)*100)}%. 
          Level exam setelah ≥80% unit lulus.
        </p>
      </div>
      ${passedLevel ? '<span class="goal-status achieved">Level exam lulus ✓</span>' :
        (isReadyForLevelExam(level)
          ? `<button class="btn btn-primary btn-sm" onclick="startLevelExam('${level}')">Ujian Naik Level</button>`
          : `<span class="goal-status in-progress">${pct}% unit dikuasai</span>`)}
    </div>`;

  path.innerHTML = banner + units.map((u, i) => {
    const mastered = isUnitMastered(level, u.id);
    const unlocked = isUnitUnlocked(level, i);
    const rec = getUnitRecord(level, u.id);
    let cls = "learn-unit";
    if (mastered) cls += " done";
    else if (unlocked) cls += " current";
    else cls += " level-locked";
    const scoreTxt = rec && typeof rec.score === "number"
      ? ` · skor ${Math.round(rec.score * 100)}%`
      : "";
    return `
      <div class="${cls}">
        <div class="learn-dot">${mastered ? "✓" : (i + 1)}</div>
        <div class="learn-unit-body" onclick="${unlocked ? `openLearnLesson('${level}','${u.id}')` : `showToast('Selesaikan unit sebelumnya dulu','error')`}">
          <h4>${u.title}${!unlocked ? " 🔒" : ""}</h4>
          <p>${u.desc}${scoreTxt}</p>
          <div class="learn-tags">${(u.tags || []).map(tg => `<span>${tg}</span>`).join("")}</div>
        </div>
      </div>`;
  }).join("");
}

let learnCtx = null;
let learnPhase = 0;
/** Phases: 0 orient, 1 theory, 2 examples, 3 vocab, 4 guided, 5 independent, 6 practice, 7 eval, 8 result */

function openLearnLesson(level, id) {
  const units = LEARN_PATH[level] || [];
  const idx = units.findIndex(u => u.id === id);
  if (idx < 0) return;
  if (!isUnitUnlocked(level, idx)) {
    showToast("Unit terkunci — selesaikan prasyarat.", "error");
    return;
  }
  learnCtx = { level, unit: units[idx], idx };
  learnPhase = 0;
  document.getElementById("learn-path").classList.add("hidden");
  document.getElementById("learn-lesson").classList.remove("hidden");
  renderLearnPhase();
}

function closeLearnLesson() {
  const lv = (learnCtx && learnCtx.level) || state.level || "a1";
  learnCtx = null;
  document.getElementById("learn-lesson").classList.add("hidden");
  document.getElementById("learn-path").classList.remove("hidden");
  renderLearnPath(lv);
}

function learnPhaseNames() {
  return [
    "Orientasi", "Materi inti", "Contoh", "Vocab & dialog",
    "Latihan terbimbing", "Latihan mandiri", "Praktik", "Evaluasi", "Hasil"
  ];
}

function renderLearnPhase() {
  if (!learnCtx) return;
  const { unit, level } = learnCtx;
  const c = unit.content || {};
  const names = learnPhaseNames();
  const bar = names.map((n, i) => {
    const st = i === learnPhase ? "background:var(--primary);color:#fff;" :
      (i < learnPhase ? "background:var(--success);color:#fff;" : "background:var(--bg);color:var(--text-muted);");
    return `<span style="padding:4px 8px;border-radius:12px;font-size:0.68rem;font-weight:600;${st}">${i + 1}. ${n}</span>`;
  }).join(" ");

  let body = "";
  const nav = (prev, next, nextLabel) => `
    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:22px;">
      ${prev != null ? `<button class="btn btn-secondary" type="button" onclick="learnPhase=${prev};renderLearnPhase()"><i class="fas fa-arrow-left"></i> Kembali</button>` : ""}
      ${next != null ? `<button class="btn btn-primary" type="button" onclick="learnPhase=${next};renderLearnPhase()">${nextLabel || "Lanjut"} <i class="fas fa-arrow-right"></i></button>` : ""}
    </div>`;

  if (learnPhase === 0) {
    body = `
      <div class="writing-prompt" style="border-left-color:var(--primary);">
        <h4>🎯 Tujuan pembelajaran</h4>
        <ul style="margin:10px 0 0 18px;line-height:1.7;">${(c.objectives || []).map(o => `<li>${o}</li>`).join("") || "<li>Menguasai materi unit ini</li>"}</ul>
      </div>
      <p style="margin-top:14px;line-height:1.7;">${c.orientation || ""}</p>
      <p style="color:var(--text-muted);font-size:0.9rem;margin-top:10px;">Tombol lanjut hanya membuka tahap berikutnya — kelulusan unit ditentukan evaluasi (min. ${Math.round((UNIT_PASS_SCORE||0.8)*100)}%).</p>
      ${nav(null, 1, "Mulai materi inti")}`;
  } else if (learnPhase === 1) {
    body = `
      <h4 style="color:var(--primary-light);">Materi inti</h4>
      <div style="line-height:1.8;">${c.theory || ""}</div>
      ${(c.rules && c.rules.length) ? `<h4 style="margin-top:18px;color:var(--primary-light);">Aturan penting</h4><ul style="margin:8px 0 0 18px;">${c.rules.map(r => `<li>${r}</li>`).join("")}</ul>` : ""}
      ${nav(0, 2)}`;
  } else if (learnPhase === 2) {
    body = `
      <h4 style="color:var(--primary-light);">Contoh bertingkat</h4>
      ${(c.examples || []).map((ex, i) => `
        <div class="example" style="margin-bottom:12px;">
          <strong>${i + 1}. ${ex.en}</strong><br>
          <span style="color:var(--text-muted);">${ex.id || ""}</span><br>
          <em style="font-size:0.9rem;">Mengapa benar: ${ex.why || ""}</em>
        </div>`).join("") || "<p>Tidak ada contoh.</p>"}
      ${c.compare ? `<div style="margin-top:14px;padding:12px;background:var(--bg);border-radius:10px;"><strong>Perbandingan:</strong> ${c.compare}</div>` : ""}
      ${(c.commonErrors || []).length ? `<h4 style="margin-top:16px;color:var(--warning);">Kesalahan umum</h4>
        ${(c.commonErrors).map(e => `<div class="example"><span style="color:#f87171;">✗ ${e.wrong}</span><br>✓ ${e.right}<br><em>${e.why}</em></div>`).join("")}` : ""}
      ${nav(1, 3)}`;
  } else if (learnPhase === 3) {
    body = renderVocabDialogPhase(c, unit, level);
  } else if (learnPhase === 4) {
    const items = c.guided || [];
    body = `
      <h4 style="color:var(--primary-light);">Latihan terbimbing</h4>
      <p style="color:var(--text-muted);margin-bottom:12px;">Jawab, lalu cek. Ada pembahasan.</p>
      <div id="guided-box">${items.map((it, qi) => `
        <div style="margin-bottom:16px;padding:12px;background:var(--bg);border-radius:12px;border:1px solid var(--border);">
          <p>${qi + 1}. ${it.q}</p>
          ${(it.options || []).map((o, oi) => `
            <label class="option" style="display:flex;cursor:pointer;margin:6px 0;">
              <input type="radio" name="gd${qi}" value="${oi}" style="margin-right:8px;"> ${o}
            </label>`).join("")}
          <div id="gd-fb${qi}" style="margin-top:8px;font-size:0.9rem;"></div>
        </div>`).join("") || "<p>Tidak ada soal terbimbing.</p>"}</div>
      <button class="btn btn-primary" type="button" onclick="checkGuidedPhase()">Cek jawaban terbimbing</button>
      ${nav(3, 5, "Lanjut mandiri")}`;
  } else if (learnPhase === 5) {
    const items = c.independent || [];
    body = `
      <h4 style="color:var(--primary-light);">Latihan mandiri</h4>
      ${items.map((it, qi) => {
        if (it.type === "write" || it.answer === "open") {
          return `<div style="margin-bottom:14px;"><p>${qi + 1}. ${it.q}</p>
            <textarea id="ind${qi}" rows="3" style="width:100%;padding:10px;border-radius:10px;background:var(--bg);border:1px solid var(--border);color:var(--text);"></textarea>
            <p style="font-size:0.85rem;color:var(--text-muted);margin-top:6px;">Petunjuk: ${it.explain || "Jawab sesuai materi."}</p></div>`;
        }
        if (it.options) {
          return `<div style="margin-bottom:14px;padding:12px;background:var(--bg);border-radius:12px;">
            <p>${qi + 1}. ${it.q}</p>
            ${(it.options).map((o, oi) => `<label class="option" style="display:flex;cursor:pointer;margin:6px 0;">
              <input type="radio" name="ind${qi}" value="${oi}" style="margin-right:8px;"> ${o}</label>`).join("")}
          </div>`;
        }
        return `<div style="margin-bottom:14px;"><p>${qi + 1}. ${it.q}</p>
          <input id="ind${qi}" style="width:100%;padding:10px;border-radius:10px;background:var(--bg);border:1px solid var(--border);color:var(--text);" placeholder="Jawaban singkat">
          <p style="font-size:0.85rem;color:var(--text-muted);">Kunci: akan dibahas di evaluasi / self-check (${it.explain || it.answer || ""})</p></div>`;
      }).join("") || "<p>Praktikkan sendiri dari materi.</p>"}
      ${nav(4, 6, "Praktik nyata")}`;
  } else if (learnPhase === 6) {
    body = `
      <h4 style="color:var(--primary-light);">Praktik nyata</h4>
      <div class="writing-prompt">${c.practice || "Terapkan materi dalam konteks nyata."}</div>
      <textarea id="practice-real" rows="4" style="width:100%;margin-top:12px;padding:12px;border-radius:12px;background:var(--bg);border:1px solid var(--border);color:var(--text);" placeholder="Catat praktikmu di sini (opsional, untuk refleksi)"></textarea>
      ${nav(5, 7, "Mulai evaluasi")}`;
  } else if (learnPhase === 7) {
    const items = c.evaluation || [];
    body = `
      <h4 style="color:var(--primary-light);">Evaluasi penguasaan</h4>
      <p style="color:var(--text-muted);margin-bottom:12px;">Satu soal per layar. Kunci jawaban baru muncul setelah kamu menjawab. Lulus ≥ ${Math.round((UNIT_PASS_SCORE||0.8)*100)}%.</p>
      <p><strong>${items.length}</strong> soal · unit: ${unit.title}</p>
      <button class="btn btn-primary" type="button" onclick="startAdaptiveEval()"><i class="fas fa-play"></i> Mulai evaluasi adaptif</button>
      ${nav(6, null)}`;
  } else {
    const rec = getUnitRecord(level, unit.id) || {};
    const pass = !!rec.passed;
    body = `
      <div class="result-hero" style="text-align:center;padding:20px;">
        <h2>${pass ? "Unit dikuasai ✓" : "Belum lulus"}</h2>
        <div class="big-score">${rec.score != null ? Math.round(rec.score * 100) + "%" : "—"}</div>
        <p>${pass ? "Kamu bisa lanjut unit berikutnya." : "Pelajari remedial, lalu ulangi evaluasi."}</p>
      </div>
      ${!pass && c.remedial ? `<div class="writing-prompt"><strong>Remedial:</strong> ${c.remedial}</div>` : ""}
      ${rec.details ? `<div style="margin-top:12px;font-size:0.9rem;">${rec.details}</div>` : ""}
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:18px;justify-content:center;">
        ${!pass ? `<button class="btn btn-primary" type="button" onclick="learnPhase=1;renderLearnPhase()">Ulangi materi</button>
        <button class="btn btn-secondary" type="button" onclick="learnPhase=7;renderLearnPhase()">Ulangi evaluasi</button>` : ""}
        <button class="btn btn-secondary" type="button" onclick="closeLearnLesson();renderLearnPath('${level}')">Kembali ke jalur</button>
      </div>`;
  }

  document.getElementById("learn-lesson-body").innerHTML = `
    <button class="btn btn-secondary btn-sm" type="button" onclick="closeLearnLesson();renderLearnPath('${level}')"><i class="fas fa-arrow-left"></i> Jalur belajar</button>
    <h2 style="margin:12px 0 6px;">${unit.title}</h2>
    <p style="color:var(--text-muted);margin-bottom:12px;">${unit.desc || ""}</p>
    <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:18px;">${bar}</div>
    ${body}`;
}

function checkGuidedPhase() {
  if (!learnCtx) return;
  const items = learnCtx.unit.content.guided || [];
  let ok = 0;
  items.forEach((it, qi) => {
    const sel = document.querySelector(`input[name="gd${qi}"]:checked`);
    const fb = document.getElementById("gd-fb" + qi);
    if (!fb) return;
    if (sel && parseInt(sel.value, 10) === it.correct) {
      ok++;
      fb.innerHTML = `<span style="color:var(--success);">Benar. ${it.explain || ""}</span>`;
    } else {
      fb.innerHTML = `<span style="color:#f87171;">Belum tepat. ${it.explain || ""} Jawaban: ${(it.options || [])[it.correct] || ""}</span>`;
    }
  });
  showToast(`Terbimbing: ${ok}/${items.length}`, ok === items.length ? "success" : "error");
}

function logMistake(entry) {
  state.mistakes = state.mistakes || [];
  const key = (entry.q || "") + "|" + (entry.level || "");
  const existing = state.mistakes.find(m => (m.q + "|" + m.level) === key);
  if (existing) {
    existing.count = (existing.count || 1) + 1;
    existing.lastAt = new Date().toISOString();
    existing.userAns = entry.userAns;
  } else {
    state.mistakes.unshift({
      ...entry,
      count: 1,
      resolved: false,
      lastAt: new Date().toISOString()
    });
  }
  state.mistakes = state.mistakes.slice(0, 100);
  saveState();
}

function submitUnitEvaluation() {
  if (!learnCtx) return;
  const { unit, level } = learnCtx;
  const items = unit.content.evaluation || [];
  if (!items.length) {
    showToast("Evaluasi belum tersedia.", "error");
    return;
  }
  // Adaptive one-at-a-time uses evalState
  if (window.__evalState && window.__evalState.active) {
    finishAdaptiveEval();
    return;
  }
  let correct = 0;
  let details = "<ul style='margin:8px 0 0 16px;'>";
  items.forEach((it, qi) => {
    const sel = document.querySelector(`input[name="ev${qi}"]:checked`);
    const ans = sel ? parseInt(sel.value, 10) : -1;
    const good = ans === it.correct;
    if (good) correct++;
    else {
      logMistake({
        q: it.q,
        correctOpt: (it.options || [])[it.correct],
        userAns: ans >= 0 ? (it.options || [])[ans] : "(kosong)",
        explain: it.explain || "",
        level,
        unitId: unit.id,
        source: "unit-eval"
      });
    }
    details += `<li>${good ? "✓" : "✗"} ${it.q} — ${it.explain || ""} ${!good ? "(kunci: " + ((it.options||[])[it.correct]||"") + ")" : ""}</li>`;
  });
  details += "</ul>";
  const score = correct / items.length;
  const threshold = typeof UNIT_PASS_SCORE !== "undefined" ? UNIT_PASS_SCORE : 0.8;
  const passed = score >= threshold;

  const prev = getUnitRecord(level, unit.id);
  const firstPass = passed && !(prev && prev.passed);
  setUnitRecord(level, unit.id, {
    passed,
    score,
    correct,
    total: items.length,
    details,
    at: new Date().toISOString()
  });

  if (firstPass) {
    if (!(state.lessonsCompleted || []).includes(unit.id)) {
      state.lessonsCompleted = state.lessonsCompleted || [];
      state.lessonsCompleted.push(unit.id);
    }
    state.xp = (state.xp || 0) + 40;
    updateGoalProgress("lessons");
    saveState();
    updateUI();
    showToast("Lulus unit! +40 XP", "success");
  } else if (passed) {
    showToast("Sudah lulus sebelumnya — XP tidak digandakan.", "success");
  } else {
    showToast(`Belum lulus (${Math.round(score*100)}%). Lihat My Mistakes & remedial.`, "error");
  }

  learnPhase = 8;
  renderLearnPhase();
}

function startAdaptiveEval() {
  if (!learnCtx) return;
  const items = (learnCtx.unit.content.evaluation || []).slice();
  if (!items.length) {
    showToast("Tidak ada soal evaluasi.", "error");
    return;
  }
  window.__evalState = {
    active: true,
    items,
    idx: 0,
    correct: 0,
    details: [],
    answered: false
  };
  renderAdaptiveEvalQuestion();
}

function renderAdaptiveEvalQuestion() {
  const st = window.__evalState;
  if (!st || !learnCtx) return;
  const { unit, level } = learnCtx;
  const it = st.items[st.idx];
  const total = st.items.length;
  const box = document.getElementById("learn-lesson-body");
  if (!it) {
    finishAdaptiveEval();
    return;
  }
  box.innerHTML = `
    <button class="btn btn-secondary btn-sm" type="button" onclick="closeLearnLesson();renderLearnPath('${level}')"><i class="fas fa-arrow-left"></i> Jalur</button>
    <h2 style="margin:12px 0 6px;">Evaluasi — ${st.idx + 1} / ${total}</h2>
    <p style="color:var(--text-muted);">Satu soal per layar. Kunci baru muncul setelah kamu menjawab.</p>
    <div style="margin-top:16px;padding:16px;background:var(--bg);border-radius:14px;border:1px solid var(--border);">
      <p style="font-weight:600;margin-bottom:12px;">${it.q}</p>
      <div id="adapt-opts">${(it.options || []).map((o, oi) => `
        <button type="button" class="option adapt-opt" data-oi="${oi}" style="display:block;width:100%;text-align:left;margin-bottom:8px;cursor:pointer;"
          onclick="answerAdaptive(${oi})">${String.fromCharCode(65 + oi)}. ${o}</button>`).join("")}
      </div>
      <div id="adapt-fb" style="margin-top:12px;"></div>
      <button type="button" class="btn btn-primary hidden" id="adapt-next" onclick="nextAdaptiveQuestion()">Soal berikutnya</button>
    </div>
    <p style="margin-top:10px;font-size:0.85rem;color:var(--text-muted);">Skor saat ini: ${st.correct} benar</p>
  `;
}

function answerAdaptive(oi) {
  const st = window.__evalState;
  if (!st || st.answered) return;
  st.answered = true;
  const it = st.items[st.idx];
  const good = oi === it.correct;
  if (good) st.correct++;
  else {
    logMistake({
      q: it.q,
      correctOpt: (it.options || [])[it.correct],
      userAns: (it.options || [])[oi],
      explain: it.explain || "",
      level: learnCtx.level,
      unitId: learnCtx.unit.id,
      source: "unit-eval"
    });
  }
  st.details.push({ good, q: it.q, explain: it.explain || "", oi, correct: it.correct });
  const fb = document.getElementById("adapt-fb");
  document.querySelectorAll(".adapt-opt").forEach(btn => {
    btn.disabled = true;
    const v = parseInt(btn.dataset.oi, 10);
    if (v === it.correct) btn.style.outline = "2px solid var(--success)";
    if (v === oi && !good) btn.style.outline = "2px solid #f87171";
  });
  if (fb) {
    fb.innerHTML = good
      ? `<span style="color:var(--success);font-weight:600;">Benar.</span> ${it.explain || ""}`
      : `<span style="color:#f87171;font-weight:600;">Belum tepat.</span> Kunci: <strong>${(it.options || [])[it.correct]}</strong>. ${it.explain || ""}`;
  }
  const next = document.getElementById("adapt-next");
  if (next) {
    next.classList.remove("hidden");
    next.textContent = st.idx >= st.items.length - 1 ? "Lihat hasil" : "Soal berikutnya";
  }
}

function nextAdaptiveQuestion() {
  const st = window.__evalState;
  if (!st) return;
  st.idx++;
  st.answered = false;
  if (st.idx >= st.items.length) finishAdaptiveEval();
  else renderAdaptiveEvalQuestion();
}

function finishAdaptiveEval() {
  const st = window.__evalState;
  if (!st || !learnCtx) return;
  const { unit, level } = learnCtx;
  const total = st.items.length;
  const correct = st.correct;
  const score = total ? correct / total : 0;
  const threshold = typeof UNIT_PASS_SCORE !== "undefined" ? UNIT_PASS_SCORE : 0.8;
  const passed = score >= threshold;
  let details = "<ul style='margin:8px 0 0 16px;'>";
  st.details.forEach(d => {
    details += `<li>${d.good ? "✓" : "✗"} ${d.q} — ${d.explain}</li>`;
  });
  details += "</ul>";
  const prev = getUnitRecord(level, unit.id);
  const firstPass = passed && !(prev && prev.passed);
  setUnitRecord(level, unit.id, {
    passed, score, correct, total, details, at: new Date().toISOString()
  });
  if (firstPass) {
    if (!(state.lessonsCompleted || []).includes(unit.id)) {
      state.lessonsCompleted = state.lessonsCompleted || [];
      state.lessonsCompleted.push(unit.id);
    }
    state.xp = (state.xp || 0) + 40;
    updateGoalProgress("lessons");
    saveState();
    updateUI();
    showToast("Lulus unit! +40 XP", "success");
  } else if (!passed) {
    showToast(`Belum lulus (${Math.round(score * 100)}%). Cek My Mistakes.`, "error");
  }
  window.__evalState = null;
  learnPhase = 8;
  renderLearnPhase();
}


function startLevelExam(level) {
  if (!isReadyForLevelExam(level)) {
    showToast("Selesaikan minimal 80% unit (lulus evaluasi) dulu.", "error");
    return;
  }
  const units = LEARN_PATH[level] || [];
  const pool = [];
  units.forEach(u => {
    (u.content && u.content.evaluation || []).forEach(q => pool.push(q));
  });
  const quiz = shuffle(pool).slice(0, Math.min(10, pool.length));
  if (quiz.length < 5) {
    showToast("Bank soal level belum cukup.", "error");
    return;
  }
  let idx = 0, answers = [];
  const run = () => {
    if (idx >= quiz.length) {
      let sc = 0;
      answers.forEach((a, i) => { if (a === quiz[i].correct) sc++; });
      const ratio = sc / quiz.length;
      const pass = ratio >= (UNIT_PASS_SCORE || 0.8);
      if (pass) {
        if (!(state.levelTestsPassed || []).includes(level)) {
          state.levelTestsPassed = [...(state.levelTestsPassed || []), level];
        }
        const order = CEFR_ORDER || ["a1","a2","b1","b2","c1","c2"];
        const i = order.indexOf(level);
        if (i >= 0 && i < order.length - 1) {
          const next = order[i + 1];
          if (!(state.unlockedLevels || []).includes(next)) {
            state.unlockedLevels = [...(state.unlockedLevels || []), next];
          }
          state.level = next;
        }
        state.xp = (state.xp || 0) + 120;
        saveState();
        updateUI();
        showModal(`<h3>Lulus ${level.toUpperCase()}!</h3><p>Skor ${sc}/${quiz.length}. Level berikutnya terbuka.</p>
          <button class="btn btn-primary" onclick="closeModal();renderLearnPath(state.level)">Lanjut</button>`);
      } else {
        showModal(`<h3>Belum lulus level exam</h3><p>Skor ${sc}/${quiz.length}. Ulangi unit lemah.</p>
          <button class="btn btn-primary" onclick="closeModal()">OK</button>`);
      }
      return;
    }
    const q = quiz[idx];
    showModal(`<h3>Level exam ${level.toUpperCase()} — ${idx+1}/${quiz.length}</h3>
      <p style="margin:12px 0;">${q.q}</p>
      ${(q.options||[]).map((o,oi)=>`<div class="option" onclick="window.__lev=${oi}">${String.fromCharCode(65+oi)}. ${o}</div>`).join("")}
      <button class="btn btn-primary" style="margin-top:14px;" onclick="
        if(window.__lev===undefined){alert('Pilih jawaban');return;}
        answers.push(window.__lev);window.__lev=undefined;idx++;closeModal();setTimeout(run,200);
      ">Lanjut</button>`);
  };
  // bind locals for inline handler via closure on window
  window.__levelExamRun = { get idx(){return idx;}, set idx(v){idx=v;}, answers, quiz, run };
  // simpler sequential without broken inline
  const step = () => {
    if (idx >= quiz.length) {
      let sc = 0;
      answers.forEach((a, i) => { if (a === quiz[i].correct) sc++; });
      const ratio = sc / quiz.length;
      const pass = ratio >= (UNIT_PASS_SCORE || 0.8);
      if (pass) {
        if (!(state.levelTestsPassed || []).includes(level)) {
          state.levelTestsPassed = [...(state.levelTestsPassed || []), level];
        }
        const order = (typeof CEFR_ORDER !== "undefined") ? CEFR_ORDER : ["a1","a2","b1","b2","c1","c2"];
        const ii = order.indexOf(level);
        if (ii >= 0 && ii < order.length - 1) {
          const next = order[ii + 1];
          if (!(state.unlockedLevels || []).includes(next)) {
            state.unlockedLevels.push(next);
          }
          state.level = next;
        }
        state.xp = (state.xp || 0) + 120;
        saveState();
        updateUI();
        showModal(`<h3>Lulus ${level.toUpperCase()}!</h3><p>Skor ${sc}/${quiz.length}.</p>
          <button class="btn btn-primary" onclick="closeModal();renderLearnPath(state.level)">Lanjut</button>`);
      } else {
        showModal(`<h3>Belum lulus</h3><p>Skor ${sc}/${quiz.length} (butuh ≥80%).</p>
          <button class="btn btn-primary" onclick="closeModal()">OK</button>`);
      }
      return;
    }
    const q = quiz[idx];
    const opts = (q.options || []).map((o, oi) =>
      `<div class="option" data-oi="${oi}" style="cursor:pointer;">${String.fromCharCode(65+oi)}. ${o}</div>`
    ).join("");
    showModal(`<h3>Level exam ${level.toUpperCase()} — ${idx+1}/${quiz.length}</h3>
      <p style="margin:12px 0;">${q.q}</p>${opts}
      <button class="btn btn-primary" style="margin-top:14px;" id="lev-next">Lanjut</button>`);
    let chosen = undefined;
    document.querySelectorAll("#modal-body .option").forEach(el => {
      el.onclick = () => {
        document.querySelectorAll("#modal-body .option").forEach(x => x.style.outline = "");
        el.style.outline = "2px solid var(--primary)";
        chosen = parseInt(el.dataset.oi, 10);
      };
    });
    document.getElementById("lev-next").onclick = () => {
      if (chosen === undefined) { alert("Pilih jawaban"); return; }
      answers.push(chosen);
      idx++;
      closeModal();
      setTimeout(step, 200);
    };
  };
  step();
}

function completeLearnUnit(id) {
  // Legacy no-op: mastery only via evaluation
  showToast("Selesaikan evaluasi unit untuk menandai penguasaan.", "error");
}


function resetApp() {
  if (confirm("Yakin ingin reset semua data? Progress akan hilang.")) {
    localStorage.removeItem("linguapro_state");
    location.reload();
  }
}

// ---------- AI Tutor (real API via Netlify Function) ----------
const AI_HISTORY_KEY = "linguapro_ai_history";
let aiChatHistory = [];
let aiSending = false;

function loadAIHistory() {
  try {
    const raw = localStorage.getItem(AI_HISTORY_KEY + "_" + (state.email || "guest"));
    aiChatHistory = raw ? JSON.parse(raw) : [];
  } catch {
    aiChatHistory = [];
  }
}

function saveAIHistory() {
  try {
    localStorage.setItem(
      AI_HISTORY_KEY + "_" + (state.email || "guest"),
      JSON.stringify(aiChatHistory.slice(-40))
    );
  } catch (_) {}
}

function renderAIHistory() {
  const box = document.getElementById("ai-messages");
  if (!box) return;
  const welcome = `
    <div class="ai-msg bot">
      <div class="ai-avatar">🤖</div>
      <div class="ai-bubble">
        Halo${state.name ? ", <strong>" + escapeHtml(state.name) + "</strong>" : ""}! Aku AI Tutor LinguaPro.
        Tanya apa saja: koreksi kalimat, penjelasan grammar (Bahasa Indonesia), contoh, atau minta soal latihan.
        <br><small style="opacity:.75">Jawaban digenerate AI (Gemini) lewat server aman — bukan template statis.</small>
      </div>
    </div>`;
  if (!aiChatHistory.length) {
    box.innerHTML = welcome;
    return;
  }
  box.innerHTML =
    welcome +
    aiChatHistory
      .map(
        (m) => `
    <div class="ai-msg ${m.role === "user" ? "user" : "bot"}">
      <div class="ai-avatar">${m.role === "user" ? "👤" : "🤖"}</div>
      <div class="ai-bubble">${m.role === "user" ? escapeHtml(m.text) : m.text}</div>
    </div>`
      )
      .join("");
  box.scrollTop = box.scrollHeight;
}

function askAI(text) {
  document.getElementById("ai-input").value = text;
  sendAI();
}

async function sendAI() {
  if (aiSending) return;
  const input = document.getElementById("ai-input");
  const text = (input.value || "").trim();
  if (!text) return;
  input.value = "";

  appendAIMessage(escapeHtml(text), "user");
  aiChatHistory.push({ role: "user", text });
  saveAIHistory();

  aiSending = true;
  const sendBtn = document.querySelector(".ai-chat-input button");
  if (sendBtn) sendBtn.disabled = true;
  const thinking = appendAIMessage(
    `<span class="ai-loading"><span></span><span></span><span></span></span> AI sedang menjawab...`,
    "bot",
    true
  );

  try {
    const endpoints = ["/.netlify/functions/ai-tutor", "/api/ai-tutor"];
    let lastErr = null;
    let data = null;

    for (const url of endpoints) {
      try {
        const resp = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            message: text,
            history: aiChatHistory.slice(0, -1).map((h) => ({
              role: h.role === "user" ? "user" : "model",
              text: h.text
            })),
            userName: state.name || "siswa",
            level: state.level || "beginner"
          })
        });
        data = await resp.json().catch(() => ({}));
        if (resp.ok && data.reply) {
          lastErr = null;
          break;
        }
        lastErr = data.message || data.error || `HTTP ${resp.status}`;
        data = null;
      } catch (e) {
        lastErr = e.message || "Network error";
        data = null;
      }
    }

    thinking.remove();

    if (data && data.reply) {
      const safe = sanitizeAIHtml(data.reply);
      appendAIMessage(safe, "bot");
      aiChatHistory.push({ role: "bot", text: safe });
      saveAIHistory();
    } else {
      const msg = lastErr || "Tidak ada respons";
      const isConfig = /API_NOT_CONFIGURED|not configured|GEMINI/i.test(String(msg));
      appendAIMessage(
        `<strong>AI Tutor tidak tersedia saat ini.</strong><br><br>
        ${escapeHtml(String(msg).slice(0, 300))}<br><br>
        ${
          isConfig
            ? `<em>Untuk admin Netlify:</em> Site settings → Environment variables → tambah <code>GEMINI_API_KEY</code> (dari <a href="https://aistudio.google.com/apikey" target="_blank" rel="noopener">Google AI Studio</a>), lalu <strong>Redeploy</strong> site.`
            : `Coba lagi beberapa saat. Jika berulang, cek koneksi atau kuota API.`
        }`,
        "bot"
      );
      showToast("AI Tutor gagal merespons", "error");
    }
  } catch (e) {
    thinking.remove();
    appendAIMessage(
      `Terjadi error: ${escapeHtml(e.message || "unknown")}. Pastikan site di-deploy di Netlify dengan function aktif.`,
      "bot"
    );
    showToast("Error AI Tutor", "error");
  } finally {
    aiSending = false;
    if (sendBtn) sendBtn.disabled = false;
  }
}

function sanitizeAIHtml(html) {
  // Allow only simple formatting tags from model
  let s = String(html);
  s = s.replace(/```[\s\S]*?```/g, (m) => m.replace(/```\w*/g, "").replace(/```/g, ""));
  s = s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  s = s
    .replace(/&lt;(\/?(strong|b|em|i|br|ul|ol|li|p|code|u)(?:\s[^&]*)?)&gt;/gi, "<$1>")
    .replace(/&lt;br\s*\/?&gt;/gi, "<br>");
  s = s.replace(/\n/g, "<br>");
  return s;
}

function clearAIChat() {
  if (!confirm("Hapus riwayat chat AI Tutor?")) return;
  aiChatHistory = [];
  saveAIHistory();
  renderAIHistory();
  showToast("Riwayat chat dihapus", "success");
}

function appendAIMessage(html, role, isTemp) {
  const box = document.getElementById("ai-messages");
  const div = document.createElement("div");
  div.className = `ai-msg ${role}`;
  if (isTemp) div.id = "ai-thinking";
  div.innerHTML = `
    <div class="ai-avatar">${role === "bot" ? "🤖" : "👤"}</div>
    <div class="ai-bubble">${html}</div>
  `;
  box.appendChild(div);
  box.scrollTop = box.scrollHeight;
  return div;
}

function generateAIReply(q) {
  const lower = q.toLowerCase();

  // Correction request
  if (/koreksi|correct|perbaiki|fix this|salahkah/i.test(q)) {
    const sentence = q.replace(/koreksi[:\s]*|correct[:\s]*|perbaiki[:\s]*|fix this[:\s]*/i, "").trim();
    return correctEnglish(sentence || q);
  }

  // Present perfect
  if (/present perfect/i.test(lower)) {
    return `<strong>Present Perfect</strong> = have/has + V3<br><br>
    Dipakai untuk:<br>
    1. Pengalaman (tanpa waktu spesifik): <div class="example-line">I have visited Bali twice.</div>
    2. Kejadian yang baru selesai: <div class="example-line">She has just finished her essay.</div>
    3. Sesuatu yang dimulai di masa lalu dan masih relevan: <div class="example-line">They have lived here for 5 years.</div>
    <br><strong>Tip:</strong> Jangan pakai present perfect dengan waktu spesifik seperti <em>yesterday / last week</em> → pakai Past Simple.`;
  }

  // Since vs For
  if (/since.*for|for.*since|bedanya since|since dan for/i.test(lower)) {
    return `<strong>Since vs For</strong><br><br>
    <strong>For</strong> = durasi (berapa lama)<br>
    <div class="example-line">I have studied English <strong>for</strong> 3 years.</div>
    <strong>Since</strong> = titik awal waktu<br>
    <div class="example-line">I have studied English <strong>since</strong> 2021.</div>
    <br>Keduanya sering muncul bersama Present Perfect.`;
  }

  // Conditional
  if (/conditional|if clause|type 2|tipe 2/i.test(lower)) {
    return `<strong>Conditional Type 2</strong> (hypothetical sekarang)<br><br>
    Pola: <em>If + Past Simple, would + V1</em><br>
    <div class="example-line">If I <strong>were</strong> rich, I <strong>would travel</strong> the world.</div>
    <div class="example-line">If she <strong>studied</strong> harder, she <strong>would pass</strong>.</div>
    <br>Catatan: untuk "to be" di type 2, formal memakai <strong>were</strong> untuk semua subject (If I were you...).`;
  }

  // Passive
  if (/passive/i.test(lower)) {
    return `<strong>Passive Voice</strong><br><br>
    Pola: <em>Object + be + V3 (+ by agent)</em><br>
    Active: Someone wrote the report.<br>
    Passive: <div class="example-line">The report <strong>was written</strong> (by someone).</div>
    <br>Digunakan saat pelaku tidak penting atau ingin fokus ke objek. Sangat umum di academic writing.`;
  }

  // IELTS writing tips
  if (/ielts.*writ|writing.*ielts|tips writing|task 2/i.test(lower)) {
    return `<strong>Tips IELTS Writing Task 2</strong><br><br>
    1. <strong>Paraphrase</strong> pertanyaan di intro — jangan copy paste.<br>
    2. Struktur jelas: Intro → Body 1 → Body 2 → Conclusion.<br>
    3. Tiap body: topic sentence + explanation + example.<br>
    4. Pakai linking words: however, furthermore, in contrast, consequently.<br>
    5. Target 250+ kata, ideal 280–320.<br>
    6. Sisihkan 3–5 menit untuk cek grammar & spelling.<br><br>
    Latihan di menu <em>Latihan → Writing</em> lalu dapat AI feedback!`;
  }

  // Articles
  if (/\ba\/an\b|artikel|articles/i.test(lower)) {
    return `<strong>Articles: a / an / the</strong><br><br>
    <strong>a</strong> + consonant sound: a university, a book<br>
    <strong>an</strong> + vowel sound: an apple, an hour<br>
    <strong>the</strong> = spesifik / sudah disebut / unik (the sun, the first time)<br>
    <div class="example-line">I saw <strong>a</strong> cat. <strong>The</strong> cat was black.</div>`;
  }

  // Past simple vs present perfect
  if (/past simple|present perfect.*past|beda.*tense/i.test(lower)) {
    return `<strong>Past Simple vs Present Perfect</strong><br><br>
    <strong>Past Simple</strong>: waktu selesai & spesifik<br>
    <div class="example-line">I went to Jakarta <strong>yesterday</strong>.</div>
    <strong>Present Perfect</strong>: pengalaman / masih relevan, waktu tidak spesifik<br>
    <div class="example-line">I <strong>have been</strong> to Jakarta (before).</div>`;
  }

  // Vocab / synonym
  if (/sinonim|synonym|vocab|kosakata/i.test(lower)) {
    return `Beberapa pasangan berguna untuk writing:<br>
    <div class="example-line">important → crucial, significant, essential</div>
    <div class="example-line">many → numerous, a wide range of, a variety of</div>
    <div class="example-line">show → illustrate, demonstrate, indicate</div>
    <div class="example-line">help → assist, facilitate, contribute to</div>
    Hindari mengulang kata yang sama di essay.`;
  }

  // Greeting / general
  if (/^(hi|halo|hai|hello|hey)/i.test(lower)) {
    return `Halo ${state.name || "teman"}! Ada yang mau ditanyakan tentang English? Grammar, vocab, writing tips, atau minta koreksi kalimat — silakan.`;
  }

  // Default helpful response
  return `Aku bisa bantu menjelaskan topik seperti:<br>
  • Tenses (Present Perfect, Past Simple, dll.)<br>
  • Conditionals, Passive Voice, Articles<br>
  • Tips IELTS/TOEFL Writing & Speaking<br>
  • Koreksi kalimat (ketik: <em>Koreksi: I go yesterday</em>)<br><br>
  Coba tanya lebih spesifik, misalnya: <strong>"Jelaskan present perfect"</strong> atau <strong>"Bedanya since dan for"</strong>.`;
}

function correctEnglish(sentence) {
  if (!sentence || sentence.length < 3) {
    return `Ketik kalimat yang mau dikoreksi, contoh:<br><div class="example-line">Koreksi: I go to school yesterday</div>`;
  }

  let fixed = sentence;
  const notes = [];

  // Common fixes
  if (/\bi go\b.*\byesterday\b/i.test(sentence)) {
    fixed = sentence.replace(/\bi go\b/i, "I went");
    notes.push("Past time marker (yesterday) → pakai Past Simple: go → went");
  }
  if (/\bshe go\b/i.test(sentence)) {
    fixed = fixed.replace(/\bshe go\b/i, "she goes");
    notes.push("He/She/It + Present Simple → verb + s/es");
  }
  if (/\bi have went\b/i.test(sentence)) {
    fixed = fixed.replace(/\bhave went\b/i, "have gone");
    notes.push("Present Perfect memakai V3: go → gone (bukan went)");
  }
  if (/\bmore better\b/i.test(sentence)) {
    fixed = fixed.replace(/\bmore better\b/i, "better");
    notes.push("'Better' sudah comparative — tidak perlu 'more'");
  }
  if (/\binteresing\b/i.test(sentence)) {
    fixed = fixed.replace(/\binteresing\b/i, "interesting");
    notes.push("Spelling: interesting");
  }
  if (/\bdont\b/i.test(sentence)) {
    fixed = fixed.replace(/\bdont\b/i, "don't");
    notes.push("Apostrophe: don't");
  }
  if (/\bi am agree\b/i.test(sentence)) {
    fixed = fixed.replace(/\bi am agree\b/i, "I agree");
    notes.push("'Agree' tidak memakai 'am' — langsung: I agree");
  }
  if (/\bhe can plays\b/i.test(sentence)) {
    fixed = fixed.replace(/\bcan plays\b/i, "can play");
    notes.push("Setelah modal (can/should/must) → base verb tanpa -s");
  }

  if (notes.length === 0) {
    return `Kalimat: <div class="example-line">${escapeHtml(sentence)}</div>
    Tidak ketemu error umum yang jelas. Coba cek: subject-verb agreement, tense vs time marker, dan spelling.<br>
    Untuk feedback lebih dalam, latihan di menu Writing.`;
  }

  return `Asli: <div class="example-line">${escapeHtml(sentence)}</div>
  Koreksi: <div class="example-line">${escapeHtml(fixed)}</div>
  <strong>Catatan:</strong><ul style="margin:8px 0 0 16px;">${notes.map(n => `<li>${n}</li>`).join("")}</ul>`;
}

function escapeHtml(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}



// ---------- Goal tracks ----------
function setLearningTrack(track) {
  state.learningTrack = track;
  saveState();
  renderTrackStatus();
  const tips = {
    conversation: "Prioritas: Jalur A1–B1 speaking units, AI Call Casual, Latihan Speaking.",
    academic: "Prioritas: writing units B1+, Writing Lab, Grammar advanced patterns.",
    scholarship: "Prioritas: Writing Lab essay, AI Call Interview, vocab akademik.",
    exam: "Prioritas: Mock IELTS/TOEFL setelah B1+ dikuasai. Jangan skip fondasi A1–A2."
  };
  showToast("Jalur: " + track, "success");
  const el = document.getElementById("track-status");
  if (el) el.innerHTML = `<strong>Jalur aktif:</strong> ${track}<br>${tips[track] || ""}`;
}

function renderTrackStatus() {
  const el = document.getElementById("track-status");
  if (!el) return;
  if (!state.learningTrack) {
    el.textContent = "Belum memilih jalur tujuan — pilih kartu di atas.";
    return;
  }
  el.innerHTML = `<strong>Jalur aktif:</strong> ${state.learningTrack}`;
}

// ---------- My Mistakes ----------
function renderMistakes() {
  const box = document.getElementById("mistakes-list");
  if (!box) return;
  const list = state.mistakes || [];
  if (!list.length) {
    box.innerHTML = `<p class="empty-state">Belum ada kesalahan tersimpan. Kerjakan evaluasi unit — jawaban salah akan masuk ke sini.</p>`;
    return;
  }
  box.innerHTML = list.map((m, i) => `
    <div class="mistake-card ${m.resolved ? 'resolved' : ''}">
      <div class="mistake-meta">${(m.level || "").toUpperCase()} · ${m.source || "eval"} · ×${m.count || 1}</div>
      <p><strong>Soal:</strong> ${escapeHtml(m.q || "")}</p>
      <p style="color:#f87171;"><strong>Jawabanmu:</strong> ${escapeHtml(m.userAns || "")}</p>
      <p style="color:var(--success);"><strong>Kunci:</strong> ${escapeHtml(m.correctOpt || "")}</p>
      <p style="color:var(--text-muted);">${escapeHtml(m.explain || "")}</p>
      <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;">
        <button class="btn btn-sm btn-primary" type="button" onclick="drillMistake(${i})">Latihan ulang</button>
        <button class="btn btn-sm btn-secondary" type="button" onclick="resolveMistake(${i})">Tandai dikuasai</button>
      </div>
    </div>
  `).join("");
}

function resolveMistake(i) {
  if (!state.mistakes || !state.mistakes[i]) return;
  state.mistakes[i].resolved = true;
  saveState();
  renderMistakes();
  showToast("Ditandai dikuasai", "success");
}

function drillMistake(i) {
  const m = state.mistakes && state.mistakes[i];
  if (!m) return;
  const opts = shuffle([m.correctOpt, m.userAns, "Not sure", "Skip"].filter(Boolean));
  // unique
  const uniq = [...new Set(opts)].slice(0, 4);
  const correct = uniq.indexOf(m.correctOpt);
  showModal(`<h3>Drill kesalahan</h3>
    <p style="margin:12px 0;">${escapeHtml(m.q)}</p>
    ${uniq.map((o, oi) => `<div class="option" data-oi="${oi}" style="cursor:pointer;margin:6px 0;">${String.fromCharCode(65+oi)}. ${escapeHtml(o)}</div>`).join("")}
    <div id="drill-fb" style="margin-top:10px;"></div>
    <button class="btn btn-primary" style="margin-top:12px;" id="drill-close" onclick="closeModal()">Tutup</button>`);
  document.querySelectorAll("#modal-body .option").forEach(el => {
    el.onclick = () => {
      const oi = parseInt(el.dataset.oi, 10);
      const fb = document.getElementById("drill-fb");
      if (oi === correct) {
        fb.innerHTML = `<span style="color:var(--success);">Benar! ${escapeHtml(m.explain || "")}</span>`;
        state.mistakes[i].resolved = true;
        saveState();
      } else {
        fb.innerHTML = `<span style="color:#f87171;">Masih salah. Kunci: ${escapeHtml(m.correctOpt)}</span>`;
      }
    };
  });
}

// ---------- Writing Lab ----------
function runWritingLab() {
  const text = (document.getElementById("wl-text").value || "").trim();
  const prompt = (document.getElementById("wl-prompt").value || "").trim();
  const out = document.getElementById("wl-result");
  if (!out) return;
  if (text.split(/\s+/).filter(Boolean).length < 15) {
    showToast("Tulis minimal ~15 kata dulu.", "error");
    return;
  }
  // Local heuristic analysis (always available). AI optional via askAIWritingLab.
  const words = text.split(/\s+/).filter(Boolean);
  const issues = [];
  let revised = text;

  if (/\bi go\b.*\b(yesterday|last)\b/i.test(text)) {
    issues.push({ bad: "go + past time", fix: "Pakai Past Simple: went", why: "Waktu lampau spesifik membutuhkan V2." });
    revised = revised.replace(/\bi go\b/i, "I went");
  }
  if (/\bshe go\b/i.test(text)) {
    issues.push({ bad: "she go", fix: "she goes", why: "He/She/It + Present Simple → verb-s." });
    revised = revised.replace(/\bshe go\b/i, "she goes");
  }
  if (/\bi have went\b/i.test(text)) {
    issues.push({ bad: "have went", fix: "have gone", why: "Past participle of go = gone." });
    revised = revised.replace(/\bi have went\b/i, "I have gone");
  }
  if (/\ba apple\b/i.test(text)) {
    issues.push({ bad: "a apple", fix: "an apple", why: "Bunyi vokal → an." });
    revised = revised.replace(/\ba apple\b/i, "an apple");
  }
  if (/\bi am agree\b/i.test(text)) {
    issues.push({ bad: "I am agree", fix: "I agree", why: "Agree adalah verb, bukan adjective." });
    revised = revised.replace(/\bi am agree\b/i, "I agree");
  }
  if (/\bmore better\b/i.test(text)) {
    issues.push({ bad: "more better", fix: "better", why: "Better sudah comparative." });
    revised = revised.replace(/\bmore better\b/i, "better");
  }
  // weak thesis for short opinion
  if (prompt && /opinion|should|agree/i.test(prompt) && words.length < 80) {
    issues.push({ bad: "Pengembangan terbatas", fix: "Tambah alasan + contoh (target 100+ kata untuk opini B1).", why: "Esai pendek jarang memenuhi task response." });
  }
  if (!issues.length) {
    issues.push({ bad: "Tidak ada pola error klasik terdeteksi", fix: "Periksa coherence & vocabulary secara mandiri atau pakai AI Tutor.", why: "Analyzer lokal hanya menangkap pola umum." });
  }

  out.classList.remove("hidden");
  out.innerHTML = `
    <h4>Hasil analisis (lokal)</h4>
    <p style="color:var(--text-muted);font-size:0.9rem;">Ini bukan skor IELTS resmi. Pola error umum dicek di perangkatmu. Untuk feedback lebih dalam, gunakan tombol AI Tutor.</p>
    <div class="fb-item"><strong>Jumlah kata</strong>${words.length}</div>
    ${issues.map(is => `<div class="fb-item"><strong>${escapeHtml(is.bad)}</strong>→ ${escapeHtml(is.fix)}<br><em>${escapeHtml(is.why)}</em></div>`).join("")}
    <h4 style="margin-top:14px;">Revisi usulan</h4>
    <div class="writing-prompt">${escapeHtml(revised)}</div>
    <h4 style="margin-top:14px;">Latihan lanjutan</h4>
    <p>Tulis ulang paragraf yang sama dengan 2 complex sentences (because / although / which).</p>
  `;
  state.xp = (state.xp || 0) + 5;
  saveState();
  updateUI();
}

function askAIWritingLab() {
  const text = (document.getElementById("wl-text").value || "").trim();
  const prompt = (document.getElementById("wl-prompt").value || "").trim();
  if (text.length < 20) {
    showToast("Isi tulisan dulu.", "error");
    return;
  }
  const q = `Koreksi dan perbaiki tulisan berikut untuk level ${state.level || "a1"}. Beri: (1) daftar kesalahan spesifik, (2) versi revisi, (3) satu latihan lanjutan. Prompt/topik: ${prompt || "(umum)"}.\n\nTulisan:\n${text}`;
  navigateTo("aitutor");
  setTimeout(() => {
    document.getElementById("ai-input").value = q;
    sendAI();
  }, 400);
}

// Enhance renderProgress competence vs activity
function renderProgressCompetencePatch() {
  // called from renderProgress if container exists
  const host = document.getElementById("progress-competence");
  if (!host) return;
  const order = (typeof CEFR_ORDER !== "undefined") ? CEFR_ORDER : ["a1","a2","b1","b2","c1","c2"];
  host.innerHTML = order.map(lv => {
    const pct = levelUnitProgress(lv);
    const unlocked = isLevelUnlocked(lv);
    return `<div class="section-score-card"><h4>${lv.toUpperCase()}</h4>
      <div class="score">${unlocked ? pct + "%" : "🔒"}</div>
      <p style="font-size:0.75rem;color:var(--text-muted);">unit dikuasai</p></div>`;
  }).join("");
}

// Preload speech voices
if (typeof speechSynthesis !== "undefined") {
  speechSynthesis.getVoices();
  speechSynthesis.onvoiceschanged = () => speechSynthesis.getVoices();
}


// ========== AI CALL — Free conversation (Gemini) + Exam mode ==========
let callState = null;
let callRec = null;
let callTranscriptBuf = "";
let callTimerInt = null;
let callSeconds = 0;
let callAIMuted = false;
let callBusy = false; // prevent double Gemini requests

const EXAM_QUESTIONS = {
  ielts: [
    "Hello. Let's begin. Can you tell me your full name, please?",
    "Where are you from, and what do you like about living there?",
    "Do you work or are you a student? What do you enjoy most about it?",
    "Describe a skill you would like to learn. Say what it is, why you want it, and how it could help you.",
    "What skills do you think are important for young people in your country today, and why?",
    "Thank you. That is the end of the practice test."
  ],
  interview: [
    "Good morning. Please introduce yourself briefly — name, education, and the role you want.",
    "Why are you interested in this field, and what makes you a good fit?",
    "Tell me about a challenge you faced and how you handled it.",
    "Where do you see yourself in three to five years?",
    "Do you have any questions for me?",
    "Thank you for your time. That concludes this practice interview."
  ]
};

function getCallLevel() {
  const el = document.getElementById("call-level");
  return (el && el.value) || state.level || "b1";
}
function getCallTopic() {
  const el = document.getElementById("call-topic");
  return (el && el.value) || "free";
}

function supportsSpeechRec() {
  return !!(window.SpeechRecognition || window.webkitSpeechRecognition);
}

async function callGeminiSpeaking(message, history, mode) {
  const endpoints = ["/.netlify/functions/ai-tutor", "/api/ai-tutor"];
  let lastErr = null;
  for (const url of endpoints) {
    try {
      const resp = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode: mode || "speaking",
          message,
          history,
          userName: state.name || "student",
          level: callState ? callState.level : getCallLevel(),
          topic: callState ? callState.topic : getCallTopic()
        })
      });
      const data = await resp.json().catch(() => ({}));
      if (resp.ok && data.reply) return data.reply;
      lastErr = data.message || data.error || ("HTTP " + resp.status);
    } catch (e) {
      lastErr = e.message || "network";
    }
  }
  throw new Error(lastErr || "AI tidak merespons");
}


function setCallPhase(phase, statusText) {
  const pill = document.getElementById("call-phase-pill");
  const st = document.getElementById("call-status");
  if (st && statusText) st.textContent = statusText;
  if (!pill) return;
  pill.className = "call-phase-pill " + (phase || "");
  const labels = {
    listening: "Listening",
    thinking: "Thinking",
    speaking: "AI speaking",
    "your-turn": "Your turn",
    idle: "—"
  };
  pill.textContent = labels[phase] || phase || "—";
}

function setCallLive(text) {
  const el = document.getElementById("call-live-line");
  if (el) el.textContent = text || "";
}

function clearCallQuick() {
  const q = document.getElementById("call-quick");
  if (q) q.innerHTML = "";
}

function showCallQuick(replies) {
  const q = document.getElementById("call-quick");
  if (!q) return;
  if (!replies || !replies.length) {
    q.innerHTML = "";
    return;
  }
  q.innerHTML = replies
    .map(
      (r) =>
        `<button type="button" onclick='submitCallTurn(${JSON.stringify(r)})'>${escapeHtml(r)}</button>`
    )
    .join("");
}

function cleanSpeakText(text) {
  return String(text || "")
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/[*_#`>]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function skipAIAndListen() {
  callAIMuted = true;
  stopSpeech();
  stopCallRec();
  const av = document.getElementById("call-avatar");
  const wave = document.getElementById("call-wave");
  if (av) av.classList.remove("speaking");
  if (wave) wave.classList.remove("active");
  setCallPhase("your-turn", "Giliranmu — klik mic atau ketik");
  enableCallMic();
}

function sendCallText() {
  const input = document.getElementById("call-text-input");
  if (!input) return;
  const text = (input.value || "").trim();
  if (!text) return;
  if (!callState) {
    showToast("Mulai sesi dulu dari lobby.", "error");
    return;
  }
  if (callBusy) {
    showToast("Tunggu AI selesai merespons.", "error");
    return;
  }
  input.value = "";
  stopSpeech();
  stopCallRec();
  submitCallTurn(text);
}


function startFreeCall() {
  if (!supportsSpeechRec()) {
    showToast("Speech recognition butuh Chrome/Edge. Kamu masih bisa ketik jawaban di kolom bawah.", "error");
  }
  stopSpeech();
  stopCallRec();
  if (window.__callSilenceTimer) clearTimeout(window.__callSilenceTimer);
  callState = {
    kind: "free",
    level: getCallLevel(),
    topic: getCallTopic(),
    history: [],
    userTurns: [],
    allText: ""
  };
  openCallScreen("Free Conversation · " + callState.level.toUpperCase());
  setCallPhase("thinking", "AI menyiapkan sapaan...");
  document.getElementById("call-mic-btn").disabled = true;
  clearCallQuick();
  const openers = {
    free: "Greet me warmly like a phone call with a friend. One short greeting + one natural question about my day. Keep under 25 words.",
    campus: "Greet me. Ask one natural question about university or classes. Under 25 words.",
    hobby: "Greet me. Ask what I like doing in free time. Under 25 words.",
    travel: "Greet me. Ask about a place I want to visit. Under 25 words.",
    work: "Greet me. Ask about work or internship plans. Under 25 words.",
    daily: "Greet me. Ask about my morning or weekend routine. Under 25 words."
  };
  askAIAndSpeak(openers[callState.topic] || openers.free, true);
}

function startExamCall(type) {
  stopSpeech();
  stopCallRec();
  const qs = EXAM_QUESTIONS[type] || EXAM_QUESTIONS.ielts;
  callState = {
    kind: "exam",
    examType: type,
    level: getCallLevel(),
    topic: type,
    questions: qs,
    qIndex: 0,
    userTurns: [],
    allText: "",
    history: []
  };
  openCallScreen(type === "interview" ? "Interview Practice" : "Speaking Exam (practice)");
  speakAILine(qs[0], () => enableCallMic());
}

function openCallScreen(label) {
  callSeconds = 0;
  callAIMuted = false;
  callBusy = false;
  document.getElementById("call-lobby").classList.add("hidden");
  document.getElementById("call-result").classList.add("hidden");
  document.getElementById("call-screen").classList.remove("hidden");
  document.getElementById("call-transcript").innerHTML = "";
  document.getElementById("call-mode-label").textContent = label;
  document.getElementById("call-mic-hint").textContent = "Tunggu AI...";
  if (callTimerInt) clearInterval(callTimerInt);
  callTimerInt = setInterval(() => {
    callSeconds++;
    const m = String(Math.floor(callSeconds / 60)).padStart(2, "0");
    const s = String(callSeconds % 60).padStart(2, "0");
    const el = document.getElementById("call-timer");
    if (el) el.textContent = m + ":" + s;
  }, 1000);
}

// Legacy entry points from mock test / old cards
function startAICall(mode) {
  if (mode === "casual") startFreeCall();
  else startExamCall(mode === "interview" ? "interview" : "ielts");
}

function stopCallRec() {
  if (callRec) {
    try { callRec.stop(); } catch (e) {}
    callRec = null;
  }
  const btn = document.getElementById("call-mic-btn");
  if (btn) btn.classList.remove("recording");
}

function toggleAIMute() {
  callAIMuted = true;
  stopSpeech();
  const av = document.getElementById("call-avatar");
  const wave = document.getElementById("call-wave");
  if (av) av.classList.remove("speaking");
  if (wave) wave.classList.remove("active");
  document.getElementById("call-status").textContent = "Suara AI dihentikan — kamu bisa bicara";
  enableCallMic();
  showToast("Suara AI dihentikan", "success");
}

function speakAILine(text, onDone) {
  const cleaned = cleanSpeakText(text);
  appendCallBubble("ai", cleaned);
  setCallPhase("speaking", "AI berbicara (browser TTS)...");
  setCallLive("");
  document.getElementById("call-avatar").classList.add("speaking");
  document.getElementById("call-wave").classList.add("active");
  document.getElementById("call-mic-btn").disabled = true;
  stopCallRec();
  clearCallQuick();

  const finishSpeak = () => {
    document.getElementById("call-avatar").classList.remove("speaking");
    document.getElementById("call-wave").classList.remove("active");
    setCallPhase("your-turn", "Giliranmu — mic atau ketik");
    // Contextual quick replies (short) to keep interaction flowing
    if (callState && callState.kind === "free") {
      showCallQuick(["Yes, that's right.", "Not really.", "Can you repeat that?", "What do you mean?"]);
    }
    if (onDone) onDone();
  };

  if (callAIMuted || !window.speechSynthesis) {
    setTimeout(finishSpeak, 600);
    return;
  }

  stopSpeech();
  const u = new SpeechSynthesisUtterance(cleaned);
  u.lang = "en-US";
  u.rate = callState && /a1|a2/i.test(callState.level) ? 0.88 : 0.95;
  const voices = speechSynthesis.getVoices();
  const en = voices.find(v => /en(-|_)US/i.test(v.lang)) || voices.find(v => /^en/i.test(v.lang));
  if (en) u.voice = en;
  u.onend = finishSpeak;
  u.onerror = finishSpeak;
  speechSynthesis.speak(u);
}

function appendCallBubble(who, text) {
  const box = document.getElementById("call-transcript");
  if (!box) return;
  const div = document.createElement("div");
  div.className = "call-bubble " + who;
  div.innerHTML = `<div class="who">${who === "ai" ? "AI" : "Kamu"}</div>${escapeHtml(text)}`;
  box.appendChild(div);
  box.scrollTop = box.scrollHeight;
}

function enableCallMic() {
  document.getElementById("call-mic-btn").disabled = false;
  document.getElementById("call-mic-hint").textContent = "Klik mic → bicara (otomatis kirim setelah jeda) atau ketik di bawah";
  setCallPhase("your-turn", "Menunggu jawabanmu...");
  callTranscriptBuf = "";
  callAIMuted = false;
  const ti = document.getElementById("call-text-input");
  if (ti) ti.disabled = false;
}

function toggleCallMic() {
  const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRec) {
    document.getElementById("call-text-input") && document.getElementById("call-text-input").focus();
    showToast("Mic recognition tidak didukung — ketik di kolom bawah.", "error");
    return;
  }
  const btn = document.getElementById("call-mic-btn");
  if (callRec) {
    if (window.__callSilenceTimer) clearTimeout(window.__callSilenceTimer);
    try { callRec.stop(); } catch (e) {}
    callRec = null;
    btn.classList.remove("recording");
    const finalText = callTranscriptBuf.trim();
    setCallLive("");
    if (finalText.length < 2) {
      showToast("Belum tertangkap — bicara lagi atau ketik.", "error");
      enableCallMic();
      return;
    }
    submitCallTurn(finalText);
    return;
  }
  stopSpeech();
  clearCallQuick();
  callTranscriptBuf = "";
  callRec = new SpeechRec();
  callRec.lang = "en-US";
  callRec.continuous = true;
  callRec.interimResults = true;
  const armSilence = () => {
    if (window.__callSilenceTimer) clearTimeout(window.__callSilenceTimer);
    window.__callSilenceTimer = setTimeout(() => {
      if (!callRec) return;
      const finalText = callTranscriptBuf.trim();
      try { callRec.stop(); } catch (e) {}
      callRec = null;
      btn.classList.remove("recording");
      setCallLive("");
      if (finalText.length >= 2) submitCallTurn(finalText);
      else {
        showToast("Tidak ada suara — coba lagi.", "error");
        enableCallMic();
      }
    }, 2200);
  };
  callRec.onstart = () => {
    btn.classList.add("recording");
    setCallPhase("listening", "🎤 Mendengarkan... klik mic lagi atau diam ~2 detik untuk kirim");
    document.getElementById("call-mic-hint").textContent = "Bicara natural — otomatis kirim setelah jeda singkat";
  };
  callRec.onresult = (ev) => {
    let interim = "";
    for (let i = ev.resultIndex; i < ev.results.length; i++) {
      if (ev.results[i].isFinal) {
        callTranscriptBuf += ev.results[i][0].transcript + " ";
        armSilence();
      } else interim += ev.results[i][0].transcript;
    }
    const shown = (callTranscriptBuf + interim).trim();
    setCallLive(shown.slice(0, 120));
    setCallPhase("listening", "🎤 " + shown.slice(0, 70) + (shown.length > 70 ? "…" : ""));
  };
  callRec.onerror = (e) => {
    btn.classList.remove("recording");
    if (window.__callSilenceTimer) clearTimeout(window.__callSilenceTimer);
    if (e.error === "not-allowed") showToast("Izinkan mikrofon di browser.", "error");
    else if (e.error !== "aborted") showToast("Mic: " + e.error, "error");
  };
  callRec.onend = () => {
    btn.classList.remove("recording");
    callRec = null;
  };
  try {
    callRec.start();
  } catch (err) {
    showToast("Mic error: " + err.message, "error");
  }
}

function submitCallTurn(text) {
  if (!callState || callBusy) return;
  appendCallBubble("user", text);
  callState.userTurns.push(text);
  callState.allText += " " + text;
  document.getElementById("call-mic-btn").disabled = true;
  document.getElementById("call-mic-hint").textContent = "AI sedang berpikir...";
  document.getElementById("call-status").textContent = "⏳ AI merespons...";

  if (callState.kind === "free") {
    callState.history.push({ role: "user", text });
    askAIAndSpeak(text, false);
    return;
  }
  // Exam mode: store answer, next question
  callState.history.push({ role: "user", text });
  callState.qIndex++;
  const qs = callState.questions;
  if (callState.qIndex >= qs.length - 1) {
    // last AI line is closing then finish
    const closing = qs[qs.length - 1];
    speakAILine(closing, () => finishAICall());
    return;
  }
  const nextQ = qs[callState.qIndex];
  callState.history.push({ role: "model", text: nextQ });
  speakAILine(nextQ, () => enableCallMic());
}

async function askAIAndSpeak(userMessage, isSystemKickoff) {
  if (callBusy) return;
  callBusy = true;
  setCallPhase("thinking", "AI sedang berpikir...");
  setCallLive("");
  clearCallQuick();
  // temporary thinking bubble
  const box = document.getElementById("call-transcript");
  let thinkEl = null;
  if (box) {
    thinkEl = document.createElement("div");
    thinkEl.className = "call-bubble ai thinking";
    thinkEl.id = "call-thinking-bubble";
    thinkEl.innerHTML = `<div class="who">AI</div><span class="ai-loading"><span></span><span></span><span></span></span> thinking…`;
    box.appendChild(thinkEl);
    box.scrollTop = box.scrollHeight;
  }
  try {
    const hist = (callState.history || []).map((h) => ({
      role: h.role === "user" ? "user" : "model",
      text: h.text
    }));
    // nudge model to be conversational
    const msg = isSystemKickoff
      ? userMessage
      : userMessage + "\n\n(Reply in natural spoken English, 1-3 short sentences, one follow-up question. No lists.)";
    const reply = await callGeminiSpeaking(msg, isSystemKickoff ? [] : hist, "speaking");
    if (thinkEl) thinkEl.remove();
    callState.history.push({ role: "model", text: reply });
    if (callState.history.length > 20) callState.history = callState.history.slice(-20);
    speakAILine(reply, () => enableCallMic());
  } catch (e) {
    if (thinkEl) thinkEl.remove();
    const msg = e.message || "error";
    appendCallBubble("ai", "(AI error) " + msg);
    setCallPhase("idle", "Error — coba lagi / cek GEMINI_API_KEY");
    showToast(msg, "error");
    enableCallMic();
  } finally {
    callBusy = false;
  }
}

async function finishAICall() {
  stopSpeech();
  stopCallRec();
  if (callTimerInt) clearInterval(callTimerInt);
  document.getElementById("call-screen").classList.add("hidden");
  document.getElementById("call-result").classList.remove("hidden");

  const text = (callState && callState.allText) || "";
  const turns = (callState && callState.userTurns) || [];

  // Local objective estimate (not official IELTS)
  const obj = objectiveSpeakingScore(text || "hi", ["study", "work", "like", "because", "think"]);
  let band = obj.band;
  let detailHtml = "";

  // Try Gemini evaluation for richer feedback
  try {
    document.getElementById("call-feedback-detail").innerHTML = "<p>Menyusun feedback...</p>";
    const transcript = turns.map((t, i) => "Student " + (i + 1) + ": " + t).join("\n");
    const evalReply = await callGeminiSpeaking(
      "Transcript of practice speaking:\n" + transcript + "\n\nProvide evaluation as instructed.",
      [],
      "speaking_eval"
    );
    detailHtml = sanitizeAIHtml(evalReply);
  } catch (e) {
    detailHtml =
      `<p><strong>Evaluasi lokal (tanpa Gemini):</strong></p>
      <ul>
        <li>Panjang total ~${text.split(/\s+/).filter(Boolean).length} kata</li>
        <li>Jumlah giliran: ${turns.length}</li>
        <li>${escapeHtml(obj.feedback || "")}</li>
        <li><em>Pengucapan tidak diukur secara akustik — hanya transkrip speech recognition.</em></li>
        <li>Ini <strong>bukan</strong> skor IELTS resmi.</li>
      </ul>
      <p style="color:var(--text-muted);">Detail AI gagal: ${escapeHtml(e.message || "")}</p>`;
  }

  document.getElementById("call-final-band").textContent = band.toFixed(1);
  document.getElementById("call-feedback-detail").innerHTML =
    `<p style="margin-bottom:10px;font-size:0.9rem;color:var(--text-muted);">Perkiraan band latihan (tidak resmi). TTS = browser; konten AI = Gemini.</p>` +
    detailHtml;

  // Mock test speaking hook
  if (typeof currentMock !== "undefined" && currentMock && currentMock.type) {
    currentMock.scores = currentMock.scores || {};
    currentMock.scores.speaking = band;
  }

  if (callState && callState.userTurns.length) {
    state.xp = (state.xp || 0) + 25;
    saveState();
    updateUI();
  }
  callState = null;
  showToast("Sesi speaking selesai", "success");
}

function endAICall() {
  if (!callState) {
    backToCallLobby();
    return;
  }
  if (callState.kind === "free" && callState.userTurns.length === 0) {
    backToCallLobby();
    return;
  }
  if (confirm("Akhiri sesi dan lihat feedback?")) {
    finishAICall();
  }
}

function backToCallLobby() {
  stopSpeech();
  stopCallRec();
  if (callTimerInt) clearInterval(callTimerInt);
  callState = null;
  callBusy = false;
  document.getElementById("call-screen").classList.add("hidden");
  document.getElementById("call-result").classList.add("hidden");
  document.getElementById("call-lobby").classList.remove("hidden");
}


