# LinguaPro

Platform belajar English CEFR A1–C2 + AI Tutor (Gemini) + Mock IELTS/TOEFL.

## Deploy Netlify Drop

1. Extract ZIP. Upload **semua file/folder**:
   - `index.html`, `css/`, `js/`, `netlify.toml`, `netlify/functions/`
2. Environment variables:
   - `GEMINI_API_KEY` = key dari https://aistudio.google.com/apikey
   - optional `GEMINI_MODEL` = `gemini-3.8-flash`
3. Redeploy setelah set env.

## Fitur utama

- Jalur CEFR A1–C2, unit berprasyarat, evaluasi adaptif (≥80%)
- My Mistakes Notebook, Writing Lab, Goal tracks
- AI Tutor via Netlify Function (key server-side)
- AI Call speaking, Mock tests, Vocab bank, Goals, XP/streak

## Uji (lokal / setelah deploy)

Lihat laporan pengujian di pesan rilis.
